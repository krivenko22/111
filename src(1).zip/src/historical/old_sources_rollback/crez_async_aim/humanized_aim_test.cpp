#include "source/Unity/humanized_aim.h"
#include <cassert>
#include <cmath>
#include <cstdio>
int main(){
 using namespace HumanizedAim;State s{};
 auto m=Step(100,0,.035f,10,120,1.f/60,s);assert(m.x>=0&&m.x<=4&&m.y==0&&s.vx>0);
 float first=s.vx;for(int i=0;i<20;i++){m=Step(100,0,.035f,10,120,1.f/60,s);assert(m.x>=0&&m.x<=4&&m.y==0);}assert(s.vx>first);
 m=Step(-100,0,.035f,10,120,1.f/60,s);assert(m.x<=0&&s.vx<0);
 m=Step(1,0,.035f,10,120,1.f/60,s);assert(m.x==0&&s.vx==0&&s.rx==0);
 m=Step(NAN,0,.035f,10,120,.016f,s);assert(m.x==0&&s.vx==0);
 State wave{};float low=1e9f,high=0.f;for(int i=0;i<180;i++){
  Step(40,0,.035f,10,120,1.f/120,wave);if(i>60){low=(std::min)(low,wave.vx);high=(std::max)(high,wave.vx);}}
 assert(high>low*1.02f && high<low*1.30f);
 State tiny{};for(int i=0;i<1000;i++){auto step=Step(2.1f,0,.005f,50.f,400.f,1.f/144,tiny);assert(step.x>=0);}
 State a{},b{};int fast=0,slow=0;for(int i=0;i<144;i++)fast+=Step(40,0,.035f,10,120,1.f/144,a).x;for(int i=0;i<60;i++)slow+=Step(40,0,.035f,10,120,1.f/60,b).x;
 assert(fast>0&&std::abs(fast-slow)<=4);
 // Simulated horizontal strafe: target advances at 400 px/s, with the
 // simplified 1 input count = 1 px model, and responsiveness at smooth=1.
 State chase{};float cursor=0;for(int i=0;i<240;i++){
  float target=(i+1)*400.f/240.f;
  cursor+=Step(target-cursor,0,.035f,1,120,1.f/240,chase).x;
 }
 assert(400.f-cursor<35.f);
 State at60{},at240{},at1000{};int x60=0,x240=0,x1000=0;
 for(int i=0;i<60;i++)x60+=Step(40,0,.035f,1,120,1.f/60,at60).x;
 for(int i=0;i<240;i++)x240+=Step(40,0,.035f,1,120,1.f/240,at240).x;
 for(int i=0;i<1000;i++)x1000+=Step(40,0,.035f,1,120,1.f/1000,at1000).x;
 assert(std::abs(x60-x240)<30&&std::abs(x240-x1000)<12);
 State limit{};for(int i=0;i<100;i++){auto v=Step(500,0,.15f,1,400,1.f/60,limit);assert(v.x>=0&&v.x<=32);}
 State pitchOnly{},yawPitch{};float vPitch=0,vCombined=0;for(int i=0;i<60;i++){
  Step(0,30,.035f,10,120,1.f/60,pitchOnly);Step(100,30,.035f,10,120,1.f/60,yawPitch);vPitch+=pitchOnly.vy;vCombined+=yawPitch.vy;}
 assert(vPitch>0&&vCombined>0&&vCombined<vPitch*.6f);
 m=Step(40,0,.035f,10,120,.2f,s);assert(m.x==0&&s.vx==0&&s.phase==0);
 puts("PASS motion: strafe simulation, uncapped frame rates, bounds, pitch, direction, reset");
}
