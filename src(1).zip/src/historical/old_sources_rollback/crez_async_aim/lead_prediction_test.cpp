#include "source/Unity/lead_prediction.h"
#include <cassert>
#include <cmath>
#include <cstdio>
int main(){Vector3 o{0,0,0},p{0,0,100},v{10,0,0},out{};
 assert(LeadPrediction::Calculate(o,p,v,100,1,0,out));assert(out.x>10&&out.x<10.1f&&out.y==0&&out.z==100);
 assert(LeadPrediction::Calculate(o,p,v,100,.5,0,out));assert(out.x>5&&out.x<5.1f);
 assert(LeadPrediction::Calculate(o,p,{0,0,0},100,1,9.81f,out));assert(std::abs(out.y-4.905f)<.001f);
 assert(!LeadPrediction::Calculate(o,p,{100,0,0},100,1,0,out));assert(out.x==p.x&&out.y==p.y);
 assert(!LeadPrediction::Calculate(o,p,{NAN,0,0},100,1,0,out));
 assert(!LeadPrediction::Calculate(o,{0,0,1000},v,100,1,0,out));
 puts("PASS lead: intercept, scaling, optional gravity, bounds, NaN and fallback");}
