#pragma once

#include "Feature.h"
#include "RenderFeature.h"
#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"
#include "Driver/Driver.h"
#include "Offsets.h"
#include "base_networkable.h"
#include "localplayer.h"
#include "flags.h"

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <string>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

class RadarModule : public Module
{
public:
    float size = 220.f;
    float range = 150.f;
    float posX = 100.f;
    float posY = 100.f;

    float playerColor[4] = { 1.f, 1.f, 1.f, 1.f };
    float teammateColor[4] = { 0.f, 1.f, 0.f, 1.f };
    float sleeperColor[4] = { .6745f, .9294f, 1.f, 1.f };
    float npcColor[4] = { 1.f, .45f, .35f, 1.f };

    bool ignoreSleepers = true;
    bool ignoreNpc = true;

    bool drawCardinals = true;
    bool drawGrid = true;

    inline static RadarModule* s_instance = nullptr;

    RadarModule()
        : Module(_xorstr("Radar"), ModuleCategory::Visuals, false),
        networkable(BaseNetworkable::Get())
    {
        keybind.key = 0;
        keybind.mode = KeyBindMode::Toggle;

        s_instance = this;
    }

    ~RadarModule() override
    {
        if (s_instance == this)
            s_instance = nullptr;
    }

    static RadarModule* Get()
    {
        return s_instance;
    }

    void OnRenderMenu() override
    {
        static const std::string radarMenu_0 = "Radar";
        static const std::string radarMenu_1 = "Включить Radar";
        static const std::string radarMenu_2 = "Размер";
        static const std::string radarMenu_3 = "Размер радара";
        static const std::string radarMenu_4 = "%.0f px";
        static const std::string radarMenu_5 = "Дистанция";
        static const std::string radarMenu_6 = "Радиус обзора";
        static const std::string radarMenu_7 = "%.0f м";
        static const std::string radarMenu_8 = "Фильтры";
        static const std::string radarMenu_9 = "Игнорировать спящих";
        static const std::string radarMenu_10 = "Игнорировать NPC";
        static const std::string radarMenu_11 = "Цвета";
        static const std::string radarMenu_12 = "Обычный игрок";
        static const std::string radarMenu_13 = "Союзник";
        static const std::string radarMenu_14 = "Спящий";
        static const std::string radarMenu_15 = "NPC";
        static const std::string radarMenu_16 = "Вид";
        static const std::string radarMenu_17 = "Показывать стороны света";
        static const std::string radarMenu_18 = "Показывать сетку";

        RenderFeature::SectionTitle(
            radarMenu_0.c_str()
        );

        RenderFeature::GradientSeparator();

        RenderFeature::Toggle(
            this,
            radarMenu_1.c_str(),
            &enabled,
            0
        );

        ImGui::Spacing();

        RenderFeature::Text(
            radarMenu_2.c_str()
        );

        RenderFeature::SliderFloat(
            this,
            radarMenu_3.c_str(),
            &size,
            120.f,
            400.f,
            radarMenu_4.c_str()
        );

        ImGui::Spacing();

        RenderFeature::Text(
            radarMenu_5.c_str()
        );

        RenderFeature::SliderFloat(
            this,
            radarMenu_6.c_str(),
            &range,
            30.f,
            500.f,
            radarMenu_7.c_str()
        );

        ImGui::Spacing();

        RenderFeature::SectionTitle(
            radarMenu_8.c_str()
        );

        RenderFeature::GradientSeparator();

        RenderFeature::Toggle(
            this,
            radarMenu_9.c_str(),
            &ignoreSleepers,
            0
        );

        RenderFeature::Toggle(
            this,
            radarMenu_10.c_str(),
            &ignoreNpc,
            0
        );

        ImGui::Spacing();

        RenderFeature::SectionTitle(
            radarMenu_11.c_str()
        );

        RenderFeature::GradientSeparator();

        RenderFeature::ColorEdit4(
            this,
            radarMenu_12.c_str(),
            playerColor
        );

        RenderFeature::ColorEdit4(
            this,
            radarMenu_13.c_str(),
            teammateColor
        );

        RenderFeature::ColorEdit4(
            this,
            radarMenu_14.c_str(),
            sleeperColor
        );

        RenderFeature::ColorEdit4(
            this,
            radarMenu_15.c_str(),
            npcColor
        );

        ImGui::Spacing();

        RenderFeature::SectionTitle(
            radarMenu_16.c_str()
        );

        RenderFeature::GradientSeparator();

        RenderFeature::Toggle(
            this,
            radarMenu_17.c_str(),
            &drawCardinals,
            0
        );

        RenderFeature::Toggle(
            this,
            radarMenu_18.c_str(),
            &drawGrid,
            0
        );
    }

    void OnRenderOverlay() override
    {
    }

    void DrawInterface(
        ImDrawList* dl,
        const ImRect& rect,
        float alpha,
        bool preview
    )
    {
        if (!dl || !enabled)
            return;

        alpha = ImClamp(
            alpha,
            0.f,
            1.f
        );

        if (alpha <= 0.001f)
            return;

        const RenderSnapshot snapshot =
            networkable.GetSnapshot();

        if (snapshot.players.empty())
            return;

        DrawRadarInterface(
            dl,
            rect,
            snapshot,
            alpha,
            preview
        );
    }

private:
    BaseNetworkable& networkable;

    static void DrawLocalArrow(
        ImDrawList* dl,
        const ImVec2& center,
        float alpha = 1.f
    )
    {
        if (!dl)
            return;

        const ImU32 fill = IM_COL32(
            60,
            220,
            60,
            static_cast<int>(
                255.f * alpha
            )
        );

        const ImU32 border = IM_COL32(
            190,
            255,
            190,
            static_cast<int>(
                210.f * alpha
            )
        );

        const ImVec2 tip = {
            center.x,
            center.y - 10.0f
        };

        const ImVec2 left = {
            center.x - 5.5f,
            center.y + 5.0f
        };

        const ImVec2 right = {
            center.x + 5.5f,
            center.y + 5.0f
        };

        const ImVec2 base = {
            center.x,
            center.y + 2.5f
        };

        dl->AddQuadFilled(
            tip,
            left,
            base,
            right,
            fill
        );

        dl->AddQuad(
            tip,
            left,
            base,
            right,
            border,
            1.0f
        );
    }

    void DrawRadarInterface(
        ImDrawList* dl,
        const ImRect& rect,
        const RenderSnapshot& snapshot,
        float alpha,
        bool preview
    )
    {
        if (!dl)
            return;

        alpha = ImClamp(
            alpha,
            0.f,
            1.f
        );

        const float width =
            ImMax(
                40.f,
                rect.GetWidth()
            );

        const float totalHeight =
            ImMax(
                58.f,
                rect.GetHeight()
            );

        const float radarSize =
            ImMax(
                40.f,
                ImMin(
                    width,
                    totalHeight - 18.f
                )
            );

        const float radius =
            radarSize * 0.5f;

        const ImVec2 center{
            rect.Min.x + width * 0.5f,
            rect.Min.y + radius + 2.f
        };

        const ImU32 background = IM_COL32(
            7,
            8,
            13,
            static_cast<int>(
                235.f * alpha
            )
        );

        const ImU32 outline = IM_COL32(
            90,
            92,
            130,
            static_cast<int>(
                200.f * alpha
            )
        );

        dl->AddCircleFilled(
            center,
            radius,
            background,
            128
        );

        dl->AddCircle(
            center,
            radius,
            outline,
            128,
            1.8f
        );

        if (drawGrid)
        {
            const ImU32 grid = IM_COL32(
                50,
                52,
                72,
                static_cast<int>(
                    50.f * alpha
                )
            );

            const ImU32 gridAxis = IM_COL32(
                50,
                52,
                72,
                static_cast<int>(
                    40.f * alpha
                )
            );

            dl->AddCircle(
                center,
                radius * 0.33f,
                grid,
                64,
                1.f
            );

            dl->AddCircle(
                center,
                radius * 0.66f,
                grid,
                64,
                1.f
            );

            dl->AddLine(
                {
                    center.x - radius,
                    center.y
                },
                {
                    center.x + radius,
                    center.y
                },
                gridAxis,
                1.f
            );

            dl->AddLine(
                {
                    center.x,
                    center.y - radius
                },
                {
                    center.x,
                    center.y + radius
                },
                gridAxis,
                1.f
            );
        }

        const uintptr_t localId =
            LocalPlayerUtils::GetLocalPlayerId(
                snapshot.players
            );

        if (!localId)
        {
            DrawLocalArrow(
                dl,
                center,
                alpha
            );

            return;
        }

        Vector3 localPos{};

        for (const auto& p : snapshot.players)
        {
            if (p.entityId != localId)
                continue;

            localPos = p.position;
            break;
        }

        float localYaw = 0.f;

        const uintptr_t input =
            kernelHandler.readmem<uintptr_t>(
                localId +
                offsets::base_player::player_input
            );

        if (Decryption::is_valid_ptr(input))
        {
            const Vector3 angles =
                kernelHandler.readmem<Vector3>(
                    input +
                    offsets::player_input::bodyAngles
                );

            localYaw = angles.y;
        }

        const float yawRad =
            localYaw *
            static_cast<float>(
                M_PI / 180.0
            );

        const float safeRange =
            ImMax(
                0.001f,
                range
            );

        const float scale =
            (radius - 8.f) /
            safeRange;

        if (drawCardinals)
        {
            static constexpr const char* cardinals[] = {
                "N",
                "E",
                "S",
                "W"
            };

            const float cdx[] = {
                0.f,
                1.f,
                0.f,
                -1.f
            };

            const float cdz[] = {
                1.f,
                0.f,
                -1.f,
                0.f
            };

            for (int i = 0; i < 4; ++i)
            {
                const float rx =
                    cdx[i] * std::cos(yawRad) -
                    cdz[i] * std::sin(yawRad);

                const float rz =
                    cdx[i] * std::sin(yawRad) +
                    cdz[i] * std::cos(yawRad);

                const ImVec2 ts =
                    ImGui::CalcTextSize(
                        cardinals[i]
                    );

                const float lx =
                    center.x +
                    rx * (radius - 10.f) -
                    ts.x * 0.5f;

                const float ly =
                    center.y -
                    rz * (radius - 10.f) -
                    ts.y * 0.5f;

                dl->AddText(
                    {
                        lx,
                        ly
                    },
                    IM_COL32(
                        120,
                        122,
                        160,
                        static_cast<int>(
                            180.f * alpha
                        )
                    ),
                    cardinals[i]
                );
            }
        }

        for (const auto& p : snapshot.players)
        {
            if (
                p.entityId == localId ||
                !p.entityId
            )
            {
                continue;
            }

            if (!p.isAlive)
                continue;

            if (
                ignoreSleepers &&
                p.isSleeping
            )
            {
                continue;
            }

            if (
                ignoreNpc &&
                p.isNpc
            )
            {
                continue;
            }

            const float dx =
                p.position.x -
                localPos.x;

            const float dz =
                p.position.z -
                localPos.z;

            const float dist =
                std::sqrt(
                    dx * dx +
                    dz * dz
                );

            if (dist > safeRange)
                continue;

            const float rx =
                dx * std::cos(yawRad) -
                dz * std::sin(yawRad);

            const float rz =
                dx * std::sin(yawRad) +
                dz * std::cos(yawRad);

            float bx =
                center.x +
                rx * scale;

            float by =
                center.y -
                rz * scale;

            const float offsetX =
                bx -
                center.x;

            const float offsetY =
                by -
                center.y;

            const float fromCenter =
                std::sqrt(
                    offsetX * offsetX +
                    offsetY * offsetY
                );

            if (fromCenter > radius - 6.f)
            {
                const float angle =
                    std::atan2(
                        offsetY,
                        offsetX
                    );

                bx =
                    center.x +
                    std::cos(angle) *
                    (radius - 6.f);

                by =
                    center.y +
                    std::sin(angle) *
                    (radius - 6.f);
            }

            const float distanceAlpha =
                1.f -
                (dist / safeRange) *
                0.3f;

            const bool isTeammate =
                PlayerFlagsUtils::IsTeammate(
                    p.entityId,
                    localId
                );

            const float* selectedColor =
                playerColor;

            if (p.isNpc)
            {
                selectedColor =
                    npcColor;
            }
            else if (p.isSleeping)
            {
                selectedColor =
                    sleeperColor;
            }
            else if (isTeammate)
            {
                selectedColor =
                    teammateColor;
            }

            const int pointAlpha =
                static_cast<int>(
                    255.f *
                    distanceAlpha *
                    alpha
                );

            const int borderAlpha =
                static_cast<int>(
                    190.f *
                    distanceAlpha *
                    alpha
                );

            const ImU32 fillColor =
                IM_COL32(
                    static_cast<int>(
                        ImClamp(
                            selectedColor[0],
                            0.f,
                            1.f
                        ) * 255.f
                    ),
                    static_cast<int>(
                        ImClamp(
                            selectedColor[1],
                            0.f,
                            1.f
                        ) * 255.f
                    ),
                    static_cast<int>(
                        ImClamp(
                            selectedColor[2],
                            0.f,
                            1.f
                        ) * 255.f
                    ),
                    pointAlpha
                );

            const ImU32 borderColor =
                IM_COL32(
                    static_cast<int>(
                        ImClamp(
                            selectedColor[0] + 0.20f,
                            0.f,
                            1.f
                        ) * 255.f
                    ),
                    static_cast<int>(
                        ImClamp(
                            selectedColor[1] + 0.20f,
                            0.f,
                            1.f
                        ) * 255.f
                    ),
                    static_cast<int>(
                        ImClamp(
                            selectedColor[2] + 0.20f,
                            0.f,
                            1.f
                        ) * 255.f
                    ),
                    borderAlpha
                );

            dl->AddCircleFilled(
                {
                    bx,
                    by
                },
                4.f,
                fillColor,
                12
            );

            dl->AddCircle(
                {
                    bx,
                    by
                },
                4.f,
                borderColor,
                12,
                1.f
            );
        }

        DrawLocalArrow(
            dl,
            center,
            alpha
        );

        char label[32]{};

        std::snprintf(
            label,
            sizeof(label),
            "%.0fm",
            safeRange
        );

        const ImVec2 labelSize =
            ImGui::CalcTextSize(
                label
            );

        dl->AddText(
            {
                rect.Min.x +
                width * 0.5f -
                labelSize.x * 0.5f,

                rect.Max.y -
                labelSize.y
            },
            IM_COL32(
                110,
                112,
                150,
                static_cast<int>(
                    160.f * alpha
                )
            ),
            label
        );

        (void)preview;
    }
};