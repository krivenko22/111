#ifndef UNICODE
#define UNICODE
#endif

#ifndef _UNICODE
#define _UNICODE
#endif

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <windowsx.h>
#include <dwmapi.h>
#include <commctrl.h>
#include <uxtheme.h>
#include <wincodec.h>
#include <objidl.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <memory>
#include <mutex>
#include <string>
#include <sstream>
#include <thread>
#include <vector>

#include "Overlay.h"
#include "Menu.h"
#include "FeatureManager.h"
#include "ESP.h"
#include "aim.h"
#include "recoil.h"
#include "Arrows.h"
#include "Driver/Driver.h"
#include "Driver/Tools.h"
#include "FakeAdmin.h"
#include "Spider.h"
#include "AlwaysEoka.h"
#include "HeldItem.h"
#include "WorldEsp.h"
#include "ItemEsp.h"
#include "InventoryEsp.h"
#include "Radar.h"
#include "Automatic.h"

#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "uxtheme.lib")
#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "msimg32.lib")

#ifndef ELYSIUM_RUST_ICON_DATA
#define ELYSIUM_RUST_ICON_DATA rust_icon
#endif

#ifndef ELYSIUM_RUST_ICON_SIZE
#define ELYSIUM_RUST_ICON_SIZE sizeof(rust_icon)
#endif

ID3D11Device* gD3DDevice = nullptr;
InventoryManager gInventoryManager;

extern kernelmode_proc_handler kernelHandler;
uintptr_t g_currentAimTarget = 0;

namespace LoaderTheme
{
    constexpr COLORREF Background = RGB(4, 3, 5);
    constexpr COLORREF Surface = RGB(6, 5, 8);

    constexpr COLORREF Card = RGB(10, 9, 12);
    constexpr COLORREF CardHover = RGB(17, 14, 20);

    constexpr COLORREF Separator = RGB(31, 26, 34);

    constexpr COLORREF Accent = RGB(186, 18, 61);
    constexpr COLORREF AccentSoft = RGB(118, 13, 42);
    constexpr COLORREF AccentLight = RGB(220, 59, 100);

    constexpr COLORREF Text = RGB(237, 235, 241);
    constexpr COLORREF TextMuted = RGB(125, 120, 133);
    constexpr COLORREF TextDim = RGB(79, 73, 88);

    constexpr COLORREF Success = RGB(139, 182, 153);
    constexpr COLORREF Error = RGB(178, 104, 128);

    constexpr COLORREF Selection = RGB(144, 18, 48);
    constexpr COLORREF SelectionText = RGB(255, 255, 255);
}

namespace obf {
    volatile std::uint64_t __obf_global_state = 0x123456789ABCDEF0ULL;
    volatile std::uint64_t __obf_global_seq = 0;
}

static float Clamp01(float v)
{
    return (std::max)(0.0f, (std::min)(1.0f, v));
}

static float EaseOutCubic(float t)
{
    t = Clamp01(t);
    const float k = 1.0f - t;
    return 1.0f - k * k * k;
}

static float Lerp(float a, float b, float t)
{
    return a + (b - a) * Clamp01(t);
}

static std::wstring HexAddress(uint64_t value)
{
    std::wostringstream os;
    os << std::hex << value;
    return os.str();
}

static COLORREF LerpColor(COLORREF a, COLORREF b, float t)
{
    t = Clamp01(t);

    return RGB(
        static_cast<int>(GetRValue(a) + (GetRValue(b) - GetRValue(a)) * t),
        static_cast<int>(GetGValue(a) + (GetGValue(b) - GetGValue(a)) * t),
        static_cast<int>(GetBValue(a) + (GetBValue(b) - GetBValue(a)) * t)
    );
}

bool IsDriverDeviceAvailable(DWORD* lastError);

static HBITMAP LoadBitmapFromMemoryWIC(const unsigned char* data, size_t size)
{
    if (!data || size == 0)
        return nullptr;

    HGLOBAL memory = GlobalAlloc(GMEM_MOVEABLE, size);
    if (!memory)
        return nullptr;

    void* memPtr = GlobalLock(memory);
    if (!memPtr)
    {
        GlobalFree(memory);
        return nullptr;
    }

    std::memcpy(memPtr, data, size);
    GlobalUnlock(memory);

    IStream* stream = nullptr;
    if (FAILED(CreateStreamOnHGlobal(memory, TRUE, &stream)))
    {
        GlobalFree(memory);
        return nullptr;
    }

    IWICImagingFactory* factory = nullptr;
    IWICBitmapDecoder* decoder = nullptr;
    IWICBitmapFrameDecode* frame = nullptr;
    IWICFormatConverter* converter = nullptr;

    HBITMAP result = nullptr;

    HRESULT hr = CoCreateInstance(
        CLSID_WICImagingFactory,
        nullptr,
        CLSCTX_INPROC_SERVER,
        IID_PPV_ARGS(&factory)
    );

    if (SUCCEEDED(hr))
    {
        hr = factory->CreateDecoderFromStream(
            stream,
            nullptr,
            WICDecodeMetadataCacheOnLoad,
            &decoder
        );
    }

    if (SUCCEEDED(hr))
    {
        hr = decoder->GetFrame(0, &frame);
    }

    if (SUCCEEDED(hr))
    {
        hr = factory->CreateFormatConverter(&converter);
    }

    if (SUCCEEDED(hr))
    {
        hr = converter->Initialize(
            frame,
            GUID_WICPixelFormat32bppPBGRA,
            WICBitmapDitherTypeNone,
            nullptr,
            0.0,
            WICBitmapPaletteTypeCustom
        );
    }

    UINT width = 0;
    UINT height = 0;

    if (SUCCEEDED(hr))
    {
        hr = converter->GetSize(&width, &height);
    }

    if (SUCCEEDED(hr) && width > 0 && height > 0 && width <= 2048 && height <= 2048)
    {
        BITMAPINFO bmi{};
        bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bmi.bmiHeader.biWidth = static_cast<LONG>(width);
        bmi.bmiHeader.biHeight = -static_cast<LONG>(height);
        bmi.bmiHeader.biPlanes = 1;
        bmi.bmiHeader.biBitCount = 32;
        bmi.bmiHeader.biCompression = BI_RGB;

        void* bits = nullptr;
        HDC screen = GetDC(nullptr);

        HBITMAP bitmap = CreateDIBSection(
            screen,
            &bmi,
            DIB_RGB_COLORS,
            &bits,
            nullptr,
            0
        );

        ReleaseDC(nullptr, screen);

        if (bitmap && bits)
        {
            const UINT stride = width * 4;
            const UINT imageSize = stride * height;

            if (SUCCEEDED(converter->CopyPixels(
                nullptr,
                stride,
                imageSize,
                reinterpret_cast<BYTE*>(bits)
            )))
            {
                result = bitmap;
            }
            else
            {
                DeleteObject(bitmap);
            }
        }
    }

    if (converter) converter->Release();
    if (frame) frame->Release();
    if (decoder) decoder->Release();
    if (factory) factory->Release();
    stream->Release();

    return result;
}

class LoaderUI
{
public:

    enum class Screen
    {
        Login,
        Launcher
    };

    enum class State
    {
        Idle,
        Working,
        Success,
        Error
    };

    struct LogEntry
    {
        std::wstring text;
        COLORREF color{};
    };

    static constexpr int IDC_TELEGRAM = 1001;
    static constexpr int IDC_PASSWORD = 1002;

    static constexpr float LOG_VIEW_HEIGHT = 98.0f;
    static constexpr float LOG_LINE_HEIGHT = 16.0f;

    ~LoaderUI()
    {
        Destroy();
    }

    bool Create()
    {
        if (m_hwnd)
            return true;

        WNDCLASSEXW wc{};
        wc.cbSize = sizeof(wc);
        wc.lpfnWndProc = &LoaderUI::WndProc;
        wc.hInstance = GetModuleHandleW(nullptr);
        wc.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hbrBackground = nullptr;
        wc.lpszClassName = _xorstrw(L"ElysiumLoaderWindow");
        wc.style = CS_HREDRAW | CS_VREDRAW;

        if (!RegisterClassExW(&wc))
        {
            if (GetLastError() != ERROR_CLASS_ALREADY_EXISTS)
                return false;
        }

        constexpr int width = 620;
        constexpr int height = 390;

        m_width = width;
        m_height = height;

        const int screenW = GetSystemMetrics(SM_CXSCREEN);
        const int screenH = GetSystemMetrics(SM_CYSCREEN);

        const int x = (screenW - width) / 2;
        const int y = (screenH - height) / 2;

        m_hwnd = CreateWindowExW(
            WS_EX_APPWINDOW | WS_EX_LAYERED,
            wc.lpszClassName,
            _xorstrw(L"Crez External"),
            WS_POPUP,
            x,
            y,
            width,
            height,
            nullptr,
            nullptr,
            wc.hInstance,
            this
        );

        if (!m_hwnd)
            return false;

        const DWM_WINDOW_CORNER_PREFERENCE corner = DWMWCP_ROUND;
        DwmSetWindowAttribute(
            m_hwnd,
            DWMWA_WINDOW_CORNER_PREFERENCE,
            &corner,
            sizeof(corner)
        );

        CreateFonts();
        LoadRustIcon();
        SetLayeredWindowAttributes(m_hwnd, 0, 0, LWA_ALPHA);
        SetTimer(m_hwnd, 1, 16, nullptr);
        // Source login was only a screen transition; never request credentials.
        SwitchToLauncher();

        return true;
    }

    void Show()
    {
        if (!m_hwnd)
            return;

        m_visible = true;
        m_fade = 0.0f;

        ShowWindow(m_hwnd, SW_SHOW);
        SetForegroundWindow(m_hwnd);

        if (m_telegramEdit)
            SetFocus(m_telegramEdit);

        UpdateWindow(m_hwnd);
    }

    void Destroy()
    {
        m_quitRequested = true;

        RestoreEditSubclass(m_telegramEdit, m_originalTelegramProc);
        RestoreEditSubclass(m_passwordEdit, m_originalPasswordProc);

        if (m_worker.joinable())
            m_worker.join();

        if (m_hwnd)
        {
            KillTimer(m_hwnd, 1);
            DestroyWindow(m_hwnd);
            m_hwnd = nullptr;
        }

        if (m_rustBitmap)
        {
            DeleteObject(m_rustBitmap);
            m_rustBitmap = nullptr;
        }

        DestroyFonts();

        if (m_editBrush)
        {
            DeleteObject(m_editBrush);
            m_editBrush = nullptr;
        }

        if (m_backDC)
        {
            if (m_backOldBitmap)
                SelectObject(m_backDC, m_backOldBitmap);
            if (m_backBitmap)
                DeleteObject(m_backBitmap);
            DeleteDC(m_backDC);
            m_backDC = nullptr;
            m_backBitmap = nullptr;
            m_backOldBitmap = nullptr;
            m_backWidth = 0;
            m_backHeight = 0;
        }

        if (m_logBackDC)
        {
            if (m_logBackOldBitmap)
                SelectObject(m_logBackDC, m_logBackOldBitmap);
            if (m_logBackBitmap)
                DeleteObject(m_logBackBitmap);
            DeleteDC(m_logBackDC);
            m_logBackDC = nullptr;
            m_logBackBitmap = nullptr;
            m_logBackOldBitmap = nullptr;
            m_logBackWidth = 0;
            m_logBackHeight = 0;
        }

        if (m_statusBackDC)
        {
            if (m_statusBackOldBitmap)
                SelectObject(m_statusBackDC, m_statusBackOldBitmap);
            if (m_statusBackBitmap)
                DeleteObject(m_statusBackBitmap);
            DeleteDC(m_statusBackDC);
            m_statusBackDC = nullptr;
            m_statusBackBitmap = nullptr;
            m_statusBackOldBitmap = nullptr;
            m_statusBackWidth = 0;
            m_statusBackHeight = 0;
        }

        m_telegramEdit = nullptr;
        m_passwordEdit = nullptr;
    }

    void RunLoop()
    {
        MSG msg{};

        while (!m_quitRequested)
        {
            while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE))
            {
                if (msg.message == WM_QUIT)
                {
                    m_quitRequested = true;
                    break;
                }

                TranslateMessage(&msg);
                DispatchMessageW(&msg);
            }

            if (m_launchRequested.exchange(false, std::memory_order_acq_rel))
            {
                if (m_worker.joinable() && !m_workerActive.load(std::memory_order_acquire))
                    m_worker.join();
                if (!m_worker.joinable())
                {
                    m_workerActive.store(true, std::memory_order_release);
                    m_worker = std::thread(&LoaderUI::RunInitialization, this);
                }
            }

            Sleep(1);
        }
    }

    void AddLog(
        const std::wstring& text,
        COLORREF color = LoaderTheme::TextMuted
    )
    {
        {
            std::lock_guard<std::mutex> lock(m_logMutex);

            m_logs.push_back({ text, color });

            if (m_logs.size() > 32)
                m_logs.erase(m_logs.begin());

            m_logCount.store(
                static_cast<int>(m_logs.size()),
                std::memory_order_release
            );
        }

        m_logWakeDirty.store(true, std::memory_order_release);

        if (m_logFollowTail.load(std::memory_order_acquire))
        {
            m_logScrollTarget.store(
                CalculateMaxLogScrollFast(),
                std::memory_order_release
            );
        }

        Wake();
    }

    void SetStatus(
        const std::wstring& title,
        const std::wstring& detail,
        float progress,
        bool indeterminate = false
    )
    {
        {
            std::lock_guard<std::mutex> lock(m_stateMutex);

            m_state = State::Working;
            m_title = title;
            m_detail = detail;
            m_progress = Clamp01(progress);
            m_indeterminate = indeterminate;
        }

        m_statusWakeDirty.store(true, std::memory_order_release);
        Wake();
    }

    void SetSuccess(const std::wstring& detail)
    {
        {
            std::lock_guard<std::mutex> lock(m_stateMutex);

            m_state = State::Success;
            m_title = L"\u0413\u043E\u0442\u043E\u0432\u043E";
            m_detail = detail;
            m_progress = 1.0f;
            m_indeterminate = false;
        }

        m_statusWakeDirty.store(true, std::memory_order_release);
        Wake();
    }

    void SetError(const std::wstring& detail)
    {
        {
            std::lock_guard<std::mutex> lock(m_stateMutex);

            m_state = State::Error;
            m_title = L"\u041E\u0448\u0438\u0431\u043A\u0430";
            m_detail = detail;
            m_progress = 0.0f;
            m_indeterminate = false;
        }

        m_statusWakeDirty.store(true, std::memory_order_release);
        Wake();
    }

private:

    static constexpr UINT WM_UI_WAKE = WM_APP + 10;
    static constexpr LPCWSTR PROP_SELF = L"Elysium.LoaderUI";
    static constexpr LPCWSTR PROP_KIND = L"Elysium.EditKind";

    static void GetEditSelection(HWND hwnd, DWORD& start, DWORD& end)
    {
        start = end = 0;
        if (!hwnd)
            return;

        SendMessageW(hwnd, EM_GETSEL,
            reinterpret_cast<WPARAM>(&start),
            reinterpret_cast<LPARAM>(&end));
    }

    static bool EditSelectionChanged(HWND hwnd, DWORD beforeStart, DWORD beforeEnd)
    {
        DWORD start = 0;
        DWORD end = 0;
        GetEditSelection(hwnd, start, end);
        return start != beforeStart || end != beforeEnd;
    }

    static LRESULT CALLBACK EditWndProc(
        HWND hwnd,
        UINT msg,
        WPARAM wParam,
        LPARAM lParam
    )
    {
        auto* self = reinterpret_cast<LoaderUI*>(GetPropW(hwnd, PROP_SELF));
        const int kind = static_cast<int>(reinterpret_cast<INT_PTR>(GetPropW(hwnd, PROP_KIND)));

        WNDPROC original = nullptr;
        if (self)
        {
            if (kind == 1)
                original = self->m_originalTelegramProc;
            else if (kind == 2)
                original = self->m_originalPasswordProc;
        }

        if (!original)
            return DefWindowProcW(hwnd, msg, wParam, lParam);

        if (msg == WM_PAINT)
        {
            if (self)
            {
                self->PaintEditContents(hwnd, kind);
                return 0;
            }
        }

        if (msg == WM_ERASEBKGND)
            return 1;

        // Never let the native EDIT paint its own selection/client area.
        // This also covers code paths that use WM_PRINTCLIENT/WM_PRINT internally.
        if (msg == WM_PRINTCLIENT || msg == WM_PRINT || msg == WM_NCPAINT)
            return 0;

        if (msg == WM_SETFOCUS)
        {
            const LRESULT r = CallWindowProcW(original, hwnd, msg, wParam, lParam);
            HideCaret(hwnd);
            InvalidateRect(hwnd, nullptr, FALSE);
            return r;
        }

        if (msg == WM_KILLFOCUS)
        {
            const LRESULT r = CallWindowProcW(original, hwnd, msg, wParam, lParam);
            InvalidateRect(hwnd, nullptr, FALSE);
            return r;
        }

        const bool selectionSensitive =
            msg == WM_KEYDOWN ||
            msg == WM_CHAR ||
            msg == WM_DEADCHAR ||
            msg == WM_SYSKEYDOWN ||
            msg == WM_SYSCHAR ||
            msg == WM_PASTE ||
            msg == WM_CUT ||
            msg == WM_CLEAR ||
            msg == WM_UNDO ||
            msg == WM_LBUTTONDOWN ||
            msg == WM_LBUTTONUP ||
            (msg == WM_MOUSEMOVE && GetCapture() == hwnd);

        if (selectionSensitive)
        {
            DWORD beforeStart = 0;
            DWORD beforeEnd = 0;
            GetEditSelection(hwnd, beforeStart, beforeEnd);

            const int beforeLength = GetWindowTextLengthW(hwnd);

            // Let the native control update its internal text/selection/caret state,
            // but suppress its immediate redraw. Without this, Windows can briefly
            // flash COLOR_HIGHLIGHT (the system selection color) before our custom
            // WM_PAINT arrives.
            SendMessageW(hwnd, WM_SETREDRAW, FALSE, 0);
            const LRESULT r = CallWindowProcW(original, hwnd, msg, wParam, lParam);
            SendMessageW(hwnd, WM_SETREDRAW, TRUE, 0);

            HideCaret(hwnd);

            const int afterLength = GetWindowTextLengthW(hwnd);
            const bool changed = beforeLength != afterLength ||
                EditSelectionChanged(hwnd, beforeStart, beforeEnd);

            if (changed)
            {
                InvalidateRect(hwnd, nullptr, FALSE);
            }

            return r;
        }

        return CallWindowProcW(original, hwnd, msg, wParam, lParam);
    }

    void InstallEditSubclass(HWND edit, int kind)
    {
        if (!edit)
            return;

        SetPropW(edit, PROP_SELF, reinterpret_cast<HANDLE>(this));
        SetPropW(edit, PROP_KIND, reinterpret_cast<HANDLE>(static_cast<INT_PTR>(kind)));

        WNDPROC oldProc = reinterpret_cast<WNDPROC>(SetWindowLongPtrW(
            edit,
            GWLP_WNDPROC,
            reinterpret_cast<LONG_PTR>(&LoaderUI::EditWndProc)
        ));

        if (kind == 1)
            m_originalTelegramProc = oldProc;
        else
            m_originalPasswordProc = oldProc;
    }

    void RestoreEditSubclass(HWND edit, WNDPROC original)
    {
        if (!edit)
            return;

        if (original)
        {
            SetWindowLongPtrW(
                edit,
                GWLP_WNDPROC,
                reinterpret_cast<LONG_PTR>(original)
            );
        }

        RemovePropW(edit, PROP_SELF);
        RemovePropW(edit, PROP_KIND);
    }

    void PaintEditContents(HWND hwnd, int kind)
    {
        PAINTSTRUCT ps{};
        HDC dc = BeginPaint(hwnd, &ps);

        RECT rc{};
        GetClientRect(hwnd, &rc);

        const bool focused = GetFocus() == hwnd;
        const float focusAnim = kind == 1 ? m_telegramFocusAnim : m_passwordFocusAnim;

        const COLORREF bg = LerpColor(
            LoaderTheme::Card,
            LoaderTheme::CardHover,
            focusAnim * 0.10f
        );

        HBRUSH background = CreateSolidBrush(bg);
        FillRect(dc, &rc, background);
        DeleteObject(background);

        HFONT oldFont = nullptr;
        if (m_fontBody)
            oldFont = static_cast<HFONT>(SelectObject(dc, m_fontBody));

        SetBkMode(dc, TRANSPARENT);
        SetTextColor(dc, LoaderTheme::Text);

        const int length = GetWindowTextLengthW(hwnd);
        std::wstring text;

        if (length > 0)
        {
            text.resize(static_cast<size_t>(length) + 1);
            GetWindowTextW(hwnd, text.data(), length + 1);
            text.resize(static_cast<size_t>(length));
        }

        std::wstring displayText = text;
        if (kind == 2 && !displayText.empty())
        {
            wchar_t passwordChar = static_cast<wchar_t>(SendMessageW(hwnd, EM_GETPASSWORDCHAR, 0, 0));
            if (!passwordChar)
                passwordChar = L'*';
            std::fill(displayText.begin(), displayText.end(), passwordChar);
        }

        DWORD selStart = 0;
        DWORD selEnd = 0;
        GetEditSelection(hwnd, selStart, selEnd);

        if (selStart > static_cast<DWORD>(displayText.size()))
            selStart = static_cast<DWORD>(displayText.size());
        if (selEnd > static_cast<DWORD>(displayText.size()))
            selEnd = static_cast<DWORD>(displayText.size());

        POINT origin{ 8, 0 };
        if (!displayText.empty())
        {
            const LRESULT p = SendMessageW(hwnd, EM_POSFROMCHAR, 0, 0);
            if (p != -1)
            {
                origin.x = GET_X_LPARAM(p);
                origin.y = GET_Y_LPARAM(p);
            }
        }
        else
        {
            TEXTMETRICW tm{};
            GetTextMetricsW(dc, &tm);
            origin.y = (rc.bottom - rc.top - tm.tmHeight) / 2;
        }

        const bool hasSelection = selStart != selEnd;
        int selLeft = 0;
        int selRight = 0;

        auto XAtChar = [&](DWORD index) -> int
            {
                if (index == 0)
                    return origin.x;

                const LRESULT p = SendMessageW(
                    hwnd,
                    EM_POSFROMCHAR,
                    static_cast<WPARAM>(index),
                    0
                );

                if (p != -1)
                    return GET_X_LPARAM(p);

                const size_t count = (std::min)(
                    static_cast<size_t>(index),
                    displayText.size()
                    );

                SIZE size{};
                if (count > 0)
                {
                    GetTextExtentPoint32W(
                        dc,
                        displayText.data(),
                        static_cast<int>(count),
                        &size
                    );
                }
                return origin.x + size.cx;
            };

        if (hasSelection)
        {
            selLeft = XAtChar((std::min)(selStart, selEnd));
            selRight = XAtChar((std::max)(selStart, selEnd));

            RECT selectionRect{
                static_cast<LONG>((std::max)(static_cast<LONG>(rc.left), static_cast<LONG>(selLeft))),
                rc.top + 2,
                static_cast<LONG>((std::min)(static_cast<LONG>(rc.right), static_cast<LONG>(selRight))),
                rc.bottom - 2
            };

            if (selectionRect.right > selectionRect.left)
            {
                HBRUSH selectionBrush = CreateSolidBrush(LoaderTheme::Selection);
                FillRect(dc, &selectionRect, selectionBrush);
                DeleteObject(selectionBrush);
            }
        }

        if (displayText.empty())
        {
            const float alpha = kind == 1
                ? m_telegramPlaceholderAlpha
                : m_passwordPlaceholderAlpha;

            if (alpha > 0.001f)
            {
                const COLORREF animatedAccent = GetAnimatedAccent(kind == 1 ? 0.10f : 0.30f);
                const COLORREF placeholderColor = LerpColor(
                    LoaderTheme::Card,
                    LerpColor(LoaderTheme::TextMuted, animatedAccent, 0.10f),
                    Clamp01(alpha)
                );

                SetTextColor(dc, placeholderColor);

                const wchar_t* placeholder = kind == 1 ? _xorstrw(L"@usermode") : _xorstrw(L"Password");
                RECT textRect = rc;
                textRect.left += 8;
                textRect.right -= 8;

                DrawTextW(
                    dc,
                    placeholder,
                    -1,
                    &textRect,
                    DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX | DT_END_ELLIPSIS
                );
            }
        }
        else if (!hasSelection)
        {
            SetTextColor(dc, LoaderTheme::Text);
            TextOutW(
                dc,
                origin.x,
                origin.y,
                displayText.c_str(),
                static_cast<int>(displayText.size())
            );
        }
        else
        {
            const size_t begin = static_cast<size_t>((std::min)(selStart, selEnd));
            const size_t end = static_cast<size_t>((std::max)(selStart, selEnd));

            if (begin > 0)
            {
                SetTextColor(dc, LoaderTheme::Text);
                TextOutW(
                    dc,
                    origin.x,
                    origin.y,
                    displayText.data(),
                    static_cast<int>(begin)
                );
            }

            SetTextColor(dc, LoaderTheme::SelectionText);
            if (end > begin)
            {
                const int selectedX = XAtChar(static_cast<DWORD>(begin));
                TextOutW(
                    dc,
                    selectedX,
                    origin.y,
                    displayText.data() + begin,
                    static_cast<int>(end - begin)
                );
            }

            if (end < displayText.size())
            {
                const int afterX = XAtChar(static_cast<DWORD>(end));
                SetTextColor(dc, LoaderTheme::Text);
                TextOutW(
                    dc,
                    afterX,
                    origin.y,
                    displayText.data() + end,
                    static_cast<int>(displayText.size() - end)
                );
            }
        }

        // Static caret: native blinking/repaint is disabled to avoid typing flicker.
        if (focused && !hasSelection)
        {
            const int caretX = XAtChar(selEnd);
            const int caretTop = rc.top + 4;
            const int caretBottom = rc.bottom - 4;

            RECT caretRect{
                caretX,
                caretTop,
                caretX + 1,
                caretBottom
            };

            HBRUSH caretBrush = CreateSolidBrush(GetAnimatedAccent(kind == 1 ? 0.05f : 0.25f));
            FillRect(dc, &caretRect, caretBrush);
            DeleteObject(caretBrush);
        }

        if (oldFont)
            SelectObject(dc, oldFont);

        EndPaint(hwnd, &ps);
    }

    static LRESULT CALLBACK WndProc(
        HWND hwnd,
        UINT msg,
        WPARAM wParam,
        LPARAM lParam
    )
    {
        auto* self = reinterpret_cast<LoaderUI*>(
            GetWindowLongPtrW(hwnd, GWLP_USERDATA)
            );

        if (msg == WM_NCCREATE)
        {
            const auto* cs = reinterpret_cast<CREATESTRUCTW*>(lParam);
            self = static_cast<LoaderUI*>(cs->lpCreateParams);

            SetWindowLongPtrW(
                hwnd,
                GWLP_USERDATA,
                reinterpret_cast<LONG_PTR>(self)
            );

            self->m_hwnd = hwnd;
        }

        if (!self)
            return DefWindowProcW(hwnd, msg, wParam, lParam);

        switch (msg)
        {
        case WM_TIMER:
        {
            if (wParam != 1)
                break;

            self->m_animTime += 0.016f;

            const float oldFade = self->m_fade;
            const float oldLoginHover = self->m_loginHover;
            const float oldActionHover = self->m_actionHover;
            const float oldTelegramFocus = self->m_telegramFocusAnim;
            const float oldPasswordFocus = self->m_passwordFocusAnim;
            const float oldTelegramPlaceholder = self->m_telegramPlaceholderAlpha;
            const float oldPasswordPlaceholder = self->m_passwordPlaceholderAlpha;
            const float oldLogScroll = self->m_logScroll;

            self->m_fade = (std::min)(1.0f, self->m_fade + 0.075f);

            self->m_loginHover += (
                (self->m_loginHovered ? 1.0f : 0.0f) - self->m_loginHover
                ) * 0.18f;

            self->m_actionHover += (
                (self->m_actionHovered ? 1.0f : 0.0f) - self->m_actionHover
                ) * 0.18f;

            const float telegramTarget =
                (!self->m_telegramEdit ||
                    GetWindowTextLengthW(self->m_telegramEdit) == 0)
                ? 1.0f : 0.0f;

            const float passwordTarget =
                (!self->m_passwordEdit ||
                    GetWindowTextLengthW(self->m_passwordEdit) == 0)
                ? 1.0f : 0.0f;

            self->m_telegramPlaceholderAlpha +=
                (telegramTarget - self->m_telegramPlaceholderAlpha) * 0.24f;

            self->m_passwordPlaceholderAlpha +=
                (passwordTarget - self->m_passwordPlaceholderAlpha) * 0.24f;

            if (std::abs(telegramTarget - self->m_telegramPlaceholderAlpha) < 0.002f)
                self->m_telegramPlaceholderAlpha = telegramTarget;

            if (std::abs(passwordTarget - self->m_passwordPlaceholderAlpha) < 0.002f)
                self->m_passwordPlaceholderAlpha = passwordTarget;

            const float telegramFocusTarget =
                GetFocus() == self->m_telegramEdit ? 1.0f : 0.0f;

            const float passwordFocusTarget =
                GetFocus() == self->m_passwordEdit ? 1.0f : 0.0f;

            self->m_telegramFocusAnim +=
                (telegramFocusTarget - self->m_telegramFocusAnim) * 0.22f;

            self->m_passwordFocusAnim +=
                (passwordFocusTarget - self->m_passwordFocusAnim) * 0.22f;

            const bool logScrollChanged = self->UpdateLogScrollAnimation();

            const bool telegramPlaceholderChanged =
                std::abs(oldTelegramPlaceholder - self->m_telegramPlaceholderAlpha) > 0.0005f;

            const bool passwordPlaceholderChanged =
                std::abs(oldPasswordPlaceholder - self->m_passwordPlaceholderAlpha) > 0.0005f;

            if (telegramPlaceholderChanged && self->m_telegramEdit)
                InvalidateRect(self->m_telegramEdit, nullptr, FALSE);

            if (passwordPlaceholderChanged && self->m_passwordEdit)
                InvalidateRect(self->m_passwordEdit, nullptr, FALSE);

            const bool workingIndeterminate = [&]()
                {
                    std::lock_guard<std::mutex> lock(self->m_stateMutex);
                    return self->m_state == State::Working && self->m_indeterminate;
                }();

            const bool parentAnimation =
                std::abs(oldFade - self->m_fade) > 0.0005f ||
                std::abs(oldLoginHover - self->m_loginHover) > 0.002f ||
                (self->m_screen == Screen::Login &&
                    (std::abs(oldTelegramFocus - self->m_telegramFocusAnim) > 0.002f ||
                        std::abs(oldPasswordFocus - self->m_passwordFocusAnim) > 0.002f));

            const bool launcherButtonAnimation =
                self->m_screen == Screen::Launcher &&
                std::abs(oldActionHover - self->m_actionHover) > 0.002f;

            (void)oldLogScroll;

            if (parentAnimation)
            {
                InvalidateRect(hwnd, nullptr, FALSE);
            }
            else
            {
                if (launcherButtonAnimation)
                    self->RenderLauncherStatusToWindow();

                if (logScrollChanged && self->m_screen == Screen::Launcher)
                    self->RenderLogViewportToWindow();

                if (self->m_screen == Screen::Launcher && workingIndeterminate)
                    self->RenderLauncherStatusToWindow();
            }

            return 0;
        }

        case WM_ERASEBKGND:
            return 1;

        case WM_MOUSEMOVE:
        {
            POINT pt{ GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
            self->m_lastMouse = pt;
            self->UpdateHover(pt);
            break;
        }

        case WM_MOUSEWHEEL:
        {
            POINT pt{ GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
            ScreenToClient(hwnd, &pt);

            if (self->m_screen == Screen::Launcher && self->HitLogViewport(pt))
            {
                const int wheelDelta = GET_WHEEL_DELTA_WPARAM(wParam);
                const float steps = static_cast<float>(wheelDelta) / 120.0f;
                self->ScrollLogs(-steps * 48.0f);
                self->RenderLogViewportToWindow();
                return 0;
            }
            break;
        }

        case WM_LBUTTONDOWN:
        {
            POINT pt{ GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };

            // Let the native edit controls receive mouse clicks/selections.
            if (ChildWindowFromPointEx(hwnd, pt, CWP_SKIPINVISIBLE) == self->m_telegramEdit ||
                ChildWindowFromPointEx(hwnd, pt, CWP_SKIPINVISIBLE) == self->m_passwordEdit)
            {
                break;
            }

            if (self->HitTopBar(pt))
            {
                ReleaseCapture();
                SendMessageW(hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
                return 0;
            }

            if (self->m_screen == Screen::Login &&
                self->HitRect(self->m_loginButtonRect, pt))
            {
                self->SwitchToLauncher();
                return 0;
            }

            if (self->m_screen == Screen::Launcher &&
                self->HitRect(self->m_actionButtonRect, pt))
            {
                const State state = self->GetState();

                if (state == State::Idle || (state == State::Error && !self->m_workerActive.load(std::memory_order_acquire)))
                {
                    self->m_launchRequested.store(true, std::memory_order_release);
                    self->SetStatus(
                        L"\u0417\u0430\u043F\u0443\u0441\u043A",
                        L"\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 Elysium...",
                        0.02f
                    );
                }
                else if (state == State::Success)
                {
                    PostMessageW(hwnd, WM_CLOSE, 0, 0);
                }
                return 0;
            }
            break;
        }

        case WM_CTLCOLOREDIT:
        {
            HDC dc = reinterpret_cast<HDC>(wParam);
            SetTextColor(dc, LoaderTheme::Text);
            SetBkMode(dc, TRANSPARENT);
            return reinterpret_cast<LRESULT>(GetStockObject(NULL_BRUSH));
        }

        case WM_COMMAND:
        {
            const int controlId = LOWORD(wParam);
            const int notification = HIWORD(wParam);

            if (notification == EN_CHANGE)
            {
                if (controlId == IDC_TELEGRAM && self->m_telegramEdit)
                    InvalidateRect(self->m_telegramEdit, nullptr, FALSE);
                else if (controlId == IDC_PASSWORD && self->m_passwordEdit)
                    InvalidateRect(self->m_passwordEdit, nullptr, FALSE);

                return 0;
            }

            break;
        }

        case WM_PAINT:
            self->Paint();
            return 0;

        case WM_KEYDOWN:
            if (wParam == VK_ESCAPE) { PostMessageW(hwnd, WM_CLOSE, 0, 0); return 0; }
            break;

        case WM_CLOSE:
        {
            self->m_quitRequested = true;
            DestroyWindow(hwnd);
            return 0;
        }

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;

        case WM_UI_WAKE:
        {
            self->m_wakePending.store(false, std::memory_order_release);

            const bool logDirty = self->m_logWakeDirty.exchange(false, std::memory_order_acq_rel);
            const bool statusDirty = self->m_statusWakeDirty.exchange(false, std::memory_order_acq_rel);

            if (self->m_screen == Screen::Launcher)
            {
                if (logDirty)
                    self->RenderLogViewportToWindow();

                if (statusDirty)
                    self->RenderLauncherStatusToWindow();
            }
            else
            {
                // Login screen is small and only receives a couple of wakeups.
                InvalidateRect(hwnd, nullptr, FALSE);
            }

            return 0;
        }
        }

        return DefWindowProcW(hwnd, msg, wParam, lParam);
    }

    State GetState() const
    {
        std::lock_guard<std::mutex> lock(m_stateMutex);
        return m_state;
    }

    void GetVisualState(
        State& state,
        std::wstring& title,
        std::wstring& detail,
        float& progress,
        bool& indeterminate
    ) const
    {
        std::lock_guard<std::mutex> lock(m_stateMutex);
        state = m_state;
        title = m_title;
        detail = m_detail;
        progress = m_progress;
        indeterminate = m_indeterminate;
    }

    void Wake()
    {
        HWND hwnd = m_hwnd;
        if (!hwnd || m_quitRequested)
            return;

        if (!m_wakePending.exchange(true, std::memory_order_acq_rel))
        {
            if (!PostMessageW(hwnd, WM_UI_WAKE, 0, 0))
                m_wakePending.store(false, std::memory_order_release);
        }
    }

    COLORREF GetAnimatedAccent(float phase = 0.0f) const
    {
        const float pulse = 0.5f + 0.5f * std::sin(m_animTime * 0.85f + phase);

        return LerpColor(
            LoaderTheme::Accent,
            LoaderTheme::AccentLight,
            0.24f + pulse * 0.28f
        );
    }

    COLORREF GetFocusColor(float focusAnim) const
    {
        return LerpColor(
            LoaderTheme::Separator,
            GetAnimatedAccent(0.18f),
            Clamp01(focusAnim)
        );
    }

    float CalculateMaxLogScrollFast() const
    {
        const int count = m_logCount.load(std::memory_order_acquire);
        const float contentHeight = static_cast<float>(count) * LOG_LINE_HEIGHT;
        return (std::max)(0.0f, contentHeight - LOG_VIEW_HEIGHT);
    }

    bool UpdateLogScrollAnimation()
    {
        const float maxScroll = CalculateMaxLogScrollFast();
        float target = m_logScrollTarget.load(std::memory_order_relaxed);
        target = (std::max)(0.0f, (std::min)(target, maxScroll));
        m_logScrollTarget.store(target, std::memory_order_relaxed);

        const float oldScroll = m_logScroll;
        const float delta = target - m_logScroll;

        // Faster response than the old 0.42 factor. This is intentionally done
        // in the small log viewport only, so the animation stays cheap.
        m_logScroll += delta * 0.64f;

        if (std::abs(delta) < 0.08f)
            m_logScroll = target;

        if (target >= maxScroll - 1.0f)
            m_logFollowTail.store(true, std::memory_order_release);

        return std::abs(m_logScroll - oldScroll) > 0.01f;
    }

    void ScrollLogs(float delta)
    {
        const float maxScroll = CalculateMaxLogScrollFast();
        if (maxScroll <= 0.0f)
        {
            m_logScroll = 0.0f;
            m_logScrollTarget.store(0.0f, std::memory_order_release);
            m_logFollowTail.store(true, std::memory_order_release);
            return;
        }

        float target = m_logScrollTarget.load(std::memory_order_relaxed);
        target += delta;
        target = (std::max)(0.0f, (std::min)(target, maxScroll));

        m_logScrollTarget.store(target, std::memory_order_release);

        // Move part of the distance immediately. The timer then eases the rest.
        // This removes the one-frame input latency that made wheel scrolling feel
        // sticky when the message queue was busy.
        m_logScroll += (target - m_logScroll) * 0.36f;

        const bool atBottom = target >= maxScroll - 1.0f;
        m_logFollowTail.store(atBottom, std::memory_order_release);
    }

    void EnsureLogBuffer(HDC referenceDC, int width, int height)
    {
        if (!referenceDC || width <= 0 || height <= 0)
            return;

        if (m_logBackDC && m_logBackWidth == width && m_logBackHeight == height)
            return;

        if (m_logBackDC)
        {
            if (m_logBackOldBitmap)
                SelectObject(m_logBackDC, m_logBackOldBitmap);

            if (m_logBackBitmap)
                DeleteObject(m_logBackBitmap);

            DeleteDC(m_logBackDC);
            m_logBackDC = nullptr;
            m_logBackBitmap = nullptr;
            m_logBackOldBitmap = nullptr;
        }

        m_logBackDC = CreateCompatibleDC(referenceDC);
        if (!m_logBackDC)
            return;

        m_logBackBitmap = CreateCompatibleBitmap(referenceDC, width, height);
        if (!m_logBackBitmap)
        {
            DeleteDC(m_logBackDC);
            m_logBackDC = nullptr;
            return;
        }

        m_logBackOldBitmap = static_cast<HBITMAP>(
            SelectObject(m_logBackDC, m_logBackBitmap)
            );

        m_logBackWidth = width;
        m_logBackHeight = height;
    }

    void RenderLogViewport(HDC dc, int windowWidth, float scroll)
    {
        if (!dc || windowWidth <= 0)
            return;

        const int bufferWidth = windowWidth - 96;
        constexpr int bufferHeight = 104;

        if (bufferWidth <= 0)
            return;

        HDC targetDC = dc;

        SaveDC(targetDC);

        RECT localRect{ 0, 0, bufferWidth, bufferHeight };
        HBRUSH bgBrush = CreateSolidBrush(LoaderTheme::Card);
        FillRect(targetDC, &localRect, bgBrush);
        DeleteObject(bgBrush);

        std::vector<LogEntry> snapshot;
        {
            std::lock_guard<std::mutex> lock(m_logMutex);
            snapshot = m_logs;
        }

        constexpr float logTop = 3.0f;
        constexpr float logBottom = 101.0f;
        const int textClipRight = bufferWidth - 8;

        SaveDC(targetDC);
        IntersectClipRect(
            targetDC,
            0,
            static_cast<int>(logTop),
            textClipRight,
            static_cast<int>(logBottom)
        );

        for (size_t i = 0; i < snapshot.size(); ++i)
        {
            const float drawY = 6.0f + static_cast<float>(i) * LOG_LINE_HEIGHT - scroll;
            if (drawY < logTop - 20.0f || drawY > logBottom)
                continue;

            DrawTextColor(
                targetDC,
                m_fontSmall,
                snapshot[i].color,
                6,
                static_cast<int>(drawY),
                snapshot[i].text
            );
        }

        RestoreDC(targetDC, -1);

        const float maxScroll = CalculateMaxLogScrollFast();
        if (maxScroll > 0.0f && !snapshot.empty())
        {
            constexpr float trackTop = 4.0f;
            constexpr float trackBottom = 100.0f;
            constexpr float trackHeight = trackBottom - trackTop;

            const float contentHeight =
                static_cast<float>(snapshot.size()) * LOG_LINE_HEIGHT;

            const float thumbHeight = (std::max)(
                18.0f,
                trackHeight * trackHeight / (std::max)(contentHeight, trackHeight)
                );

            const float usableHeight = trackHeight - thumbHeight;
            const float ratio = Clamp01(scroll / maxScroll);
            const float thumbTop = trackTop + usableHeight * ratio;

            RECT track{ bufferWidth - 7, static_cast<int>(trackTop), bufferWidth - 4, static_cast<int>(trackBottom) };
            RECT thumb{ bufferWidth - 8, static_cast<int>(thumbTop), bufferWidth - 3, static_cast<int>(thumbTop + thumbHeight) };

            FillRoundRect(targetDC, track, LoaderTheme::Separator, 2);
            FillRoundRect(
                targetDC,
                thumb,
                LerpColor(LoaderTheme::TextDim, GetAnimatedAccent(0.55f), 0.42f),
                2
            );
        }

        RestoreDC(targetDC, -1);
    }

    void EnsureStatusBuffer(HDC referenceDC, int width, int height)
    {
        if (!referenceDC || width <= 0 || height <= 0)
            return;

        if (m_statusBackDC && m_statusBackWidth == width && m_statusBackHeight == height)
            return;

        if (m_statusBackDC)
        {
            if (m_statusBackOldBitmap)
                SelectObject(m_statusBackDC, m_statusBackOldBitmap);

            if (m_statusBackBitmap)
                DeleteObject(m_statusBackBitmap);

            DeleteDC(m_statusBackDC);
            m_statusBackDC = nullptr;
            m_statusBackBitmap = nullptr;
            m_statusBackOldBitmap = nullptr;
        }

        m_statusBackDC = CreateCompatibleDC(referenceDC);
        if (!m_statusBackDC)
            return;

        m_statusBackBitmap = CreateCompatibleBitmap(referenceDC, width, height);
        if (!m_statusBackBitmap)
        {
            DeleteDC(m_statusBackDC);
            m_statusBackDC = nullptr;
            return;
        }

        m_statusBackOldBitmap = static_cast<HBITMAP>(
            SelectObject(m_statusBackDC, m_statusBackBitmap)
            );

        m_statusBackWidth = width;
        m_statusBackHeight = height;
    }

    void RenderLauncherStatus(HDC dc, int width, int height)
    {
        if (!dc || width <= 0 || height <= 0)
            return;

        // Coordinates are local to the status backbuffer at window (34, 292).
        constexpr int originX = 34;
        constexpr int originY = 292;
        (void)originX;
        (void)originY;

        RECT local{ 0, 0, width - 68, 91 };
        HBRUSH bg = CreateSolidBrush(LoaderTheme::Background);
        FillRect(dc, &local, bg);
        DeleteObject(bg);

        State state;
        std::wstring title;
        std::wstring detail;
        float progress = 0.0f;
        bool indeterminate = false;
        GetVisualState(state, title, detail, progress, indeterminate);

        DrawTextColor(dc, m_fontBody, LoaderTheme::Text, 6, 9, title);
        DrawTextColor(dc, m_fontSmall, LoaderTheme::TextMuted, 6, 35, detail);

        RECT progressRect{
            6,
            height - 27 - originY,
            (width - 68) - 171,
            height - 19 - originY
        };

        DrawProgress(dc, progressRect, state, progress, indeterminate);

        const int percentX = (width - 193) - originX;
        const int percentY = (height - 33) - originY;

        std::wstring percentText;
        if (indeterminate && state == State::Working)
        {
            percentText = L"...";
        }
        else
        {
            percentText = std::to_wstring(
                static_cast<int>(std::round(Clamp01(progress) * 100.0f))
            ) + L"%";
        }

        DrawTextColor(dc, m_fontSmall, LoaderTheme::TextMuted, percentX, percentY, percentText);

        m_actionButtonRect = RECT{
            width - 178,
            296,
            width - 40,
            338
        };

        const RECT localButton{
            m_actionButtonRect.left - originX,
            m_actionButtonRect.top - originY,
            m_actionButtonRect.right - originX,
            m_actionButtonRect.bottom - originY
        };

        std::wstring buttonText = L"\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C";
        if (state == State::Working)
            buttonText = L"\u0417\u0430\u043F\u0443\u0441\u043A\u0430\u0435\u0442\u0441\u044F...";
        else if (state == State::Success)
            buttonText = L"\u0417\u0430\u043A\u0440\u044B\u0442\u044C";
        else if (state == State::Error)
            buttonText = L"\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C";

        DrawButton(dc, localButton, buttonText, m_actionHovered, m_actionHover, true);

        COLORREF stateColor = GetAnimatedAccent(0.40f);
        if (state == State::Success)
            stateColor = LoaderTheme::Success;
        else if (state == State::Error)
            stateColor = LoaderTheme::Error;

        const wchar_t* statusText =
            state == State::Working
            ? L"\u0418\u041D\u0418\u0426\u0418\u0410\u041B\u0418\u0417\u0410\u0426\u0418\u042F"
            : state == State::Success
            ? L"\u0417\u0410\u041F\u0423\u0429\u0415\u041D\u041E"
            : state == State::Error
            ? L"\u041E\u0428\u0418\u0411\u041A\u0410"
            : L"\u0413\u041E\u0422\u041E\u0412";

        const int statusX = 6;
        const int statusY = (height - 50) - originY;
        DrawTextColor(dc, m_fontSmall, stateColor, statusX, statusY, statusText);
    }

    void RenderLauncherStatusToWindow()
    {
        if (!m_hwnd || m_screen != Screen::Launcher)
            return;

        HDC windowDC = GetDC(m_hwnd);
        if (!windowDC)
            return;

        const int bufferWidth = m_width - 68;
        constexpr int bufferHeight = 91;

        EnsureStatusBuffer(windowDC, bufferWidth, bufferHeight);
        if (m_statusBackDC)
        {
            RenderLauncherStatus(m_statusBackDC, m_width, m_height);
            BitBlt(
                windowDC,
                34,
                292,
                bufferWidth,
                bufferHeight,
                m_statusBackDC,
                0,
                0,
                SRCCOPY
            );
        }

        ReleaseDC(m_hwnd, windowDC);
    }

    void RenderLogViewportToWindow()
    {
        if (!m_hwnd || m_screen != Screen::Launcher)
            return;

        HDC windowDC = GetDC(m_hwnd);
        if (!windowDC)
            return;

        const int bufferWidth = m_width - 96;
        constexpr int bufferHeight = 104;

        EnsureLogBuffer(windowDC, bufferWidth, bufferHeight);
        if (m_logBackDC)
        {
            RenderLogViewport(m_logBackDC, m_width, m_logScroll);
            BitBlt(
                windowDC,
                52,
                177,
                bufferWidth,
                bufferHeight,
                m_logBackDC,
                0,
                0,
                SRCCOPY
            );
        }

        ReleaseDC(m_hwnd, windowDC);
    }

    bool HitLogViewport(POINT pt) const
    {
        const RECT rc{ 48, 177, m_width - 48, 280 };
        return pt.x >= rc.left && pt.x <= rc.right && pt.y >= rc.top && pt.y <= rc.bottom;
    }

    void CreateFonts()
    {
        m_fontBrand = CreateFontW(-18, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
            DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");

        m_fontTitle = CreateFontW(-25, 0, 0, 0, FW_MEDIUM, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
            DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");

        m_fontBody = CreateFontW(-13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
            DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");

        m_fontSmall = CreateFontW(-12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
            DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");

        m_fontButton = CreateFontW(-14, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
            DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
    }

    void DestroyFonts()
    {
        if (m_fontBrand) DeleteObject(m_fontBrand);
        if (m_fontTitle) DeleteObject(m_fontTitle);
        if (m_fontBody) DeleteObject(m_fontBody);
        if (m_fontSmall) DeleteObject(m_fontSmall);
        if (m_fontButton) DeleteObject(m_fontButton);

        m_fontBrand = nullptr;
        m_fontTitle = nullptr;
        m_fontBody = nullptr;
        m_fontSmall = nullptr;
        m_fontButton = nullptr;
    }

    void CreateInputs()
    {
        m_editBrush = CreateSolidBrush(LoaderTheme::Card);

        m_telegramEdit = CreateWindowExW(
            0,
            L"EDIT",
            L"",
            WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_LEFT | ES_NOHIDESEL,
            55, 175, 264, 24,
            m_hwnd,
            reinterpret_cast<HMENU>(static_cast<INT_PTR>(IDC_TELEGRAM)),
            GetModuleHandleW(nullptr),
            nullptr
        );

        m_passwordEdit = CreateWindowExW(
            0,
            L"EDIT",
            L"",
            WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_LEFT | ES_PASSWORD | ES_NOHIDESEL,
            55, 223, 264, 24,
            m_hwnd,
            reinterpret_cast<HMENU>(static_cast<INT_PTR>(IDC_PASSWORD)),
            GetModuleHandleW(nullptr),
            nullptr
        );

        auto SetupEdit = [&](HWND edit, int kind)
            {
                if (!edit)
                    return;

                SendMessageW(edit, WM_SETFONT, reinterpret_cast<WPARAM>(m_fontBody), TRUE);

                LONG_PTR style = GetWindowLongPtrW(edit, GWL_STYLE);
                style &= ~static_cast<LONG_PTR>(WS_BORDER);
                SetWindowLongPtrW(edit, GWL_STYLE, style);

                SetWindowTheme(edit, L"", L"");
                SendMessageW(edit, EM_SETMARGINS, EC_LEFTMARGIN | EC_RIGHTMARGIN, MAKELPARAM(8, 7));

                InstallEditSubclass(edit, kind);
                HideCaret(edit);
                InvalidateRect(edit, nullptr, FALSE);
            };

        SetupEdit(m_telegramEdit, 1);
        SetupEdit(m_passwordEdit, 2);
    }

    void LoadRustIcon()
    {
        m_rustBitmap = nullptr;
        m_rustBitmapWidth = 1;
        m_rustBitmapHeight = 1;
    }

    void SwitchToLauncher()
    {
        m_screen = Screen::Launcher;

        if (m_telegramEdit)
            ShowWindow(m_telegramEdit, SW_HIDE);
        if (m_passwordEdit)
            ShowWindow(m_passwordEdit, SW_HIDE);

        AddLog(L"[+] Preview build: no login or password required.", LoaderTheme::Success);
        AddLog(L"[!] WmipRpc adapter experimental; writes enabled; offsets unverified.", LoaderTheme::Error);
        AddLog(L"[+] \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u043A \u0437\u0430\u043F\u0443\u0441\u043A\u0443 Rust...", LoaderTheme::AccentLight);

        {
            std::lock_guard<std::mutex> lock(m_stateMutex);
            m_title = L"Rust";
            m_detail = L"\u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u00AB\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C\u00BB, \u0447\u0442\u043E\u0431\u044B \u043D\u0430\u0447\u0430\u0442\u044C \u0438\u043D\u0438\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044E";
            m_state = State::Idle;
            m_progress = 0.0f;
            m_indeterminate = false;
        }

        // The two AddLog() calls above were rendered by the full screen transition.
        m_logWakeDirty.store(false, std::memory_order_release);
        m_statusWakeDirty.store(false, std::memory_order_release);

        const float maxScroll = CalculateMaxLogScrollFast();
        m_logScroll = maxScroll;
        m_logScrollTarget.store(maxScroll, std::memory_order_release);
        m_logFollowTail.store(true, std::memory_order_release);

        InvalidateRect(m_hwnd, nullptr, FALSE);
        SetFocus(m_hwnd);
    }

    bool HitRect(const RECT& rc, POINT pt) const
    {
        return pt.x >= rc.left && pt.x <= rc.right && pt.y >= rc.top && pt.y <= rc.bottom;
    }

    bool HitTopBar(POINT pt) const
    {
        return pt.y >= 0 && pt.y <= 58;
    }

    void UpdateHover(POINT pt)
    {
        m_loginHovered = m_screen == Screen::Login && HitRect(m_loginButtonRect, pt);
        m_actionHovered = m_screen == Screen::Launcher && HitRect(m_actionButtonRect, pt);
    }

    static void FillRoundRect(HDC dc, const RECT& rc, COLORREF color, int radius)
    {
        HBRUSH brush = CreateSolidBrush(color);
        HGDIOBJ oldBrush = SelectObject(dc, brush);

        HPEN pen = CreatePen(PS_SOLID, 1, color);
        HGDIOBJ oldPen = SelectObject(dc, pen);

        RoundRect(dc, rc.left, rc.top, rc.right, rc.bottom, radius, radius);

        SelectObject(dc, oldPen);
        SelectObject(dc, oldBrush);
        DeleteObject(pen);
        DeleteObject(brush);
    }

    static void DrawTextColor(HDC dc, HFONT font, COLORREF color, int x, int y, const std::wstring& text)
    {
        if (!font || text.empty())
            return;

        HFONT old = static_cast<HFONT>(SelectObject(dc, font));
        SetBkMode(dc, TRANSPARENT);
        SetTextColor(dc, color);
        TextOutW(dc, x, y, text.c_str(), static_cast<int>(text.size()));
        SelectObject(dc, old);
    }

    void DrawButton(HDC dc, const RECT& rc, const std::wstring& text, bool hovered, float hoverAnim, bool accent)
    {
        const float hover = EaseOutCubic(hoverAnim);

        RECT box = rc;
        box.top -= static_cast<int>(hover);
        box.bottom -= static_cast<int>(hover);

        COLORREF bg = LerpColor(LoaderTheme::Card, LoaderTheme::CardHover, hover);
        if (accent)
            bg = LerpColor(bg, LoaderTheme::AccentSoft, hovered ? 0.19f + hover * 0.05f : 0.12f);

        FillRoundRect(dc, box, bg, 9);

        HGDIOBJ oldBrush = SelectObject(dc, GetStockObject(NULL_BRUSH));
        const COLORREF borderColor = hovered
            ? LerpColor(LoaderTheme::Accent, GetAnimatedAccent(0.16f), 0.48f)
            : LoaderTheme::Separator;

        HPEN pen = CreatePen(PS_SOLID, 1, borderColor);
        HGDIOBJ oldPen = SelectObject(dc, pen);

        RoundRect(dc, box.left, box.top, box.right, box.bottom, 9, 9);

        SelectObject(dc, oldPen);
        SelectObject(dc, oldBrush);
        DeleteObject(pen);

        SIZE ts{};
        HFONT oldFont = static_cast<HFONT>(SelectObject(dc, m_fontButton));
        GetTextExtentPoint32W(dc, text.c_str(), static_cast<int>(text.size()), &ts);

        SetBkMode(dc, TRANSPARENT);
        SetTextColor(dc, LerpColor(LoaderTheme::TextMuted, LoaderTheme::Text, 0.70f + hover * 0.30f));

        TextOutW(
            dc,
            (box.left + box.right - ts.cx) / 2,
            (box.top + box.bottom - ts.cy) / 2,
            text.c_str(),
            static_cast<int>(text.size())
        );

        SelectObject(dc, oldFont);
    }

    void DrawInput(HDC dc, const RECT& rc, float focusAnim)
    {
        const COLORREF bg = LerpColor(LoaderTheme::Card, LoaderTheme::CardHover, focusAnim * 0.10f);
        FillRoundRect(dc, rc, bg, 8);

        HGDIOBJ oldBrush = SelectObject(dc, GetStockObject(NULL_BRUSH));
        HPEN pen = CreatePen(PS_SOLID, 1, GetFocusColor(focusAnim));
        HGDIOBJ oldPen = SelectObject(dc, pen);

        RoundRect(dc, rc.left, rc.top, rc.right, rc.bottom, 8, 8);

        SelectObject(dc, oldPen);
        SelectObject(dc, oldBrush);
        DeleteObject(pen);
    }

    void DrawProgress(HDC dc, const RECT& rc, State state, float progress, bool indeterminate)
    {
        FillRoundRect(dc, rc, LoaderTheme::Separator, 4);

        if (state == State::Error)
        {
            RECT fill = rc;
            fill.right = fill.left + static_cast<int>((fill.right - fill.left) * Clamp01(progress));
            if (fill.right > fill.left)
                FillRoundRect(dc, fill, LoaderTheme::Error, 4);
            return;
        }

        if (indeterminate && state == State::Working)
        {
            const int width = rc.right - rc.left;
            const int segment = static_cast<int>(width * 0.22f);
            const float p = std::fmod(m_animTime * 0.55f, 1.35f) - 0.15f;
            const int center = rc.left + static_cast<int>(p * width);

            RECT fill{
                center - segment / 2,
                rc.top,
                center + segment / 2,
                rc.bottom
            };

            fill.left = static_cast<LONG>((std::max)(static_cast<LONG>(fill.left), static_cast<LONG>(rc.left)));
            fill.right = static_cast<LONG>((std::min)(static_cast<LONG>(fill.right), static_cast<LONG>(rc.right)));

            if (fill.right > fill.left)
                FillRoundRect(dc, fill, GetAnimatedAccent(0.32f), 4);
            return;
        }

        RECT fill = rc;
        fill.right = fill.left + static_cast<int>((fill.right - fill.left) * Clamp01(progress));
        if (fill.right > fill.left)
        {
            const COLORREF color = state == State::Success
                ? LoaderTheme::Success
                : GetAnimatedAccent(0.28f);
            FillRoundRect(dc, fill, color, 4);
        }
    }

    void Paint()
    {
        if (!m_hwnd)
            return;

        PAINTSTRUCT ps{};
        HDC windowDC = BeginPaint(m_hwnd, &ps);

        RECT client{};
        GetClientRect(m_hwnd, &client);

        const int width = client.right - client.left;
        const int height = client.bottom - client.top;

        if (!m_backDC || m_backWidth != width || m_backHeight != height)
        {
            if (m_backDC)
            {
                if (m_backOldBitmap)
                    SelectObject(m_backDC, m_backOldBitmap);
                if (m_backBitmap)
                    DeleteObject(m_backBitmap);
                DeleteDC(m_backDC);
            }

            m_backDC = CreateCompatibleDC(windowDC);
            m_backBitmap = CreateCompatibleBitmap(windowDC, width, height);
            m_backOldBitmap = static_cast<HBITMAP>(SelectObject(m_backDC, m_backBitmap));
            m_backWidth = width;
            m_backHeight = height;
        }

        HDC memDC = m_backDC;

        FillRoundRect(memDC, client, LoaderTheme::Background, 22);

        const float pulse = 0.5f + 0.5f * std::sin(m_animTime * 0.55f);
        RECT sheenRect{ 24, 14, width - 24, 21 };

        FillRoundRect(
            memDC,
            sheenRect,
            LerpColor(LoaderTheme::Surface, LoaderTheme::AccentSoft, 0.018f + pulse * 0.018f),
            11
        );

        HGDIOBJ oldBrush = SelectObject(memDC, GetStockObject(NULL_BRUSH));
        HPEN outerPen = CreatePen(PS_SOLID, 1, LoaderTheme::Separator);
        HGDIOBJ oldPen = SelectObject(memDC, outerPen);

        RoundRect(memDC, 1, 1, width - 1, height - 1, 22, 22);

        SelectObject(memDC, oldPen);
        SelectObject(memDC, oldBrush);
        DeleteObject(outerPen);

        DrawTextColor(memDC, m_fontTitle, LoaderTheme::Text, 30, 19, L"Rust");
        DrawTextColor(memDC, m_fontSmall, LoaderTheme::TextMuted, 31, 47, _xorstrw(L"Crez External / prototype"));

        HPEN divider = CreatePen(PS_SOLID, 1, LoaderTheme::Separator);
        HGDIOBJ oldDivider = SelectObject(memDC, divider);
        MoveToEx(memDC, 26, 68, nullptr);
        LineTo(memDC, width - 26, 68);
        SelectObject(memDC, oldDivider);
        DeleteObject(divider);

        if (m_screen == Screen::Login)
            PaintLogin(memDC, width, height);
        else
            PaintLauncher(memDC, width, height);

        BitBlt(windowDC, 0, 0, width, height, memDC, 0, 0, SRCCOPY);

        const BYTE alpha = static_cast<BYTE>(Clamp01(m_fade) * 255.0f);
        SetLayeredWindowAttributes(m_hwnd, 0, alpha, LWA_ALPHA);

        EndPaint(m_hwnd, &ps);
    }

    void PaintLogin(HDC dc, int width, int height)
    {
        DrawTextColor(dc, m_fontTitle, LoaderTheme::Text, 40, 94, L"\u0412\u0445\u043E\u0434");

        RECT card{ 40, 145, width - 40, 303 };
        FillRoundRect(dc, card, LoaderTheme::Card, 12);

        HGDIOBJ oldBrush = SelectObject(dc, GetStockObject(NULL_BRUSH));
        HPEN border = CreatePen(PS_SOLID, 1, LoaderTheme::Separator);
        HGDIOBJ oldPen = SelectObject(dc, border);
        RoundRect(dc, card.left, card.top, card.right, card.bottom, 12, 12);
        SelectObject(dc, oldPen);
        SelectObject(dc, oldBrush);
        DeleteObject(border);

        const RECT telegramRect{ 52, 166, 322, 206 };
        const RECT passwordRect{ 52, 214, 322, 254 };

        DrawInput(dc, telegramRect, m_telegramFocusAnim);
        DrawInput(dc, passwordRect, m_passwordFocusAnim);

        m_loginButtonRect = RECT{ 350, 166, width - 52, 254 };

        DrawButton(
            dc,
            m_loginButtonRect,
            L"\u0412\u043E\u0439\u0442\u0438",
            m_loginHovered,
            m_loginHover,
            true
        );

        std::wstring elysiumRust = std::wstring(_xorstrw(L"Elysium")) + L" \u2022 " + _xorstrw(L"Rust");
        DrawTextColor(dc, m_fontSmall, LoaderTheme::TextDim, 40, height - 30, elysiumRust);
    }

    void PaintLauncher(HDC dc, int width, int height)
    {
        DrawTextColor(dc, m_fontTitle, LoaderTheme::Text, 40, 92, L"\u041B\u0430\u0443\u043D\u0447\u0435\u0440");

        RECT logCard{ 40, 148, width - 40, 286 };
        FillRoundRect(dc, logCard, LoaderTheme::Card, 12);

        HGDIOBJ oldBrush = SelectObject(dc, GetStockObject(NULL_BRUSH));
        HPEN border = CreatePen(PS_SOLID, 1, LoaderTheme::Separator);
        HGDIOBJ oldPen = SelectObject(dc, border);
        RoundRect(dc, logCard.left, logCard.top, logCard.right, logCard.bottom, 12, 12);
        SelectObject(dc, oldPen);
        SelectObject(dc, oldBrush);
        DeleteObject(border);

        DrawTextColor(dc, m_fontSmall, LoaderTheme::TextMuted, 58, 160, L"\u041B\u041E\u0413\u0418");

        const int logBufferWidth = width - 96;
        const int logBufferHeight = 104;
        EnsureLogBuffer(dc, logBufferWidth, logBufferHeight);
        if (m_logBackDC)
        {
            RenderLogViewport(m_logBackDC, width, m_logScroll);
            BitBlt(
                dc,
                52,
                177,
                logBufferWidth,
                logBufferHeight,
                m_logBackDC,
                0,
                0,
                SRCCOPY
            );
        }

        const int statusBufferWidth = width - 68;
        constexpr int statusBufferHeight = 91;
        EnsureStatusBuffer(dc, statusBufferWidth, statusBufferHeight);
        if (m_statusBackDC)
        {
            RenderLauncherStatus(m_statusBackDC, width, height);
            BitBlt(
                dc,
                34,
                292,
                statusBufferWidth,
                statusBufferHeight,
                m_statusBackDC,
                0,
                0,
                SRCCOPY
            );
        }
    }

    void RunInitialization()
    {
        auto Step = [&](const std::wstring& title,
            const std::wstring& detail,
            float from,
            float to,
            int count,
            int delayMs)
            {
                count = (std::max)(1, count);
                for (int i = 0; i <= count; ++i)
                {
                    const float t = static_cast<float>(i) / static_cast<float>(count);
                    SetStatus(title, detail, Lerp(from, to, EaseOutCubic(t)), false);
                    Sleep(delayMs);
                }
            };

        AddLog(L"[+] \u0417\u0430\u043F\u0443\u0441\u043A\u0430\u044E\u0441\u044C...", LoaderTheme::AccentLight);

        Step(
            L"\u0417\u0430\u043F\u0443\u0441\u043A",
            L"\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 Elysium...",
            0.02f, 0.07f, 6, 25
        );

        AddLog(L"[+] \u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0434\u0440\u0430\u0439\u0432\u0435\u0440\u0430...", LoaderTheme::Text);

        Step(
            L"\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0434\u0440\u0430\u0439\u0432\u0435\u0440\u0430",
            L"\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u044E \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E\u0441\u0442\u044C \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0430",
            0.08f, 0.22f, 10, 24
        );

        AddLog(L"[+] Driver-only mode. Waiting for WmipRpc device; no Windows API fallback.", LoaderTheme::Text);
        AddLog(L"[!] Experimental: writes enabled; protocol and offsets not verified.", LoaderTheme::Error);
        auto Fail = [&](const std::wstring& reason) {
            AddLog(L"[-] " + reason, LoaderTheme::Error);
            m_workerActive.store(false, std::memory_order_release);
            SetError(reason);
        };
        bool driverAvailable = false;
        DWORD driverError = ERROR_FILE_NOT_FOUND;
        const ULONGLONG driverStart = GetTickCount64();
        while (!m_quitRequested.load(std::memory_order_acquire) && GetTickCount64() - driverStart < 5000) {
            driverAvailable = IsDriverDeviceAvailable(&driverError);
            if (driverAvailable) break;
            SetStatus(L"Driver required", L"Checking WmipRpc device...", 0.22f, true);
            Sleep(250);
        }
        if (m_quitRequested.load(std::memory_order_acquire)) { m_workerActive.store(false, std::memory_order_release); return; }
        if (!driverAvailable) {
            std::wstring reason = L"WmipRpc: \u043E\u0448\u0438\u0431\u043A\u0430 Windows " + std::to_wstring(driverError);
            if (driverError == ERROR_FILE_NOT_FOUND || driverError == ERROR_PATH_NOT_FOUND) reason += L": \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E";
            else if (driverError == ERROR_ACCESS_DENIED) reason += L": \u043E\u0442\u043A\u0430\u0437\u0430\u043D\u043E \u0432 \u0434\u043E\u0441\u0442\u0443\u043F\u0435";
            else if (driverError == ERROR_SHARING_VIOLATION) reason += L": \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E \u0437\u0430\u043D\u044F\u0442\u043E";
            else if (driverError == ERROR_REVISION_MISMATCH) reason += L": \u043D\u0435\u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F";
            Fail(reason); return;
        }
        AddLog(L"[+] WmipRpc heartbeat accepted; read/write compatibility not yet verified.", LoaderTheme::Success);
        Sleep(180);
        AddLog(L"[+] Waiting for RustClient.exe...", LoaderTheme::Text);

        uint32_t pid = 0;
        const ULONGLONG processStart = GetTickCount64();
        while (pid == 0 && !m_quitRequested.load(std::memory_order_acquire))
        {
            if (GetTickCount64() - processStart >= 30000) { Fail(L"RustClient.exe \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0437\u0430 30 \u0441\u0435\u043A\u0443\u043D\u0434"); return; }
            pid = get_process_pid(_xorstr("RustClient.exe"));
            SetStatus(L"\u041F\u043E\u0438\u0441\u043A Rust", L"\u041E\u0436\u0438\u0434\u0430\u044E RustClient.exe", 0.30f, true);
            Sleep(100);
        }

        if (m_quitRequested.load(std::memory_order_acquire)) { m_workerActive.store(false, std::memory_order_release); return; }

        AddLog(L"[\u2713] \u041D\u0430\u0439\u0434\u0435\u043D RustClient.exe \u0441 PID: " + std::to_wstring(pid), LoaderTheme::Success);
        AddLog(L"[+] \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u043A RustClient.exe...", LoaderTheme::Text);

        bool attached = false;
        const ULONGLONG attachStart = GetTickCount64();
        while (!attached && !m_quitRequested.load(std::memory_order_acquire))
        {
            if (GetTickCount64() - attachStart >= 10000) { Fail(L"\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C\u0441\u044F \u043A RustClient.exe \u0447\u0435\u0440\u0435\u0437 WmipRpc"); return; }
            attached = kernelHandler.attach(_xorstr("RustClient.exe"));
            SetStatus(L"\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435",
                L"\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0430\u044E\u0441\u044C \u043A RustClient.exe",
                0.40f, !attached);
            if (!attached)
                Sleep(100);
        }

        if (m_quitRequested.load(std::memory_order_acquire)) { m_workerActive.store(false, std::memory_order_release); return; }

        Step(
            L"\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E",
            L"\u0421\u0432\u044f\u0437\u044c \u0441 RustClient.exe \u0430\u043A\u0442\u0438\u0432\u043D\u0430",
            0.40f, 0.51f, 8, 25
        );

        AddLog(L"[+] Process found and driver opened; game memory not yet verified.", LoaderTheme::Text);
        AddLog(L"[+] \u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435 GameAssembly.dll...", LoaderTheme::Text);

        uint64_t gameAssemblyBase = 0;
        const ULONGLONG gameAssemblyBaseStart = GetTickCount64();
        while (gameAssemblyBase == 0 && !m_quitRequested.load(std::memory_order_acquire))
        {
            if (GetTickCount64() - gameAssemblyBaseStart >= 15000) { Fail(L"GameAssembly.dll \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D: \u0438\u0433\u0440\u0430 \u0438\u043B\u0438 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0434\u0440\u0430\u0439\u0432\u0435\u0440\u0430"); return; }
            gameAssemblyBase = kernelHandler.get_module_base(_xorstr("GameAssembly.dll"));
            SetStatus(L"\u041F\u043E\u0438\u0441\u043A \u043C\u043E\u0434\u0443\u043B\u044F",
                L"\u041E\u0436\u0438\u0434\u0430\u044E GameAssembly.dll",
                0.56f, true);
            Sleep(100);
        }

        if (m_quitRequested.load(std::memory_order_acquire)) { m_workerActive.store(false, std::memory_order_release); return; }

        AddLog(L"[\u2713] GameAssembly.dll \u0431\u0430\u0437\u0430: 0x" + HexAddress(gameAssemblyBase), LoaderTheme::Success);
        AddLog(L"[+] \u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435 UnityPlayer.dll...", LoaderTheme::Text);

        uint64_t unityPlayerBase = 0;
        const ULONGLONG unityPlayerBaseStart = GetTickCount64();
        while (unityPlayerBase == 0 && !m_quitRequested.load(std::memory_order_acquire))
        {
            if (GetTickCount64() - unityPlayerBaseStart >= 15000) { Fail(L"UnityPlayer.dll \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D: \u0438\u0433\u0440\u0430 \u0438\u043B\u0438 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0434\u0440\u0430\u0439\u0432\u0435\u0440\u0430"); return; }
            unityPlayerBase = kernelHandler.get_module_base(_xorstr("UnityPlayer.dll"));
            SetStatus(L"\u041F\u043E\u0438\u0441\u043A \u043C\u043E\u0434\u0443\u043B\u044F",
                L"\u041E\u0436\u0438\u0434\u0430\u044E UnityPlayer.dll",
                0.65f, true);
            Sleep(100);
        }

        if (m_quitRequested.load(std::memory_order_acquire)) { m_workerActive.store(false, std::memory_order_release); return; }

        AddLog(L"[\u2713] UnityPlayer.dll \u0431\u0430\u0437\u0430: 0x" + HexAddress(unityPlayerBase), LoaderTheme::Success);

        gBase = gameAssemblyBase;
        uBase = unityPlayerBase;
        pId = pid;

        AddLog(L"[+] \u0418\u043D\u0438\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \u041C\u0435\u043D\u0435\u0434\u0436\u0435\u0440\u0430 \u0424\u0443\u043D\u043A\u0446\u0438\u0439...", LoaderTheme::Text);

        Step(
            L"\u0418\u043D\u0438\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \u043C\u043E\u0434\u0443\u043B\u0435\u0439",
            L"\u041F\u043E\u0434\u0433\u043E\u0442\u0430\u0432\u043B\u0438\u0432\u0430\u044E \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u043C\u043E\u0434\u0443\u043B\u0438",
            0.73f, 0.86f, 12, 25
        );

        ModuleManager moduleManager;
        Menu menu;

        auto aim = std::make_shared<AimModule>();
        auto recoil = std::make_shared<RecoilModule>();
        auto esp = std::make_shared<EspModule>();
        auto arrows = std::make_shared<ArrowsModule>();
        auto fakeAdmin = std::make_shared<FakeAdminModule>();
        auto spider = std::make_shared<SpiderModule>();
        auto alwaysEoka = std::make_shared<AlwaysEokaModule>();
        auto world = std::make_shared<WorldEsp>();
        auto item = std::make_shared<ItemEspModule>();
        auto inventoryesp = std::make_shared<InventoryEspModule>();
        auto radar = std::make_shared<RadarModule>();
        auto automatic = std::make_shared<AutomaticModule>();

        moduleManager.RegisterModule(automatic);
        moduleManager.RegisterModule(radar);
        moduleManager.RegisterModule(inventoryesp);
        moduleManager.RegisterModule(item);
        moduleManager.RegisterModule(world);
        moduleManager.RegisterModule(spider);
        moduleManager.RegisterModule(fakeAdmin);
        moduleManager.RegisterModule(aim);
        moduleManager.RegisterModule(recoil);
        moduleManager.RegisterModule(esp);
        moduleManager.RegisterModule(arrows);
        moduleManager.RegisterModule(alwaysEoka);

        EspModule::s_aimInstance = aim.get();

        // Register stable, validated settings before loading the last session.
        LastConfig lastConfig;
        auto bindModule=[&](const char* id, Module& mod){
            const std::string k=id;
            lastConfig.Bool(k+".enabled",mod.enabled);
            lastConfig.Int(k+".key",mod.keybind.key,0,255);
            lastConfig.Enum(k+".keyMode",mod.keybind.mode,0,1);
        };
        bindModule("aim",*aim);bindModule("recoil",*recoil);bindModule("esp",*esp);
        bindModule("arrows",*arrows);bindModule("radar",*radar);bindModule("world",*world);
        bindModule("item",*item);bindModule("inventory",*inventoryesp);
#define CB(obj,field) lastConfig.Bool(#obj "." #field,obj->field)
#define CI(obj,field,lo,hi) lastConfig.Int(#obj "." #field,obj->field,lo,hi)
#define CF(obj,field,lo,hi) lastConfig.Float(#obj "." #field,obj->field,lo,hi)
#define CC(obj,field) lastConfig.Color(#obj "." #field,obj->field)
#define CE(obj,field,lo,hi) lastConfig.Enum(#obj "." #field,obj->field,lo,hi)
        CB(aim,changeBoxColorOnTarget);CB(aim,targetTeammates);CB(aim,lockOnTarget);
        CB(aim,prediction);CF(aim,projectileSpeed,50.f,1200.f);CF(aim,predictionAmount,0.f,1.25f);CF(aim,predictionGravity,0.f,20.f);
        CB(aim,distanceFovScaling);CB(aim,skipSleepers);CB(aim,skipWounded);CB(aim,showFov);CB(aim,targetLine);
        CC(aim,fovColor);CC(aim,lineColor);
        CC(aim,activeTargetColor);CI(aim,aimKey,0,255);CI(aim,aimMode,0,3);CI(aim,targetPriority,0,1);
        CF(aim,radius,20.f,400.f);CF(aim,gain,.005f,.15f);CF(aim,smooth,1.f,50.f);CF(aim,maxDistance,10.f,500.f);
        CI(recoil,mode,0,1);CB(recoil,onlyAds);CF(recoil,vertical,0.f,300.f);CF(recoil,horizontal,-100.f,100.f);
        CB(esp,drawBox);CB(esp,drawOutline);CB(esp,drawDistance);CB(esp,drawNames);CB(esp,drawPlayers);CB(esp,drawSleepers);CB(esp,drawNpcs);CB(esp,drawLocalPlayer);CB(esp,drawTeammates);
        CI(esp,nameField,0,3);
        CB(esp,experimentalHeadCamera);CB(esp,boxFill);CB(esp,boxGradient);CB(esp,snapLines);CB(esp,headCircle);CB(esp,stateFlags);
        CE(esp,playerBoxStyle,0,4);CE(esp,npcBoxStyle,0,4);CI(esp,snapAlignment,0,2);
        CF(esp,cornerLength,.1f,.5f);CF(esp,npcCornerLength,.1f,.5f);CF(esp,maxDistance,100.f,1000.f);
        CC(esp,fillTop);CC(esp,fillBottom);CC(esp,gradientBottom);CC(esp,snapColor);CC(esp,headColor);
        CC(esp,boxColor);CC(esp,teammateColor);CC(esp,sleepingColor);CC(esp,npcColor);CC(esp,localPlayerColor);
        lastConfig.Bool("esp.skeleton.drawSkeleton",esp->skeleton.drawSkeleton);lastConfig.Bool("esp.skeleton.drawOutline",esp->skeleton.drawOutline);
        lastConfig.Color("esp.skeleton.skeletonColor",esp->skeleton.skeletonColor);lastConfig.Color("esp.skeleton.outlineColor",esp->skeleton.outlineColor);
        lastConfig.Float("esp.skeleton.lineThickness",esp->skeleton.lineThickness,.5f,5.f);lastConfig.Float("esp.skeleton.outlineThickness",esp->skeleton.outlineThickness,1.f,8.f);
        CF(arrows,arrowSize,1.f,200.f);CF(arrows,maxDistance,0.f,5000.f);CF(arrows,crosshairDistance,0.f,5000.f);
        CB(arrows,drawOutline);CB(arrows,showName);CB(arrows,showDistance);CB(arrows,useScreenCoordinates);CB(arrows,showPlayers);CB(arrows,showNPCs);CB(arrows,showSleeping);
        CC(arrows,playerColor);CC(arrows,npcColor);CC(arrows,sleepingColor);CE(arrows,arrowStyle,0,2);
        CF(radar,size,120.f,400.f);CF(radar,range,30.f,500.f);CF(radar,posX,-10000.f,10000.f);CF(radar,posY,-10000.f,10000.f);
        CC(radar,playerColor);CC(radar,teammateColor);CC(radar,sleeperColor);CC(radar,npcColor);
        CB(radar,ignoreSleepers);CB(radar,ignoreNpc);CB(radar,drawCardinals);CB(radar,drawGrid);
        CB(item,drawItems);CB(item,drawItemNames);CB(item,drawItemIcons);CB(item,drawItemDistance);CB(item,drawOutline);
        CF(item,itemIconSize,8.f,64.f);CF(item,itemMaxDistance,100.f,1000.f);CF(item,itemCornerLength,.1f,.5f);CC(item,itemColor);CE(item,itemBoxStyle,0,5);
        CB(world,drawOreMetal);CB(world,drawOreSulfur);CB(world,drawOreStone);CB(world,drawOreHqm);CB(world,drawHorse);CB(world,drawWood);
        CB(world,drawNames);CB(world,drawDistance);CB(world,drawOutline);CF(world,maxDistance,0.f,5000.f);CF(world,cornerLen,.1f,.5f);CF(world,iconSize,1.f,200.f);CE(world,boxStyle,0,5);
        CC(world,colorMetal);CC(world,colorSulfur);CC(world,colorStone);CC(world,colorHqm);CC(world,colorHorse);CC(world,colorWood);CC(world,colorDefault);
        CB(inventoryesp,invFilterPlayers);CB(inventoryesp,invFilterSleepers);CB(inventoryesp,invFilterNpcs);
        CF(inventoryesp,invSlotSize,16.f,64.f);CF(inventoryesp,invAimRadius,25.f,1500.f);CF(inventoryesp,maxDistance,100.f,2000.f);
#undef CB
#undef CI
#undef CF
#undef CC
#undef CE
        lastConfig.Bool("targethud.enabled",TargetHud::Get().enabled);
        menu.RegisterLastConfig(lastConfig);
        bool configOk=lastConfig.Init();
        AddLog(configOk ? L"Last config: automatic save enabled" : L"Last config unavailable or invalid; previous file not overwritten", configOk ? LoaderTheme::Text : LoaderTheme::Error);

        AddLog(L"[\u2713] \u0412\u0441\u0435 \u0424\u0443\u043D\u043A\u0446\u0438\u0438 \u0418\u043D\u0438\u0446\u0438\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u044B!", LoaderTheme::Success);
        AddLog(L"[+] \u0417\u0430\u043F\u0443\u0441\u043A \u041E\u0432\u0435\u0440\u043B\u0435\u044F...", LoaderTheme::Text);

        SetStatus(
            L"\u0417\u0430\u043F\u0443\u0441\u043A \u043E\u0432\u0435\u0440\u043B\u0435\u044F",
            L"\u0421\u043E\u0437\u0434\u0430\u044E \u0433\u0440\u0430\u0444\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u043F\u043E\u0432\u0435\u0440\u0445\u043D\u043E\u0441\u0442\u044C",
            0.90f
        );

        Overlay overlay;

        if (!overlay.Init())
        {
            AddLog(L"[-] \u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u041E\u0448\u0438\u0431\u043A\u0430: \u0418\u043D\u0438\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \u041E\u043A\u043D\u0430 \u041E\u0432\u0435\u0440\u043B\u0435\u044F!", LoaderTheme::Error);
            SetError(L"\u041E\u0448\u0438\u0431\u043A\u0430 \u0438\u043D\u0438\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438 \u043E\u0432\u0435\u0440\u043B\u0435\u044F");
            m_workerActive.store(false, std::memory_order_release);
            return;
        }

        ArrowsModule::SetD3D11Device(overlay.GetD3DDevice());
        AddLog(L"[\u2713] \u041E\u0432\u0435\u0440\u043B\u0435\u0439 \u0418\u043D\u0438\u0446\u0438\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D!", LoaderTheme::Success);

        menu.SetupStyle(overlay.GetD3DDevice());
        AddLog(L"[\u2713] \u041C\u0435\u043D\u044E \u0418\u043D\u0438\u0446\u0438\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043E!", LoaderTheme::Success);

        std::atomic<bool> stopWatcher{ false };
        std::thread processWatcher([&]() {
            while (!stopWatcher.load(std::memory_order_acquire) && !m_quitRequested.load(std::memory_order_acquire)) {
                const uint32_t currentPid = get_process_pid(_xorstr("RustClient.exe"));
                if (currentPid == 0 || currentPid != pId) {
                    PostMessageW(m_hwnd, WM_CLOSE, 0, 0);
                    break;
                }
                Sleep(500);
            }
        });

        SetSuccess(L"Crez External initialized (experimental)");
        AddLog(L"[+] Overlay initialized. Game addresses remain unverified.", LoaderTheme::Text);
        m_workerActive.store(false, std::memory_order_release);
        overlay.Run(moduleManager, menu, lastConfig, esp.get(), &m_quitRequested);
        lastConfig.Tick(true);
        stopWatcher.store(true, std::memory_order_release);
        processWatcher.join();

        AddLog(L"[+] \u041E\u0432\u0435\u0440\u043B\u0435\u0439 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D", LoaderTheme::TextMuted);
    }

private:
    HWND m_hwnd = nullptr;

    HWND m_telegramEdit = nullptr;
    HWND m_passwordEdit = nullptr;

    WNDPROC m_originalTelegramProc = nullptr;
    WNDPROC m_originalPasswordProc = nullptr;

    HBRUSH m_editBrush = nullptr;
    HBITMAP m_rustBitmap = nullptr;

    UINT m_rustBitmapWidth = 1;
    UINT m_rustBitmapHeight = 1;

    HFONT m_fontBrand = nullptr;
    HFONT m_fontTitle = nullptr;
    HFONT m_fontBody = nullptr;
    HFONT m_fontSmall = nullptr;
    HFONT m_fontButton = nullptr;

    HDC m_backDC = nullptr;
    HBITMAP m_backBitmap = nullptr;
    HBITMAP m_backOldBitmap = nullptr;
    int m_backWidth = 0;
    int m_backHeight = 0;

    HDC m_logBackDC = nullptr;
    HBITMAP m_logBackBitmap = nullptr;
    HBITMAP m_logBackOldBitmap = nullptr;
    int m_logBackWidth = 0;
    int m_logBackHeight = 0;

    HDC m_statusBackDC = nullptr;
    HBITMAP m_statusBackBitmap = nullptr;
    HBITMAP m_statusBackOldBitmap = nullptr;
    int m_statusBackWidth = 0;
    int m_statusBackHeight = 0;

    int m_width = 620;
    int m_height = 390;

    Screen m_screen = Screen::Login;
    State m_state = State::Idle;

    std::wstring m_title = L"\u0412\u0445\u043E\u0434";

    std::wstring m_detail =
        L"";

    float m_progress = 0.0f;
    bool m_indeterminate = false;

    float m_animTime = 0.0f;
    float m_fade = 0.0f;

    float m_loginHover = 0.0f;
    float m_actionHover = 0.0f;

    float m_telegramFocusAnim = 0.0f;
    float m_passwordFocusAnim = 0.0f;

    float m_telegramPlaceholderAlpha = 1.0f;
    float m_passwordPlaceholderAlpha = 1.0f;

    bool m_loginHovered = false;
    bool m_actionHovered = false;

    bool m_visible = false;
    std::atomic<bool> m_quitRequested{ false };

    POINT m_lastMouse{};

    RECT m_loginButtonRect{};
    RECT m_actionButtonRect{};

    std::atomic<int> m_logCount{ 0 };
    std::atomic<float> m_logScrollTarget{ 0.0f };
    std::atomic<bool> m_logFollowTail{ true };
    float m_logScroll = 0.0f;

    std::atomic<bool> m_launchRequested{ false };
    std::atomic<bool> m_workerActive{ false };

    std::atomic<bool> m_wakePending{ false };
    std::atomic<bool> m_logWakeDirty{ false };
    std::atomic<bool> m_statusWakeDirty{ false };

    std::thread m_worker;

    mutable std::mutex m_stateMutex;
    mutable std::mutex m_logMutex;

    std::vector<LogEntry> m_logs;
};

bool IsDriverDeviceAvailable(DWORD* lastError)
{
    return ProbeWmipDevice(lastError);
}

int main()
{
    if (HWND console = GetConsoleWindow())
    {
        ShowWindow(console, SW_HIDE);
        FreeConsole();
    }

    HRESULT comHr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    LoaderUI loader;
    if (!loader.Create())
    {
        if (SUCCEEDED(comHr))
            CoUninitialize();
        return -1;
    }

    loader.Show();
    loader.RunLoop();
    loader.Destroy();

    if (SUCCEEDED(comHr))
        CoUninitialize();

    return 0;
}
