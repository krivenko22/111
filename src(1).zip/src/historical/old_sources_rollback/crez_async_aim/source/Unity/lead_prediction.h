#pragma once
#include "types.h"
#include <algorithm>
#include <cmath>
namespace LeadPrediction {
inline bool finite(Vector3 v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z);}
// Simple constant-speed intercept, no drag / wind / weapon data. Gravity is an
// optional approximate correction and defaults to zero, not a weapon model.
inline bool Calculate(Vector3 origin,Vector3 target,Vector3 velocity,float speed,float amount,float gravity,Vector3& out){
 out=target;if(!finite(origin)||!finite(target)||!finite(velocity)||!std::isfinite(speed)||!std::isfinite(amount)||!std::isfinite(gravity)||speed<50||speed>1200||amount<0||amount>1.25f||gravity<0||gravity>20)return false;
 float v2=velocity.x*velocity.x+velocity.y*velocity.y+velocity.z*velocity.z;if(v2>625.f)return false;
 Vector3 r{target.x-origin.x,target.y-origin.y,target.z-origin.z};
 float d2=r.x*r.x+r.y*r.y+r.z*r.z;if(!std::isfinite(d2)||d2<1.f||d2>25000000.f)return false;
 float a=v2-speed*speed,b=2*(r.x*velocity.x+r.y*velocity.y+r.z*velocity.z),disc=b*b-4*a*d2;
 if(!std::isfinite(disc)||disc<0||std::abs(a)<.001f)return false;
 float t=(-b-std::sqrt(disc))/(2*a);if(!std::isfinite(t)||t<=0||t>1.5f)return false;
 Vector3 delta{velocity.x*t*amount,velocity.y*t*amount+.5f*gravity*t*t*amount,velocity.z*t*amount};
 float shift=std::sqrt(delta.x*delta.x+delta.y*delta.y+delta.z*delta.z);if(!std::isfinite(shift)||shift>12.f)return false;
 out={target.x+delta.x,target.y+delta.y,target.z+delta.z};return finite(out);
}
}
