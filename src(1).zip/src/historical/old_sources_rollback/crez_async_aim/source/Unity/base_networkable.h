#pragma once
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "types.h"
#include "transform_position.h"
#include "Offsets.h"
#include "decryptors.h"
#include "world_to_screen.h"
#include "Driver/Driver.h"
#include "BaseNpc.h"
#include "BasePlayer.h"
#include "flags.h"
#include <vector>
#include <chrono>
#include <thread>
#include <mutex>
#include <atomic>
#include <cmath>
#include <cstring>
#include <type_traits>
#include <unordered_map>
#include <string>
#include <utility>
#include <cstdio>

extern uintptr_t gBase;

struct PlayerRenderData {
    uintptr_t entityId{};
    Vector3 position{};
    Vector3 velocity{};
    bool velocityValid{}; // false when the position was reused after a failed read
    bool valid{};
    bool isSleeping{};
    bool isNpc{};
    bool isAlive{};
    bool isWounded{};
    bool isCrawling{};
    bool isDucked{};
    bool isMounted{};
    char name[64]{};
};

struct SnapshotStats {
    int chainStage = 0; // deepest successful stage, 10 means array located
    int entityCount = 0, badPointer = 0, rejected = 0, notAlive = 0, badPosition = 0;
    int classMatches = 0, badModel = 0, positionRoot = 0, positionFeet = 0;
    bool typeInfoVerified = false, arrayReadFailed = false;
};
struct RenderSnapshot {
    std::vector<PlayerRenderData> players;
    std::chrono::steady_clock::time_point time{};
    SnapshotStats stats{};
};

inline void safe_strcpy(char* dest, size_t dest_size, const char* src) {
    if (!dest || dest_size == 0) return;
    if (!src) { dest[0] = '\0'; return; }
    size_t i = 0;
    while (i < dest_size - 1 && src[i] != '\0') { dest[i] = src[i]; ++i; }
    dest[i] = '\0';
}

class BaseNetworkable {
public:
    BaseNetworkable() {
        playerBuffers[0].reserve(256);
        playerBuffers[1].reserve(256);
        threadRunning.store(true, std::memory_order_release);
        updateThread = std::thread(&BaseNetworkable::UpdateLoop, this);
    }

    std::vector<uintptr_t> GetCachedEntities() {
        std::lock_guard<std::mutex> lock(entityMutex);
        return cachedEntities;
    }

    static BaseNetworkable& Get() {
        static BaseNetworkable instance;
        return instance;
    }

    ~BaseNetworkable() {
        threadRunning.store(false, std::memory_order_release);
        if (updateThread.joinable()) updateThread.join();
    }

    void GetSnapshot(RenderSnapshot& snap) {
        std::lock_guard<std::mutex> lock(bufferSwapMutex);
        snap.players = playerBuffers[readBufferIdx];
        snap.time = bufferTimes[readBufferIdx];
        snap.stats = bufferStats[readBufferIdx];
    }
    RenderSnapshot GetSnapshot() {
        RenderSnapshot snap;
        GetSnapshot(snap);
        return snap;
    }

private:
    uintptr_t cachedEntityList = 0;
    int cachedSize = 0;
    std::chrono::steady_clock::time_point lastBufferUpdate{};
    std::chrono::steady_clock::time_point bufferTimes[2];
    SnapshotStats bufferStats[2]{};
    int chainStage = 0;

    std::vector<uintptr_t> cachedEntities;
    std::mutex entityMutex;

    static constexpr int BUFFER_UPDATE_MS = 250;
    static constexpr int PTR_BLOCK = 64;
    static constexpr int UPDATE_US = 5000; // target 200 Hz; actual rate depends on reads and scheduling
    static constexpr float VELOCITY_ALPHA = 0.5f;
    static constexpr float VELOCITY_DECAY = 0.85f;
    static constexpr float MAX_VELOCITY_SQ = 3600.0f;
    static constexpr float TELEPORT_DISTANCE_SQ = 10000.0f;
    static constexpr int NAME_CACHE_SECONDS = 2;

    struct PtrBlock {
        uintptr_t ptr[PTR_BLOCK];
    };

    static_assert(std::is_trivially_copyable<PtrBlock>::value);
    static_assert(sizeof(PtrBlock) == PTR_BLOCK * sizeof(uintptr_t));

    struct VelocityState {
        Vector3 lastPosition{};
        Vector3 velocity{};
        std::chrono::steady_clock::time_point lastTime{};
        std::chrono::steady_clock::time_point lastMovedTime{};
        std::chrono::steady_clock::time_point lastPositionRead{};
        bool initialized{ false };
    };

    std::unordered_map<uintptr_t, std::pair<std::string, std::chrono::steady_clock::time_point>> nameCache;
    std::vector<PlayerRenderData> playerBuffers[2];
    int readBufferIdx = 0;
    std::mutex bufferSwapMutex;
    std::thread updateThread;
    std::atomic<bool> threadRunning{ false };
    std::unordered_map<uintptr_t, VelocityState> velocityCache;
    std::unordered_map<uintptr_t, int> playerClassCache;
    uintptr_t playerTypeInfo = 0;
    std::chrono::steady_clock::time_point lastTypeInfoCheck{}, lastClassCacheClear{};

    // Target build candidate: script metadata slot for BasePlayer. Confirm its
    // runtime name before trusting the pointer; parent layout is still unverified.
    uintptr_t GetVerifiedPlayerType() {
        const auto now = std::chrono::steady_clock::now();
        if (lastTypeInfoCheck.time_since_epoch().count() &&
            now - lastTypeInfoCheck < std::chrono::seconds(2)) return playerTypeInfo;
        lastTypeInfoCheck = now;
        if (!lastClassCacheClear.time_since_epoch().count() || now - lastClassCacheClear >= std::chrono::seconds(4)) {
            playerClassCache.clear(); lastClassCacheClear = now;
        }
        uintptr_t type = 0, name = 0; char text[11]{};
        if (!gBase || !kernelHandler.read_memory(gBase + 0xF116310, reinterpret_cast<uint64_t>(&type), sizeof(type)) ||
            !Decryption::is_valid_ptr(type) ||
            !kernelHandler.read_memory(type + offsets::klass_layout::name_ptr, reinterpret_cast<uint64_t>(&name), sizeof(name)) ||
            !Decryption::is_valid_ptr(name) ||
            !kernelHandler.read_memory(name, reinterpret_cast<uint64_t>(text), sizeof(text)) ||
            std::memcmp(text, "BasePlayer", 11) != 0) type = 0;
        if (type != playerTypeInfo) { playerTypeInfo = type; playerClassCache.clear(); }
        return playerTypeInfo;
    }

    // Return 1 for a matching class, 0 for a verified non-player, -1 on
    // incomplete metadata. No guessed class is promoted to player.
    int ClassifyPlayer(uintptr_t ent, uintptr_t basePlayerType) {
        uintptr_t klass = 0;
        if (!kernelHandler.read_memory(ent, reinterpret_cast<uint64_t>(&klass), sizeof(klass)) ||
            !Decryption::is_valid_ptr(klass)) return -1;
        auto it = playerClassCache.find(klass);
        if (it != playerClassCache.end()) return it->second;
        const auto remember = [&](int result) { if (result >= 0 && playerClassCache.size() < 4096) playerClassCache[klass] = result; return result; };
        uintptr_t cur = klass;
        for (int depth = 0; depth < 16; ++depth) {
            if (!Decryption::is_valid_ptr(cur)) return remember(-1);
            if (basePlayerType && cur == basePlayerType) return remember(1);
            if (!basePlayerType) {
                uintptr_t name = 0; char text[11]{};
                if (!kernelHandler.read_memory(cur+offsets::klass_layout::name_ptr, reinterpret_cast<uint64_t>(&name), sizeof(name)) ||
                    !Decryption::is_valid_ptr(name) || !kernelHandler.read_memory(name, reinterpret_cast<uint64_t>(text), sizeof(text))) return remember(-1);
                if (!std::memcmp(text, "BasePlayer", 11)) return remember(1);
            }
            uintptr_t parent = 0;
            if (!kernelHandler.read_memory(cur+offsets::klass_layout::parent, reinterpret_cast<uint64_t>(&parent), sizeof(parent))) return remember(-1);
            if (!parent) return remember(0);
            if (parent == cur) return remember(-1);
            cur = parent;
        }
        return remember(-1);
    }

    bool FindEntityBuffer(uintptr_t& outListPtr, int& outSize) {
        outListPtr = 0;
        outSize = 0;
        chainStage = 0;
        if (!gBase) return false;
        chainStage = 1;

        // 1. BaseNetworkable Static Class
        uintptr_t bnClass = kernelHandler.readmem<uintptr_t>(gBase + offsets::rust_globals::base_networkable_static);
        if (!Decryption::is_valid_ptr(bnClass)) return false;
        chainStage = 2;

        // 2. Static Fields (0xB8)
        uintptr_t staticFields = kernelHandler.readmem<uintptr_t>(bnClass + offsets::klass_layout::static_fields);
        if (!Decryption::is_valid_ptr(staticFields)) return false;
        chainStage = 3;

        // 3. Client Entities Wrapper (BaseNetworkableStatic statics slot 0x38, build 2636 — proven from .cctor 0x4B26010)
        uintptr_t clientEntitiesWrapper = kernelHandler.readmem<uintptr_t>(staticFields + 0x38);
        if (!Decryption::is_valid_ptr(clientEntitiesWrapper)) return false;
        chainStage = 4;

        // 4. Decrypt to get EntityRealm
        uintptr_t entityRealm = Decryption::client_entities(clientEntitiesWrapper);
        if (!Decryption::is_valid_ptr(entityRealm)) return false;
        chainStage = 5;

        // 5. Entity List Wrapper (EntityRealm::entityList = 0x18)
        uintptr_t entityListWrapper = kernelHandler.readmem<uintptr_t>(entityRealm + 0x18);
        if (!Decryption::is_valid_ptr(entityListWrapper)) return false;
        chainStage = 6;

        // 6. Decrypt to get ListDictionary
        uintptr_t listDict = Decryption::entity_list(entityListWrapper);
        if (!Decryption::is_valid_ptr(listDict)) return false;
        chainStage = 7;

        // 7. Values List (ListDictionary::values = 0x18, build 2636 — proven: get_Count 0x4B24B60 reads [[dict+0x18]+0x18],
        //    Clear 0x4B247E0 resets count/_items there; +0x20 is the reverse Dictionary, NOT a List)
        uintptr_t bufferList = kernelHandler.readmem<uintptr_t>(listDict + 0x18);
        if (!Decryption::is_valid_ptr(bufferList)) return false;
        chainStage = 8;

        // 8. Read Size and Array (System.List: _size = 0x18, _items = 0x10)
        int size = kernelHandler.readmem<int>(bufferList + 0x18);
        if (size <= 0 || size > 10000) return false;
        chainStage = 9;

        uintptr_t arrayObj = kernelHandler.readmem<uintptr_t>(bufferList + 0x10);
        if (!Decryption::is_valid_ptr(arrayObj)) return false;

        // Check declared IL2CPP array capacity before the bulk read.
        uint64_t capacity = 0;
        if (!kernelHandler.read_memory(arrayObj + 0x18, reinterpret_cast<uint64_t>(&capacity), sizeof(capacity)) ||
            capacity < static_cast<uint64_t>(size) || capacity > 1000000) return false;
        // 9. Array Data (System.Array: first element = 0x20)
        uintptr_t arrayData = arrayObj + 0x20;
        if (!Decryption::is_valid_ptr(arrayData)) return false;

        chainStage = 10;
        outListPtr = arrayData;
        outSize = size;
        return true;
    }

    bool UpdateBufferIfNeeded() {
        const auto now = std::chrono::steady_clock::now();
        const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastBufferUpdate).count();
        const bool needUpdate = !Decryption::is_valid_ptr(cachedEntityList) || cachedSize <= 0 || elapsed >= BUFFER_UPDATE_MS;
        if (!needUpdate) return true;

        uintptr_t newList = 0;
        int newSize = 0;
        if (FindEntityBuffer(newList, newSize)) {
            cachedEntityList = newList;
            cachedSize = newSize;
            lastBufferUpdate = now;
            return true;
        }
        // A stale list can outlive its game allocation. Drop it after 250ms.
        if (elapsed > 250) {
            cachedEntityList = 0; cachedSize = 0;
            std::lock_guard<std::mutex> lock(entityMutex);
            cachedEntities.clear();
        }
        return Decryption::is_valid_ptr(cachedEntityList) && cachedSize > 0;
    }

    bool ReadEntityPointers(uintptr_t arrayData, int count, std::vector<uintptr_t>& out) {
        if (count <= 0) { out.clear(); return false; }
        if (out.capacity() < static_cast<size_t>(count)) out.reserve(count);
        out.resize(count);

        // Bulk copy replaces dozens of one-pointer IOCTLs per update.
        if (!kernelHandler.read_memory(arrayData, reinterpret_cast<uint64_t>(out.data()),
                                       static_cast<size_t>(count) * sizeof(uintptr_t))) {
            out.clear(); return false;
        }

        return true;
    }

    void FillPlayerName(uintptr_t ent, PlayerRenderData& rd) {
        const auto now = std::chrono::steady_clock::now();
        auto it = nameCache.find(ent);

        if (it != nameCache.end()) {
            const auto age = std::chrono::duration_cast<std::chrono::seconds>(now - it->second.second).count();
            if (age < NAME_CACHE_SECONDS) {
                safe_strcpy(rd.name, sizeof(rd.name), it->second.first.c_str());
                return;
            }
        }

        Game::BasePlayer bp(ent);
        std::string name = bp.ReadPlayerName();
        nameCache[ent] = { name, now };

        safe_strcpy(rd.name, sizeof(rd.name), name.c_str());
    }

    void UpdateLoop() {
        std::vector<uintptr_t> entityCache;
        entityCache.reserve(1024);
        // Spread expensive class checks across frames; update old candidates'
        // positions meanwhile and replace the list only when a scan completes.
        std::vector<uintptr_t> candidates, nextCandidates;
        size_t scanIndex = 0;
        bool scanRunning = false;
        std::chrono::steady_clock::time_point lastScan{}, lastScanStep{};
        SnapshotStats scanStats{}, nextStats{};

        while (threadRunning.load(std::memory_order_relaxed)) {
            const auto startTime = std::chrono::steady_clock::now();

            UpdateBufferIfNeeded();
            SnapshotStats stats{};
            stats.chainStage = chainStage;
            stats.entityCount = cachedSize;
            const uintptr_t basePlayerType = cachedSize > 0 ? GetVerifiedPlayerType() : 0;
            stats.typeInfoVerified = basePlayerType != 0;

            int writeIdx;
            {
                std::lock_guard<std::mutex> lock(bufferSwapMutex);
                writeIdx = 1 - readBufferIdx;
            }

            auto& out = playerBuffers[writeIdx];
            out.clear();
            if (out.capacity() < 256) out.reserve(256);

            if (Decryption::is_valid_ptr(cachedEntityList) && cachedSize > 0) {
                const bool scanDue = !lastScan.time_since_epoch().count() ||
                    startTime - lastScan >= std::chrono::milliseconds(250);
                if (!scanRunning && scanDue) {
                    if (ReadEntityPointers(cachedEntityList, cachedSize, entityCache)) {
                        { std::lock_guard<std::mutex> lock(entityMutex); cachedEntities = entityCache; }
                        nextCandidates.clear(); nextStats = {}; scanIndex = 0; scanRunning = true; lastScanStep = {};
                    } else {
                        stats.arrayReadFailed = true;
                        if (lastScan.time_since_epoch().count() && startTime-lastScan > std::chrono::milliseconds(1500)) candidates.clear();
                    }
                }
                if (scanRunning && (!lastScanStep.time_since_epoch().count() || startTime-lastScanStep >= std::chrono::milliseconds(40))) {
                    lastScanStep = startTime;
                    const size_t end = (std::min)(scanIndex + size_t(64), entityCache.size());
                    while (scanIndex < end) {
                        uintptr_t ent = entityCache[scanIndex++];
                        if (!Decryption::is_valid_ptr(ent)) { ++nextStats.badPointer; continue; }
                        const int result = ClassifyPlayer(ent, basePlayerType);
                        if (result == 1) ++nextStats.classMatches;
                        else if (result == 0 || Game::BasePlayer(ent).IsGarbage()) { ++nextStats.rejected; continue; }
                        nextCandidates.push_back(ent);
                    }
                    if (scanIndex == entityCache.size()) {
                        candidates.swap(nextCandidates); scanStats = nextStats;
                        lastScan = startTime; scanRunning = false;
                    }
                }
                stats.badPointer=scanStats.badPointer; stats.rejected=scanStats.rejected; stats.classMatches=scanStats.classMatches;
                for (uintptr_t ent : candidates) {
                    // Guard against an old entity address being recycled between scans.
                    const int classResult = ClassifyPlayer(ent, basePlayerType);
                    if (classResult != 1 && (classResult == 0 || Game::BasePlayer(ent).IsGarbage())) continue;
                    Game::BasePlayer bp(ent);

                        const uint32_t playerFlags = PlayerFlagsUtils::GetPlayerFlags(ent);
                        const uint32_t modelFlags = PlayerFlagsUtils::GetModelStateFlags(ent);
                        const bool isSleeping = (playerFlags & offsets::base_player_flags::Sleeping) || (modelFlags & offsets::modelstate_flags::Sleeping);
                        const bool isWounded = (playerFlags & offsets::base_player_flags::Wounded) != 0;
                        const bool isCrawling = (modelFlags & offsets::modelstate_flags::crawling) != 0;
                        const bool isDucked = (modelFlags & offsets::modelstate_flags::ducked) != 0;
                        const bool isMounted = (modelFlags & offsets::modelstate_flags::Mounted) != 0;

                        if (!PlayerFlagsUtils::IsAlive(ent)) { ++stats.notAlive; continue; }

                        // Old userid/model offsets misclassify this build. Treat
                        // type-confirmed candidates as players until NPC typing is verified.
                        const bool isNpc = classResult == 1 ? false : BaseNpcUtils::IsNpc(ent);

                        Vector3 pos{};
                        uintptr_t pModel = kernelHandler.readmem<uintptr_t>(ent + offsets::base_entity::model);
                        if (!Decryption::is_valid_ptr(pModel)) ++stats.badModel;
                        auto readTransform = [](uint64_t address, void* dst, size_t size) {
                            return kernelHandler.read_memory(address, reinterpret_cast<uint64_t>(dst), size);
                        };
                        uintptr_t root = Decryption::is_valid_ptr(pModel) ? kernelHandler.readmem<uintptr_t>(pModel + offsets::model::rootBone) : 0;
                        bool posOk = TransformPosition::WorldPosition(readTransform, root, pos);
                        if (posOk) ++stats.positionRoot;
                        if (!posOk) {
                            uintptr_t arr = Decryption::is_valid_ptr(pModel) ? kernelHandler.readmem<uintptr_t>(pModel + offsets::model::boneTransforms) : 0;
                            uint64_t n = 0; Vector3 feet[2]{}; int found = 0;
                            if (Decryption::is_valid_ptr(arr) && kernelHandler.read_memory(arr+0x18, reinterpret_cast<uint64_t>(&n), sizeof(n)) && n > offsets::model::r_foot && n < 512) {
                                for (auto i : {offsets::model::l_foot, offsets::model::r_foot}) {
                                    uintptr_t foot = kernelHandler.readmem<uintptr_t>(arr+0x20+8*i);
                                    if (TransformPosition::WorldPosition(readTransform, foot, feet[found])) ++found;
                                }
                            }
                            if (found) { pos = feet[0]; if (found == 2) pos = {(feet[0].x+feet[1].x)*.5f,(feet[0].y+feet[1].y)*.5f,(feet[0].z+feet[1].z)*.5f}; posOk = true; ++stats.positionFeet; }
                        }
                        if (!posOk) {
                            ++stats.badPosition;
                            const auto prev = velocityCache.find(ent);
                            const auto now = std::chrono::steady_clock::now();
                            if (prev == velocityCache.end() || !prev->second.lastPositionRead.time_since_epoch().count() ||
                                now-prev->second.lastPositionRead > std::chrono::milliseconds(150)) continue;
                            pos = prev->second.lastPosition;
                        }

                        PlayerRenderData rd{};
                        rd.entityId = ent;
                        rd.position = pos;
                        rd.velocity = Vector3{};
                        rd.valid = true;
                        rd.isSleeping = isSleeping;
                        rd.isNpc = isNpc;
                        rd.isAlive = true;
                        rd.isWounded = isWounded;
                        rd.isCrawling = isCrawling;
                        rd.isDucked = isDucked;
                        rd.isMounted = isMounted;

                        // Display-name offset is unverified for this build.
                        if (classResult == 1) safe_strcpy(rd.name, sizeof(rd.name), "Player");
                        else FillPlayerName(ent, rd);

                        auto& vs = velocityCache[ent];
                        auto entityTime = std::chrono::steady_clock::now();
                        if (posOk) vs.lastPositionRead = entityTime;

                        if (rd.isSleeping) {
                            vs.lastPosition = pos;
                            vs.lastTime = entityTime;
                            vs.lastMovedTime = entityTime;
                            vs.velocity = Vector3{};
                            vs.initialized = true;
                        }
                        else if (!vs.initialized) {
                            vs.lastPosition = pos;
                            vs.lastTime = entityTime;
                            vs.lastMovedTime = entityTime;
                            vs.velocity = Vector3{};
                            vs.initialized = true;
                        }
                        else {
                            float dx = pos.x - vs.lastPosition.x;
                            float dy = pos.y - vs.lastPosition.y;
                            float dz = pos.z - vs.lastPosition.z;
                            float distSq = dx * dx + dy * dy + dz * dz;

                            if (distSq > 0.0001f) {
                                float dt = std::chrono::duration<float>(entityTime - vs.lastTime).count();

                                if (distSq > TELEPORT_DISTANCE_SQ) {
                                    vs.velocity = Vector3{};
                                }
                                else if (dt > 0.001f && dt < 1.0f) {
                                    Vector3 raw{};
                                    raw.x = dx / dt;
                                    raw.y = dy / dt;
                                    raw.z = dz / dt;

                                    float speedSq = raw.x * raw.x + raw.y * raw.y + raw.z * raw.z;

                                    if (std::isfinite(raw.x) && std::isfinite(raw.y) && std::isfinite(raw.z) &&
                                        speedSq <= MAX_VELOCITY_SQ) {
                                        vs.velocity.x = vs.velocity.x + (raw.x - vs.velocity.x) * VELOCITY_ALPHA;
                                        vs.velocity.y = vs.velocity.y + (raw.y - vs.velocity.y) * VELOCITY_ALPHA;
                                        vs.velocity.z = vs.velocity.z + (raw.z - vs.velocity.z) * VELOCITY_ALPHA;
                                    }
                                }

                                vs.lastPosition = pos;
                                vs.lastTime = entityTime;
                                vs.lastMovedTime = entityTime;
                            }
                            else {
                                float timeSinceMoved = std::chrono::duration<float>(entityTime - vs.lastMovedTime).count();

                                if (timeSinceMoved > 0.15f) {
                                    vs.velocity.x *= VELOCITY_DECAY;
                                    vs.velocity.y *= VELOCITY_DECAY;
                                    vs.velocity.z *= VELOCITY_DECAY;

                                    float speedSq = vs.velocity.x * vs.velocity.x + vs.velocity.y * vs.velocity.y + vs.velocity.z * vs.velocity.z;
                                    if (speedSq < 0.01f) {
                                        vs.velocity = Vector3{};
                                    }
                                }
                            }
                        }

                        rd.velocity = vs.velocity;
                        rd.velocityValid = posOk;
                        out.push_back(rd);
                }
            } else {
                candidates.clear(); nextCandidates.clear(); scanRunning = false; lastScan = {}; scanStats = {};
            }

            if (velocityCache.size() > 5000) velocityCache.clear();
            if (nameCache.size() > 5000) nameCache.clear();

            bufferTimes[writeIdx] = std::chrono::steady_clock::now();
            bufferStats[writeIdx] = stats;

            {
                std::lock_guard<std::mutex> lock(bufferSwapMutex);
                readBufferIdx = writeIdx;
            }
            const auto endTime = std::chrono::steady_clock::now();
            const auto elapsed = std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime).count();

            const int targetUs = cachedSize > 0 ? UPDATE_US : 200000;
            if (elapsed < targetUs) {
                std::this_thread::sleep_for(std::chrono::microseconds(targetUs - elapsed));
            }
            else {
                std::this_thread::yield();
            }
        }
    }
};