#pragma once
#include "types.h"
#include <cstdint>
#include <cmath>
#include <cstring>

// Candidate Unity native transform layout; not validated against this build.
namespace TransformPosition {
struct Matrix {float px,py,pz,pw,qx,qy,qz,qw,sx,sy,sz,sw;};
static_assert(sizeof(Matrix)==48);
inline bool validptr(uint64_t p){return p>=0x10000 && p<0x7ffffffff000ULL;}
inline bool validpos(const Vector3& p){return std::isfinite(p.x)&&std::isfinite(p.y)&&std::isfinite(p.z)&&std::abs(p.x)<=8000.f&&std::abs(p.z)<=8000.f&&std::abs(p.y)<=2000.f;}
template<class Read,class T> bool get(Read& read,uint64_t a,T& v){v={};return validptr(a)&&read(a,&v,sizeof(v));}
// Bundle adjacent Unity layout fields; retry separately if a contiguous read
// crosses an unreadable boundary or the backend rejects the larger request.
template<class Read> bool ReadLayout(Read& read,uint64_t managed,uint64_t& mats,uint64_t& parents,int32_t& idx){
 uint64_t native=0,data=0;mats=parents=0;idx=-1;
 if(!validptr(managed)||!get(read,managed+0x10,native)||!validptr(native))return false;
 unsigned char nativeFields[12]{};
 if(read(native+0x28,nativeFields,sizeof(nativeFields))){std::memcpy(&data,nativeFields,8);std::memcpy(&idx,nativeFields+8,4);}
 else if(!get(read,native+0x28,data)||!get(read,native+0x30,idx))return false;
 if(!validptr(data)||idx<0||idx>=4096)return false;
 unsigned char dataFields[16]{};
 if(read(data+0x18,dataFields,sizeof(dataFields))){std::memcpy(&mats,dataFields,8);std::memcpy(&parents,dataFields+8,8);}
 else if(!get(read,data+0x18,mats)||!get(read,data+0x20,parents))return false;
 return validptr(mats)&&validptr(parents);
}
template<class Read> bool WorldPosition(Read read,uint64_t managed,Vector3& out){
 out={};uint64_t mats=0,parents=0;int32_t idx=-1;
 if(!ReadLayout(read,managed,mats,parents,idx))return false;
 Matrix current{};if(!get(read,mats+uint64_t(idx)*48,current))return false;
 Vector3 pos{current.px,current.py,current.pz};if(!validpos(pos))return false;
 int32_t visited[128];int count=0;
 for(;;){
  if(count==128)return false;
  for(int j=0;j<count;j++)if(visited[j]==idx)return false;
  visited[count++]=idx;int32_t parent=-1;if(!get(read,parents+uint64_t(idx)*4,parent))return false;
  if(parent==-1)break;
  if(parent<0||parent>=4096)return false;
  Matrix m{};if(!get(read,mats+uint64_t(parent)*48,m))return false;
  const float q2=m.qx*m.qx+m.qy*m.qy+m.qz*m.qz+m.qw*m.qw;
  if(!std::isfinite(q2)||q2<0.8f||q2>1.2f||!std::isfinite(m.sx)||!std::isfinite(m.sy)||!std::isfinite(m.sz)||std::abs(m.sx)>1000||std::abs(m.sy)>1000||std::abs(m.sz)>1000)return false;
  float x=pos.x*m.sx,y=pos.y*m.sy,z=pos.z*m.sz;
  float tx=2*(m.qy*z-m.qz*y),ty=2*(m.qz*x-m.qx*z),tz=2*(m.qx*y-m.qy*x);
  pos={m.px+x+m.qw*tx+(m.qy*tz-m.qz*ty),m.py+y+m.qw*ty+(m.qz*tx-m.qx*tz),m.pz+z+m.qw*tz+(m.qx*ty-m.qy*tx)};
  if(!validpos(pos))return false;
  idx=parent;
 }
 out=pos;return true;
}
}
