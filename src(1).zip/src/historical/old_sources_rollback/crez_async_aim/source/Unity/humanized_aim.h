#pragma once
#include "srcoaw_aim_core.h"
#include <algorithm>
#include <cmath>

namespace HumanizedAim {
// Bounded speed variation and reduced vertical correction while yawing.
// This does not guarantee human-like behavior or conceal automated input.
struct State {
    float vx=0.f, vy=0.f, rx=0.f, ry=0.f, phase=0.f;
    void Reset() { vx=vy=rx=ry=phase=0.f; }
};
inline SrcoawAimCore::Movement Step(float dx, float dy, float gain, float smoothing,
                                     float radius, float dt, State& s) {
    const float distance=std::hypot(dx,dy);
    if(!std::isfinite(dx)||!std::isfinite(dy)||!std::isfinite(gain)||!std::isfinite(smoothing)||
       !std::isfinite(radius)||!std::isfinite(dt)||gain<0.f||smoothing<1.f||radius<=0.f||dt<=0.f||dt>.1f){
        s.Reset(); return {};
    }
    const float smoothingBlend=(std::max)(0.f,(std::min)(1.f,(smoothing-1.f)/4.f));
    const float fovRatio=(std::min)(1.f,distance/radius);
    const float divisor=smoothing*(1.f+4.f*smoothingBlend*fovRatio);
    dt=(std::min)(dt, .033f);
    s.phase=std::fmod(s.phase+dt, 100.f);
    const float variation=1.f+.07f*std::sin(12.7f*s.phase)+.03f*std::sin(5.7f*s.phase);
    const float alpha=1.f-std::exp(-dt/(.020f+.035f*smoothingBlend));
    const float pitchScale=std::abs(dx)<2.f ? 1.f :
        .20f+.80f*std::abs(dy)/(std::abs(dx)+std::abs(dy)+1.f);
    auto axis=[&](float error,float scale,float& velocity,float& residual){
        if(std::abs(error)<2.f){velocity=residual=0.f;return 0;}
        if(velocity*error<0.f) velocity=residual=0.f;
        const float desired=(std::max)(-1600.f,(std::min)(1600.f,error*gain*600.f/divisor*scale*variation));
        velocity+=(desired-velocity)*alpha;
        if(std::abs(velocity)>std::abs(desired))velocity=desired;
        float step=velocity*dt+residual;
        step=(std::max)(-32.f,(std::min)(32.f,step));
        int sent=static_cast<int>(std::lround(step));
        if(sent*error<0.f)sent=0;
        residual=step-sent;
        return sent;
    };
    return {axis(dx,1.f,s.vx,s.rx),axis(dy,pitchScale,s.vy,s.ry)};
}
}
