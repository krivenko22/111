#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <windows.h>
#include <vector>
#include <memory>
#include <string>
#include <cmath>
#include <cstddef>
#include <algorithm>

#include "Feature.h"
#include "RenderFeature.h"
#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"

class ModuleManager
{
private:
    std::vector<std::shared_ptr<Module>> modules;

    struct ModuleAnimation
    {
        float hover = 0.0f;
        float press = 0.0f;
        float enabled = 0.0f;
        float expanded = 0.0f;
        float contentHeight = 0.0f;
        float layoutHeight = 0.0f;
    };

    std::vector<ModuleAnimation> animations;

    static float Clamp01(float value)
    {
        if (value < 0.0f)
            return 0.0f;

        if (value > 1.0f)
            return 1.0f;

        return value;
    }

    static float Smooth(
        float current,
        float target,
        float speed,
        float dt
    )
    {
        if (dt <= 0.0f)
            return current;

        const float factor =
            1.0f -
            std::exp(
                -speed * dt
            );

        return current +
            (target - current) * factor;
    }

    static void ResetCursorMaxY()
    {
        ImGuiWindow* window =
            ImGui::GetCurrentWindow();

        if (!window)
            return;

        window->DC.CursorMaxPos.y =
            window->DC.CursorPos.y;

        window->DC.IdealMaxPos.y =
            window->DC.CursorPos.y;
    }

    void EnsureAnimationCount()
    {
        while (animations.size() < modules.size())
            animations.emplace_back();
    }

    void RenderModuleHeader(const std::shared_ptr<Module>& mod, std::size_t index)
    {
        if (!mod) return;
        EnsureAnimationCount();
        ModuleAnimation& anim=animations[index];
        const float alpha=Clamp01(ImGui::GetStyle().Alpha);
        const float dt=ImClamp(ImGui::GetIO().DeltaTime,0.f,.05f);
        const float width=ImMax(40.f,ImGui::GetContentRegionAvail().x);
        constexpr float height=38.f, arrowWidth=34.f;
        const bool expandable=!mod->IsMenuExpansionLocked();
        const float bodyWidth=ImMax(40.f,expandable ? width-arrowWidth-4.f : width);
        ImGui::PushID(static_cast<int>(index));
        ImGui::InvisibleButton("##ModuleBody",ImVec2(bodyWidth,height));
        const bool hovered=ImGui::IsItemHovered();
        if(ImGui::IsItemClicked(ImGuiMouseButton_Left))mod->enabled=!mod->enabled;
        if(ImGui::IsItemClicked(ImGuiMouseButton_Right))mod->ToggleMenuExpanded();
        const ImVec2 min=ImGui::GetItemRectMin();
        const ImVec2 bodyMax(min.x+bodyWidth,min.y+height);
        bool arrowHover=false;
        if (expandable) {
            ImGui::SameLine(0.f,4.f);
            if(ImGui::InvisibleButton("##Expand",ImVec2(arrowWidth,height)))mod->ToggleMenuExpanded();
            arrowHover=ImGui::IsItemHovered();
        }
        anim.expanded=Smooth(anim.expanded,mod->IsMenuExpanded()?1.f:0.f,14.f,dt);
        ImDrawList* draw=ImGui::GetWindowDrawList();
        if(draw){
            const ImVec2 max(min.x+width,min.y+height);
            const float shade=(hovered||arrowHover)? .105f : .080f;
            draw->AddRectFilled(min,max,ImGui::ColorConvertFloat4ToU32(ImVec4(shade,shade,shade+.002f,alpha)),4.f);
            ImVec4 marker=mod->enabled?RenderFeature::ACCENT:RenderFeature::TEXT_MUTED;
            marker.w=alpha*(mod->enabled?1.f:.55f);
            draw->AddCircleFilled(ImVec2(min.x+13.f,min.y+height*.5f),3.f,ImGui::ColorConvertFloat4ToU32(marker),12);
            const ImVec2 size=ImGui::CalcTextSize(mod->name.c_str());
            ImVec4 text=RenderFeature::TEXT;text.w*=alpha;
            draw->AddText(ImVec2(min.x+25.f,min.y+(height-size.y)*.5f),ImGui::ColorConvertFloat4ToU32(text),mod->name.c_str());
            if (expandable) RenderFeature::DrawChevron(draw,ImVec2(bodyMax.x+4.f+arrowWidth*.5f,min.y+height*.5f),mod->IsMenuExpanded(),alpha,4.f);
        }
        ImGui::PopID();
        ImGui::Dummy(ImVec2(0.f,5.f));
    }

    static const char* CategoryName(
        ModuleCategory category
    )
    {
        switch (category)
        {
        case ModuleCategory::Combat:
            return "";

        case ModuleCategory::Visuals:
            return "";

        default:
            return "";
        }
    }

    void RenderCategoryPanel(
        ModuleCategory category
    )
    {
        std::size_t count = 0;

        for (const auto& mod : modules)
        {
            if (
                mod &&
                mod->category == category
                )
            {
                ++count;
            }
        }

        if (count == 0)
            return;

        float height =
            45.0f +
            static_cast<float>(count) * 55.0f +
            12.0f;

        for (
            std::size_t i = 0;
            i < modules.size();
            ++i
            )
        {
            const auto& mod =
                modules[i];

            if (
                !mod ||
                mod->category != category
                )
            {
                continue;
            }

            if (i >= animations.size())
                continue;

            const ModuleAnimation& animation =
                animations[i];

            height +=
                animation.layoutHeight;

            height += 7.0f;
        }

        const ImVec2 start =
            ImGui::GetCursorScreenPos();

        const float width =
            ImMax(
                0.0f,
                ImGui::GetContentRegionAvail().x
            );

        ImDrawList* draw =
            ImGui::GetWindowDrawList();

        if (draw)
        {
            draw->AddRectFilled(
                start,
                ImVec2(
                    start.x + width,
                    start.y + height
                ),
                ImGui::ColorConvertFloat4ToU32(
                    ImVec4(
                        RenderFeature::GLASS_R,
                        RenderFeature::GLASS_G,
                        RenderFeature::GLASS_B,
                        0.22f *
                        ImGui::GetStyle().Alpha
                    )
                ),
                13.0f
            );

            draw->AddRect(
                ImVec2(
                    start.x + 0.5f,
                    start.y + 0.5f
                ),
                ImVec2(
                    start.x + width - 0.5f,
                    start.y + height - 0.5f
                ),
                ImGui::ColorConvertFloat4ToU32(
                    ImVec4(
                        1.0f,
                        1.0f,
                        1.0f,
                        0.045f *
                        ImGui::GetStyle().Alpha
                    )
                ),
                13.0f,
                ImDrawFlags_RoundCornersAll,
                1.0f
            );
        }

        ImGui::Dummy(
            ImVec2(
                0.0f,
                10.0f
            )
        );

        ImGui::Indent(10.0f);

        ImGui::TextColored(
            ImVec4(
                0.64f,
                0.68f,
                0.78f,
                ImGui::GetStyle().Alpha
            ),
            "%s",
            CategoryName(category)
        );

        ImGui::Dummy(
            ImVec2(
                0.0f,
                5.0f
            )
        );

        for (
            std::size_t i = 0;
            i < modules.size();
            ++i
            )
        {
            const auto& mod =
                modules[i];

            if (
                !mod ||
                mod->category != category
                )
            {
                continue;
            }

            EnsureAnimationCount();

            ModuleAnimation& animation =
                animations[i];

            RenderModuleHeader(
                mod,
                i
            );

            const ImVec2 contentCursor =
                ImGui::GetCursorPos();

            const ImVec2 contentStart =
                ImGui::GetCursorScreenPos();

            const float availableWidth =
                ImMax(
                    0.0f,
                    ImGui::GetContentRegionAvail().x
                );

            const float reveal =
                Clamp01(
                    animation.expanded
                );

            const float easedReveal =
                RenderFeature::EaseOutCubic(
                    reveal
                );

            const float targetHeight =
                animation.contentHeight *
                easedReveal;

            const float layoutSpeed =
                targetHeight <
                animation.layoutHeight
                ? 24.0f
                : 18.0f;

            animation.layoutHeight =
                Smooth(
                    animation.layoutHeight,
                    targetHeight,
                    layoutSpeed,
                    ImGui::GetIO().DeltaTime
                );

            if (
                std::fabs(
                    animation.layoutHeight -
                    targetHeight
                ) < 0.05f
                )
            {
                animation.layoutHeight =
                    targetHeight;
            }

            animation.layoutHeight =
                ImMax(
                    0.0f,
                    animation.layoutHeight
                );

            const float visibleHeight =
                animation.layoutHeight;

            ImGui::PushStyleVar(
                ImGuiStyleVar_Alpha,
                reveal *
                ImGui::GetStyle().Alpha
            );

            ImGui::PushClipRect(
                contentStart,
                ImVec2(
                    contentStart.x +
                    availableWidth,

                    contentStart.y +
                    visibleHeight
                ),
                true
            );

            mod->OnRenderMenu();

            const float measuredHeight =
                ImMax(
                    0.0f,
                    ImGui::GetCursorPos().y -
                    contentCursor.y
                );

            ImGui::PopClipRect();

            ImGui::PopStyleVar();

            if (measuredHeight > 0.0f)
            {
                animation.contentHeight =
                    measuredHeight;
            }

            const float correctedTargetHeight =
                animation.contentHeight *
                easedReveal;

            if (
                std::fabs(
                    correctedTargetHeight -
                    animation.layoutHeight
                ) > 0.01f
                )
            {
                animation.layoutHeight =
                    Smooth(
                        animation.layoutHeight,
                        correctedTargetHeight,
                        correctedTargetHeight <
                        animation.layoutHeight
                        ? 24.0f
                        : 18.0f,
                        ImGui::GetIO().DeltaTime
                    );
            }

            if (
                std::fabs(
                    animation.layoutHeight -
                    correctedTargetHeight
                ) < 0.05f
                )
            {
                animation.layoutHeight =
                    correctedTargetHeight;
            }

            animation.layoutHeight =
                ImMax(
                    0.0f,
                    animation.layoutHeight
                );

            ImGui::SetCursorPos(
                ImVec2(
                    contentCursor.x,
                    contentCursor.y +
                    animation.layoutHeight
                )
            );

            ResetCursorMaxY();

            ImGui::Dummy(
                ImVec2(
                    0.0f,
                    7.0f
                )
            );

            ResetCursorMaxY();
        }

        ImGui::Unindent(10.0f);

        ImGui::Dummy(
            ImVec2(
                0.0f,
                12.0f
            )
        );

        ResetCursorMaxY();
    }

public:
    void RegisterModule(
        std::shared_ptr<Module> mod
    )
    {
        if (!mod)
            return;

        modules.push_back(
            std::move(mod)
        );

        animations.emplace_back();
    }

    void RenderMenu(
        ModuleCategory category
    )
    {
        EnsureAnimationCount();

        const float alpha =
            Clamp01(
                ImGui::GetStyle().Alpha
            );

        if (alpha <= 0.001f)
            return;

        RenderCategoryPanel(
            category
        );

        ResetCursorMaxY();
    }

    void RenderOverlay()
    {
        for (auto& mod : modules)
        {
            if (mod)
                mod->UpdateKeyBind();
        }

        for (auto& mod : modules)
        {
            if (mod)
                mod->OnRenderOverlay();
        }
    }

    const std::vector<
        std::shared_ptr<Module>
    >& GetModules() const
    {
        return modules;
    }
};