#pragma once
#include <string>
#include "types.h"

namespace Prediction
{
    inline float GetProjectileSpeed(float base, const std::string& weapon, float mult)
    {
        if (weapon.empty())
            return 0.f;

        // Rust muzzle velocities, m/s
        float speed = 0.f;
        if (weapon == _xorstr("rifle.ak") || weapon == _xorstr("rifle.ak.ice") ||
            weapon == _xorstr("rifle.ak.diver") || weapon == _xorstr("rifle.ak.jungle") ||
            weapon == _xorstr("rifle.ak.med") || weapon == _xorstr("rifle.semiauto") ||
            weapon == _xorstr("rifle.semiauto.a.m15") || weapon == _xorstr("rifle.abyss") ||
            weapon == _xorstr("rifle.medieval") || weapon == _xorstr("m16a2") ||
            weapon == _xorstr("rifle.m16a2") || weapon == _xorstr("rifle.lr300") ||
            weapon == _xorstr("rifle.lr300.space") || weapon == _xorstr("lmg.m249") ||
            weapon == _xorstr("hmlmg") || weapon == _xorstr("hcr"))
            speed = 375.f;
        else if (weapon == _xorstr("rifle.bolt") || weapon == _xorstr("rifle.l96"))
            speed = 656.f;
        else if (weapon == _xorstr("rifle.m39") || weapon == _xorstr("rifle.sks"))
            speed = 460.f;
        else if (weapon == _xorstr("smg.thompson") || weapon == _xorstr("smg.mp5"))
            speed = 320.f;
        else if (weapon == _xorstr("smg.2"))
            speed = 280.f;
        else if (weapon == _xorstr("bow.hunting"))
            speed = 60.f;
        else if (weapon == _xorstr("crossbow"))
            speed = 75.f;
        else if (weapon == _xorstr("nailgun"))
            speed = 45.f;
        else if (weapon == _xorstr("pistol.python") || weapon == _xorstr("pistol.revolver"))
            speed = 260.f;
        else if (weapon == _xorstr("pistol.eoka"))
            speed = 40.f;
        else if (weapon.find(_xorstr("minigun")) != std::string::npos)
            speed = 375.f;

        return speed * mult;
    }

    // Iterative travel-time solution with gravity drop compensation.
    // Returns the point the caller should aim at (camPos -> returned point = firing direction).
    inline Vector3 PredictPosition(const Vector3& camPos, const Vector3& targetPos,
                                   const Vector3& velocity, const std::string& weapon)
    {
        float speed = GetProjectileSpeed(100.f, weapon, 1.f);
        if (speed <= 0.001f)
            return targetPos;

        constexpr float gravity = 9.81f;
        Vector3 aim = targetPos;

        for (int i = 0; i < 3; i++)
        {
            float dx = aim.x - camPos.x;
            float dy = aim.y - camPos.y;
            float dz = aim.z - camPos.z;
            float t = sqrtf(dx * dx + dy * dy + dz * dz) / speed;
            if (t <= 0.f)
                break;

            Vector3 future{
                targetPos.x + velocity.x * t,
                targetPos.y + velocity.y * t,
                targetPos.z + velocity.z * t
            };
            // compensate drop along the initial aim arc
            float drop = 0.5f * gravity * t * t;
            aim.x = future.x;
            aim.y = future.y + drop;
            aim.z = future.z;
        }
        return aim;
    }
}
