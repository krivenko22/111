#pragma once
#include "Feature.h"
#include "ESP.h"
#include "Feature.h"
#include "RenderFeature.h"
#include "world_to_screen.h"
#include "localplayer.h"
#include "imgui/imgui.h"
#include "playerinventory.h"
#include "iconsmanager.h"
#include "base_networkable.h"
#include <cmath>
#include <cstdio>
#include <cfloat>
#include <algorithm>
#include <vector>
#include <chrono>
#include <unordered_map>

class InventoryEspModule : public Module {
public:
    bool invFilterPlayers = true;
    bool invFilterSleepers = false;
    bool invFilterNpcs = false;

    float invSlotSize = 34.f;
    float invAimRadius = 100.f;
    float maxDistance = 1000.f;

    InventoryOverlay inventoryOverlay;
    IconsManager iconsManager;

    InventoryEspModule() : Module(_xorstr("Inventory ESP")), networkable(BaseNetworkable::Get()) {}
    ~InventoryEspModule() override = default;

    void OnRenderMenu() override {
        RenderFeature::Toggle(this, _xorstr("Включить Inventory ESP"), &enabled, 0);

        bool bindToggle = keybind.mode == KeyBindMode::Toggle;
        RenderFeature::BindButton(this, _xorstr("Bind"), &keybind.key, &bindToggle, 0);
        keybind.mode = bindToggle ? KeyBindMode::Toggle : KeyBindMode::Hold;

        ImGui::Spacing();
        RenderFeature::SectionTitle(("НАСТРОЙКА ИНВЕНТАРЯ ИГРОКОВ"));
        ImGui::Spacing();

        const float revealInventory = RenderFeature::BeginAnimatedGroup(this, _xorstr("InventoryOptions"), enabled, 0, 16.f, 1.f);
        if (revealInventory > 0.001f) {
            RenderFeature::Toggle(this, _xorstr("Инвентарь игроков"), &invFilterPlayers, 14);
            RenderFeature::Toggle(this, _xorstr("Инвентарь спящих"), &invFilterSleepers, 15);
            RenderFeature::Toggle(this, _xorstr("Инвентарь NPC"), &invFilterNpcs, 16);
            RenderFeature::SliderFloat(this, _xorstr("Размер слота инвентаря"), &invSlotSize, 16.f, 64.f, _xorstr("%.0f px"));
            RenderFeature::SliderFloat(this, _xorstr("Радиус срабатывания отрисовки инвентарей от прицела"), &invAimRadius, 25.f, 1500.f, _xorstr("%.0f px"));
            RenderFeature::SliderFloat(this, _xorstr("Максимальная дистанция"), &maxDistance, 100.f, 2000.f, _xorstr("%.0f м"));
        }
        RenderFeature::EndAnimatedGroup(this, _xorstr("InventoryOptions"), 0);
    }

    void OnRenderOverlay() override {
        if (!enabled) return;
        if (!invFilterPlayers && !invFilterSleepers && !invFilterNpcs) return;

        const RenderSnapshot snapshot = networkable.GetSnapshot();
        const auto cam = WorldToScreenUtils::GetCameraSnapshot();
        const ImVec2 displaySize = ImGui::GetIO().DisplaySize;
        const int width = (int)displaySize.x, height = (int)displaySize.y;

        if (!cam.valid || width <= 0 || height <= 0) return;

        ImDrawList* drawList = ImGui::GetBackgroundDrawList();
        if (!drawList) return;

        ImFont* font = ImGui::GetFont();
        if (!font) return;

        const auto& viewMatrix = cam.viewMatrix;
        const auto& camPos = cam.position;

        uintptr_t localPlayerPtr = LocalPlayerUtils::GetLocalPlayerId(snapshot.players);

        std::unordered_map<uintptr_t, ImVec2> invAnchorPoints;
        invAnchorPoints.reserve(snapshot.players.size());

        std::vector<uintptr_t> validInvTargets;
        validInvTargets.reserve(snapshot.players.size());

        for (const auto& pd : snapshot.players) {
            if (!pd.valid || !pd.entityId) continue;
            if (pd.entityId == localPlayerPtr) continue;

            const bool isNpc = pd.isNpc;
            const bool isSleeping = pd.isSleeping;

            bool invAllowed = false;
            if (isNpc) invAllowed = invFilterNpcs;
            else if (isSleeping) invAllowed = invFilterSleepers;
            else invAllowed = invFilterPlayers;

            if (!invAllowed) continue;

            Vector3 pos = pd.position;
            float dx = pos.x - camPos.x;
            float dy = pos.y - camPos.y;
            float dz = pos.z - camPos.z;
            float dist = std::sqrt(dx * dx + dy * dy + dz * dz);
            if (!std::isfinite(dist) || dist > maxDistance) continue;

            Vector3 modelCenterPos = { pos.x, pos.y + (isSleeping ? 0.3f : 0.9f), pos.z };
            ImVec2 screen{};
            if (WorldToScreenUtils::WorldToScreen(modelCenterPos, viewMatrix, screen, width, height) &&
                std::isfinite(screen.x) && std::isfinite(screen.y)) {
                invAnchorPoints.emplace(pd.entityId, screen);
            }

            validInvTargets.push_back(pd.entityId);
        }

        inventoryOverlay.aimRadiusPx = invAimRadius;
        inventoryOverlay.SetTargets(validInvTargets);
        inventoryOverlay.Draw(drawList, font, snapshot, cam, width, height, iconsManager, invSlotSize, invAnchorPoints);
    }

private:
    BaseNetworkable& networkable;
};