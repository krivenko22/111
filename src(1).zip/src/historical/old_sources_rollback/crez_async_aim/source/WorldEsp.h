#pragma once
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "Feature.h"
#include "Offsets.h"
#include "world_to_screen.h"
#include "world.h"
#include "RenderFeature.h"
#include "imgui/imgui.h"
#include "iconsmanager.h"

#include <cmath>
#include <cstdio>
#include <cfloat>
#include <algorithm>
#include <utility>
#include <vector>
#include <string>

enum class WorldBoxStyle {
    None = 0, Box2D = 1, Corners = 2, Box3D = 3, Box2DCircle = 4, Icon = 5
};

class WorldEsp : public Module {
public:
    static inline WorldEsp* s_instance = nullptr;

    WorldEsp() : Module(_xorstr("World ESP")) { s_instance = this; }

    // --- Руды (раздельно) ---
    bool drawOreMetal = true;
    bool drawOreSulfur = true;
    bool drawOreStone = true;
    bool drawOreHqm = true;

    // --- Лошади ---
    bool drawHorse = true;

    // --- Дрова ---
    bool drawWood = true;

    bool  drawNames = true;
    bool  drawDistance = true;
    float maxDistance = 500.f;

    WorldBoxStyle boxStyle = WorldBoxStyle::Icon;
    float         cornerLen = .25f;
    bool          drawOutline = true;

    float iconSize = 24.f;

    float colorMetal[4] = { .80f, .80f, .85f, 1.f };
    float colorSulfur[4] = { 1.00f, .90f, .30f, 1.f };
    float colorStone[4] = { .65f, .65f, .65f, 1.f };
    float colorHqm[4] = { .55f, .80f, 1.00f, 1.f };
    float colorHorse[4] = { .85f, .65f, .35f, 1.f };
    float colorWood[4] = { .85f, .65f, .35f, 1.f };
    float colorDefault[4] = { 1.f, 1.f, 1.f, 1.f };

    static IconsManager& Icons() {
        static IconsManager inst;
        return inst;
    }

    void OnRenderMenu() override
    {
        RenderFeature::Toggle(this, _xorstr("Включить World ESP"), &enabled, 40);

        bool bindToggle = keybind.mode == KeyBindMode::Toggle;
        RenderFeature::BindButton(this, _xorstr("Bind"), &keybind.key, &bindToggle, 40);
        keybind.mode = bindToggle ? KeyBindMode::Toggle : KeyBindMode::Hold;

        ImGui::Spacing();
        RenderFeature::SectionTitle(_xorstr("WORLD ESP"));
        ImGui::Spacing();

        const float reveal = RenderFeature::BeginAnimatedGroup(
            this, _xorstr("WorldESPOptions"), enabled, 0, 8.f, 1.f);

        if (reveal > 0.001f) {
            RenderFeature::SectionTitle(_xorstr("РУДЫ"));
            ImGui::Spacing();
            RenderFeature::Toggle(this, _xorstr("Металлическая руда"), &drawOreMetal, 41);
            RenderFeature::Toggle(this, _xorstr("Серная руда"), &drawOreSulfur, 48);
            RenderFeature::Toggle(this, _xorstr("Каменная руда"), &drawOreStone, 49);
            RenderFeature::Toggle(this, _xorstr("Мвк руда"), &drawOreHqm, 50);

            ImGui::Spacing();
            RenderFeature::SectionTitle(_xorstr("ЖИВОТНЫЕ"));
            ImGui::Spacing();
            RenderFeature::Toggle(this, _xorstr("Лошади"), &drawHorse, 44);

            ImGui::Spacing();
            RenderFeature::SectionTitle(_xorstr("ПРОЧЕЕ"));
            ImGui::Spacing();
            RenderFeature::Toggle(this, _xorstr("Дрова"), &drawWood, 68);

            ImGui::Spacing();
            RenderFeature::Toggle(this, _xorstr("Название"), &drawNames, 45);
            RenderFeature::Toggle(this, _xorstr("Дистанция"), &drawDistance, 46);

            ImGui::Spacing();
            RenderFeature::SliderFloat(this, _xorstr("Дистанция прорисовки"),
                &maxDistance, 50.f, 1000.f, _xorstr("%.0f м"));

            ImGui::Spacing();
            RenderFeature::Toggle(this, _xorstr("Обводка бокса"), &drawOutline, 47);

            ImGui::Spacing();
            RenderFeature::Text(_xorstr("Тип бокса"));
            static const std::string stylesStorage[] = {
                _xorstr("None"),
                _xorstr("2D Box"),
                _xorstr("Corners"),
                _xorstr("3D Box"),
                _xorstr("2D Circle"),
                _xorstr("Icon")
            };

            const char* styles[] = {
                stylesStorage[0].c_str(),
                stylesStorage[1].c_str(),
                stylesStorage[2].c_str(),
                stylesStorage[3].c_str(),
                stylesStorage[4].c_str(),
                stylesStorage[5].c_str()
            };
            int cur = static_cast<int>(boxStyle);
            ImGui::PushID(_xorstr("WorldBoxStyle"));
            if (ImGui::Combo(_xorstr("##WorldBoxStyle"), &cur, styles, IM_ARRAYSIZE(styles))) {
                cur = (std::max)(0, (std::min)(cur, 5));
                boxStyle = static_cast<WorldBoxStyle>(cur);
            }
            ImGui::PopID();

            const float revealCorners = RenderFeature::BeginAnimatedGroup(
                this, _xorstr("WorldCorners"), boxStyle == WorldBoxStyle::Corners, 0, 8.f, 1.f);
            if (revealCorners > 0.001f) {
                RenderFeature::SliderFloat(this, _xorstr("Длина углов"),
                    &cornerLen, .1f, .5f, _xorstr("%.2f"));
            }
            RenderFeature::EndAnimatedGroup(this, _xorstr("WorldCorners"), 0);

            const float revealIcon = RenderFeature::BeginAnimatedGroup(
                this, _xorstr("WorldIconSize"), boxStyle == WorldBoxStyle::Icon, 0, 8.f, 1.f);
            if (revealIcon > 0.001f) {
                RenderFeature::SliderFloat(this, _xorstr("Размер иконки"),
                    &iconSize, 12.f, 96.f, _xorstr("%.0f px"));
            }
            RenderFeature::EndAnimatedGroup(this, _xorstr("WorldIconSize"), 0);

            ImGui::Spacing();
            RenderFeature::SectionTitle(_xorstr("ЦВЕТА РУД"));
            ImGui::Spacing();
            RenderFeature::ColorEdit4(this, _xorstr("Металлическая руда"), colorMetal);
            RenderFeature::ColorEdit4(this, _xorstr("Серная руда"), colorSulfur);
            RenderFeature::ColorEdit4(this, _xorstr("Каменная руда"), colorStone);
            RenderFeature::ColorEdit4(this, _xorstr("Мвк руда"), colorHqm);

            ImGui::Spacing();
            RenderFeature::SectionTitle(_xorstr("ЦВЕТА ПРОЧЕГО"));
            ImGui::Spacing();
            RenderFeature::ColorEdit4(this, _xorstr("Лошади"), colorHorse);
            RenderFeature::ColorEdit4(this, _xorstr("Дрова"), colorWood);

        }
        RenderFeature::EndAnimatedGroup(this, _xorstr("WorldESPOptions"), 0);
    }

    void OnRenderOverlay() override
    {
        if (!enabled) return;

        const auto cam = WorldToScreenUtils::GetCameraSnapshot();
        if (!cam.valid) return;

        const ImVec2 disp = ImGui::GetIO().DisplaySize;
        const int width = (int)disp.x;
        const int height = (int)disp.y;
        if (width <= 0 || height <= 0) return;

        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        if (!dl) return;

        ImFont* font = ImGui::GetFont();
        if (!font) return;

        auto DrawTextWithOutline = [&](ImVec2 pos, const char* text,
            ImU32 col, ImU32 outCol, float fontSize) {
                if (!text || !text[0]) return;
                dl->AddText(font, fontSize, ImVec2(pos.x - 1, pos.y), outCol, text);
                dl->AddText(font, fontSize, ImVec2(pos.x + 1, pos.y), outCol, text);
                dl->AddText(font, fontSize, ImVec2(pos.x, pos.y - 1), outCol, text);
                dl->AddText(font, fontSize, ImVec2(pos.x, pos.y + 1), outCol, text);
                dl->AddText(font, fontSize, pos, col, text);
            };

        Draw(dl, font, cam, width, height, DrawTextWithOutline);
    }

    template <typename CameraT, typename DrawTextFn>
    void Draw(ImDrawList* dl, ImFont* font, const CameraT& cam,
        int width, int height, DrawTextFn&& drawText)
    {
        const auto entities = WorldManager::Get().GetAllEntities();
        if (entities.empty()) return;

        const auto& vm = cam.viewMatrix;
        const auto& camP = cam.position;

        for (const auto& e : entities) {
            if (!e.valid) continue;
            if (!IsTypeEnabled(e)) continue;

            const float dx = e.position.x - camP.x;
            const float dy = e.position.y - camP.y;
            const float dz = e.position.z - camP.z;
            const float dist = std::sqrt(dx * dx + dy * dy + dz * dz);
            if (!std::isfinite(dist) || dist > maxDistance) continue;

            const float* col4 = PickColor(e);
            const ImU32 color = IM_COL32((int)(col4[0] * 255.f), (int)(col4[1] * 255.f),
                (int)(col4[2] * 255.f), (int)(col4[3] * 255.f));
            const ImU32 outline = IM_COL32(0, 0, 0, (int)(col4[3] * 220.f));

            Vector3 ext;
            float   yLift = 0.f;

            if (e.isOre) {
                ext = { 0.55f, 0.55f, 0.55f };
                yLift = ext.y;
            }
            else if (e.collectType == CollectType::Wood) {
                ext = { 0.50f, 0.30f, 0.50f };
            }
            else if (e.isVehicle) {
                ext = e.bounds;
                if (ext.x < 0.5f || ext.y < 0.5f || ext.z < 0.5f) ext = { 0.8f, 0.9f, 1.4f };
                ext.x = (std::min)(ext.x, 1.2f);
                ext.y = (std::min)(ext.y, 1.4f);
                ext.z = (std::min)(ext.z, 2.0f);
            }
            else {
                ext = e.bounds;
            }

            if (ext.x < 0.1f) ext.x = 0.1f;
            if (ext.y < 0.1f) ext.y = 0.1f;
            if (ext.z < 0.1f) ext.z = 0.1f;

            Vector3 c = e.position;
            c.y += yLift;

            const Vector3 minB = { c.x - ext.x, c.y - ext.y, c.z - ext.z };
            const Vector3 maxB = { c.x + ext.x, c.y + ext.y, c.z + ext.z };

            const Vector3 corners[8] = {
                { minB.x, minB.y, minB.z },{ maxB.x, minB.y, minB.z },
                { minB.x, minB.y, maxB.z },{ maxB.x, minB.y, maxB.z },
                { minB.x, maxB.y, minB.z },{ maxB.x, maxB.y, minB.z },
                { minB.x, maxB.y, maxB.z },{ maxB.x, maxB.y, maxB.z }
            };

            ImVec2 sc[8]{};
            bool   ok[8]{};
            float  minX = FLT_MAX, maxX = -FLT_MAX, minY = FLT_MAX, maxY = -FLT_MAX;
            int    validCount = 0;

            for (int i = 0; i < 8; ++i) {
                if (WorldToScreenUtils::WorldToScreen(corners[i], vm, sc[i], width, height)
                    && std::isfinite(sc[i].x) && std::isfinite(sc[i].y)) {
                    ok[i] = true;
                    ++validCount;
                    minX = (std::min)(minX, sc[i].x); maxX = (std::max)(maxX, sc[i].x);
                    minY = (std::min)(minY, sc[i].y); maxY = (std::max)(maxY, sc[i].y);
                }
            }
            if (validCount < 2) continue;

            const float w = maxX - minX;
            const float h = maxY - minY;
            if (w < 1.f && h < 1.f) continue;

            const float centerX = (minX + maxX) * .5f;
            const float centerY = (minY + maxY) * .5f;
            const float lineThick = (std::max)(w, h) < 35.f ? 1.f : 1.5f;
            const float outlineThick = (std::max)(2.5f, lineThick + 1.5f);

            switch (boxStyle) {
            case WorldBoxStyle::Box3D: {
                static constexpr std::pair<int, int> edges[12] = {
                    { 0,1 },{ 1,3 },{ 3,2 },{ 2,0 },
                    { 4,5 },{ 5,7 },{ 7,6 },{ 6,4 },
                    { 0,4 },{ 1,5 },{ 2,6 },{ 3,7 }
                };
                for (const auto& ed : edges) {
                    if (!ok[ed.first] || !ok[ed.second]) continue;
                    if (drawOutline) dl->AddLine(sc[ed.first], sc[ed.second], outline, outlineThick);
                    dl->AddLine(sc[ed.first], sc[ed.second], color, lineThick);
                }
                break;
            }
            case WorldBoxStyle::Box2D:
                if (drawOutline) dl->AddRect({ minX,minY }, { maxX,maxY }, outline, 0.f, 0, outlineThick);
                dl->AddRect({ minX,minY }, { maxX,maxY }, color, 0.f, 0, lineThick);
                break;
            case WorldBoxStyle::Box2DCircle: {
                const float r = (std::min)(w, h) * .5f;
                if (drawOutline) dl->AddRect({ minX,minY }, { maxX,maxY }, outline, r, 0, outlineThick);
                dl->AddRect({ minX,minY }, { maxX,maxY }, color, r, 0, lineThick);
                break;
            }
            case WorldBoxStyle::Corners: {
                const float cw = w * cornerLen;
                const float ch = h * cornerLen;
                auto C = [&](ImVec2 a, ImVec2 b) {
                    if (drawOutline) dl->AddLine(a, b, outline, outlineThick);
                    dl->AddLine(a, b, color, lineThick);
                    };
                C({ minX,minY }, { minX + cw,minY });
                C({ minX,minY }, { minX,minY + ch });
                C({ maxX,minY }, { maxX - cw,minY });
                C({ maxX,minY }, { maxX,minY + ch });
                C({ minX,maxY }, { minX + cw,maxY });
                C({ minX,maxY }, { minX,maxY - ch });
                C({ maxX,maxY }, { maxX - cw,maxY });
                C({ maxX,maxY }, { maxX,maxY - ch });
                break;
            }
            case WorldBoxStyle::Icon: {
                ImTextureID tex = 0;
                if (!e.iconName.empty())
                    tex = Icons().GetIcon(e.iconName);

                if (tex) {
                    const float half = iconSize * .5f;
                    dl->AddImage(tex,
                        ImVec2(centerX - half, centerY - half),
                        ImVec2(centerX + half, centerY + half));
                }
                else {
                    if (drawOutline) dl->AddRect({ minX,minY }, { maxX,maxY }, outline, 0.f, 0, outlineThick);
                    dl->AddRect({ minX,minY }, { maxX,maxY }, color, 0.f, 0, lineThick);
                }
                break;
            }
            default: break;
            }

            if (drawNames && !e.shortName.empty()) {
                const ImVec2 ts = font->CalcTextSizeA(13.f, FLT_MAX, 0.f, e.shortName.c_str());
                drawText(ImVec2(centerX - ts.x * .5f, minY - ts.y - 2.f),
                    e.shortName.c_str(), color, outline, 13.f);
            }

            if (drawDistance) {
                char dt[32];
                std::snprintf(dt, sizeof(dt), _xorstr("%d м"), (int)dist);
                const ImVec2 ts = font->CalcTextSizeA(13.f, FLT_MAX, 0.f, dt);
                drawText(ImVec2(centerX - ts.x * .5f, maxY + 4.f), dt, color, outline, 13.f);
            }
        }
    }

private:
    bool IsTypeEnabled(const WorldEntityData& e) const
    {
        if (e.isOre) {
            switch (e.oreType) {
            case OreType::Metal:  return drawOreMetal;
            case OreType::Sulfur: return drawOreSulfur;
            case OreType::Stone:  return drawOreStone;
            case OreType::Hqm:    return drawOreHqm;
            default: break;
            }
            return false;
        }
        if (e.isVehicle && drawHorse) return true;
        if (e.collectType == CollectType::Wood && drawWood) return true;

        return false;
    }

    const float* PickColor(const WorldEntityData& e) const
    {
        if (e.isOre) {
            switch (e.oreType) {
            case OreType::Metal:  return colorMetal;
            case OreType::Sulfur: return colorSulfur;
            case OreType::Stone:  return colorStone;
            case OreType::Hqm:    return colorHqm;
            default:              return colorMetal;
            }
        }
        if (e.isVehicle) return colorHorse;
        if (e.collectType == CollectType::Wood) return colorWood;

        return colorDefault;
    }
};