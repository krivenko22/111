#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <dwmapi.h>
#include <tlhelp32.h>

#include <atomic>
#include <mutex>
#include <thread>
#include <chrono>
#include <iostream>
#include <random>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "dwmapi.lib")

#include "imgui/imgui.h"
#include "imgui/backends/imgui_impl_win32.h"
#include "imgui/backends/imgui_impl_dx11.h"

#include "FeatureManager.h"
#include "aim_activation.h"
#include "anti_screen.h"
#include "Menu.h"
#include "ESP.h"
#include "aim_worker.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hWnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam
);

namespace OverlayLogger
{
    inline std::vector<std::string> SplitUTF8(
        const std::string& str
    )
    {
        std::vector<std::string> result;
        result.reserve(str.size());

        for (std::size_t i = 0; i < str.size();)
        {
            const unsigned char c =
                static_cast<unsigned char>(
                    str[i]
                    );

            int len = 1;

            if ((c & 0x80) == 0)
                len = 1;
            else if ((c & 0xE0) == 0xC0)
                len = 2;
            else if ((c & 0xF0) == 0xE0)
                len = 3;
            else if ((c & 0xF8) == 0xF0)
                len = 4;

            if (
                i +
                static_cast<std::size_t>(len)
                <= str.size()
                )
            {
                result.push_back(
                    str.substr(
                        i,
                        static_cast<std::size_t>(len)
                    )
                );
            }
            else
            {
                result.push_back(
                    str.substr(i)
                );
            }

            i +=
                static_cast<std::size_t>(
                    len
                    );
        }

        return result;
    }

    inline void PrintGradient(
        const std::string& text,
        int r1,
        int g1,
        int b1,
        int r2,
        int g2,
        int b2
    )
    {
        const auto chars =
            SplitUTF8(text);

        const std::size_t count =
            chars.size();

        for (
            std::size_t i = 0;
            i < count;
            ++i
            )
        {
            const float t =
                count > 1
                ? static_cast<float>(i) /
                static_cast<float>(count - 1)
                : 0.f;

            const int r =
                static_cast<int>(
                    r1 +
                    t *
                    (
                        r2 -
                        r1
                        )
                    );

            const int g =
                static_cast<int>(
                    g1 +
                    t *
                    (
                        g2 -
                        g1
                        )
                    );

            const int b =
                static_cast<int>(
                    b1 +
                    t *
                    (
                        b2 -
                        b1
                        )
                    );

            std::cout
                << "\033[38;2;"
                << r
                << ";"
                << g
                << ";"
                << b
                << "m"
                << chars[i];
        }

        std::cout
            << "\033[0m";
    }

    inline void LogInfo(
        const std::string& msg
    )
    {
        PrintGradient(
            "[+] " + msg,
            168,
            108,
            188,
            99,
            59,
            112
        );

        std::cout << '\n';
    }

    inline void LogError(
        const std::string& msg
    )
    {
        PrintGradient(
            "[-] " + msg,
            190,
            70,
            120,
            99,
            40,
            70
        );

        std::cout << '\n';
    }
}

class Overlay
{
private:

    HWND hwnd = nullptr;
    HWND gameHwnd = nullptr;

    ID3D11Device* device = nullptr;
    ID3D11DeviceContext* context = nullptr;
    IDXGISwapChain* swapChain = nullptr;
    ID3D11RenderTargetView* renderTargetView = nullptr;

    RECT lastGameRect{};
    bool hasLastGameRect = false;

    HWND cachedGameHwnd = nullptr;

    std::chrono::steady_clock::time_point
        lastWindowSearch{};

    bool isOverlayVisible = false;
    bool isLayered = false;
    bool isClickThrough = true;

    bool menuWasOpen = false;

    // Автоматически переводим фокус на Rust
    // только один раз после обнаружения игры.
    bool gameAutoFocused = false;

    std::wstring className;

    bool antiScreenStateInitialized = false;
    bool lastAntiScreenState = true;

private:

    std::wstring GenerateClassName()
    {
        std::random_device rd;

        std::mt19937 gen(
            rd()
        );

        std::uniform_int_distribution<> dis(
            0,
            15
        );

        const wchar_t hex[] =
            L"0123456789abcdef";

        std::wstring name =
            L"w_";

        for (int i = 0; i < 14; ++i)
        {
            name +=
                hex[
                    dis(gen)
                ];
        }

        return name;
    }

    static LRESULT WINAPI WndProc(
        HWND hWnd,
        UINT msg,
        WPARAM wParam,
        LPARAM lParam
    )
    {
        if (
            ImGui_ImplWin32_WndProcHandler(
                hWnd,
                msg,
                wParam,
                lParam
            )
            )
        {
            return true;
        }

        switch (msg)
        {
        case WM_SYSCOMMAND:

            if (
                (wParam & 0xfff0) ==
                SC_KEYMENU
                )
            {
                return 0;
            }

            break;

        case WM_DESTROY:

            ::PostQuitMessage(0);
            return 0;

        default:
            break;
        }

        return ::DefWindowProc(
            hWnd,
            msg,
            wParam,
            lParam
        );
    }

    void SetClickThrough(
        bool enabled
    )
    {
        if (
            isClickThrough ==
            enabled
            )
        {
            return;
        }

        isClickThrough =
            enabled;

        LONG_PTR exStyle =
            ::GetWindowLongPtr(
                hwnd,
                GWL_EXSTYLE
            );

        if (enabled)
        {
            exStyle |=
                WS_EX_TRANSPARENT;
        }
        else
        {
            exStyle &=
                ~WS_EX_TRANSPARENT;
        }

        ::SetWindowLongPtr(
            hwnd,
            GWL_EXSTYLE,
            exStyle
        );
    }

    void SetLayered(
        bool enabled
    )
    {
        if (
            isLayered ==
            enabled
            )
        {
            return;
        }

        isLayered =
            enabled;

        LONG_PTR exStyle =
            ::GetWindowLongPtr(
                hwnd,
                GWL_EXSTYLE
            );

        if (enabled)
        {
            exStyle |=
                WS_EX_LAYERED;

            ::SetWindowLongPtr(
                hwnd,
                GWL_EXSTYLE,
                exStyle
            );

            ::SetLayeredWindowAttributes(
                hwnd,
                RGB(
                    0,
                    0,
                    0
                ),
                255,
                LWA_ALPHA
            );
        }
        else
        {
            exStyle &=
                ~WS_EX_LAYERED;

            ::SetWindowLongPtr(
                hwnd,
                GWL_EXSTYLE,
                exStyle
            );
        }
    }

    void ApplyMenuState(
        bool menuIsOpen
    )
    {
        SetClickThrough(
            !menuIsOpen
        );
    }

    void ApplyAntiScreenState(
        bool enabled
    )
    {
        if (
            !hwnd ||
            !::IsWindow(hwnd)
            )
        {
            return;
        }

        if (enabled)
        {
            AntiScreen::Apply(
                hwnd
            );
        }
        else
        {
            AntiScreen::Remove(
                hwnd
            );
        }

        lastAntiScreenState =
            enabled;

        antiScreenStateInitialized =
            true;
    }

    HWND FindGameWindow()
    {
        const auto now =
            std::chrono::steady_clock::now();

        if (
            cachedGameHwnd ==
            nullptr ||
            std::chrono::duration_cast<
            std::chrono::milliseconds
            >(
                now -
                lastWindowSearch
            ).count() >
            1000
            )
        {
            lastWindowSearch =
                now;

            DWORD targetPid = 0;

            HANDLE snap =
                ::CreateToolhelp32Snapshot(
                    TH32CS_SNAPPROCESS,
                    0
                );

            if (
                snap !=
                INVALID_HANDLE_VALUE
                )
            {
                PROCESSENTRY32W pe{};

                pe.dwSize =
                    sizeof(pe);

                if (
                    ::Process32FirstW(
                        snap,
                        &pe
                    )
                    )
                {
                    do
                    {
                        if (
                            _wcsicmp(
                                pe.szExeFile,
                                L"RustClient.exe"
                            ) == 0
                            )
                        {
                            targetPid =
                                pe.th32ProcessID;

                            break;
                        }

                    } while (
                        ::Process32NextW(
                            snap,
                            &pe
                        )
                        );
                }

                ::CloseHandle(
                    snap
                );
            }

            if (targetPid)
            {
                struct Ctx
                {
                    DWORD pid;
                    HWND hwnd;
                }
                ctx{
                    targetPid,
                    nullptr
                };

                ::EnumWindows(
                    [](
                        HWND h,
                        LPARAM lp
                        ) -> BOOL
                    {
                        auto* c =
                            reinterpret_cast<Ctx*>(
                                lp
                                );

                        DWORD pid = 0;

                        ::GetWindowThreadProcessId(
                            h,
                            &pid
                        );

                        if (
                            pid ==
                            c->pid &&
                            ::IsWindowVisible(h)
                            )
                        {
                            c->hwnd =
                                h;

                            return FALSE;
                        }

                        return TRUE;
                    },
                    reinterpret_cast<LPARAM>(
                        &ctx
                        )
                );

                if (ctx.hwnd)
                {
                    cachedGameHwnd =
                        ctx.hwnd;

                    return ctx.hwnd;
                }
            }

            HWND window =
                ::FindWindowA(
                    "UnityWndClass",
                    nullptr
                );

            if (
                window &&
                ::IsWindowVisible(
                    window
                )
                )
            {
                cachedGameHwnd =
                    window;

                return window;
            }

            window =
                ::FindWindowA(
                    nullptr,
                    "Rust"
                );

            if (
                window &&
                ::IsWindowVisible(
                    window
                )
                )
            {
                cachedGameHwnd =
                    window;

                return window;
            }

            cachedGameHwnd =
                nullptr;
        }

        if (
            cachedGameHwnd &&
            !::IsWindow(
                cachedGameHwnd
            )
            )
        {
            cachedGameHwnd =
                nullptr;
        }

        return cachedGameHwnd;
    }

    bool CreateRenderTarget()
    {
        if (
            !swapChain ||
            !device
            )
        {
            return false;
        }

        ID3D11Texture2D*
            backBuffer = nullptr;

        const HRESULT hr =
            swapChain->GetBuffer(
                0,
                __uuidof(
                    ID3D11Texture2D
                    ),
                reinterpret_cast<void**>(
                    &backBuffer
                    )
            );

        if (FAILED(hr))
            return false;

        const HRESULT viewResult =
            device->CreateRenderTargetView(
                backBuffer,
                nullptr,
                &renderTargetView
            );

        backBuffer->Release();

        return SUCCEEDED(
            viewResult
        );
    }

    bool ResizeBuffers(
        UINT width,
        UINT height
    )
    {
        if (!swapChain)
            return false;

        if (renderTargetView)
        {
            renderTargetView->Release();

            renderTargetView =
                nullptr;
        }

        const HRESULT hr =
            swapChain->ResizeBuffers(
                0,
                width,
                height,
                DXGI_FORMAT_UNKNOWN,
                0
            );

        if (FAILED(hr))
            return false;

        return CreateRenderTarget();
    }

    bool UpdateGameWindow(HWND found = nullptr)
    {
        if (!found) found = FindGameWindow();

        if (!found)
            return false;

        gameHwnd =
            found;

        RECT client{};

        if (
            !::GetClientRect(
                gameHwnd,
                &client
            )
            )
        {
            return false;
        }

        POINT pt{
            0,
            0
        };

        if (
            !::ClientToScreen(
                gameHwnd,
                &pt
            )
            )
        {
            return false;
        }

        RECT rect{};

        rect.left =
            pt.x;

        rect.top =
            pt.y;

        rect.right =
            pt.x +
            client.right;

        rect.bottom =
            pt.y +
            client.bottom;

        const int width =
            rect.right -
            rect.left;

        const int height =
            rect.bottom -
            rect.top;

        if (
            width <= 0 ||
            height <= 0
            )
        {
            return false;
        }

        const bool changed =
            !hasLastGameRect ||
            rect.left !=
            lastGameRect.left ||
            rect.top !=
            lastGameRect.top ||
            rect.right !=
            lastGameRect.right ||
            rect.bottom !=
            lastGameRect.bottom;

        if (!changed)
            return true;

        ::SetWindowPos(
            hwnd,
            HWND_TOPMOST,
            rect.left,
            rect.top,
            width,
            height,
            SWP_NOACTIVATE |
            SWP_NOOWNERZORDER |
            SWP_NOSENDCHANGING
        );

        if (swapChain)
        {
            DXGI_SWAP_CHAIN_DESC desc{};

            if (
                SUCCEEDED(
                    swapChain->GetDesc(
                        &desc
                    )
                )
                )
            {
                if (
                    desc.BufferDesc.Width !=
                    static_cast<UINT>(
                        width
                        ) ||
                    desc.BufferDesc.Height !=
                    static_cast<UINT>(
                        height
                        )
                    )
                {
                    if (
                        !ResizeBuffers(
                            static_cast<UINT>(
                                width
                                ),
                            static_cast<UINT>(
                                height
                                )
                        )
                        )
                    {
                        return false;
                    }
                }
            }
        }

        lastGameRect =
            rect;

        hasLastGameRect =
            true;

        return true;
    }

    void HideOverlay()
    {
        if (
            isOverlayVisible &&
            hwnd
            )
        {
            ::ShowWindow(
                hwnd,
                SW_HIDE
            );

            isOverlayVisible =
                false;
        }
    }

    void FocusGameWindow()
    {
        if (
            !gameHwnd ||
            !::IsWindow(gameHwnd)
            )
        {
            return;
        }

        if (
            ::IsIconic(
                gameHwnd
            )
            )
        {
            ::ShowWindow(
                gameHwnd,
                SW_RESTORE
            );
        }

        ::BringWindowToTop(
            gameHwnd
        );

        ::SetForegroundWindow(
            gameHwnd
        );
    }

public:

    ID3D11Device*
        GetD3DDevice() const
    {
        return device;
    }

    bool Init()
    {
        className =
            GenerateClassName();

        WNDCLASSEXW wc{};

        wc.cbSize =
            sizeof(
                WNDCLASSEXW
                );

        wc.style =
            CS_CLASSDC;

        wc.lpfnWndProc =
            WndProc;

        wc.hInstance =
            GetModuleHandle(
                nullptr
            );

        wc.lpszClassName =
            className.c_str();

        if (
            !::RegisterClassExW(
                &wc
            )
            )
        {
            OverlayLogger::LogError(
                "Класс окна не создался!"
            );

            return false;
        }

        const int width =
            GetSystemMetrics(
                SM_CXSCREEN
            );

        const int height =
            GetSystemMetrics(
                SM_CYSCREEN
            );

        hwnd =
            ::CreateWindowExW(
                WS_EX_TOPMOST |
                WS_EX_TOOLWINDOW |
                WS_EX_NOACTIVATE,
                wc.lpszClassName,
                L"",
                WS_POPUP,
                0,
                0,
                width,
                height,
                nullptr,
                nullptr,
                wc.hInstance,
                nullptr
            );

        if (!hwnd)
        {
            OverlayLogger::LogError(
                "Создать окно не удалось!"
            );

            return false;
        }

        SetLayered(
            true
        );

        ApplyAntiScreenState(
            true
        );

        LONG_PTR exStyle =
            ::GetWindowLongPtr(
                hwnd,
                GWL_EXSTYLE
            );

        ::SetWindowLongPtr(
            hwnd,
            GWL_EXSTYLE,
            exStyle |
            WS_EX_TRANSPARENT |
            WS_EX_NOACTIVATE
        );

        isClickThrough =
            true;

        MARGINS margins{
            -1,
            -1,
            -1,
            -1
        };

        ::DwmExtendFrameIntoClientArea(
            hwnd,
            &margins
        );

        DXGI_SWAP_CHAIN_DESC sd{};

        sd.BufferCount =
            2;

        sd.BufferDesc.Width =
            static_cast<UINT>(
                width
                );

        sd.BufferDesc.Height =
            static_cast<UINT>(
                height
                );

        sd.BufferDesc.Format =
            DXGI_FORMAT_R8G8B8A8_UNORM;

        sd.BufferDesc.RefreshRate.Numerator =
            0;

        sd.BufferDesc.RefreshRate.Denominator =
            0;

        sd.BufferUsage =
            DXGI_USAGE_RENDER_TARGET_OUTPUT;

        sd.OutputWindow =
            hwnd;

        sd.SampleDesc.Count =
            1;

        sd.SampleDesc.Quality =
            0;

        sd.Windowed =
            TRUE;

        sd.SwapEffect =
            DXGI_SWAP_EFFECT_DISCARD;

        sd.Flags =
            0;

        D3D_FEATURE_LEVEL featureLevel{};

        const HRESULT hr =
            D3D11CreateDeviceAndSwapChain(
                nullptr,
                D3D_DRIVER_TYPE_HARDWARE,
                nullptr,
                0,
                nullptr,
                0,
                D3D11_SDK_VERSION,
                &sd,
                &swapChain,
                &device,
                &featureLevel,
                &context
            );

        if (FAILED(hr))
        {
            OverlayLogger::LogError(
                "D3D11 Не удалось создать!"
            );

            return false;
        }

        if (!CreateRenderTarget())
        {
            OverlayLogger::LogError(
                "RenderTarget Не удалось создать!"
            );

            return false;
        }

        /*
            Overlay не показывается сразу.
            Сначала Run() найдет Rust,
            переведет фокус на него,
            затем покажет overlay.
        */
        ::ShowWindow(
            hwnd,
            SW_HIDE
        );

        isOverlayVisible =
            false;

        ::UpdateWindow(
            hwnd
        );

        IMGUI_CHECKVERSION();

        ImGui::CreateContext();

        ImGuiIO& io =
            ImGui::GetIO();

        io.IniFilename =
            nullptr;

        if (
            !ImGui_ImplWin32_Init(
                hwnd
            )
            )
        {
            OverlayLogger::LogError(
                "ImGui Win32 Не удалось иницилизироватся!"
            );

            return false;
        }

        if (
            !ImGui_ImplDX11_Init(
                device,
                context
            )
            )
        {
            OverlayLogger::LogError(
                "ImGui DX11 Не удалось иницилизироватся!"
            );

            return false;
        }

        /*
            Пытаемся сразу найти Rust,
            но overlay пока не показываем.
        */
        FindGameWindow();

        if (
            gameHwnd &&
            ::IsWindow(
                gameHwnd
            )
            )
        {
            UpdateGameWindow();
        }

        OverlayLogger::LogInfo(
            "Overlay инициализирован!"
        );

        return true;
    }

    void Run(
        ModuleManager& modules,
        Menu& menu,
        LastConfig& lastConfig,
        EspModule* esp,
        const std::atomic<bool>* cancel = nullptr
    )
    {
        bool done = false;
        double featuresMs = 0.0, presentMs = 0.0, frameMs = 0.0;
        bool haveFeatures = false, havePresent = false, haveFrame = false;
        std::chrono::steady_clock::time_point lastFrame{};
        std::mutex featureMutex;
        int aimWidth = 0, aimHeight = 0; // protected by featureMutex
        AimWorker aimWorker;
        bool workerStarted = false;
        auto tickEpoch = std::chrono::steady_clock::now();
        unsigned long long previousTicks = 0;
        double aimTicksPerSecond = 0.0;
        if (esp) {
            try {
                esp->asyncAim = true;
                aimWorker.Start(featureMutex, [&] { esp->AsyncAimTick(aimWidth, aimHeight); });
                workerStarted = true;
            } catch (...) {
                esp->asyncAim = false; // retain the old main-thread path
            }
        }
        auto average = [](double& value, bool& initialized, double sample) {
            if (!initialized) { value = sample; initialized = true; }
            else value += (sample - value) * 0.08;
        };

        while (!done && (!cancel || !cancel->load(std::memory_order_acquire)))
        {
            lastConfig.Tick();
            MSG msg{};

            while (
                ::PeekMessage(
                    &msg,
                    nullptr,
                    0U,
                    0U,
                    PM_REMOVE
                )
                )
            {
                ::TranslateMessage(
                    &msg
                );

                ::DispatchMessage(
                    &msg
                );

                if (
                    msg.message ==
                    WM_QUIT
                    )
                {
                    done = true;
                }
            }

            if (done)
                break;

            /*
                ---------------------------------------------------
                1. Ищем Rust.
                ---------------------------------------------------
            */

            HWND found =
                FindGameWindow();

            if (
                !found ||
                !UpdateGameWindow(found)
                )
            {
                /*
                    Rust отсутствует ->
                    overlay скрыт.
                */

                ++AimActivation::focusGeneration;
                AimActivation::menuOpen = false;
                lastFrame={};
                HideOverlay();

                /*
                    Закрываем меню.
                */
                if (menu.IsOpen())
                {
                    menu.Toggle();
                }

                menuWasOpen =
                    false;

                ApplyMenuState(
                    false
                );

                /*
                    Разрешаем автофокус снова,
                    когда Rust появится.
                */
                gameAutoFocused =
                    false;

                ::Sleep(
                    16
                );

                continue;
            }

            /*
                ---------------------------------------------------
                2. Автоматически переводим фокус на Rust.
                   Выполняется только один раз
                   после обнаружения окна.
                ---------------------------------------------------
            */

            if (!gameAutoFocused)
            {
                HWND foreground =
                    ::GetForegroundWindow();

                if (
                    foreground !=
                    gameHwnd
                    )
                {
                    FocusGameWindow();

                    ::Sleep(
                        50
                    );
                }

                /*
                    Даже если Windows не сразу отдал
                    foreground, больше не дергаем окно
                    каждый кадр.
                */
                gameAutoFocused =
                    true;
            }

            /*
                ---------------------------------------------------
                3. Проверяем foreground.
                ---------------------------------------------------
            */

            HWND foreground =
                ::GetForegroundWindow();

            const bool gameIsForeground =
                foreground ==
                gameHwnd;

            /*
                ---------------------------------------------------
                4. Если Rust не активен:
                   - меню закрываем
                   - overlay скрываем
                   - input не читаем
                ---------------------------------------------------
            */

            if (!gameIsForeground)
            {
                ++AimActivation::focusGeneration;
                AimActivation::menuOpen = false;
                lastFrame={};
                if (menu.IsOpen())
                {
                    menu.Toggle();
                }

                menuWasOpen =
                    false;

                ApplyMenuState(
                    false
                );

                HideOverlay();

                ::Sleep(
                    16
                );

                continue;
            }

            /*
                ---------------------------------------------------
                5. Rust активен.
                   Теперь разрешено принимать Delete.
                ---------------------------------------------------
            */

            menu.HandleInputs();

            const bool menuOpen =
                menu.IsOpen();
            AimActivation::menuOpen = menuOpen;

            if (
                menuOpen !=
                menuWasOpen
                )
            {
                menuWasOpen =
                    menuOpen;

                ApplyMenuState(
                    menuOpen
                );
            }

            /*
                ---------------------------------------------------
                6. AntiScreen
                ---------------------------------------------------
            */

            const bool antiScreenEnabled =
                menu.IsAntiScreenEnabled();

            if (
                !antiScreenStateInitialized ||
                antiScreenEnabled !=
                lastAntiScreenState
                )
            {
                ApplyAntiScreenState(
                    antiScreenEnabled
                );
            }

            /*
                ---------------------------------------------------
                8. Показываем overlay только
                   когда Rust является foreground.
                ---------------------------------------------------
            */

            if (!isOverlayVisible)
            {
                ::ShowWindow(
                    hwnd,
                    SW_SHOWNA
                );

                isOverlayVisible =
                    true;
            }

            /*
                ---------------------------------------------------
                9. ImGui frame.
                ---------------------------------------------------
            */

            const auto frameStart=std::chrono::steady_clock::now();
            if(lastFrame.time_since_epoch().count())
                average(frameMs, haveFrame, std::chrono::duration<double, std::milli>(frameStart-lastFrame).count());
            lastFrame=frameStart;

            ImGui_ImplDX11_NewFrame();

            ImGui_ImplWin32_NewFrame();

            ImGui::NewFrame();

            const auto featuresBegin = std::chrono::steady_clock::now();
            {
                std::lock_guard<std::mutex> guard(featureMutex);
                const ImVec2 display = ImGui::GetIO().DisplaySize;
                aimWidth = static_cast<int>(display.x);
                aimHeight = static_cast<int>(display.y);
                modules.RenderOverlay();
                menu.Render(modules);
            }
            const auto featuresEnd = std::chrono::steady_clock::now();
            average(featuresMs, haveFeatures, std::chrono::duration<double, std::milli>(featuresEnd-featuresBegin).count());
            const double tickSeconds = std::chrono::duration<double>(featuresEnd-tickEpoch).count();
            if (tickSeconds >= 1.0) {
                const auto currentTicks = aimWorker.Ticks();
                aimTicksPerSecond = (currentTicks - previousTicks) / tickSeconds;
                previousTicks = currentTicks;
                tickEpoch = featuresEnd;
            }
            if (menuOpen) {
                char perf[220]{};
                std::snprintf(perf, sizeof(perf), "Overlay %.0f FPS | features %.1f ms | present %.1f ms | aim worker %.0f/s %s",
                              haveFrame && frameMs>0.01 ? 1000.0/frameMs : 0.0, featuresMs, presentMs,
                              aimTicksPerSecond, workerStarted ? "" : "(fallback)");
                ImGui::GetForegroundDrawList()->AddText(ImVec2(12.f, 110.f), IM_COL32(230, 190, 140, 255), perf);
            }
            ImGui::Render();

            const float clearColor[4] = {
                0.f,
                0.f,
                0.f,
                0.f
            };

            context->OMSetRenderTargets(
                1,
                &renderTargetView,
                nullptr
            );

            context->ClearRenderTargetView(
                renderTargetView,
                clearColor
            );

            ImGui_ImplDX11_RenderDrawData(
                ImGui::GetDrawData()
            );

            const auto presentBegin = std::chrono::steady_clock::now();
            const HRESULT presentResult =
                swapChain->Present(
                    0, // no VSync wait or application-side frame cap
                    0
                );
            average(presentMs, havePresent, std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now()-presentBegin).count());

            if (
                presentResult ==
                DXGI_ERROR_DEVICE_REMOVED ||
                presentResult ==
                DXGI_ERROR_DEVICE_RESET
                )
            {
                break;
            }
        }
        aimWorker.Stop();
        if (esp) esp->asyncAim = false;
    }

    void Shutdown()
    {
        ImGui_ImplDX11_Shutdown();

        ImGui_ImplWin32_Shutdown();

        ImGui::DestroyContext();

        AntiScreen::Remove(
            hwnd
        );

        if (renderTargetView)
        {
            renderTargetView->Release();

            renderTargetView =
                nullptr;
        }

        if (swapChain)
        {
            swapChain->Release();

            swapChain =
                nullptr;
        }

        if (context)
        {
            context->Release();

            context =
                nullptr;
        }

        if (device)
        {
            device->Release();

            device =
                nullptr;
        }

        if (hwnd)
        {
            ::DestroyWindow(
                hwnd
            );

            hwnd =
                nullptr;
        }

        if (!className.empty())
        {
            ::UnregisterClassW(
                className.c_str(),
                GetModuleHandle(
                    nullptr
                )
            );
        }

        className.clear();

        antiScreenStateInitialized =
            false;

        isOverlayVisible =
            false;

        gameHwnd =
            nullptr;

        cachedGameHwnd =
            nullptr;

        gameAutoFocused =
            false;
    }
};