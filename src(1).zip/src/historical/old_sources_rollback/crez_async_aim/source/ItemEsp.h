#pragma once
#include "Feature.h"
#include "ESP.h"
#include "Feature.h"
#include "RenderFeature.h"
#include "world_to_screen.h"
#include "localplayer.h"
#include "imgui/imgui.h"
#include "Item.h"
#include "iconsmanager.h"
#include "base_networkable.h"
#include <cmath>
#include <cstdio>
#include <cfloat>
#include <algorithm>
#include <vector>
#include <chrono>

class ItemEspModule : public Module {
public:
    bool drawItems = true;
    bool drawItemNames = true;
    bool drawItemIcons = true;
    bool drawItemDistance = true;
    bool drawOutline = true;

    float itemIconSize = 20.f;
    float itemMaxDistance = 1000.f;
    float itemColor[4] = { .75f, 1.f, .25f, 1.f };

    BoxStyle itemBoxStyle = BoxStyle::Icon;
    float itemCornerLength = .25f;

    ItemEspManager itemManager;
    IconsManager iconsManager;

    ItemEspModule() : Module(_xorstr("Item ESP")), networkable(BaseNetworkable::Get()) {}
    ~ItemEspModule() override = default;

    void OnRenderMenu() override {
        RenderFeature::Toggle(this, _xorstr("Включить Item ESP"), &enabled, 0);

        bool bindToggle = keybind.mode == KeyBindMode::Toggle;
        RenderFeature::BindButton(this, _xorstr("Bind"), &keybind.key, &bindToggle, 0);
        keybind.mode = bindToggle ? KeyBindMode::Toggle : KeyBindMode::Hold;

        ImGui::Spacing();
        RenderFeature::SectionTitle(_xorstr("ITEM ESP"));
        ImGui::Spacing();

        RenderFeature::Toggle(this, _xorstr("Предметы на земле"), &drawItems, 10);
        const float revealItems = RenderFeature::BeginAnimatedGroup(this, _xorstr("ItemESPOptions"), drawItems, 0, 8.f, 1.f);
        if (revealItems > 0.001f) {
            RenderFeature::Toggle(this, _xorstr("Название предмета"), &drawItemNames, 11);
            RenderFeature::Toggle(this, _xorstr("Показывать дистанцию до предмета"), &drawItemDistance, 17);
            RenderFeature::Toggle(this, _xorstr("Обводка"), &drawOutline, 18);
            RenderFeature::SliderFloat(this, _xorstr("Дистанция прорисовки предметов"), &itemMaxDistance, 100.f, 1000.f, _xorstr("%.0f м"));
            RenderFeature::ColorEdit4(this, _xorstr("Цвет предметов"), itemColor);

            ImGui::Spacing();
            RenderFeature::Text(_xorstr("Тип бокса предметов"));
const std::string itemBoxStylesStorage[] = {
    _xorstr("None"),
    _xorstr("2D Box"),
    _xorstr("Corners"),
    _xorstr("3D Box"),
    _xorstr("2D Circle"),
    _xorstr("Иконка")
};

const char* itemBoxStyles[] = {
    itemBoxStylesStorage[0].c_str(),
    itemBoxStylesStorage[1].c_str(),
    itemBoxStylesStorage[2].c_str(),
    itemBoxStylesStorage[3].c_str(),
    itemBoxStylesStorage[4].c_str(),
    itemBoxStylesStorage[5].c_str()
};

            int currentItemStyle = static_cast<int>(itemBoxStyle);
            ImGui::PushID(_xorstr("ItemBoxStyle"));
            if (ImGui::Combo(_xorstr("##ItemBoxStyle"), &currentItemStyle, itemBoxStyles, IM_ARRAYSIZE(itemBoxStyles))) {
                currentItemStyle = (std::max)(0, (std::min)(currentItemStyle, 5));
                itemBoxStyle = static_cast<BoxStyle>(currentItemStyle);
            }
            ImGui::PopID();

            const float revealItemCorners = RenderFeature::BeginAnimatedGroup(this, _xorstr("ItemCornersOptions"), itemBoxStyle == BoxStyle::Corners, 0, 8.f, 1.f);
            if (revealItemCorners > 0.001f) {
                ImGui::Spacing();
                RenderFeature::Text(_xorstr("Длина углов (предметы)"));
                RenderFeature::SliderFloat(this, _xorstr("Длина углов для Corners боксов предметов"), &itemCornerLength, .1f, .5f, _xorstr("%.2f"));
            }
            RenderFeature::EndAnimatedGroup(this, _xorstr("ItemCornersOptions"), 0);

            ImGui::Spacing();
            RenderFeature::Toggle(this, _xorstr("Иконка"), &drawItemIcons, 12);
            const float revealIcon = RenderFeature::BeginAnimatedGroup(this, _xorstr("ItemIconOptions"), drawItemIcons, 0, 8.f, 1.f);
            if (revealIcon > 0.001f) {
                RenderFeature::SliderFloat(this, _xorstr("Размер иконки"), &itemIconSize, 8.f, 64.f, _xorstr("%.0f px"));
            }
            RenderFeature::EndAnimatedGroup(this, _xorstr("ItemIconOptions"), 0);
        }
        RenderFeature::EndAnimatedGroup(this, _xorstr("ItemESPOptions"), 0);
    }

    void OnRenderOverlay() override {
        if (!enabled || !drawItems) return;

        const RenderSnapshot snapshot = networkable.GetSnapshot();
        const auto cam = WorldToScreenUtils::GetCameraSnapshot();
        const ImVec2 displaySize = ImGui::GetIO().DisplaySize;
        const int width = (int)displaySize.x, height = (int)displaySize.y;

        if (!cam.valid || width <= 0 || height <= 0) return;

        ImDrawList* drawList = ImGui::GetBackgroundDrawList();
        if (!drawList) return;

        ImFont* font = ImGui::GetFont();
        if (!font) return;

        const auto& viewMatrix = cam.viewMatrix;
        const auto& camPos = cam.position;

        auto DrawTextWithOutline = [&](ImVec2 pos, const char* text, ImU32 col, ImU32 outCol, float fontSize) {
            if (!text || !text[0]) return;
            drawList->AddText(font, fontSize, ImVec2(pos.x - 1, pos.y), outCol, text);
            drawList->AddText(font, fontSize, ImVec2(pos.x + 1, pos.y), outCol, text);
            drawList->AddText(font, fontSize, ImVec2(pos.x, pos.y - 1), outCol, text);
            drawList->AddText(font, fontSize, ImVec2(pos.x, pos.y + 1), outCol, text);
            drawList->AddText(font, fontSize, pos, col, text);
            };

        uintptr_t localPlayer = LocalPlayerUtils::GetLocalPlayerPointer(snapshot.players);
        itemManager.Update(localPlayer, camPos, itemMaxDistance);

        const ImU32 itemCol = IM_COL32((int)(itemColor[0] * 255.f), (int)(itemColor[1] * 255.f), (int)(itemColor[2] * 255.f), (int)(itemColor[3] * 255.f));
        const ImU32 itemOut = IM_COL32(0, 0, 0, (int)(itemColor[3] * 220.f));

        for (auto idt : itemManager.GetItems()) {
            const float nowSecItem = std::chrono::duration<float>(std::chrono::steady_clock::now().time_since_epoch()).count();
            const float dt = (std::max)(0.f, (std::min)(nowSecItem - idt.lastUpdateTime, 0.25f));
            Vector3 renderPos = idt.smoothedPos;
            renderPos.x += idt.velocity.x * dt;
            renderPos.y += idt.velocity.y * dt;
            renderPos.z += idt.velocity.z * dt;

            const float idx = renderPos.x - camPos.x;
            const float idy = renderPos.y - camPos.y;
            const float idz = renderPos.z - camPos.z;
            const float itemDist = std::sqrt(idx * idx + idy * idy + idz * idz);
            if (!std::isfinite(itemDist) || itemDist > itemMaxDistance) continue;

            ImVec2 anchorScreen{};
            bool anchorOk = WorldToScreenUtils::WorldToScreen(renderPos, viewMatrix, anchorScreen, width, height);

            const Vector3 minB = { renderPos.x - .25f, renderPos.y - .05f, renderPos.z - .25f };
            const Vector3 maxB = { renderPos.x + .25f, renderPos.y + .35f, renderPos.z + .25f };

            const Vector3 corners3D[8] = {
                { minB.x, minB.y, minB.z },{ maxB.x, minB.y, minB.z },
                { minB.x, minB.y, maxB.z },{ maxB.x, minB.y, maxB.z },
                { minB.x, maxB.y, minB.z },{ maxB.x, maxB.y, minB.z },
                { minB.x, maxB.y, maxB.z },{ maxB.x, maxB.y, maxB.z }
            };

            float rawMinX = FLT_MAX, rawMaxX = -FLT_MAX;
            float rawMinY = FLT_MAX, rawMaxY = -FLT_MAX;
            int validCount = 0;

            ImVec2 scCorners[8]{};
            bool screenValid[8]{};

            for (int i = 0; i < 8; ++i) {
                if (WorldToScreenUtils::WorldToScreen(corners3D[i], viewMatrix, scCorners[i], width, height) && std::isfinite(scCorners[i].x) && std::isfinite(scCorners[i].y)) {
                    screenValid[i] = true;
                    ++validCount;
                    rawMinX = (std::min)(rawMinX, scCorners[i].x);
                    rawMaxX = (std::max)(rawMaxX, scCorners[i].x);
                    rawMinY = (std::min)(rawMinY, scCorners[i].y);
                    rawMaxY = (std::max)(rawMaxY, scCorners[i].y);
                }
            }

            if (validCount < 2) {
                if (!anchorOk) continue;
                rawMinX = anchorScreen.x - 10.f;
                rawMaxX = anchorScreen.x + 10.f;
                rawMinY = anchorScreen.y - 20.f;
                rawMaxY = anchorScreen.y;
            }

            float minX = rawMinX, minY = rawMinY, maxX = rawMaxX, maxY = rawMaxY;
            float w = maxX - minX, h = maxY - minY;
            float centerX = (minX + maxX) * .5f;

            if (itemBoxStyle == BoxStyle::Icon) {
                if (!anchorOk) continue;
                ImTextureID iconTex = iconsManager.GetIcon(idt.label);
                if (!iconTex) continue;

                const float s = itemIconSize;
                drawList->AddImage(iconTex, ImVec2(anchorScreen.x - s * .5f, anchorScreen.y - s * .5f), ImVec2(anchorScreen.x + s * .5f, anchorScreen.y + s * .5f));

                float labelTop = anchorScreen.y - s * .5f;
                if (drawItemNames) {
                    std::string label = idt.label;
                    if (idt.amount > 1) label += _xorstr(" x") + std::to_string(idt.amount);
                    const ImVec2 ls = font->CalcTextSizeA(12.f, FLT_MAX, 0.f, label.c_str());
                    DrawTextWithOutline(ImVec2(anchorScreen.x - ls.x * .5f, labelTop - ls.y - 2.f), label.c_str(), itemCol, itemOut, 12.f);
                }

                if (drawItemDistance) {
                    char distText[32]{};
                    std::snprintf(distText, sizeof(distText), _xorstr("%d м"), (int)itemDist);
                    const ImVec2 ts = font->CalcTextSizeA(12.f, FLT_MAX, 0.f, distText);
                    DrawTextWithOutline(ImVec2(anchorScreen.x - ts.x * .5f, anchorScreen.y + s * .5f + 2.f), distText, itemCol, itemOut, 12.f);
                }
                continue;
            }

            if (w < 1.f && h < 1.f) continue;
            const float lineThick = 1.f;
            const float outlineThick = 2.5f;

            if (itemBoxStyle == BoxStyle::Box3D) {
                if (validCount > 0) {
                    static constexpr std::pair<int, int> edges3D[12] = {
                        { 0,1 },{ 1,3 },{ 3,2 },{ 2,0 },{ 4,5 },{ 5,7 },{ 7,6 },{ 6,4 },{ 0,4 },{ 1,5 },{ 2,6 },{ 3,7 }
                    };
                    for (const auto& [i1, i2] : edges3D) {
                        if (!screenValid[i1] || !screenValid[i2]) continue;
                        if (drawOutline) drawList->AddLine(scCorners[i1], scCorners[i2], itemOut, outlineThick);
                        drawList->AddLine(scCorners[i1], scCorners[i2], itemCol, lineThick);
                    }
                }
            }
            else if (itemBoxStyle == BoxStyle::Box2D) {
                if (drawOutline) drawList->AddRect({ minX, minY }, { maxX, maxY }, itemOut, 0.f, 0, outlineThick);
                drawList->AddRect({ minX, minY }, { maxX, maxY }, itemCol, 0.f, 0, lineThick);
            }
            else if (itemBoxStyle == BoxStyle::Box2DCircle) {
                const float rounding = (std::min)(w, h) * .5f;
                if (drawOutline) drawList->AddRect({ minX, minY }, { maxX, maxY }, itemOut, rounding, 0, outlineThick);
                drawList->AddRect({ minX, minY }, { maxX, maxY }, itemCol, rounding, 0, lineThick);
            }
            else if (itemBoxStyle == BoxStyle::Corners) {
                const float cw = w * itemCornerLength;
                const float ch = h * itemCornerLength;
                auto DrawCorner = [&](ImVec2 a, ImVec2 b) {
                    if (drawOutline) drawList->AddLine(a, b, itemOut, outlineThick);
                    drawList->AddLine(a, b, itemCol, lineThick);
                    };
                DrawCorner({ minX, minY }, { minX + cw, minY });
                DrawCorner({ minX, minY }, { minX, minY + ch });
                DrawCorner({ maxX, minY }, { maxX - cw, minY });
                DrawCorner({ maxX, minY }, { maxX, minY + ch });
                DrawCorner({ minX, maxY }, { minX + cw, maxY });
                DrawCorner({ minX, maxY }, { minX, maxY - ch });
                DrawCorner({ maxX, maxY }, { maxX - cw, maxY });
                DrawCorner({ maxX, maxY }, { maxX, maxY - ch });
            }

            float labelTop = minY;
            if (drawItemIcons) {
                ImTextureID iconTex = iconsManager.GetIcon(idt.label);
                if (iconTex) {
                    const float s = itemIconSize;
                    drawList->AddImage(iconTex, ImVec2(centerX - s * .5f, labelTop - s - 2.f), ImVec2(centerX + s * .5f, labelTop - 2.f));
                    labelTop -= s + 2.f;
                }
            }

            if (drawItemNames) {
                std::string label = idt.label;
                if (idt.amount > 1) label += _xorstr(" x") + std::to_string(idt.amount);
                const ImVec2 ls = font->CalcTextSizeA(12.f, FLT_MAX, 0.f, label.c_str());
                DrawTextWithOutline(ImVec2(centerX - ls.x * .5f, labelTop - ls.y - 2.f), label.c_str(), itemCol, itemOut, 12.f);
            }

            if (drawItemDistance) {
                char distText[32]{};
                std::snprintf(distText, sizeof(distText), _xorstr("%d м"), (int)itemDist);
                const ImVec2 ts = font->CalcTextSizeA(12.f, FLT_MAX, 0.f, distText);
                DrawTextWithOutline(ImVec2(centerX - ts.x * .5f, maxY + 2.f), distText, itemCol, itemOut, 12.f);
            }
        }
    }

private:
    BaseNetworkable& networkable;
};