#include "source/Unity/config_store.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <string>
enum class Style{A,B,C};
int main(){
 bool b=false;int i=1;float f=0.2f,c[4]={0,0,0,1};Style style=Style::A;
 ConfigStore s;s.Bool("enabled",b);s.Int("mode",i,0,3);s.Float("gain",f,0.f,1.f);s.Color("color",c);s.Enum("style",style,0,2);
 assert(!s.Load("bad header\nenabled=1\n"));assert(!b);
 assert(s.Load("CREZ_LAST_CONFIG_V1\nenabled=1\nmode=3\ngain=0.7\ncolor.2=0.8\nstyle=2\nunknown=9\n"));
 assert(b&&i==3&&std::abs(f-.7f)<.001f&&std::abs(c[2]-.8f)<.001f&&style==Style::C);
 std::string snapshot=s.Snapshot();b=false;i=0;f=0;c[2]=0;style=Style::A;assert(s.Load(snapshot));assert(b&&i==3&&std::abs(f-.7f)<.001f&&std::abs(c[2]-.8f)<.001f&&style==Style::C);
 assert(s.Load("CREZ_LAST_CONFIG_V1\nenabled=2\nmode=2.5\ngain=nan\nstyle=-1\ncolor.2=999\n"));
 assert(b&&i==3&&std::abs(f-.7f)<.001f&&std::abs(c[2]-.8f)<.001f&&style==Style::C);
 f=1.f;auto edge=s.Snapshot();f=0;assert(s.Load(edge)&&f==1.f);
 float gain=.15f;ConfigStore precise;precise.Float("gain",gain,.005f,.15f);auto edgeGain=precise.Snapshot();gain=.005f;assert(precise.Load(edgeGain)&&gain==.15f);
 assert(!s.Load(std::string(131073,'x')));puts("PASS config fields: round-trip, colors, enums, invalid and bounds");
}
