#include <windows.h>
static SHORT WINAPI FakeKeys(int);
static HWND WINAPI FakeForeground();
static DWORD WINAPI FakeWindowPid(HWND, LPDWORD);
static UINT WINAPI FakeSend(UINT,LPINPUT,int);
#define GetAsyncKeyState FakeKeys
#define GetForegroundWindow FakeForeground
#define GetWindowThreadProcessId FakeWindowPid
#define SendInput FakeSend
#include "source/aim.h"
#undef GetAsyncKeyState
#undef GetForegroundWindow
#undef GetWindowThreadProcessId
#undef SendInput
#include <map>
#include <cassert>
#include <cstring>
#include <cstdio>
#include <thread>
static std::map<uint64_t,unsigned char> mem;
static bool held=true, qHeld=false, foreground=true;static int sends=0,lastX=0,lastY=0;static uint64_t watchedRead=0;static int watchedCount=0;
uintptr_t g_currentAimTarget=0;
kernelmode_proc_handler kernelHandler;
kernelmode_proc_handler::kernelmode_proc_handler():handle(INVALID_HANDLE_VALUE),pid(0){}
kernelmode_proc_handler::~kernelmode_proc_handler(){}
bool kernelmode_proc_handler::read_memory(uint64_t src,uint64_t dst,size_t size){
 if(src==watchedRead)++watchedCount;
 if(!dst||!size)return false;auto*p=(unsigned char*)(uintptr_t)dst;for(size_t i=0;i<size;i++){auto it=mem.find(src+i);if(it==mem.end()){std::memset(p,0,size);return false;}p[i]=it->second;}return true;
}
template<typename T>void put(uint64_t a,T v){auto*p=(unsigned char*)&v;for(size_t i=0;i<sizeof(T);i++)mem[a+i]=p[i];}
static SHORT WINAPI FakeKeys(int k){return ((k==VK_RBUTTON&&held)||(k=='Q'&&qHeld))?SHORT(0x8000):0;}
static HWND WINAPI FakeForeground(){return (HWND)1;}
static DWORD WINAPI FakeWindowPid(HWND,LPDWORD out){*out=foreground?1234:7777;return 1;}
static UINT WINAPI FakeSend(UINT n,LPINPUT in,int){++sends;lastX=in[0].mi.dx;lastY=in[0].mi.dy;return n;}
int main(){
 pId=1234;
 uint64_t local=0x11000000,target=0x20000000,model=0x30000000,tr=0x40000000,native=0x41000000,data=0x42000000,mats=0x43000000,parents=0x44000000;
 put<uint64_t>(target+offsets::base_entity::model,model);put<uint64_t>(model+offsets::model::headBone,tr);put<uint64_t>(tr+0x10,native);put<uint64_t>(native+0x28,data);put<int32_t>(native+0x30,0);put<uint64_t>(data+0x18,mats);put<uint64_t>(data+0x20,parents);put(mats,TransformPosition::Matrix{.8f,1.6f,10.f,0,0,0,0,1,1,1,1,0});put<int32_t>(parents,-1);
 RenderSnapshot s;s.time=std::chrono::steady_clock::now();PlayerRenderData pd{};pd.entityId=target;pd.valid=pd.isAlive=true;pd.position={.8f,0,10};s.players.push_back(pd);
 WorldToScreenUtils::CameraSnapshot cam{};cam.valid=true;cam.position={0,1.6f,0};cam.viewMatrix.m[0][0]=.5625f;cam.viewMatrix.m[1][1]=1.f;cam.viewMatrix.m[1][3]=0.f;cam.viewMatrix.m[2][3]=1.f;cam.viewMatrix.m[3][1]=-1.6f;
 AimModule a;a.smooth=1;a.gain=.15f;a.enabled=false;a.OnCameraFrame(s,cam,local,1920,1080);assert(sends==0 && g_currentAimTarget==0);
 a.enabled=true;a.OnCameraFrame(s,cam,local,1920,1080);assert(sends==1 && lastX>0 && lastY==0 && g_currentAimTarget==target);
 // Do not repeat a snap while the camera still reflects the old frame.
 a.OnCameraFrame(s,cam,local,1920,1080);assert(sends==1);
 std::this_thread::sleep_for(std::chrono::milliseconds(4));cam.viewMatrix.m[0][3]=0.001f;
 a.OnCameraFrame(s,cam,local,1920,1080);assert(sends==2&&lastX>0);cam.viewMatrix.m[0][3]=0.f;
 held=false;a.OnCameraFrame(s,cam,local,1920,1080);assert(sends==2 && g_currentAimTarget==0);held=true;
 foreground=false;a.OnCameraFrame(s,cam,local,1920,1080);assert(sends==2 && g_currentAimTarget==0);foreground=true;
 s.time=std::chrono::steady_clock::now()-std::chrono::milliseconds(200);a.OnCameraFrame(s,cam,local,1920,1080);assert(sends==2);
 s.time=std::chrono::steady_clock::now();s.players[0].isSleeping=true;a.OnCameraFrame(s,cam,local,1920,1080);assert(sends==2);
 s.players[0].isSleeping=false;cam.valid=false;a.OnCameraFrame(s,cam,local,1920,1080);assert(sends==2);
 // Prediction uses snapshot velocity after selecting actual head; disabled preserves old aim.
 { cam.valid=true;AimModule lead;lead.enabled=true;lead.smooth=1;lead.gain=.15f;
   put(mats,TransformPosition::Matrix{0.f,1.6f,10.f,0,0,0,0,1,1,1,1,0});s.players[0].position={0,0,10};s.players[0].velocity={10,0,0};s.players[0].velocityValid=true;s.time=std::chrono::steady_clock::now();
   int before=sends;lead.OnCameraFrame(s,cam,local,1920,1080);std::this_thread::sleep_for(std::chrono::milliseconds(20));lead.OnCameraFrame(s,cam,local,1920,1080);assert(sends==before&&g_currentAimTarget==target);
   lead.prediction=true;lead.projectileSpeed=50;std::this_thread::sleep_for(std::chrono::milliseconds(20));lead.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target&&sends>before&&lastX>0);
   put(mats,TransformPosition::Matrix{.8f,1.6f,10.f,0,0,0,0,1,1,1,1,0});s.players[0].position={.8f,0,10};s.players[0].velocity={0,0,0};s.time=std::chrono::steady_clock::now();
 }
 // Humanized motion applies above 1; release/focus loss must stop movement.
 { AimModule natural;natural.enabled=true;natural.smooth=2;natural.gain=.15f;
   s.time=std::chrono::steady_clock::now();int before=sends;natural.OnCameraFrame(s,cam,local,1920,1080);
   for(int i=0;i<6;i++){std::this_thread::sleep_for(std::chrono::milliseconds(16));s.time=std::chrono::steady_clock::now();natural.OnCameraFrame(s,cam,local,1920,1080);}
   assert(g_currentAimTarget==target && sends>before && lastX>0);
   held=false;int stopped=sends;natural.OnCameraFrame(s,cam,local,1920,1080);assert(!g_currentAimTarget&&sends==stopped);held=true;
   s.time=std::chrono::steady_clock::now();natural.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target);
 }
 // Two candidates: one close in world, another closer to crosshair.
 cam.valid=true;s.time=std::chrono::steady_clock::now();
 const uint64_t target2=0x21000000,model2=0x31000000,tr2=0x45000000,native2=0x46000000,data2=0x47000000,mats2=0x48000000,parents2=0x49000000;
 put<uint64_t>(target2+offsets::base_entity::model,model2);put<uint64_t>(model2+offsets::model::headBone,tr2);
 put<uint64_t>(tr2+0x10,native2);put<uint64_t>(native2+0x28,data2);put<int32_t>(native2+0x30,0);
 put<uint64_t>(data2+0x18,mats2);put<uint64_t>(data2+0x20,parents2);put(mats2,TransformPosition::Matrix{.3f,1.6f,20.f,0,0,0,0,1,1,1,1,0});put<int32_t>(parents2,-1);
 PlayerRenderData pd2{};pd2.entityId=target2;pd2.valid=pd2.isAlive=true;pd2.position={.3f,0,20};s.players.push_back(pd2);
 AimModule closest;closest.enabled=true;closest.targetPriority=0;closest.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target2);
 AimModule nearest;nearest.enabled=true;nearest.targetPriority=1;nearest.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target2);
 AimModule locked;locked.enabled=true;locked.lockOnTarget=true; s.players.pop_back();locked.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target);
 s.players.push_back(pd2);watchedRead=target2+offsets::base_entity::model;watchedCount=0;
 locked.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target && watchedCount==0);
 // Stale snapshot and camera failure stop movement but preserve target identity.
 const int beforePause=sends;s.time=std::chrono::steady_clock::now()-std::chrono::milliseconds(200);
 locked.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0 && sends==beforePause);
 assert(std::strcmp(locked.GetLastLossReason(),"stale player data")==0 && locked.GetLossCount()==1);
 cam.valid=false;s.time=std::chrono::steady_clock::now();locked.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0 && sends==beforePause);
 cam.valid=true;locked.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target && watchedCount==0);
 put(mats,TransformPosition::Matrix{2.6f,1.6f,10.f,0,0,0,0,1,1,1,1,0});s.players[0].position.x=2.6f;locked.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target);
 // Lose the head transform for one frame while another target is available:
 // no movement, no switch; then reacquire the original target.
 auto oldHead=tr;put<uint64_t>(model+offsets::model::headBone,0);
 int sendsAtLoss=sends;locked.OnCameraFrame(s,cam,local,1920,1080);
 assert(g_currentAimTarget==0 && sends==sendsAtLoss);
 assert(std::strcmp(locked.GetLastLossReason(),"head transform/read")==0);
 put<uint64_t>(model+offsets::model::headBone,oldHead);
 locked.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target);
 put(mats,TransformPosition::Matrix{4.f,1.6f,10.f,0,0,0,0,1,1,1,1,0});s.players[0].position.x=4.f;
 locked.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0);
 std::this_thread::sleep_for(std::chrono::milliseconds(720));s.time=std::chrono::steady_clock::now();
 locked.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target2);
 held=false;locked.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0);held=true;
 // srcoaw distance-FOV scaling and experimental sleeper/wounded filtering.
 {AimModule f;f.enabled=true;f.lockOnTarget=false;RenderSnapshot one=s;one.players.clear();PlayerRenderData p=pd;
  p.position={8.f,0,40.f};one.players.push_back(p);one.time=std::chrono::steady_clock::now();
  put(mats,TransformPosition::Matrix{8.f,1.6f,40.f,0,0,0,0,1,1,1,1,0});
  f.distanceFovScaling=true;f.OnCameraFrame(one,cam,local,1920,1080);assert(g_currentAimTarget==0);
  f.distanceFovScaling=false;f.OnCameraFrame(one,cam,local,1920,1080);assert(g_currentAimTarget==target);
  one.players[0].isWounded=true;f.OnCameraFrame(one,cam,local,1920,1080);assert(g_currentAimTarget==0);
  f.skipWounded=false;f.OnCameraFrame(one,cam,local,1920,1080);assert(g_currentAimTarget==target);
  one.players[0].isWounded=false;one.players[0].isSleeping=true;f.OnCameraFrame(one,cam,local,1920,1080);assert(g_currentAimTarget==0);
  f.skipSleepers=false;f.OnCameraFrame(one,cam,local,1920,1080);assert(g_currentAimTarget==target);
 }
 // Locked entity disappears from the snapshot: re-read only that identity,
 // while class/model, alive, awake and current root/head all validate.
 const uint64_t klass=0x51000000,modelState=0x52000000;
 put<uint64_t>(target,klass);put<int>(target+offsets::base_combat_entity::lifestate,0);
 put<uint32_t>(target+offsets::base_player::player_flags,0);
 put<uint64_t>(target+offsets::base_player::model_state,modelState);put<uint32_t>(modelState+offsets::model_state::flags,0);
 put<uint64_t>(model+offsets::model::rootBone,tr);
 put(mats,TransformPosition::Matrix{.8f,1.6f,10.f,0,0,0,0,1,1,1,1,0});s.players[0].position={.8f,0,10};
 AimModule direct;direct.smooth=1;direct.gain=.15f;direct.enabled=true;direct.lockOnTarget=true;held=true;s.time=std::chrono::steady_clock::now();
 s.players.pop_back();direct.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target);
 s.players.clear();s.players.push_back(pd2);s.time=std::chrono::steady_clock::now();
 direct.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target);
 std::this_thread::sleep_for(std::chrono::milliseconds(20));s.time=std::chrono::steady_clock::now();int beforeDirect=sends;
 direct.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target && sends>beforeDirect);
 put<int>(target+offsets::base_combat_entity::lifestate,1);int beforeDeath=sends;direct.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0 && sends==beforeDeath);
 put<int>(target+offsets::base_combat_entity::lifestate,0);put<uint64_t>(target,klass+0x10000);
 direct.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0 && sends==beforeDeath);
 put<uint64_t>(target,klass);put<uint32_t>(modelState+offsets::model_state::flags,offsets::modelstate_flags::Sleeping);
 direct.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0 && sends==beforeDeath);
 put<uint32_t>(modelState+offsets::model_state::flags,0);direct.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target);
 std::this_thread::sleep_for(std::chrono::milliseconds(260));s.time=std::chrono::steady_clock::now();
 beforeDeath=sends;direct.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0 && sends==beforeDeath);
 s.players.clear();s.players.push_back(pd);s.players.push_back(pd2);
 // Integration of bind modes, key changes, menu and focus-loss generation.
 AimModule bind;bind.enabled=true;bind.aimKey='Q';bind.aimMode=AimActivation::Hold;
 s.time=std::chrono::steady_clock::now();held=false;qHeld=false;
 bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0);
 qHeld=true;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target2);
 qHeld=false;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0);
 bind.aimMode=AimActivation::Always;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target2);
 bind.aimMode=AimActivation::None;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0);
 bind.aimMode=AimActivation::Toggle;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0);
 qHeld=true;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target2);
 qHeld=false;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target2);
 qHeld=true;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0);
 qHeld=false;bind.OnCameraFrame(s,cam,local,1920,1080);qHeld=true;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target2);
 AimActivation::menuOpen=true;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0);
 AimActivation::menuOpen=false;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0); // still held, no phantom toggle
 qHeld=false;bind.OnCameraFrame(s,cam,local,1920,1080);qHeld=true;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==target2);
 ++AimActivation::focusGeneration;bind.OnCameraFrame(s,cam,local,1920,1080);assert(g_currentAimTarget==0);
 // Exercise the real two-column Aim menu in a headless ImGui frame.
 ImGui::CreateContext();auto& io=ImGui::GetIO();io.DisplaySize={1000,700};io.DeltaTime=1.f/60;
 unsigned char* pixels=nullptr;int tw=0,th=0;io.Fonts->GetTexDataAsRGBA32(&pixels,&tw,&th);assert(pixels&&tw&&th);
 ImGui::NewFrame();ImGui::SetNextWindowSize({720,600});ImGui::Begin("test");AimModule ui;ui.OnRenderMenu();ImGui::End();ImGui::Render();assert(ImGui::GetDrawData()->TotalVtxCount>0);ImGui::DestroyContext();
 puts("PASS mock aim: instant first move, duplicate guard, smooth mode, binds and ImGui frame");
}
