#pragma once
#include "Feature.h"
#include "RenderFeature.h"
#include "Offsets.h"
#include "base_networkable.h"
#include "world_to_screen.h"
#include "head_projection.h"
#include "srcoaw_visuals.h"
#include "player_name_candidate.h"
#include "camera_candidate.h"
#include "retry_ref_cache.h"
#include "local_input_candidate.h"
#include "localplayer.h"
#include "imgui/imgui.h"
#include "skeleton.h"
#include "aim.h"
#include "flags.h"
#include <cmath>
#include <algorithm>
#include <utility>
#include <vector>
#include <cstdio>
#include <cfloat>
#include <chrono>
#include <unordered_map>
#include <string>

enum class BoxStyle { None = 0, Box2D = 1, Corners = 2, Box3D = 3, Box2DCircle = 4, Icon = 5 };

struct SmoothBox {
    Vector3 minB, maxB;
    bool valid = false;
    float lastSeen = 0.f;
};

class EspModule : public Module {
public:
    bool drawBox = true, drawOutline = true, drawDistance = true, drawNames = true, drawPlayers = true, drawSleepers = true, drawNpcs = false, drawLocalPlayer = false, drawTeammates = true;

    BoxStyle playerBoxStyle = BoxStyle::Box3D;
    BoxStyle npcBoxStyle = BoxStyle::Box3D;

    float cornerLength = .25f;
    float npcCornerLength = .25f;
    // srcoaw-inspired optional render-only overlays, disabled by default.
    bool boxFill = false, boxGradient = false, snapLines = false, headCircle = false, stateFlags = false;
    int snapAlignment = 1;
    int nameField = 0; // User-confirmed candidate; 0 means no verified name field.
    float fillTop[4] = {0.f,1.f,1.f,.25f}, fillBottom[4] = {1.f,.4f,1.f,.25f};
    float gradientBottom[4] = {1.f,.7f,1.f,1.f}, snapColor[4] = {1.f,1.f,1.f,1.f}, headColor[4] = {1.f,1.f,1.f,1.f};

    float maxDistance = 1000.f;
    bool experimentalHeadCamera = true;


    float boxColor[4] = { 1.f, 1.f, 1.f, 1.f };
    float teammateColor[4] = { 0.f, 1.f, 0.f, 1.f };
    float sleepingColor[4] = { .6745f, .9294f, 1.f, 1.f };
    float npcColor[4] = { 1.f, .45f, .35f, 1.f };
    float localPlayerColor[4] = { 0.f, 1.f, 0.f, 1.f };

    SkeletonModule skeleton;
    static AimModule* s_aimInstance;
    std::unordered_map<uintptr_t, SmoothBox> smoothBoxes;

    EspModule() : Module(_xorstr("ESP")), networkable(BaseNetworkable::Get()) { enabled = true; }
    ~EspModule() override = default;

    void OnRenderMenu() override {
        RenderFeature::Toggle(this, _xorstr("Включить ESP"), &enabled, 0);
        RenderFeature::Toggle(this, _xorstr("Камера от головы (эксперимент)"), &experimentalHeadCamera, 11);
        if (experimentalHeadCamera)
            RenderFeature::Text(_xorstr("FOV камеры: автоматически (эксперимент)"));

        bool bindToggle = keybind.mode == KeyBindMode::Toggle;
        RenderFeature::BindButton(this, _xorstr("Bind"), &keybind.key, &bindToggle, 0);
        keybind.mode = bindToggle ? KeyBindMode::Toggle : KeyBindMode::Hold;

        ImGui::Spacing();
        RenderFeature::SectionTitle(_xorstr("ФИЛЬТР ЦЕЛЕЙ"));
        ImGui::Spacing();

        RenderFeature::Toggle(this, _xorstr("Игроки"), &drawPlayers, 1);
        RenderFeature::Toggle(this, _xorstr("Спящие"), &drawSleepers, 2);
        RenderFeature::Toggle(this, _xorstr("NPC"), &drawNpcs, 3);
        RenderFeature::Toggle(this, _xorstr("Локальный игрок"), &drawLocalPlayer, 8);
        RenderFeature::Toggle(this, _xorstr("Показывать тиммейтов"), &drawTeammates, 9);

        ImGui::Spacing();
        RenderFeature::SectionTitle(_xorstr("НАСТРОЙКИ ESP"));
        ImGui::Spacing();

        RenderFeature::Toggle(this, _xorstr("Рисовать бокс"), &drawBox, 4);
        float revealBox = RenderFeature::BeginAnimatedGroup(this, _xorstr("ESP_BoxOptions"), drawBox, 0, 16.f, 1.f);
        if (revealBox > 0.001f) {
            RenderFeature::Toggle(this, _xorstr("Обводка"), &drawOutline, 5);
            RenderFeature::Toggle(this, _xorstr("Дистанция до игрока"), &drawDistance, 6);
            RenderFeature::Toggle(this, _xorstr("Никнейм"), &drawNames, 7);
        }
        RenderFeature::EndAnimatedGroup(this, _xorstr("ESP_BoxOptions"), 0);
        if(drawNames && ImGui::CollapsingHeader(_xorstr("Настройка ников"))){
            RenderFeature::Text(_xorstr("Выбери поле, где отображается твой ник"));
            if(ImGui::Button(_xorstr("Проверить поля локального игрока"))){
                for(int i=1;i<=3;i++){
                    localNameCandidates[i].clear();
                    if(localPlayerForNames)PlayerNameCandidate::Read(ReadNameBytes,localPlayerForNames,i,localNameCandidates[i]);
                }
                nameProbeDone=true;
            }
            if(nameProbeDone){
                if(!localPlayerForNames)RenderFeature::Text(_xorstr("Локальный игрок не найден"));
                for(int i=1;i<=3;i++)ImGui::Text("+0x%llX: %s",(unsigned long long)PlayerNameCandidate::offsets[i],localNameCandidates[i].empty()?"--":localNameCandidates[i].c_str());
            }
            const char* fields[]={_xorstr("Не выбрано"),"+0x518","+0x600","+0x810"};
            ImGui::Combo(_xorstr("Поле ника (кандидат)"),&nameField,fields,IM_ARRAYSIZE(fields));
            RenderFeature::Text(_xorstr("Если своего ника нет, поле не определено"));
        }

        ImGui::Spacing();
        if(ImGui::CollapsingHeader(_xorstr("Дополнительные элементы"))){
        RenderFeature::Toggle(this,_xorstr("Заливка 2D бокса"),&boxFill,12);
        if(boxFill){RenderFeature::ColorEdit4(this,_xorstr("Заливка сверху"),fillTop);RenderFeature::ColorEdit4(this,_xorstr("Заливка снизу"),fillBottom);}
        RenderFeature::Toggle(this,_xorstr("Градиент рамки 2D бокса"),&boxGradient,13);
        if(boxGradient)RenderFeature::ColorEdit4(this,_xorstr("Градиент снизу"),gradientBottom);
        RenderFeature::Toggle(this,_xorstr("Линии к игрокам"),&snapLines,14);
        if(snapLines){const char* align[]={_xorstr("Сверху"),_xorstr("Из центра"),_xorstr("Снизу")};ImGui::Combo(_xorstr("Начало линии"),&snapAlignment,align,3);RenderFeature::ColorEdit4(this,_xorstr("Цвет линий"),snapColor);}
        RenderFeature::Toggle(this,_xorstr("Круг головы (кости эксперимент)"),&headCircle,15);
        if(headCircle)RenderFeature::ColorEdit4(this,_xorstr("Цвет круга головы"),headColor);
        RenderFeature::Toggle(this,_xorstr("Метки спящий/ранен (эксперимент)"),&stateFlags,16);
        }
        ImGui::Spacing();
        if(ImGui::CollapsingHeader(_xorstr("Скелет ESP"))) skeleton.OnRenderMenu();

        ImGui::Spacing();
        RenderFeature::Text(_xorstr("Максимальная дистанция"));
        RenderFeature::SliderFloat(this, _xorstr("Максимальная дистанция прорисовки"), &maxDistance, 100.f, 1000.f, _xorstr("%.0f м"));

        ImGui::Spacing();
        RenderFeature::Text(_xorstr("Тип бокса Игроков"));
        const std::string playerBoxStylesStorage[] = { _xorstr("None"), _xorstr("2D Box"), _xorstr("Corners"), _xorstr("3D Box"), _xorstr("2D Circle") };

        const char* playerBoxStyles[] = {
            playerBoxStylesStorage[0].c_str(),
            playerBoxStylesStorage[1].c_str(),
            playerBoxStylesStorage[2].c_str(),
            playerBoxStylesStorage[3].c_str(),
            playerBoxStylesStorage[4].c_str()
        };
        int currentPlayerStyle = static_cast<int>(playerBoxStyle);
        ImGui::PushID(_xorstr("PlayerBoxStyle"));
        if (ImGui::Combo(_xorstr("##PlayerBoxStyle"), &currentPlayerStyle, playerBoxStyles, IM_ARRAYSIZE(playerBoxStyles))) {
            currentPlayerStyle = (std::max)(0, (std::min)(currentPlayerStyle, 4));
            playerBoxStyle = static_cast<BoxStyle>(currentPlayerStyle);
        }
        ImGui::PopID();

        const float revealPlayerCorners = RenderFeature::BeginAnimatedGroup(this, _xorstr("PlayerCornersOptions"), playerBoxStyle == BoxStyle::Corners, 0, 16.f, 1.f);
        if (revealPlayerCorners > 0.001f) {
            ImGui::Spacing();
            RenderFeature::Text(_xorstr("Длина углов (игроки)"));
            RenderFeature::SliderFloat(this, _xorstr("Длина углов для Corners боксов игроков"), &cornerLength, .1f, .5f, _xorstr("%.2f"));
        }
        RenderFeature::EndAnimatedGroup(this, _xorstr("PlayerCornersOptions"), 0);

        ImGui::Spacing();
        RenderFeature::Text(_xorstr("Тип бокса NPC"));
        const std::string npcBoxStylesStorage[] = { _xorstr("None"), _xorstr("2D Box"), _xorstr("Corners"), _xorstr("3D Box"), _xorstr("2D Circle") };

        const char* npcBoxStyles[] = {
            npcBoxStylesStorage[0].c_str(),
            npcBoxStylesStorage[1].c_str(),
            npcBoxStylesStorage[2].c_str(),
            npcBoxStylesStorage[3].c_str(),
            npcBoxStylesStorage[4].c_str()
        };
        int currentNpcStyle = static_cast<int>(npcBoxStyle);
        ImGui::PushID(_xorstr("NpcBoxStyle"));
        if (ImGui::Combo(_xorstr("##NpcBoxStyle"), &currentNpcStyle, npcBoxStyles, IM_ARRAYSIZE(npcBoxStyles))) {
            currentNpcStyle = (std::max)(0, (std::min)(currentNpcStyle, 4));
            npcBoxStyle = static_cast<BoxStyle>(currentNpcStyle);
        }
        ImGui::PopID();

        const float revealNpcCorners = RenderFeature::BeginAnimatedGroup(this, _xorstr("NpcCornersOptions"), npcBoxStyle == BoxStyle::Corners, 0, 16.f, 1.f);
        if (revealNpcCorners > 0.001f) {
            ImGui::Spacing();
            RenderFeature::Text(_xorstr("Длина углов (NPC)"));
            RenderFeature::SliderFloat(this, _xorstr("Длина углов для Corners боксов NPC"), &npcCornerLength, .1f, .5f, _xorstr("%.2f"));
        }
        RenderFeature::EndAnimatedGroup(this, _xorstr("NpcCornersOptions"), 0);

        ImGui::Spacing();
        if(ImGui::CollapsingHeader(_xorstr("Цвета бокса"))){
        RenderFeature::ColorEdit4(this, _xorstr("Цвет игрока"), boxColor);
        RenderFeature::ColorEdit4(this, _xorstr("Цвет тиммейта"), teammateColor);
        RenderFeature::ColorEdit4(this, _xorstr("Цвет спящего"), sleepingColor);
        RenderFeature::ColorEdit4(this, _xorstr("Цвет NPC"), npcColor);
        RenderFeature::ColorEdit4(this, _xorstr("Цвет локального"), localPlayerColor);
        }
    }

    void OnRenderOverlay() override {
        if (!enabled) { localPlayerForNames=0; return; }

        networkable.GetSnapshot(renderSnapshot);
        const RenderSnapshot& snapshot = renderSnapshot;
        WorldToScreenUtils::CameraSnapshot cam{};
        const ImVec2 displaySize = ImGui::GetIO().DisplaySize;
        const int width = (int)displaySize.x, height = (int)displaySize.y;
        if (width <= 0 || height <= 0) return;
        ImDrawList* drawList = ImGui::GetBackgroundDrawList();
        ImFont* font = ImGui::GetFont();
        if (!drawList || !font) return;

        uintptr_t localPlayerPtr = 0;
        const char* cameraMode = "unavailable";
        const char* issue = snapshot.players.empty() ? "waiting for player list" : "camera unavailable";
        if (experimentalHeadCamera && !snapshot.players.empty()) {
            localPlayerPtr = CachedInputCandidate(snapshot.players);
            if (!localPlayerPtr) issue = "local player unavailable or ambiguous";
            else if (TryCandidateCamera(snapshot.players, localPlayerPtr, width, height, cam)) cameraMode = "transform+projection auto (candidate)";
            else {
                bool autoFov = false;
                if (TryHeadCamera(snapshot.players, localPlayerPtr, width, height, cam, autoFov))
                    cameraMode = autoFov ? "head+angles, FOV auto (approx)" : "head+angles, FOV fallback 75 (approx)";
                else issue = "camera, local head or view angles unavailable";
            }
        }
        if(localPlayerForNames!=localPlayerPtr){nameProbeDone=false;for(auto& candidate:localNameCandidates)candidate.clear();nameCache.clear();}
        localPlayerForNames=localPlayerPtr;
        if(lastNameField!=nameField){ nameCache.clear();lastNameField=nameField; }
        char status[256]{};
        if (cam.valid)
            std::snprintf(status, sizeof(status), "ESP experimental | entities: %d | players: %zu | camera: %s",
                snapshot.stats.entityCount, snapshot.players.size(), cameraMode);
        else
            std::snprintf(status, sizeof(status), "ESP experimental | entities: %d | players: %zu | stage: %d | %s",
                snapshot.stats.entityCount, snapshot.players.size(), snapshot.stats.chainStage, issue);
        drawList->AddText(ImVec2(12.f, 12.f), IM_COL32(240, 180, 100, 255), status);
        if (snapshot.stats.entityCount > 0 && snapshot.players.empty()) {
            char details[200]{};
            std::snprintf(details, sizeof(details), "filter: class=%d typeinfo=%s rejected=%d dead=%d pos=%d model=%d%s",
                snapshot.stats.classMatches, snapshot.stats.typeInfoVerified ? "ok" : "unknown",
                snapshot.stats.rejected, snapshot.stats.notAlive, snapshot.stats.badPosition, snapshot.stats.badModel,
                snapshot.stats.arrayReadFailed ? " array-read-failed" : "");
            drawList->AddText(ImVec2(12.f, 28.f), IM_COL32(240, 180, 100, 255), details);
        }
        if (s_aimInstance) s_aimInstance->OnCameraFrame(snapshot,cam,localPlayerPtr,width,height);
        if (!cam.valid) return;
        if (!drawBox && !drawDistance && !drawNames && !skeleton.drawSkeleton && !snapLines && !headCircle && !stateFlags) return;
        const auto& viewMatrix = cam.viewMatrix;
        const auto& camPos = cam.position;

        auto DrawTextWithOutline = [&](ImVec2 pos, const char* text, ImU32 col, ImU32 outCol, float fontSize) {
            if (!text || !text[0]) return;
            drawList->AddText(font, fontSize, ImVec2(pos.x - 1, pos.y), outCol, text);
            drawList->AddText(font, fontSize, ImVec2(pos.x + 1, pos.y), outCol, text);
            drawList->AddText(font, fontSize, ImVec2(pos.x, pos.y - 1), outCol, text);
            drawList->AddText(font, fontSize, ImVec2(pos.x, pos.y + 1), outCol, text);
            drawList->AddText(font, fontSize, pos, col, text);
            };

        const auto now = std::chrono::steady_clock::now();
        const float nowSec = std::chrono::duration<float>(now.time_since_epoch()).count();
        float predictTime = std::chrono::duration<float>(now - snapshot.time).count();
        predictTime = (std::max)(0.f, (std::min)(predictTime, 1.0f));

        for (auto it = smoothBoxes.begin(); it != smoothBoxes.end(); ) {
            if (nowSec - it->second.lastSeen > 2.f)
                it = smoothBoxes.erase(it);
            else
                ++it;
        }

        uintptr_t currentAimTarget = g_currentAimTarget;

        bool useActiveTargetColor = false;
        float* targetColorPtr = nullptr;
        if (s_aimInstance && s_aimInstance->changeBoxColorOnTarget) {
            useActiveTargetColor = true;
            targetColorPtr = s_aimInstance->activeTargetColor;
        }

        for (const auto& pd : snapshot.players) {
            if (!pd.valid || !pd.entityId) continue;

            const bool isLocalPlayer = pd.entityId == localPlayerPtr;
            const bool isNpc = pd.isNpc;
            const bool isSleeping = pd.isSleeping;
            const bool isTeammate = PlayerFlagsUtils::IsTeammate(pd.entityId, localPlayerPtr);

            bool shouldDraw = false;
            if (isLocalPlayer) {
                shouldDraw = drawLocalPlayer;
            }
            else {
                if (isNpc) shouldDraw = drawNpcs;
                else if (isSleeping) shouldDraw = drawSleepers;
                else shouldDraw = drawPlayers;

                if (shouldDraw && isTeammate && !drawTeammates) shouldDraw = false;
            }

            if (!shouldDraw) continue;

            BonePositionCache* boneCache = (skeleton.drawSkeleton || headCircle) ? BoneManager::Get().GetBonePositions(pd.entityId, predictTime, pd.velocity, isSleeping) : nullptr;

            Vector3 pos = pd.position;
            if (!isSleeping) {
                pos.x += pd.velocity.x * predictTime;
                pos.y += pd.velocity.y * predictTime;
                pos.z += pd.velocity.z * predictTime;
            }

            Vector3 rawMinB{}, rawMaxB{};
            bool bonesSane = false;
            bool useOriented = false;
            Vector3 orientedCorners[8] = {};

            if (skeleton.drawSkeleton && boneCache && boneCache->ok) {
                Vector3 vb[19];
                bool vok[19] = { false };
                Vector3 maxYB{}, minYB{};
                float minX = FLT_MAX, maxX = -FLT_MAX;
                float minY = FLT_MAX, maxY = -FLT_MAX;
                float minZ = FLT_MAX, maxZ = -FLT_MAX;
                int validBones = 0;

                for (int i = 0; i < 19; ++i) {
                    const Vector3& b = boneCache->rawPos[i];
                    if (b.x == 0.f && b.y == 0.f && b.z == 0.f) continue;
                    if (!std::isfinite(b.x) || !std::isfinite(b.y) || !std::isfinite(b.z)) continue;

                    vb[i] = b;
                    vok[i] = true;

                    if (validBones == 0 || b.y > maxYB.y) maxYB = b;
                    if (validBones == 0 || b.y < minYB.y) minYB = b;

                    minX = (std::min)(minX, b.x);
                    maxX = (std::max)(maxX, b.x);
                    minY = (std::min)(minY, b.y);
                    maxY = (std::max)(maxY, b.y);
                    minZ = (std::min)(minZ, b.z);
                    maxZ = (std::max)(maxZ, b.z);
                    ++validBones;
                }

                if (validBones > 3) {
                    pos = { (minX + maxX) * .5f, (minY + maxY) * .5f, (minZ + maxZ) * .5f };

                    if (isSleeping) {
                        Vector3 headB = vok[14] ? vb[14] : maxYB;
                        Vector3 feetB;

                        if (vok[3] && vok[6]) feetB = { (vb[3].x + vb[6].x) * .5f,(vb[3].y + vb[6].y) * .5f,(vb[3].z + vb[6].z) * .5f };
                        else if (vok[3]) feetB = vb[3];
                        else if (vok[6]) feetB = vb[6];
                        else feetB = minYB;

                        Vector3 d = { headB.x - feetB.x, 0.f, headB.z - feetB.z };
                        float len = std::sqrt(d.x * d.x + d.z * d.z);

                        if (len > .4f) {
                            Vector3 f = { d.x / len, 0.f, d.z / len };
                            Vector3 r = { -f.z, 0.f, f.x };
                            Vector3 ch = { (headB.x + feetB.x) * .5f, 0.f, (headB.z + feetB.z) * .5f };

                            float minU = FLT_MAX, maxU = -FLT_MAX;
                            float minV = FLT_MAX, maxV = -FLT_MAX;
                            float minW = FLT_MAX, maxW = -FLT_MAX;

                            for (int i = 0; i < 19; ++i) {
                                if (!vok[i]) continue;
                                const Vector3& b = vb[i];
                                float ox = b.x - ch.x;
                                float oz = b.z - ch.z;
                                float u = ox * f.x + oz * f.z;
                                float v = ox * r.x + oz * r.z;
                                minU = (std::min)(minU, u);
                                maxU = (std::max)(maxU, u);
                                minV = (std::min)(minV, v);
                                maxV = (std::max)(maxV, v);
                                minW = (std::min)(minW, b.y);
                                maxW = (std::max)(maxW, b.y);
                            }

                            if (maxU - minU > .1f && maxV - minV > .1f && maxW - minW > .05f) {
                                const float pad = .1f;
                                minU -= pad; maxU += pad;
                                minV -= pad; maxV += pad;

                                auto mk = [&](float u, float v, float y) -> Vector3 {
                                    return Vector3{ ch.x + f.x * u + r.x * v, y, ch.z + f.z * u + r.z * v };
                                    };

                                orientedCorners[0] = mk(minU, minV, minW);
                                orientedCorners[1] = mk(maxU, minV, minW);
                                orientedCorners[2] = mk(minU, maxV, minW);
                                orientedCorners[3] = mk(maxU, maxV, minW);
                                orientedCorners[4] = mk(minU, minV, maxW);
                                orientedCorners[5] = mk(maxU, minV, maxW);
                                orientedCorners[6] = mk(minU, maxV, maxW);
                                orientedCorners[7] = mk(maxU, maxV, maxW);
                                useOriented = true;
                            }
                        }
                    }

                    if (!useOriented) {
                        const float sizeX = maxX - minX;
                        const float sizeY = maxY - minY;
                        const float sizeZ = maxZ - minZ;
                        bool shapeOk = false;

                        if (isSleeping) {
                            shapeOk = sizeX > .1f && sizeX < 3.f && sizeY > .1f && sizeY < 3.f && sizeZ > .1f && sizeZ < 3.f;
                        }
                        else {
                            shapeOk = sizeX > .2f && sizeX < 2.5f && sizeZ > .2f && sizeZ < 2.5f && sizeY > .4f && sizeY < 3.f;
                        }

                        if (shapeOk) {
                            const float padding = .12f;
                            rawMinB = { minX - padding, minY, minZ - padding };
                            rawMaxB = { maxX + padding, maxY, maxZ + padding };
                            if (!isSleeping) rawMaxB.y += .25f;
                            bonesSane = true;
                        }
                    }
                }
            }

            if (!bonesSane && !useOriented) {
                if (isSleeping) {
                    rawMinB = { pos.x - .75f, pos.y - .05f, pos.z - .75f };
                    rawMaxB = { pos.x + .75f, pos.y + .55f, pos.z + .75f };
                }
                else {
                    rawMinB = { pos.x - .35f, pos.y, pos.z - .35f };
                    rawMaxB = { pos.x + .35f, pos.y + 1.8f, pos.z + .35f };
                }
            }

            const float dx = pos.x - camPos.x;
            const float dy = pos.y - camPos.y;
            const float dz = pos.z - camPos.z;
            const float dist = std::sqrt(dx * dx + dy * dy + dz * dz);

            if (!std::isfinite(dist) || dist > maxDistance) continue;

            Vector3 occCenter = { pos.x, pos.y + (isSleeping ? .3f : .9f), pos.z };
            ImVec2 occScr{};
            bool occProjected = WorldToScreenUtils::WorldToScreen(occCenter, viewMatrix, occScr, width, height)
                && std::isfinite(occScr.x) && std::isfinite(occScr.y);

            bool occInFront = false;
            if (occProjected) {
                ImVec2 upScr{};
                Vector3 upPos = { occCenter.x, occCenter.y + .25f, occCenter.z };
                if (WorldToScreenUtils::WorldToScreen(upPos, viewMatrix, upScr, width, height) && std::isfinite(upScr.y))
                    occInFront = upScr.y < occScr.y;
                else
                    occInFront = true;
            }

            if (!occInFront) continue;

            const bool isActiveTarget = currentAimTarget == pd.entityId;
            const float* currentColor = boxColor;

            if (isActiveTarget && !isLocalPlayer && useActiveTargetColor && targetColorPtr)
                currentColor = targetColorPtr;
            else if (isTeammate && !isLocalPlayer)
                currentColor = teammateColor;
            else if (isLocalPlayer)
                currentColor = localPlayerColor;
            else if (isNpc)
                currentColor = npcColor;
            else if (isSleeping)
                currentColor = sleepingColor;

            const ImU32 color = IM_COL32((int)(currentColor[0] * 255.f), (int)(currentColor[1] * 255.f), (int)(currentColor[2] * 255.f), (int)(currentColor[3] * 255.f));
            const ImU32 outlineColor = IM_COL32(0, 0, 0, (int)(currentColor[3] * 220.f));
            ImU32 skelColor;

            if (isActiveTarget && !isLocalPlayer && useActiveTargetColor && targetColorPtr)
                skelColor = IM_COL32((int)(targetColorPtr[0] * 255.f), (int)(targetColorPtr[1] * 255.f), (int)(targetColorPtr[2] * 255.f), (int)(targetColorPtr[3] * 255.f));
            else if (isTeammate && !isLocalPlayer)
                skelColor = IM_COL32((int)(teammateColor[0] * 255.f), (int)(teammateColor[1] * 255.f), (int)(teammateColor[2] * 255.f), (int)(teammateColor[3] * 255.f));
            else if (isLocalPlayer)
                skelColor = IM_COL32((int)(localPlayerColor[0] * 255.f), (int)(localPlayerColor[1] * 255.f), (int)(localPlayerColor[2] * 255.f), (int)(localPlayerColor[3] * 255.f));
            else if (isNpc)
                skelColor = IM_COL32((int)(npcColor[0] * 255.f), (int)(npcColor[1] * 255.f), (int)(npcColor[2] * 255.f), (int)(npcColor[3] * 255.f));
            else if (isSleeping)
                skelColor = IM_COL32((int)(sleepingColor[0] * 255.f), (int)(sleepingColor[1] * 255.f), (int)(sleepingColor[2] * 255.f), (int)(sleepingColor[3] * 255.f));
            else
                skelColor = IM_COL32((int)(skeleton.skeletonColor[0] * 255.f), (int)(skeleton.skeletonColor[1] * 255.f), (int)(skeleton.skeletonColor[2] * 255.f), (int)(skeleton.skeletonColor[3] * 255.f));

            SmoothBox& sBox = smoothBoxes[pd.entityId];
            sBox.lastSeen = nowSec;

            if (useOriented) {
                sBox.valid = false;
                sBox.minB = rawMinB;
                sBox.maxB = rawMaxB;
            }
            else if (!sBox.valid) {
                sBox.minB = rawMinB;
                sBox.maxB = rawMaxB;
                sBox.valid = true;
            }
            else {
                const float lf = 1.0f;
                sBox.minB.x += (rawMinB.x - sBox.minB.x) * lf;
                sBox.minB.y += (rawMinB.y - sBox.minB.y) * lf;
                sBox.minB.z += (rawMinB.z - sBox.minB.z) * lf;
                sBox.maxB.x += (rawMaxB.x - sBox.maxB.x) * lf;
                sBox.maxB.y += (rawMaxB.y - sBox.maxB.y) * lf;
                sBox.maxB.z += (rawMaxB.z - sBox.maxB.z) * lf;
            }

            const Vector3 minB = sBox.minB, maxB = sBox.maxB;
            const Vector3 aabbCorners[8] = {
                { minB.x, minB.y, minB.z },{ maxB.x, minB.y, minB.z },
                { minB.x, minB.y, maxB.z },{ maxB.x, minB.y, maxB.z },
                { minB.x, maxB.y, minB.z },{ maxB.x, maxB.y, minB.z },
                { minB.x, maxB.y, maxB.z },{ maxB.x, maxB.y, maxB.z }
            };

            const Vector3* corners3D = useOriented ? orientedCorners : aabbCorners;

            float rawMinX = FLT_MAX, rawMaxX = -FLT_MAX;
            float rawMinY = FLT_MAX, rawMaxY = -FLT_MAX;
            int validCount = 0;

            ImVec2 scCorners[8]{};
            bool screenValid[8]{};

            for (int i = 0; i < 8; ++i) {
                if (WorldToScreenUtils::WorldToScreen(corners3D[i], viewMatrix, scCorners[i], width, height) && std::isfinite(scCorners[i].x) && std::isfinite(scCorners[i].y)) {
                    screenValid[i] = true;
                    ++validCount;
                    rawMinX = (std::min)(rawMinX, scCorners[i].x);
                    rawMaxX = (std::max)(rawMaxX, scCorners[i].x);
                    rawMinY = (std::min)(rawMinY, scCorners[i].y);
                    rawMaxY = (std::max)(rawMaxY, scCorners[i].y);
                }
            }

            bool force2DBox = false;

            if (validCount < 2) {
                ImVec2 centerScreen{};
                Vector3 centerPos = { pos.x, pos.y + (isSleeping ? .3f : .9f), pos.z };

                if (WorldToScreenUtils::WorldToScreen(centerPos, viewMatrix, centerScreen, width, height)) {
                    const float fallbackH = isSleeping ? 20.f : 80.f;
                    const float fallbackW = isSleeping ? 60.f : 30.f;
                    rawMinX = centerScreen.x - fallbackW * .5f;
                    rawMaxX = centerScreen.x + fallbackW * .5f;
                    rawMinY = centerScreen.y - fallbackH;
                    rawMaxY = centerScreen.y;
                }
                else if (isLocalPlayer) {
                    const float fallbackH = 100.f, fallbackW = 40.f;
                    rawMinX = width * .5f - fallbackW * .5f;
                    rawMaxX = width * .5f + fallbackW * .5f;
                    rawMinY = height * .5f - fallbackH * .5f;
                    rawMaxY = height * .5f + fallbackH * .5f;
                    force2DBox = true;
                }
                else continue;
            }
            else if (isLocalPlayer && validCount < 6) {
                force2DBox = true;
            }

            float minX = rawMinX, minY = rawMinY, maxX = rawMaxX, maxY = rawMaxY;
            float w = maxX - minX, h = maxY - minY;
            float centerX = (minX + maxX) * .5f;

            if (w < 1.5f && h < 1.5f) continue;

            minY -= h * .15f;
            h = maxY - minY;

            const float maxDim = (std::max)(w, h);
            const float lineThick = maxDim < 35.f ? 1.f : 1.5f;
            const float outlineThick = (std::max)(2.5f, lineThick + 1.5f);

            if (drawNames) {
                const std::string shown=GetPlayerName(pd);
                if(!shown.empty()){
                    const float nameFontSize = 13.f;
                    const ImVec2 nameSize = font->CalcTextSizeA(nameFontSize, FLT_MAX, 0.f, shown.c_str());
                    DrawTextWithOutline(ImVec2(centerX - nameSize.x * .5f, minY - nameSize.y - 2.f), shown.c_str(), color, outlineColor, nameFontSize);
                }
            }

            skeleton.DrawCached(boneCache, viewMatrix, width, height, drawList, skelColor);
            if(snapLines) SrcoawVisuals::SnapLine(drawList,{minX,minY},{maxX,maxY},(float)width,(float)height,snapAlignment,ImGui::ColorConvertFloat4ToU32(ImVec4(snapColor[0],snapColor[1],snapColor[2],snapColor[3])));
            if(stateFlags){
                float yy=minY;
                if(isSleeping){DrawTextWithOutline({maxX+3.f,yy},"SLEEP",color,outlineColor,12.f);yy+=13.f;}
                if(pd.isWounded)DrawTextWithOutline({maxX+3.f,yy},"WOUNDED",color,outlineColor,12.f);
            }
            if(headCircle && boneCache && boneCache->ok){
                const Vector3 &head=boneCache->pos[14], &neck=boneCache->pos[13];
                ImVec2 hs{},ns{};
                if((head.x!=0.f||head.y!=0.f||head.z!=0.f)&&(neck.x!=0.f||neck.y!=0.f||neck.z!=0.f)&&
                   WorldToScreenUtils::WorldToScreen(head,viewMatrix,hs,width,height)&&WorldToScreenUtils::WorldToScreen(neck,viewMatrix,ns,width,height))
                    SrcoawVisuals::HeadCircle(drawList,hs,ns,ImGui::ColorConvertFloat4ToU32(ImVec4(headColor[0],headColor[1],headColor[2],headColor[3])));
            }

            BoxStyle effectiveBoxStyle = isNpc ? npcBoxStyle : playerBoxStyle;
            float effectiveCornerLength = isNpc ? npcCornerLength : cornerLength;

            if (!drawBox || effectiveBoxStyle == BoxStyle::None) {
                if (drawDistance) {
                    char distText[32]{};
                    std::snprintf(distText, sizeof(distText), _xorstr("%d м"), (int)dist);
                    const ImVec2 ts = font->CalcTextSizeA(14.f, FLT_MAX, 0.f, distText);
                    DrawTextWithOutline(ImVec2(centerX - ts.x * .5f, maxY + 4.f), distText, color, outlineColor, 14.f);
                }
                continue;
            }

            if (effectiveBoxStyle == BoxStyle::Box3D && !force2DBox) {
                if (validCount > 0) {
                    static constexpr std::pair<int, int> edges3D[12] = {
                        { 0,1 },{ 1,3 },{ 3,2 },{ 2,0 },{ 4,5 },{ 5,7 },{ 7,6 },{ 6,4 },{ 0,4 },{ 1,5 },{ 2,6 },{ 3,7 }
                    };
                    for (const auto& [i1, i2] : edges3D) {
                        if (!screenValid[i1] || !screenValid[i2]) continue;
                        const ImVec2 p1 = scCorners[i1];
                        const ImVec2 p2 = scCorners[i2];
                        if (drawOutline) drawList->AddLine(p1, p2, outlineColor, outlineThick);
                        drawList->AddLine(p1, p2, color, lineThick);
                    }
                }
            }
            else if (effectiveBoxStyle == BoxStyle::Box2D || effectiveBoxStyle == BoxStyle::Box2DCircle || force2DBox) {
                const ImVec2 p1(minX, minY), p2(maxX, maxY);
                if (effectiveBoxStyle == BoxStyle::Box2DCircle && !force2DBox) {
                    const float rounding = (std::min)(w, h) * .5f;
                    if (drawOutline) drawList->AddRect(p1, p2, outlineColor, rounding, 0, outlineThick);
                    drawList->AddRect(p1, p2, color, rounding, 0, lineThick);
                }
                else {
                    if(boxFill) SrcoawVisuals::Fill(drawList,p1,p2,ImGui::ColorConvertFloat4ToU32(ImVec4(fillTop[0],fillTop[1],fillTop[2],fillTop[3])),ImGui::ColorConvertFloat4ToU32(ImVec4(fillBottom[0],fillBottom[1],fillBottom[2],fillBottom[3])));
                    if (drawOutline) drawList->AddRect(p1, p2, outlineColor, 0.f, 0, outlineThick);
                    if(boxGradient) SrcoawVisuals::GradientBorder(drawList,p1,p2,color,ImGui::ColorConvertFloat4ToU32(ImVec4(gradientBottom[0],gradientBottom[1],gradientBottom[2],gradientBottom[3])),lineThick);
                    else drawList->AddRect(p1, p2, color, 0.f, 0, lineThick);
                }
            }
            else if (effectiveBoxStyle == BoxStyle::Corners) {
                const float cw = w * effectiveCornerLength;
                const float ch = h * effectiveCornerLength;
                auto DrawCorner = [&](ImVec2 a, ImVec2 b) {
                    if (drawOutline) drawList->AddLine(a, b, outlineColor, outlineThick);
                    drawList->AddLine(a, b, color, lineThick);
                    };
                DrawCorner({ minX, minY }, { minX + cw, minY });
                DrawCorner({ minX, minY }, { minX, minY + ch });
                DrawCorner({ maxX, minY }, { maxX - cw, minY });
                DrawCorner({ maxX, minY }, { maxX, minY + ch });
                DrawCorner({ minX, maxY }, { minX + cw, maxY });
                DrawCorner({ minX, maxY }, { minX, maxY - ch });
                DrawCorner({ maxX, maxY }, { maxX - cw, maxY });
                DrawCorner({ maxX, maxY }, { maxX, maxY - ch });
            }

            if (drawDistance) {
                char distText[32]{};
                std::snprintf(distText, sizeof(distText), _xorstr("%d м"), (int)dist);
                const ImVec2 ts = font->CalcTextSizeA(14.f, FLT_MAX, 0.f, distText);
                DrawTextWithOutline(ImVec2(centerX - ts.x * .5f, maxY + 4.f), distText, color, outlineColor, 14.f);
            }
        }
    }

private:
    RenderSnapshot renderSnapshot{}; // Reuse vector storage across overlay frames.
    uintptr_t localPlayerForNames=0;
    int lastNameField=-1;
    bool nameProbeDone=false;
    std::string localNameCandidates[4];
    std::unordered_map<uintptr_t,std::pair<std::string,std::chrono::steady_clock::time_point>> nameCache;
    static bool ReadNameBytes(uint64_t addr,void* out,size_t size){return kernelHandler.read_memory(addr,reinterpret_cast<uint64_t>(out),size);}
    std::string GetPlayerName(const PlayerRenderData& p){
        if(nameField<=0||nameField>3)return p.name[0]?p.name:"Player";
        const auto now=std::chrono::steady_clock::now();
        auto it=nameCache.find(p.entityId);
        if(it!=nameCache.end()&&now-it->second.second<std::chrono::seconds(2))return it->second.first;
        std::string name;
        if(!PlayerNameCandidate::Read(ReadNameBytes,p.entityId,nameField,name))name="Player";
        if(nameCache.size()>4096)nameCache.clear();
        nameCache[p.entityId]={name,now};return name;
    }
    // One live sample: PlayerInput was at +0x678 and uniquely referenced its
    // owner at +0x20. This is evidence, not a verified local-player API.
    static bool ReadAngles(uintptr_t entity, Vector3& angles) {
        auto read = [](uint64_t address, void* dst, size_t size) {
            return kernelHandler.read_memory(address, reinterpret_cast<uint64_t>(dst), size);
        };
        return LocalInputCandidate::Angles(read, entity, angles);
    }
    static uintptr_t FindSingleInputCandidate(const std::vector<PlayerRenderData>& players) {
        if (players.size() > 64) return 0;
        uintptr_t candidate = 0;
        for (const auto& p : players) {
            if (!p.valid || !p.isAlive || p.isNpc || !Decryption::is_valid_ptr(p.entityId)) continue;
            Vector3 angles{}; if (!ReadAngles(p.entityId, angles)) continue;
            if (candidate) return 0;
            candidate = p.entityId;
        }
        return candidate;
    }
    uintptr_t CachedInputCandidate(const std::vector<PlayerRenderData>& players) {
        const auto now = std::chrono::steady_clock::now();
        bool present = false;
        for (const auto& p : players) if (p.valid && p.entityId == cachedInputPlayer) { present = true; break; }
        const auto retryDelay = std::chrono::milliseconds(cachedInputPlayer ? 250 : 25);
        if ((!cachedInputPlayer || present) && lastInputCheck.time_since_epoch().count() && now-lastInputCheck < retryDelay) return cachedInputPlayer;
        cachedInputPlayer = FindSingleInputCandidate(players);
        lastInputCheck = now;
        return cachedInputPlayer;
    }
    CameraCandidate::Refs cameraRefs{};
    RetryRefCache refRetry{};
    bool GetProjection(Matrix4x4& raw) {
        auto read=[](uint64_t address,void* dst,size_t size){return kernelHandler.read_memory(address,reinterpret_cast<uint64_t>(dst),size);};
        const auto now=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
        if(refRetry.ShouldTry(now)) {
            CameraCandidate::Refs fresh{};const bool ok=CameraCandidate::Acquire(read,gBase,fresh);
            refRetry.Record(now,ok);if(ok)cameraRefs=fresh;
        }
        if(!refRetry.CanUse(now)){cameraRefs={};return false;}
        // If a refresh failed, revalidate the old object classes each frame.
        // Never reuse a stale matrix or pose; those are re-read below/by caller.
        if(refRetry.failed && (!CameraCandidate::classIs(read,cameraRefs.camera,"Camera",6) || !CameraCandidate::classIs(read,cameraRefs.transform,"Transform",9))) return false;
        return CameraCandidate::Projection(read,cameraRefs,raw);
    }
    bool TryCandidateCamera(const std::vector<PlayerRenderData>& players,uintptr_t local,int width,int height,WorldToScreenUtils::CameraSnapshot& cam) {
        if (width<=0 || height<=0) return false;
        const PlayerRenderData* player=nullptr;
        for(const auto& p:players)if(p.valid&&p.entityId==local){player=&p;break;}
        if(!player)return false;
        Matrix4x4 raw{};if(!GetProjection(raw))return false;
        auto read=[](uint64_t address,void* dst,size_t size){return kernelHandler.read_memory(address,reinterpret_cast<uint64_t>(dst),size);};
        CameraPose::Pose pose{};if(!CameraPose::World(read,cameraRefs.transform,pose))return false;
        const float dx=pose.position.x-player->position.x,dy=pose.position.y-player->position.y,dz=pose.position.z-player->position.z;
        const float dist2=dx*dx+dy*dy+dz*dz;
        if(!std::isfinite(dist2)||dist2>16.f)return false;
        // Guard against taking an unrelated camera pointing away from the player.
        Vector3 angles{};Matrix4x4 reference{};
        if(!ReadAngles(local,angles)||!HeadProjection::Build(pose.position,angles,float(width)/float(height),75.f,reference))return false;
        Vector3 f=CameraPose::rotate(pose.rotation,{0,0,1});
        const float dot=f.x*reference.m[0][3]+f.y*reference.m[1][3]+f.z*reference.m[2][3];
        if(!std::isfinite(dot)||dot<0.5f)return false;
        Matrix4x4 view{};if(!CameraPose::Build(pose,raw,view))return false;
        cam.position=pose.position;cam.viewMatrix=view;cam.valid=true;return true;
    }
    uintptr_t cachedInputPlayer = 0, cachedCameraPlayer = 0;
    std::chrono::steady_clock::time_point lastInputCheck{}, lastHeadSuccess{};
    Vector3 cachedHead{};
    bool TryHeadCamera(const std::vector<PlayerRenderData>& players, uintptr_t local,
                       int width, int height, WorldToScreenUtils::CameraSnapshot& cam, bool& autoFov) {
        autoFov = false;
        const auto now = std::chrono::steady_clock::now();
        if (local != cachedCameraPlayer) {
            cachedCameraPlayer = local; lastHeadSuccess = {}; cachedHead = {};
        }
        const PlayerRenderData* player = nullptr;
        for (const auto& p : players) if (p.valid && p.entityId == local) { player = &p; break; }
        if (!player || !HeadProjection::finite3(player->position)) return false;
        // Read new angles on every overlay frame: never reuse a stale matrix
        // during a turn. If the read fails, skip instead of projecting old view.
        Vector3 angles{};
        if (!ReadAngles(local, angles)) return false;
        auto readTransform = [](uint64_t address, void* dst, size_t size) {
            return kernelHandler.read_memory(address, reinterpret_cast<uint64_t>(dst), size);
        };
        if (!lastHeadSuccess.time_since_epoch().count() || now-lastHeadSuccess >= std::chrono::milliseconds(5)) {
            uintptr_t model = kernelHandler.readmem<uintptr_t>(local + offsets::base_entity::model);
            uintptr_t headTransform = Decryption::is_valid_ptr(model) ? kernelHandler.readmem<uintptr_t>(model + offsets::model::headBone) : 0;
            Vector3 head{};
            if (TransformPosition::WorldPosition(readTransform, headTransform, head) && HeadProjection::finite3(head) &&
                (head.x != 0.f || head.y != 0.f || head.z != 0.f)) {
                const float dx=head.x-player->position.x, dy=head.y-player->position.y, dz=head.z-player->position.z;
                const float distanceSq=dx*dx+dy*dy+dz*dz;
                if (std::isfinite(distanceSq) && distanceSq<=16.f) { cachedHead=head; lastHeadSuccess=now; }
            }
        }
        if (!lastHeadSuccess.time_since_epoch().count() || now-lastHeadSuccess > std::chrono::milliseconds(50)) return false;
        float fov = 75.f; Matrix4x4 raw{}; float fx=0,fy=0,ox=0,oy=0;
        if (GetProjection(raw) && CameraPose::Projection(raw,fx,fy,ox,oy)) {
            float measured=2.f*std::atan(1.f/fy)*57.295779513f;
            if(std::isfinite(measured) && measured>=10.f && measured<=140.f) { fov=measured; autoFov=true; }
        }
        Matrix4x4 projection{};
        if (!HeadProjection::Build(cachedHead, angles, float(width)/float(height), fov, projection)) return false;
        cam.position = cachedHead;
        cam.viewMatrix = projection;
        cam.valid = true;
        return true;
    }
    BaseNetworkable& networkable;
};

AimModule* EspModule::s_aimInstance = nullptr;