#include "source/Unity/aim_trace.h"
#include <cassert>
#include <cmath>
#include <cstdio>
using namespace AimTrace;
int main(){
 Profile p; Player player;
 auto empty=Apply(p,player,200.f,10.f,.01f);assert(empty.x==200.f&&empty.y==10.f);
 assert(p.Add(10,20,0)); assert(p.Add(110,20,1));assert(p.Valid());
 Error e{};for(int i=0;i<100;i++)e=Apply(p,player,200.f,0,.01f);
 assert(std::abs(e.x-208.8f)<.01f && std::abs(e.y)<.001f);
 // Near the target the correction is limited to <=8.8% of current error,
 // and at the target it vanishes entirely.
 auto near=Apply(p,player,1.f,0,.01f);assert(std::hypot(near.x-1.f,near.y)<=.0881f);
 auto zero=Apply(p,player,0.f,0.f,.01f);assert(zero.x==0.f&&zero.y==0.f);
 player.Reset(); float previous=0.f; float maxJump=0.f;
 for(int i=0;i<300;i++){
   auto v=Apply(p,player,200.f,0,.01f);float off=v.x-200.f;
   maxJump=(std::max)(maxJump,std::abs(off-previous));previous=off;
 }
 assert(maxJump<.60f); // includes smooth return at each loop boundary
 assert(!p.Add(NAN,0,2));assert(!p.Add(1,2,-1));assert(!p.Add(1,2,1));
 p.points[1].time=0;assert(!p.Valid());auto bad=Apply(p,player,7,9,.01f);assert(bad.x==7&&bad.y==9);
 p.Clear();for(int i=0;i<500;i++)assert(p.Add(float(i%100),float(i%70),i*.01f));
 assert(p.count<=MaxPoints&&p.Valid());assert(p.points[p.count-1].time>4.9f);
 p.Clear();assert(!p.Valid());
 puts("PASS trace: 8.8 percent, near-target cap, no offset at target, loop continuity, invalid data, decimation");
}
