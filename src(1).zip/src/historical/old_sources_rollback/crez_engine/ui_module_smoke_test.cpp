#include <windows.h>
#define CREZ_UI_TEST
#include "source/Menu.h"
#include "source/ESP.h"
#include "source/recoil.h"
#include "source/Arrows.h"
#include "source/FakeAdmin.h"
#include "source/Spider.h"
#include "source/AlwaysEoka.h"
#include "source/WorldEsp.h"
#include "source/ItemEsp.h"
#include "source/InventoryEsp.h"
#include "source/Radar.h"
#include "source/Automatic.h"
#include <cassert>
#include <cstdio>
std::atomic<uintptr_t> g_currentAimTarget{0};ID3D11Device* gD3DDevice=nullptr;
static ImVec2 center(ImRect r){return {(r.Min.x+r.Max.x)/2,(r.Min.y+r.Max.y)/2};}
int main(){
 ImGui::CreateContext();auto& io=ImGui::GetIO();io.DisplaySize={1920,1080};io.DeltaTime=1.f/60;io.IniFilename=nullptr;Menu menu;menu.SetupStyle(nullptr);unsigned char*p;int w,h;io.Fonts->GetTexDataAsRGBA32(&p,&w,&h);
 ModuleManager m;
 m.RegisterModule(std::make_shared<AutomaticModule>());m.RegisterModule(std::make_shared<RadarModule>());m.RegisterModule(std::make_shared<InventoryEspModule>());
 m.RegisterModule(std::make_shared<ItemEspModule>());m.RegisterModule(std::make_shared<WorldEsp>());m.RegisterModule(std::make_shared<SpiderModule>());
 m.RegisterModule(std::make_shared<FakeAdminModule>());m.RegisterModule(std::make_shared<AimModule>());m.RegisterModule(std::make_shared<RecoilModule>());
 m.RegisterModule(std::make_shared<EspModule>());m.RegisterModule(std::make_shared<ArrowsModule>());m.RegisterModule(std::make_shared<AlwaysEokaModule>());
 auto f=[&]{ImGui::NewFrame();menu.Render(m);ImGui::Render();};auto fs=[&](int n){while(n--)f();};
 auto click=[&](ImVec2 q){io.AddMousePosEvent(q.x,q.y);f();io.AddMouseButtonEvent(0,true);f();io.AddMouseButtonEvent(0,false);f();fs(8);};
 fs(50);
 // Every real registered module is selected and rendered, with no driver attached.
 for(int i=0;i<12;i++){ImRect r=EngineUiTest::item[i];assert(r.GetWidth()>0);click(center(r));assert(EngineUiTest::selection==i);assert(ImGui::GetDrawData()->TotalVtxCount>0);}
 puts("PASS all 12 real module inspectors in ImGui (no driver/game)");ImGui::DestroyContext();
}
