#include <windows.h>
#define CREZ_UI_TEST
#include "source/Menu.h"
#include <cassert>
#include <cstdio>
std::atomic<uintptr_t> g_currentAimTarget{0};
ID3D11Device* gD3DDevice=nullptr;
kernelmode_proc_handler kernelHandler;
kernelmode_proc_handler::kernelmode_proc_handler():handle(INVALID_HANDLE_VALUE),pid(0){}
kernelmode_proc_handler::~kernelmode_proc_handler(){}
bool kernelmode_proc_handler::read_memory(uint64_t,uint64_t,size_t){return false;}
class Fake:public Module {public: Fake():Module("ESP TEST",ModuleCategory::Visuals){} void OnRenderOverlay()override{} void OnRenderMenu()override{for(int i=0;i<60;i++)ImGui::Text("Test property %d",i);} };
static ImVec2 center(ImRect r){return ImVec2((r.Min.x+r.Max.x)/2,(r.Min.y+r.Max.y)/2);}
static void saveDraw(const char* path){
 auto* dd=ImGui::GetDrawData();unsigned char* pix;int w,h;ImGui::GetIO().Fonts->GetTexDataAsRGBA32(&pix,&w,&h);
 FILE* f=fopen(path,"wb");assert(f);fwrite(&w,4,1,f);fwrite(&h,4,1,f);fwrite(pix,4,w*h,f);
 int cmdTotal=0;for(int i=0;i<dd->CmdListsCount;i++)for(auto& c:dd->CmdLists[i]->CmdBuffer)if(c.ElemCount&&!c.UserCallback)cmdTotal++;
 fwrite(&cmdTotal,4,1,f);
 for(int i=0;i<dd->CmdListsCount;i++){auto*l=dd->CmdLists[i];for(auto& c:l->CmdBuffer){if(!c.ElemCount||c.UserCallback)continue;
  fwrite(&c.ClipRect,sizeof(float),4,f);int n=c.ElemCount;fwrite(&n,4,1,f);
  for(unsigned j=0;j<c.ElemCount;j++){auto& v=l->VtxBuffer[c.VtxOffset+l->IdxBuffer[c.IdxOffset+j]];fwrite(&v,sizeof(v),1,f);}
 }}fclose(f);
}
int main(){
 ImGui::CreateContext();auto& io=ImGui::GetIO();io.DisplaySize={1920,1080};io.DeltaTime=1.f/60;io.IniFilename=nullptr;
 Menu menu;menu.SetupStyle(nullptr);unsigned char* pixels=nullptr;int w=0,h=0;io.Fonts->GetTexDataAsRGBA32(&pixels,&w,&h);assert(pixels&&w&&h);
 ModuleManager modules;auto aim=std::make_shared<AimModule>();auto esp=std::make_shared<Fake>();modules.RegisterModule(aim);modules.RegisterModule(esp);
 wchar_t base[MAX_PATH]{};assert(GetTempPathW(MAX_PATH,base));std::wstring root=std::wstring(base)+L"crez_ui_cfg_"+std::to_wstring(GetCurrentProcessId());assert(CreateDirectoryW(root.c_str(),nullptr));assert(SetEnvironmentVariableW(L"LOCALAPPDATA",root.c_str()));
 LastConfig config;config.Bool("aim.enabled",aim->enabled);aim->RegisterTraceConfig(config);menu.RegisterLastConfig(config);assert(config.Init());
 auto frame=[&](){ImGui::NewFrame();menu.Render(modules);ImGui::Render();};
 auto frames=[&](int n){for(int i=0;i<n;i++)frame();};
 auto move=[&](ImVec2 p){io.AddMousePosEvent(p.x,p.y);frame();};
 auto down=[&](){io.AddMouseButtonEvent(0,true);frame();};auto up=[&](){io.AddMouseButtonEvent(0,false);frame();};
 auto click=[&](ImVec2 p){move(p);down();up();frame();};
 frames(50);assert(ImGui::GetDrawData()->TotalVtxCount>0);saveDraw("engine_preview.bin");
 assert(!aim->enabled);click(center(EngineUiTest::enabled));assert(aim->enabled);
 auto canvas=EngineUiTest::canvas;move({canvas.Min.x+25,canvas.Min.y+25});down();move({canvas.Min.x+45,canvas.Min.y+45});move({canvas.Min.x+90,canvas.Min.y+65});up();
 assert(aim->trace.count>=3&&aim->trace.Valid());int recorded=aim->trace.count;
 assert(config.Tick(true));{AimModule restored;LastConfig c;c.Bool("aim.enabled",restored.enabled);restored.RegisterTraceConfig(c);assert(c.Init());assert(restored.enabled && restored.trace.count==recorded && restored.trace.Valid());}
 click(center(EngineUiTest::item[1]));frames(5);move({canvas.Min.x+25,canvas.Min.y+25});down();move({canvas.Min.x+100,canvas.Min.y+70});up();assert(aim->trace.count==recorded);
 assert(!esp->enabled);click(center(EngineUiTest::enabled));assert(esp->enabled);
 move(center(EngineUiTest::inspector));io.AddMouseWheelEvent(0,-8.f);frames(8);assert(EngineUiTest::scroll>0.f);
 click(center(EngineUiTest::item[0]));frames(8);click(center(EngineUiTest::clear));assert(aim->trace.count==0);
 click(center(EngineUiTest::settings));frames(8);
 click(center(EngineUiTest::place));frames(4);assert(menu.IsInterfaceEditorOpen());
 float initial=menu.GetInterfaceManager().ConfigPosition("watermark",false);move({initial+30,30});down();move({initial+80,60});up();
 assert(menu.GetInterfaceManager().ConfigPosition("watermark",false)>initial+40);assert(config.Tick(true));
 {Menu restoredMenu;LastConfig c;restoredMenu.RegisterLastConfig(c);assert(c.Init());assert(restoredMenu.GetInterfaceManager().ConfigPosition("watermark",false)>initial+40);}
 click(center(EngineUiTest::back));frames(4);assert(!menu.IsInterfaceEditorOpen());
 menu.Toggle();frames(100);assert(!menu.IsOpen());assert(!ImGui::FindWindowByName("##CrezEngineWorkspace")->Active);
 menu.Toggle();frames(100);assert(menu.IsOpen());
 io.DisplaySize={1280,720};frames(30);assert(ImGui::GetDrawData()->TotalVtxCount>0);assert(EngineUiTest::inspector.Max.x<=1280);
 io.DisplaySize={1024,768};frames(30);assert(ImGui::GetDrawData()->TotalVtxCount>0);assert(EngineUiTest::inspector.Max.x<=1024);
 DeleteFileW((root+L"\\Crez\\last.cfg").c_str());RemoveDirectoryW((root+L"\\Crez").c_str());RemoveDirectoryW(root.c_str());
 puts("PASS real ImGui: trace draw/clear, module toggle, config roundtrip, scroll, overlay placement, hide/reopen, resize");ImGui::DestroyContext();
}
