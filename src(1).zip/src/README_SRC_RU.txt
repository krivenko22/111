СБОРКА ИСХОДНИКОВ CREZ

Состав:
- current/crez_sleep_guard — актуальное дерево исходников после ESP lag и красной кнопки закрытия.
- other_sources/ — отдельные деревья/арhives: crez_trace, crez_desktop_overlay, crez_trace_strength, crez_no_prediction.
- historical/old_sources_rollback — старые именованные снимки из проверенного rollback-архива.

Включены только исходники и нужные для сборки/тестов файлы. Не включены:
- собранные EXE/DLL/SYS и kdmapper;
- локальные конфиги и imgui.ini;
- временные логи, кэши, build/output каталоги;
- .git и прочий чувствительный служебный каталог;
- двоичные зависимости, если их не было в исходных деревьях.

Это архив исходников, не гарантия работоспособности на другой системе. Windows-only код собирается MinGW/Visual Studio x64; внешний драйвер и mapper не входят в этот архив.
