#include "source/Unity/mouse_aim_math.h"
#include <cassert>
#include <cmath>
#include <cstdio>
int main(){
 using namespace MouseAimMath;
 SmoothState s{};int sum=0;
 for(int i=0;i<60;i++){auto m=StableMove(40.f,0.f,.035f,10,1.f/60,s);assert(m.x>=0&&m.x<=4&&m.y==0);sum+=m.x;}
 assert(sum>0);auto m=StableMove(-40.f,0,.035f,10,1.f/60,s);assert(m.x<=0&&s.vx<0);
 m=StableMove(1.f,1.f,.035f,10,1.f/60,s);assert(m.x==0&&m.y==0&&s.vx==0&&s.rx==0);
 m=StableMove(NAN,20,.035f,10,.016f,s);assert(m.x==0&&m.y==0&&s.vx==0);
 SmoothState a{},b{};int fast=0,slow=0;
 for(int i=0;i<144;i++)fast+=StableMove(40,0,.035f,10,1.f/144,a).x;
 for(int i=0;i<60;i++)slow+=StableMove(40,0,.035f,10,1.f/60,b).x;
 assert(std::abs(fast-slow)<=3);
 m=StableMove(100,0,.035f,10,.2f,s);assert(m.x==0&&s.vx==0);
 puts("PASS stable movement: caps, reversal, per-axis deadzone, reset, 60/144Hz");
}
