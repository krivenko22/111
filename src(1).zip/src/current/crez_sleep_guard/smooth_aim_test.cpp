#include "source/Unity/mouse_aim_math.h"
#include <cassert>
#include <cstdio>
#include <cmath>
#include <limits>
int main(){
 using namespace MouseAimMath;
 SmoothState a{};auto m=SmoothMove(80,-60,.035f,10,1.f/60,a);assert(m.x>=0&&m.y<=0&&m.x<=8&&m.y>=-8);
 float previous=a.vx;SmoothMove(80,-60,.035f,10,1.f/60,a);assert(a.vx>previous);
 m=SmoothMove(0,0,.035f,10,1.f/60,a);assert(m.x==0&&m.y==0&&a.vx==0&&a.vy==0);
 for(int i=0;i<30;i++)SmoothMove(100,0,.035f,10,1.f/60,a);
 SmoothMove(-100,0,.035f,10,1.f/60,a);assert(a.vx<0);
 SmoothState fast{},slow{};int fs=0,ss=0;for(int i=0;i<144;i++)fs+=SmoothMove(50,0,.035f,10,1.f/144,fast).x;
 for(int i=0;i<60;i++)ss+=SmoothMove(50,0,.035f,10,1.f/60,slow).x;assert(std::abs(fs-ss)<=3);
 m=SmoothMove(20,0,.035f,10,.3f,a);assert(m.x==0&&m.y==0&&a.vx==0);
 m=SmoothMove(NAN,0,.035f,10,.016f,a);assert(m.x==0&&m.y==0&&a.vx==0);
 puts("PASS smoothing: acceleration ramp, reversal, deadzone/reset, 60/144Hz and invalid inputs");
}
