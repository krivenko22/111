#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
CXX="${CXX:-x86_64-w64-mingw32-g++-posix}"
STRIP="${STRIP:-x86_64-w64-mingw32-strip}"
BUILD="$(mktemp -d)"
trap 'rm -rf "$BUILD"' EXIT
cd "$ROOT/source"
FILES=(Main.cpp Driver/Driver.cpp Driver/Tools.cpp fontello_data.cpp icons.cpp Network.cpp imgui/imgui.cpp imgui/imgui_demo.cpp imgui/imgui_draw.cpp imgui/imgui_tables.cpp imgui/imgui_widgets.cpp imgui/backends/imgui_impl_dx11.cpp imgui/backends/imgui_impl_win32.cpp)
OBJECTS=()
for src in "${FILES[@]}"; do
  obj="$BUILD/${src//\//_}.o"
  echo "Compiling $src"
  "$CXX" -std=c++20 -O1 -DNDEBUG -D_CRT_SECURE_NO_WARNINGS -include Obfuscate.h -I. -IUnity -Iimgui -c "$src" -o "$obj"
  OBJECTS+=("$obj")
done
"$CXX" -static -static-libgcc -static-libstdc++ -o "$ROOT/CrezExternalSource.exe" "${OBJECTS[@]}" -ld3d11 -ldxgi -ld3dcompiler -ldwmapi -lole32 -luuid -lwindowscodecs -lgdiplus -lgdi32 -lcomctl32 -limm32 -lshlwapi -lwinmm -luxtheme
"$STRIP" "$ROOT/CrezExternalSource.exe"
echo "Built $ROOT/CrezExternalSource.exe"
