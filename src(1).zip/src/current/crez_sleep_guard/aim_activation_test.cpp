#include "source/Unity/aim_activation.h"
#include <cassert>
#include <cstdio>
int main(){using namespace AimActivation; Runtime s{};
 assert(!s.Update(None,81,true,true,0));
 assert(!s.Update(Hold,81,false,true,0));assert(s.Update(Hold,81,true,true,0));assert(!s.ActiveNow(Hold,81,false,true));
 assert(!s.Update(Toggle,81,true,true,0));assert(!s.Update(Toggle,81,false,true,0));
 assert(s.Update(Toggle,81,true,true,0));assert(s.Update(Toggle,81,false,true,0));assert(!s.Update(Toggle,81,true,true,0));
 assert(!s.Update(Toggle,81,false,false,0));assert(!s.Update(Toggle,81,true,true,0));
 assert(!s.Update(Toggle,81,false,true,0));assert(s.Update(Toggle,81,true,true,0));
 assert(!s.Update(Toggle,81,true,true,1));assert(!s.Update(Toggle,82,false,true,1));
 assert(s.Update(Always,0,false,true,1));assert(!s.Update(Always,0,false,false,1));
 assert(!s.Update(Hold,0,true,true,1));assert(!s.Update(Toggle,0,true,true,1));
 puts("PASS activation: none/hold/toggle/always, no phantom toggles, focus/menu/key reset");}
