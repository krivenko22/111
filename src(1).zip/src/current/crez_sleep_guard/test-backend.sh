#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
CXX="${CXX:-x86_64-w64-mingw32-g++-posix}"
TESTDIR="$(mktemp -d)"
trap 'rm -rf "$TESTDIR"' EXIT
cd "$ROOT"
FLAGS=(-std=c++20 -O1 -static -static-libgcc -static-libstdc++ -include source/Obfuscate.h -Isource -Isource/Unity -Isource/imgui)
"$CXX" "${FLAGS[@]}" backend_self_test.cpp source/Driver/Driver.cpp source/Driver/Tools.cpp -o "$TESTDIR/backend_self_test.exe"
"$CXX" "${FLAGS[@]}" backend_ioctl_mock_test.cpp -o "$TESTDIR/backend_ioctl_mock_test.exe"
(cd "$TESTDIR" && wine ./backend_self_test.exe && wine ./backend_ioctl_mock_test.exe)
