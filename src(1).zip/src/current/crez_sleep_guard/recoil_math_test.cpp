#include "source/Unity/recoil_math.h"
#include <cassert>
#include <cmath>
#include <cstdio>
int main(){
 using namespace RecoilMath;
 State full{},legit{};int syFull=0,syLegit=0;
 for(int i=0;i<600;i++){syFull+=Step(full,100,0,0,1.f/60).y;syLegit+=Step(legit,100,0,1,1.f/60).y;}
 assert(std::abs(syFull-1000)<=1);assert(std::abs(syLegit-880)<=3);
 State high{},low{};int h=0,l=0;for(int i=0;i<1440;i++)h+=Step(high,50,0,0,1.f/144).y;for(int i=0;i<600;i++)l+=Step(low,50,0,0,1.f/60).y;assert(std::abs(h-l)<=1);
 State a{};auto m=Step(a,300,100,0,.033f);assert(m.y<=8&&m.x<=8&&m.y>=0);
 m=Step(a,10,0,3,.016f);assert(m.x==0&&m.y==0&&a.elapsed==0&&a.rx==0&&a.ry==0);
 m=Step(a,10,0,0,.5f);assert(m.x==0&&m.y==0&&a.elapsed==0);
 a=State{};m=Step(a,0,0,1,.03f);assert(m.x==0&&m.y==0);
 puts("PASS recoil math: full/88% calibrated, jitter mean, 60/144Hz, caps, reset and invalid inputs");
}
