#include "source/Unity/mouse_aim_math.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <limits>
int main(){
 using namespace MouseAimMath;
 assert(InRadius(1010,540,1920,1080,120));
 assert(!InRadius(1200,540,1920,1080,120));
 assert(!InRadius(-2,540,1920,1080,2000));
 assert(!InRadius(std::numeric_limits<float>::quiet_NaN(),540,1920,1080,120));
 float x=0,y=0;auto m=Move(80,-60,.035f,1.f/60,x,y);assert(m.x>0&&m.y<0&&m.x<=8&&m.y>=-8);
 x=y=0;m=Move(5000,-5000,.15f,.03f,x,y);assert(m.x==8&&m.y==-8);
 x=y=0;m=Move(1,1,.1f,.01f,x,y);assert(m.x==0&&m.y==0);
 x=y=0;int high=0,low=0;for(int i=0;i<120;i++) high+=Move(20,0,.035f,1.f/120,x,y).x;
 x=y=0;for(int i=0;i<60;i++) low+=Move(20,0,.035f,1.f/60,x,y).x;
 assert(std::abs(high-low)<=1);
 x=y=1;m=Move(50,40,.03f,0,x,y);assert(m.x==0&&m.y==0&&x==0&&y==0);
 puts("PASS mouse aim math: radius bounds, direction, deadzone, speed cap, frame-rate normalization and bad input");
}
