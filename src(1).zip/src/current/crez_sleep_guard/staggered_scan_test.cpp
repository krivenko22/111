#include <windows.h>
#include <cstdint>
#include <map>
#include <cstring>
#include <cassert>
#include <cstdio>
#include <chrono>
#include <thread>
#include "source/Unity/base_networkable.h"
static std::map<uint64_t,unsigned char> mem;
template<typename T> void put(uint64_t address,T value){auto p=(unsigned char*)&value;for(size_t i=0;i<sizeof(T);i++)mem[address+i]=p[i];}
kernelmode_proc_handler kernelHandler;
kernelmode_proc_handler::kernelmode_proc_handler():handle(INVALID_HANDLE_VALUE),pid(0){}
kernelmode_proc_handler::~kernelmode_proc_handler(){}
bool kernelmode_proc_handler::read_memory(uint64_t src,uint64_t dst,size_t size){
 if(!dst||!size)return false;auto* p=(unsigned char*)(uintptr_t)dst;std::memset(p,0,size);
 for(size_t i=0;i<size;i++){auto it=mem.find(src+i);if(it==mem.end()){std::memset(p,0,size);return false;}p[i]=it->second;}return true;
}
int main(){
 const uint64_t base=0x50000000,klass=0x60000000,statics=0x60010000;
 const uint64_t w1=0x1D0CF08ECF0ULL,raw1=0x1D2A18DB7D0ULL,realm=0x1D0CF1B9ED0ULL;
 const uint64_t w2=0x1D0CF08ED20ULL,raw2=0x1D2A1E74B28ULL,dict=0x1D0CF192B00ULL;
 const uint64_t list=0x61000000,array=0x61010000,ent=0x62000000,invalid=0x62010000;
 const uint64_t playerModel=0x63000000,mesh=0x63010000,renderList=0x63020000,bones=0x63030000;
 const uint64_t name=0x64000000,model=0x65000000;
 const uint64_t baseClass=0x66000000, childClass=0x66010000, className=0x66020000;
 const uint64_t transform=0x67000000,native=0x67010000,data=0x67020000,mats=0x67030000,parents=0x67040000,footArray=0x68000000;
 put<uint64_t>(base+offsets::rust_globals::base_networkable_static,klass);put<uint64_t>(klass+offsets::klass_layout::static_fields,statics);put<uint64_t>(statics+0x38,w1);
 put<uint8_t>(w1+0x14,1);put<uint64_t>(w1+0x18,0x399CCCD67A87A0D3ULL);put<uint64_t>(raw1,realm);put<uint64_t>(realm+0x18,w2);
 put<uint8_t>(w2+0x14,1);put<uint64_t>(w2+0x18,0x010AA8279664C69BULL);put<uint64_t>(raw2,dict);put<uint64_t>(dict+0x18,list);
 put<int32_t>(list+0x18,700);put<uint64_t>(list+0x10,array);put<uint64_t>(array+0x18,700);
 const uint64_t objectClass=0x6A000000, dummy=0x6A010000;
 put<uint64_t>(dummy,objectClass);put<uint64_t>(objectClass+offsets::klass_layout::parent,0);
 for(int i=0;i<700;i++) put<uint64_t>(array+0x20+8*i,dummy);
 put<uint64_t>(array+0x20+8*699,ent);
 put<uint64_t>(base+0xF116310,baseClass);put<uint64_t>(baseClass+0x10,className);
 const char baseName[11]="BasePlayer";for(int i=0;i<11;i++)put<char>(className+i,baseName[i]);
 put<uint64_t>(ent,childClass);put<uint64_t>(childClass+offsets::klass_layout::parent,baseClass);
 // Deliberately omit ent+player_model: old IsGarbage would reject this player.
 (void)playerModel;put<uint64_t>(playerModel+offsets::player_model::_multiMesh,mesh);
 put<uint64_t>(mesh+offsets::skinned_multi_mesh::RendererList,renderList);put<int32_t>(renderList+offsets::system_list::size,1);
 put<uint64_t>(playerModel+offsets::player_model::boneTransforms,bones);put<uint64_t>(ent+offsets::base_player::display_name,name);
 put<uint32_t>(name+0x10,4);put<wchar_t>(name+0x14,L'T');put<wchar_t>(name+0x16,L'e');put<wchar_t>(name+0x18,L's');put<wchar_t>(name+0x1a,L't');
 put<int32_t>(ent+offsets::base_combat_entity::lifestate,0);put<uint64_t>(ent+offsets::base_entity::model,model);
 // The slot +0x60 is an object, deliberately not used as coordinates.
 put<uint64_t>(model+0x60,0xDEADBEEFDEADBEEFULL);
 put<uint64_t>(model+offsets::model::rootBone,transform);put<uint64_t>(transform+0x10,native);
 put<uint64_t>(native+0x28,data);put<int32_t>(native+0x30,0);put<uint64_t>(data+0x18,mats);put<uint64_t>(data+0x20,parents);
 put<TransformPosition::Matrix>(mats,TransformPosition::Matrix{100,20,200,0,0,0,0,1,1,1,1,0});put<int32_t>(parents,-1);gBase=base;
 {
  BaseNetworkable networkable;std::this_thread::sleep_for(std::chrono::milliseconds(700));
  RenderSnapshot snap=networkable.GetSnapshot();
  std::printf("stage=%d entities=%d players=%llu invalid=%d rejected=%d dead=%d pos=%d\n",snap.stats.chainStage,snap.stats.entityCount,(unsigned long long)snap.players.size(),snap.stats.badPointer,snap.stats.rejected,snap.stats.notAlive,snap.stats.badPosition);
  assert(snap.stats.chainStage==10 && snap.stats.entityCount==700 && !snap.stats.arrayReadFailed);
  assert(snap.players.size()==1 && snap.players[0].entityId==ent && std::strcmp(snap.players[0].name,"Player")==0);
  assert(snap.stats.badPointer==0 && snap.stats.rejected==699);
  assert(snap.stats.typeInfoVerified && snap.stats.classMatches==1 && snap.stats.positionRoot==1);
  assert(snap.players[0].position.x==100 && snap.players[0].position.y==20 && snap.players[0].position.z==200);
 }
 puts("PASS staggered scan: 700 entities with player in last chunk");
}
