#pragma once
#include "inventory.h"
#include <d3d11.h>
#include <imgui.h>
#include "base_networkable.h"
#include "world_to_screen.h"
#include "localplayer.h"
#include "iconsmanager.h"
#include "colors.h"
#include <atomic>
#include <string>
#include <vector>
#include <unordered_map>
#include <cmath>
#include <cfloat>
#include <cstdio>
#include <algorithm>

extern std::atomic<uintptr_t> g_currentAimTarget;

class InventoryOverlay {
private:
    static constexpr int WEAR_SLOTS = 7;
    static constexpr int BELT_SLOTS = 6;

    inline static ImVec2 sharedRenderMin = ImVec2(0.f, 0.f);
    inline static ImVec2 sharedRenderMax = ImVec2(0.f, 0.f);
    inline static bool sharedRenderRectValid = false;
    inline static bool sharedEditorMode = false;
    inline static bool sharedMenuPreviewActive = false;

    float renderAlpha = 0.f;
    PlayerInventoryData cachedInventory;
    std::string cachedName;
    bool cachedIsNpc = false;
    bool cachedIsSleeping = false;
    bool cachedInventoryValid = false;

    static float UpdateRenderAlpha(
        float current,
        bool active,
        float externalAlpha
    ) {
        const ImGuiIO& io = ImGui::GetIO();
        float dt = io.DeltaTime;

        if (!std::isfinite(dt) || dt <= 0.f)
            dt = 1.f / 60.f;

        dt = ImClamp(dt, 0.f, 0.05f);

        const float target =
            active
            ? ImClamp(externalAlpha, 0.f, 1.f)
            : 0.f;

        const float speed = 12.f;
        const float t = 1.f - std::exp(-speed * dt);

        current += (target - current) * t;

        if (std::fabs(target - current) < 0.001f)
            current = target;

        return ImClamp(current, 0.f, 1.f);
    }

    static bool HasRenderableInventory(
        const PlayerInventoryData& data
    ) {
        int wearCount = 0;
        int beltCount = 0;

        for (const auto& item : data.items) {
            if (item.containerType == 2 && wearCount < WEAR_SLOTS)
                ++wearCount;
            else if (item.containerType == 0 && beltCount < BELT_SLOTS)
                ++beltCount;

            if (wearCount >= WEAR_SLOTS && beltCount >= BELT_SLOTS)
                break;
        }

        return wearCount > 0 || beltCount > 0;
    }

    static float SafeSlotSize(float value) {
        if (!std::isfinite(value))
            return 34.f;

        return ImClamp(
            value,
            18.f,
            96.f
        );
    }

    static ImRect GetDefaultRect(
        int width,
        int height
    ) {
        const float safeWidth =
            static_cast<float>(
                (std::max)(1, width)
                );

        const float safeHeight =
            static_cast<float>(
                (std::max)(1, height)
                );

        const ImVec2 center(
            safeWidth * 0.5f,
            safeHeight * 0.62f
        );

        const ImVec2 size(
            390.f,
            145.f
        );

        return ImRect(
            ImVec2(
                center.x -
                size.x * 0.5f,
                center.y
            ),
            ImVec2(
                center.x +
                size.x * 0.5f,
                center.y +
                size.y
            )
        );
    }

    static ImRect GetSharedRenderRect(
        int width,
        int height
    ) {
        if (sharedRenderRectValid) {
            const float minX =
                std::isfinite(
                    sharedRenderMin.x
                )
                ? sharedRenderMin.x
                : 0.f;

            const float minY =
                std::isfinite(
                    sharedRenderMin.y
                )
                ? sharedRenderMin.y
                : 0.f;

            const float maxX =
                std::isfinite(
                    sharedRenderMax.x
                )
                ? sharedRenderMax.x
                : 0.f;

            const float maxY =
                std::isfinite(
                    sharedRenderMax.y
                )
                ? sharedRenderMax.y
                : 0.f;

            if (
                maxX > minX &&
                maxY > minY
                ) {
                return ImRect(
                    ImVec2(
                        minX,
                        minY
                    ),
                    ImVec2(
                        maxX,
                        maxY
                    )
                );
            }
        }

        return GetDefaultRect(
            width,
            height
        );
    }

    static bool ValidateSnapshotTarget(
        const RenderSnapshot& snap,
        uintptr_t id,
        uintptr_t localId,
        const char** outName,
        bool* outIsNpc = nullptr,
        bool* outIsSleeping = nullptr
    ) {
        if (id == 0 || id == localId)
            return false;

        for (const auto& pd : snap.players) {
            if (pd.entityId == id) {
                if (!pd.valid || !pd.isAlive)
                    return false;

                if (outName)
                    *outName = pd.name;
                if (outIsNpc)
                    *outIsNpc = pd.isNpc;
                if (outIsSleeping)
                    *outIsSleeping = pd.isSleeping;

                return true;
            }
        }

        return false;
    }

    static void DrawSlots(
        ImDrawList* dl,
        ImFont* font,
        IconsManager* icons,
        const InventoryItem* const* items,
        int itemCount,
        int slotCount,
        float slotSize,
        float centerX,
        float y,
        float alpha,
        bool allowIcons,
        bool drawAmounts,
        bool accent
    ) {
        if (
            !dl ||
            !font ||
            slotCount <= 0
            ) {
            return;
        }

        const float gap = 4.f;
        const float pad = 7.f;

        const float safeAlpha =
            ImClamp(
                alpha,
                0.f,
                1.f
            );

        const float rowWidth =
            static_cast<float>(slotCount) *
            slotSize +
            static_cast<float>(slotCount - 1) *
            gap +
            pad * 2.f;

        const float x0 =
            centerX -
            rowWidth * 0.5f;

        const float rowHeight =
            slotSize +
            pad * 2.f;

        const float radius = 8.f;

        const ImVec4 panel(
            0.f,
            0.f,
            0.f,
            0.f
        );

        const ImVec4 panelBorder(
            1.f,
            1.f,
            1.f,
            0.045f * safeAlpha
        );

        const ImVec4 accentBorder(
            colors::accent.x,
            colors::accent.y,
            colors::accent.z,
            0.18f * safeAlpha
        );

        const ImVec4 slot(
            colors::control.x,
            colors::control.y,
            colors::control.z,
            0.88f * safeAlpha
        );

        const ImVec4 slotBorder(
            1.f,
            1.f,
            1.f,
            0.055f * safeAlpha
        );

        dl->AddRectFilled(
            ImVec2(
                x0,
                y
            ),
            ImVec2(
                x0 + rowWidth,
                y + rowHeight
            ),
            ImGui::GetColorU32(
                panel
            ),
            radius
        );

        dl->AddRect(
            ImVec2(
                x0 + 0.5f,
                y + 0.5f
            ),
            ImVec2(
                x0 +
                rowWidth -
                0.5f,
                y +
                rowHeight -
                0.5f
            ),
            ImGui::GetColorU32(
                accent
                ? accentBorder
                : panelBorder
            ),
            radius,
            ImDrawFlags_RoundCornersAll,
            1.f
        );

        for (
            int i = 0;
            i < slotCount;
            ++i
            ) {
            const float sx =
                x0 +
                pad +
                static_cast<float>(i) *
                (slotSize + gap);

            const float sy =
                y + pad;

            dl->AddRectFilled(
                ImVec2(
                    sx,
                    sy
                ),
                ImVec2(
                    sx + slotSize,
                    sy + slotSize
                ),
                ImGui::GetColorU32(
                    slot
                ),
                6.f
            );

            dl->AddRect(
                ImVec2(
                    sx + 0.5f,
                    sy + 0.5f
                ),
                ImVec2(
                    sx +
                    slotSize -
                    0.5f,
                    sy +
                    slotSize -
                    0.5f
                ),
                ImGui::GetColorU32(
                    slotBorder
                ),
                6.f,
                ImDrawFlags_RoundCornersAll,
                1.f
            );

            const InventoryItem* item =
                (
                    items &&
                    i < itemCount
                    )
                ? items[i]
                : nullptr;

            if (!item)
                continue;

            if (
                allowIcons &&
                icons
                ) {
                const ImTextureID tex =
                    icons->GetIcon(
                        item->shortname
                    );

                if (
                    tex &&
                    tex !=
                    (ImTextureID)-1
                    ) {
                    dl->AddImage(
                        tex,
                        ImVec2(
                            sx + 3.f,
                            sy + 3.f
                        ),
                        ImVec2(
                            sx +
                            slotSize -
                            3.f,
                            sy +
                            slotSize -
                            3.f
                        ),
                        ImVec2(0.f, 0.f),
                        ImVec2(1.f, 1.f),
                        ImGui::GetColorU32(
                            ImVec4(
                                1.f,
                                1.f,
                                1.f,
                                safeAlpha
                            )
                        )
                    );
                }
            }

            if (drawAmounts && item->amount > 1) {
                char buf[16]{};

                std::snprintf(
                    buf,
                    sizeof(buf),
                    "%d",
                    item->amount
                );

                const ImVec2 ts =
                    font->CalcTextSizeA(
                        10.f,
                        FLT_MAX,
                        0.f,
                        buf
                    );

                const ImVec2 tp(
                    sx +
                    slotSize -
                    ts.x -
                    3.f,
                    sy +
                    slotSize -
                    ts.y -
                    2.f
                );

                const ImU32 shadow =
                    ImGui::GetColorU32(
                        ImVec4(
                            0.f,
                            0.f,
                            0.f,
                            0.86f *
                            safeAlpha
                        )
                    );

                const ImU32 text =
                    ImGui::GetColorU32(
                        ImVec4(
                            0.94f,
                            0.94f,
                            0.96f,
                            safeAlpha
                        )
                    );

                dl->AddText(
                    font,
                    10.f,
                    ImVec2(
                        tp.x + 1.f,
                        tp.y + 1.f
                    ),
                    shadow,
                    buf
                );

                dl->AddText(
                    font,
                    10.f,
                    tp,
                    text,
                    buf
                );
            }
        }
    }

    static void DrawName(
        ImDrawList* dl,
        ImFont* font,
        const ImRect& rect,
        const char* name,
        float centerX,
        float alpha,
        bool isNpc,
        bool isSleeping
    ) {
        if (
            !dl ||
            !font ||
            !name ||
            name[0] == '\0'
            ) {
            return;
        }

        const float safeAlpha =
            ImClamp(
                alpha,
                0.f,
                1.f
            );

        const ImVec2 ns =
            font->CalcTextSizeA(
                13.f,
                FLT_MAX,
                0.f,
                name
            );

        const float namePadX = 6.f;
        const float namePadY = 2.f;

        const ImVec4 bg(
            0.008f,
            0.009f,
            0.014f,
            0.96f * safeAlpha
        );

        const ImVec4 border(
            1.f,
            1.f,
            1.f,
            0.07f * safeAlpha
        );

        const float nameBgWidth =
            ns.x +
            namePadX * 2.f;

        const float nameBgHeight =
            ns.y +
            namePadY * 2.f;

        const ImVec2 nameBgMin(
            centerX -
            nameBgWidth * 0.5f,
            rect.Min.y + 2.f
        );

        const ImVec2 nameBgMax(
            centerX +
            nameBgWidth * 0.5f,
            nameBgMin.y +
            nameBgHeight
        );

        dl->AddRectFilled(
            nameBgMin,
            nameBgMax,
            ImGui::GetColorU32(
                bg
            ),
            6.f
        );

        dl->AddRect(
            ImVec2(
                nameBgMin.x + 0.5f,
                nameBgMin.y + 0.5f
            ),
            ImVec2(
                nameBgMax.x - 0.5f,
                nameBgMax.y - 0.5f
            ),
            ImGui::GetColorU32(
                border
            ),
            6.f,
            ImDrawFlags_RoundCornersAll,
            1.f
        );

        const ImVec2 np(
            centerX -
            ns.x * 0.5f,
            nameBgMin.y +
            namePadY
        );

        const ImU32 shadow =
            ImGui::GetColorU32(
                ImVec4(
                    0.f,
                    0.f,
                    0.f,
                    0.78f *
                    safeAlpha
                )
            );

        ImVec4 textColor;
        if (isNpc) {
            textColor = ImVec4(1.f, 0.6f, 0.2f, safeAlpha);
        }
        else if (isSleeping) {
            textColor = ImVec4(0.45f, 0.85f, 1.f, safeAlpha);
        }
        else {
            textColor = ImVec4(0.94f, 0.94f, 0.96f, safeAlpha);
        }

        const ImU32 text =
            ImGui::GetColorU32(textColor);

        dl->AddText(
            font,
            13.f,
            ImVec2(
                np.x + 1.f,
                np.y + 1.f
            ),
            shadow,
            name
        );

        dl->AddText(
            font,
            13.f,
            np,
            text,
            name
        );
    }

    static void DrawLayout(
        ImDrawList* dl,
        ImFont* font,
        const ImRect& rect,
        float slotSize,
        float alpha,
        const char* name,
        const InventoryItem* const* wear,
        int wearCount,
        const InventoryItem* const* belt,
        int beltCount,
        IconsManager* icons,
        bool allowIcons,
        bool drawAmounts,
        bool isNpc,
        bool isSleeping
    ) {
        if (
            !dl ||
            !font ||
            rect.GetWidth() <= 0.f ||
            rect.GetHeight() <= 0.f
            ) {
            return;
        }

        const float safeSlot =
            SafeSlotSize(
                slotSize
            );

        const float safeAlpha =
            ImClamp(
                alpha,
                0.f,
                1.f
            );

        const float gap = 4.f;
        const float rowGap = 4.f;
        const float pad = 7.f;
        const float rowH =
            safeSlot +
            pad * 2.f;

        const float centerX =
            rect.GetCenter().x;

        const float contentY =
            rect.Min.y + 23.f;

        const float wearRowWidth =
            static_cast<float>(
                WEAR_SLOTS
                ) *
            safeSlot +
            static_cast<float>(
                WEAR_SLOTS - 1
                ) *
            gap +
            pad * 2.f;

        const float beltRowWidth =
            static_cast<float>(
                BELT_SLOTS
                ) *
            safeSlot +
            static_cast<float>(
                BELT_SLOTS - 1
                ) *
            gap +
            pad * 2.f;

        const float bgWidth =
            ImMax(
                wearRowWidth,
                beltRowWidth
            );

        const float bgHeight =
            2.f *
            rowH +
            rowGap;

        const ImVec2 bgMin(
            centerX -
            bgWidth * 0.5f,
            contentY
        );

        const ImVec2 bgMax(
            centerX +
            bgWidth * 0.5f,
            contentY +
            bgHeight
        );

        const ImVec4 bg(
            0.008f,
            0.009f,
            0.014f,
            0.96f * safeAlpha
        );

        const ImVec4 border(
            1.f,
            1.f,
            1.f,
            0.07f * safeAlpha
        );

        dl->PushClipRect(
            rect.Min,
            rect.Max,
            true
        );

        dl->AddRectFilled(
            bgMin,
            bgMax,
            ImGui::GetColorU32(
                bg
            ),
            10.f
        );

        dl->AddRect(
            ImVec2(
                bgMin.x + 0.5f,
                bgMin.y + 0.5f
            ),
            ImVec2(
                bgMax.x - 0.5f,
                bgMax.y - 0.5f
            ),
            ImGui::GetColorU32(
                border
            ),
            10.f,
            ImDrawFlags_RoundCornersAll,
            1.f
        );

        DrawName(
            dl,
            font,
            rect,
            name,
            centerX,
            safeAlpha,
            isNpc,
            isSleeping
        );

        DrawSlots(
            dl,
            font,
            icons,
            wear,
            wearCount,
            WEAR_SLOTS,
            safeSlot,
            centerX,
            contentY,
            safeAlpha,
            allowIcons,
            drawAmounts,
            true
        );

        DrawSlots(
            dl,
            font,
            icons,
            belt,
            beltCount,
            BELT_SLOTS,
            safeSlot,
            centerX,
            contentY +
            rowH +
            rowGap,
            safeAlpha,
            allowIcons,
            drawAmounts,
            false
        );

        dl->PopClipRect();
    }

public:
    PlayerInventoryReader reader;

    bool useRadiusSelection = true;
    bool prioritizeActiveAimTarget = true;

    float aimRadiusPx = 300.f;

    static void SetRenderRect(
        const ImRect& rect
    ) {
        if (
            !std::isfinite(
                rect.Min.x
            ) ||
            !std::isfinite(
                rect.Min.y
            ) ||
            !std::isfinite(
                rect.Max.x
            ) ||
            !std::isfinite(
                rect.Max.y
            ) ||
            rect.Max.x <= rect.Min.x ||
            rect.Max.y <= rect.Min.y
            ) {
            return;
        }

        sharedRenderMin =
            rect.Min;

        sharedRenderMax =
            rect.Max;

        sharedRenderRectValid =
            true;
    }

    static void ClearRenderRect() {
        sharedRenderMin =
            ImVec2(
                0.f,
                0.f
            );

        sharedRenderMax =
            ImVec2(
                0.f,
                0.f
            );

        sharedRenderRectValid =
            false;
    }

    static bool HasRenderRect() {
        return sharedRenderRectValid;
    }

    static void SetEditorMode(
        bool value
    ) {
        sharedEditorMode =
            value;
    }

    static bool IsEditorMode() {
        return sharedEditorMode;
    }

    static void SetMenuPreviewActive(
        bool value
    ) {
        sharedMenuPreviewActive =
            value;
    }

    static bool IsMenuPreviewActive() {
        return sharedMenuPreviewActive;
    }

    void SetTargets(
        const std::vector<uintptr_t>& ids
    ) {
        if (sharedMenuPreviewActive) {
            static const std::vector<uintptr_t> emptyTargets;
            reader.SetTargetPlayers(
                emptyTargets
            );
            return;
        }

        reader.SetTargetPlayers(
            ids
        );
    }

    static void DrawPreview(
        ImDrawList* dl,
        ImFont* font,
        const ImRect& rect,
        float slotSize,
        float alpha
    ) {
        if (
            !dl ||
            !font
            ) {
            return;
        }

        static const InventoryItem fakeWear[WEAR_SLOTS] = {
            { "", "", 1, 0.f, 0.f, 1, 2 },
            { "", "", 1, 0.f, 0.f, 2, 2 },
            { "", "", 1, 0.f, 0.f, 3, 2 },
            { "", "", 1, 0.f, 0.f, 4, 2 },
            { "", "", 1, 0.f, 0.f, 5, 2 },
            { "", "", 1, 0.f, 0.f, 6, 2 },
            { "", "", 1, 0.f, 0.f, 7, 2 }
        };

        static const InventoryItem fakeBelt[BELT_SLOTS] = {
            { "", "", 1, 0.f, 0.f, 11, 0 },
            { "", "", 1, 0.f, 0.f, 12, 0 },
            { "", "", 1, 0.f, 0.f, 13, 0 },
            { "", "", 1, 0.f, 0.f, 14, 0 },
            { "", "", 1, 0.f, 0.f, 15, 0 },
            { "", "", 1, 0.f, 0.f, 16, 0 }
        };

        const InventoryItem* wear[WEAR_SLOTS] = {};
        const InventoryItem* belt[BELT_SLOTS] = {};

        for (int i = 0; i < WEAR_SLOTS; ++i) {
            wear[i] = &fakeWear[i];
        }

        for (int i = 0; i < BELT_SLOTS; ++i) {
            belt[i] = &fakeBelt[i];
        }

        DrawLayout(
            dl,
            font,
            rect,
            slotSize,
            alpha,
            "Preview Player",
            wear,
            WEAR_SLOTS,
            belt,
            BELT_SLOTS,
            nullptr,
            false,
            false,
            false,
            false
        );
    }

    void Draw(
        ImDrawList* dl,
        ImFont* font,
        const RenderSnapshot& snap,
        const WorldToScreenUtils::CameraSnapshot& cam,
        int width,
        int height,
        IconsManager& icons,
        float slotSize,
        const std::unordered_map<uintptr_t, ImVec2>& anchorPoints,
        const ImRect& rect,
        bool isEditorPreview = false,
        float alpha = 1.f
    ) {
        (void)cam;

        if (
            !dl ||
            !font ||
            width <= 0 ||
            height <= 0
            ) {
            return;
        }

        if (isEditorPreview) {
            SetRenderRect(
                rect
            );

            DrawPreview(
                dl,
                font,
                rect,
                slotSize,
                alpha
            );

            return;
        }

        if (sharedEditorMode)
            return;

        const bool menuPreview = sharedMenuPreviewActive;

        const uintptr_t localId =
            LocalPlayerUtils::GetLocalPlayerId(
                snap.players
            );

        uintptr_t bestId = 0;
        const char* bestName = nullptr;
        bool bestIsNpc = false;
        bool bestIsSleeping = false;

        if (!menuPreview && prioritizeActiveAimTarget) {
            const char* activeName = nullptr;
            bool activeIsNpc = false;
            bool activeIsSleeping = false;

            if (ValidateSnapshotTarget(
                snap,
                g_currentAimTarget,
                localId,
                &activeName,
                &activeIsNpc,
                &activeIsSleeping
            )) {
                bestId = g_currentAimTarget;
                bestName = activeName;
                bestIsNpc = activeIsNpc;
                bestIsSleeping = activeIsSleeping;
            }
        }

        if (!menuPreview && bestId == 0 && useRadiusSelection) {
            const float aimRadius =
                std::isfinite(
                    aimRadiusPx
                ) &&
                aimRadiusPx > 0.f
                ? aimRadiusPx
                : height * 0.3f;

            const float aimRadSq =
                aimRadius *
                aimRadius;

            const float screenCx =
                width * 0.5f;

            const float screenCy =
                height * 0.5f;

            uintptr_t radiusId = 0;
            float bestDSq = FLT_MAX;
            const char* radiusName = nullptr;

            for (
                const auto& [entityId, anchor] :
                anchorPoints
                ) {
                if (
                    entityId ==
                    localId
                    ) {
                    continue;
                }

                if (
                    !std::isfinite(
                        anchor.x
                    ) ||
                    !std::isfinite(
                        anchor.y
                    )
                    ) {
                    continue;
                }

                const float dx =
                    anchor.x -
                    screenCx;

                const float dy =
                    anchor.y -
                    screenCy;

                const float dSq =
                    dx * dx +
                    dy * dy;

                if (
                    !std::isfinite(
                        dSq
                    ) ||
                    dSq > aimRadSq ||
                    dSq >= bestDSq
                    ) {
                    continue;
                }

                const char* tmpName = nullptr;
                bool tmpIsNpc = false;
                bool tmpIsSleeping = false;

                if (!ValidateSnapshotTarget(
                    snap,
                    entityId,
                    localId,
                    &tmpName,
                    &tmpIsNpc,
                    &tmpIsSleeping
                )) {
                    continue;
                }

                bestDSq = dSq;
                radiusId = entityId;
                radiusName = tmpName;
                bestIsNpc = tmpIsNpc;
                bestIsSleeping = tmpIsSleeping;
            }

            if (radiusId != 0) {
                bestId = radiusId;
                bestName = radiusName;
            }
        }

        std::vector<uintptr_t> targetsForReader;

        if (!menuPreview && bestId != 0) {
            targetsForReader.push_back(bestId);
        }

        SetTargets(targetsForReader);

        bool activeTarget = false;

        if (!menuPreview && bestId != 0) {
            PlayerInventoryData invData;

            if (reader.GetPlayerInventory(bestId, invData) &&
                HasRenderableInventory(invData)) {
                cachedInventory = std::move(invData);
                cachedName = bestName ? bestName : "";
                cachedIsNpc = bestIsNpc;
                cachedIsSleeping = bestIsSleeping;
                cachedInventoryValid = true;
                activeTarget = true;
            }
        }

        renderAlpha = UpdateRenderAlpha(
            renderAlpha,
            activeTarget && cachedInventoryValid,
            alpha
        );

        if (renderAlpha <= 0.001f || !cachedInventoryValid)
            return;

        const InventoryItem* wear[WEAR_SLOTS] = {};
        const InventoryItem* belt[BELT_SLOTS] = {};

        int wearCount = 0;
        int beltCount = 0;

        for (const auto& item : cachedInventory.items) {
            if (item.containerType == 2 && wearCount < WEAR_SLOTS) {
                wear[wearCount++] = &item;
            }
            else if (item.containerType == 0 && beltCount < BELT_SLOTS) {
                belt[beltCount++] = &item;
            }

            if (wearCount >= WEAR_SLOTS && beltCount >= BELT_SLOTS)
                break;
        }

        if (wearCount == 0 && beltCount == 0) {
            cachedInventoryValid = false;
            renderAlpha = 0.f;
            return;
        }

        const ImRect renderRect =
            rect.GetWidth() > 0.f &&
            rect.GetHeight() > 0.f
            ? rect
            : GetSharedRenderRect(width, height);

        DrawLayout(
            dl,
            font,
            renderRect,
            slotSize,
            renderAlpha,
            cachedName.empty() ? nullptr : cachedName.c_str(),
            wear,
            wearCount,
            belt,
            beltCount,
            &icons,
            true,
            true,
            cachedIsNpc,
            cachedIsSleeping
        );
    }

    void Draw(
        ImDrawList* dl,
        ImFont* font,
        const RenderSnapshot& snap,
        const WorldToScreenUtils::CameraSnapshot& cam,
        int width,
        int height,
        IconsManager& icons,
        float slotSize,
        const std::unordered_map<uintptr_t, ImVec2>& anchorPoints
    ) {
        if (
            sharedEditorMode ||
            sharedMenuPreviewActive
            ) {
            return;
        }

        const ImRect rect =
            GetSharedRenderRect(
                width,
                height
            );

        Draw(
            dl,
            font,
            snap,
            cam,
            width,
            height,
            icons,
            slotSize,
            anchorPoints,
            rect,
            false,
            1.f
        );
    }
};