#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <d3d11.h>
#include <wincodec.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <imgui.h>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "ole32.lib")

extern ID3D11Device* gD3DDevice;

static const GUID k_WICFormat32bppBGRA = { 0x6fddc324, 0x4e03, 0x4bfe, { 0xb1, 0x85, 0x3d, 0x77, 0x76, 0x8d, 0xc9, 0x0f } };

class IconsManager {
public:
    ~IconsManager() {
        for (auto& kv : cache)
            if (kv.second != 0)
                reinterpret_cast<ID3D11ShaderResourceView*>(kv.second)->Release();

        if (resolvedDevice)
            resolvedDevice->Release();
    }

    std::string GetStatus() {
        std::lock_guard<std::mutex> lock(mtx);
        if (basePath.empty()) return "Icon directory not set";
        int len = WideCharToMultiByte(CP_UTF8, 0, basePath.c_str(), -1, nullptr, 0, nullptr, nullptr);
        if (len <= 1) return "Icon directory not available";
        std::string tmp(static_cast<size_t>(len), '\0');
        if (!WideCharToMultiByte(CP_UTF8, 0, basePath.c_str(), -1, &tmp[0], len, nullptr, nullptr)) return "Icon path conversion failed";
        tmp.resize(static_cast<size_t>(len-1));
        return tmp;
    }

    ImTextureID GetIcon(const std::string& shortname) {
        std::lock_guard<std::mutex> lock(mtx);

        EnsureBasePath();
        if (basePath.empty())
            return 0;

        if (!GetDevice())
            return 0;

        auto it = cache.find(shortname);
        if (it != cache.end())
            return it->second;

        auto fit = failedUntil.find(shortname);
        if (fit != failedUntil.end() && GetTickCount64() < fit->second)
            return 0;

        ImTextureID tex = 0;
        std::wstring wpath = basePath + ToWide(shortname) + L".png";

        DWORD attr = GetFileAttributesW(wpath.c_str());
        if (attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY)) {
            ID3D11ShaderResourceView* srv = LoadPNG(wpath);
            tex = reinterpret_cast<ImTextureID>(srv);
            if (tex == 0)
                failedUntil[shortname] = GetTickCount64() + 3000;
        }
        else {
            failedUntil[shortname] = GetTickCount64() + 30000;
        }

        if (tex != 0)
            cache.emplace(shortname, tex);

        return tex;
    }

private:
    std::mutex mtx;
    std::wstring basePath;
    bool pathResolved = false;
    bool comInited = false;
    ULONGLONG lastAttempt = 0;
    ID3D11Device* resolvedDevice = nullptr;
    std::unordered_map<std::string, ImTextureID> cache;
    std::unordered_map<std::string, ULONGLONG> failedUntil;

    ID3D11Device* GetDevice() {
        if (resolvedDevice)
            return resolvedDevice;

        if (gD3DDevice) {
            resolvedDevice = gD3DDevice;
            resolvedDevice->AddRef();
            return resolvedDevice;
        }

        ImTextureRef fontRef = ImGui::GetIO().Fonts->TexID;
        ImTextureID fontTex = fontRef.GetTexID();
        if (!fontTex)
            return nullptr;

        ID3D11ShaderResourceView* fontSrv = reinterpret_cast<ID3D11ShaderResourceView*>(fontTex);
        ID3D11Device* dev = nullptr;

        fontSrv->GetDevice(&dev);
        if (dev) {
            resolvedDevice = dev;
            gD3DDevice = dev;
            return resolvedDevice;
        }

        return nullptr;
    }

    static std::wstring ToWide(const std::string& s) {
        int len = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, nullptr, 0);
        std::wstring out;
        if (len > 0) {
            out.resize(len - 1);
            MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, &out[0], len);
        }
        return out;
    }

    static DWORD FindRustPid() {
        DWORD pid = 0;

        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snap == INVALID_HANDLE_VALUE)
            return 0;

        PROCESSENTRY32W pe{};
        pe.dwSize = sizeof(pe);

        if (Process32FirstW(snap, &pe)) {
            do {
                if (_wcsicmp(pe.szExeFile, L"RustClient.exe") == 0) {
                    pid = pe.th32ProcessID;
                    break;
                }
            } while (Process32NextW(snap, &pe));
        }

        CloseHandle(snap);
        return pid;
    }

    void EnsureBasePath() {
        if (pathResolved)
            return;

        ULONGLONG now = GetTickCount64();
        if (now - lastAttempt < 2000)
            return;
        lastAttempt = now;

        std::wstring resolved = ResolveItemsPath();
        if (!resolved.empty()) {
            basePath = resolved;
            pathResolved = true;
        }
    }

    std::wstring ResolveItemsPath() {
        DWORD pid = FindRustPid();
        if (pid == 0)
            return L"";

        HANDLE hProc = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
        if (!hProc)
            hProc = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pid);
        if (!hProc)
            return L"";

        wchar_t buf[1024] = { 0 };
        DWORD size = 1024;
        BOOL ok = QueryFullProcessImageNameW(hProc, 0, buf, &size);
        CloseHandle(hProc);

        if (!ok || size == 0)
            return L"";

        std::wstring exePath(buf, size);
        size_t slash = exePath.find_last_of(L"\\/");
        if (slash == std::wstring::npos)
            return L"";

        std::wstring items = exePath.substr(0, slash) + L"\\Bundles\\items\\";

        DWORD attr = GetFileAttributesW(items.c_str());
        if (attr == INVALID_FILE_ATTRIBUTES || !(attr & FILE_ATTRIBUTE_DIRECTORY))
            return L"";

        return items;
    }

    ID3D11ShaderResourceView* LoadPNG(const std::wstring& path) {
        ID3D11Device* dev = GetDevice();
        if (!dev)
            return nullptr;

        if (!comInited) {
            CoInitializeEx(nullptr, COINIT_MULTITHREADED);
            comInited = true;
        }

        IWICImagingFactory* factory = nullptr;
        if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory))))
            return nullptr;

        IWICBitmapDecoder* decoder = nullptr;
        if (FAILED(factory->CreateDecoderFromFilename(path.c_str(), nullptr, GENERIC_READ, WICDecodeMetadataCacheOnLoad, &decoder))) {
            factory->Release();
            return nullptr;
        }

        IWICBitmapFrameDecode* frame = nullptr;
        if (FAILED(decoder->GetFrame(0, &frame))) {
            decoder->Release();
            factory->Release();
            return nullptr;
        }

        IWICFormatConverter* conv = nullptr;
        if (FAILED(factory->CreateFormatConverter(&conv))) {
            frame->Release();
            decoder->Release();
            factory->Release();
            return nullptr;
        }

        if (FAILED(conv->Initialize(frame, k_WICFormat32bppBGRA, WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeCustom))) {
            conv->Release();
            frame->Release();
            decoder->Release();
            factory->Release();
            return nullptr;
        }

        UINT w = 0, h = 0;
        conv->GetSize(&w, &h);
        if (w == 0 || h == 0) {
            conv->Release();
            frame->Release();
            decoder->Release();
            factory->Release();
            return nullptr;
        }

        std::vector<BYTE> pixels(static_cast<size_t>(w) * h * 4);
        if (FAILED(conv->CopyPixels(nullptr, w * 4, static_cast<UINT>(pixels.size()), pixels.data()))) {
            conv->Release();
            frame->Release();
            decoder->Release();
            factory->Release();
            return nullptr;
        }

        conv->Release();
        frame->Release();
        decoder->Release();
        factory->Release();

        D3D11_TEXTURE2D_DESC td{};
        td.Width = w;
        td.Height = h;
        td.MipLevels = 1;
        td.ArraySize = 1;
        td.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
        td.SampleDesc.Count = 1;
        td.Usage = D3D11_USAGE_IMMUTABLE;
        td.BindFlags = D3D11_BIND_SHADER_RESOURCE;

        D3D11_SUBRESOURCE_DATA sd{};
        sd.pSysMem = pixels.data();
        sd.SysMemPitch = w * 4;

        ID3D11Texture2D* tex = nullptr;
        if (FAILED(dev->CreateTexture2D(&td, &sd, &tex)))
            return nullptr;

        ID3D11ShaderResourceView* srv = nullptr;
        if (FAILED(dev->CreateShaderResourceView(tex, nullptr, &srv))) {
            tex->Release();
            return nullptr;
        }
        tex->Release();
        return srv;
    }
};