#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <windows.h>
#include <string>

namespace Network
{

    struct TimeSnapshot
    {
        SYSTEMTIME local{};
        bool synchronized = false;
    };

    TimeSnapshot GetTime();

    std::string GetCurrentTimeString(bool withSeconds = true);
}
