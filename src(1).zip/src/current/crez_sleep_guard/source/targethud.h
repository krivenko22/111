#pragma once
#include <cstdint>
#include <cmath>
#include <string>
#include <cstdio>
#include <cfloat>
#include <algorithm>
#include <windows.h>
#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"
#include "base_networkable.h"
#include "world_to_screen.h"
#include "colors.h"
#include "flags.h"

class TargetHud {
private:
    float alpha = 0.f;
    float buttonAlpha = 0.f;
    bool showButton = false;

    uintptr_t activeTarget = 0;
    std::string cachedName = "";
    bool cachedIsNpc = false;
    bool cachedIsSleeping = false;
    bool cachedIsAiming = false;
    float cachedDistance = 0.f;
    bool hasCached = false;

    static float Clamp01(float value) {
        if (value < 0.f) return 0.f;
        if (value > 1.f) return 1.f;
        return value;
    }

    static float Animate(float current, float target, float speed) {
        const ImGuiIO& io = ImGui::GetIO();
        float dt = io.DeltaTime;

        if (!std::isfinite(dt) || dt <= 0.f)
            dt = 1.f / 60.f;

        dt = ImClamp(dt, 0.f, 0.05f);
        target = Clamp01(target);

        const float t = 1.f - std::exp(-speed * dt);
        current += (target - current) * t;

        if (std::fabs(target - current) < 0.001f)
            current = target;

        return Clamp01(current);
    }

    static ImU32 Color(const ImVec4& color) {
        return ImGui::ColorConvertFloat4ToU32(color);
    }

    static ImRect GetPanelRect(const ImRect& rect) {
        const float width = ImMin(rect.GetWidth(), 240.f);
        const float boxHeight = 28.f;
        const float gap = 6.f;
        const float height = boxHeight * 3.f + gap * 2.f;

        const ImVec2 center = rect.GetCenter();

        return ImRect(
            ImVec2(center.x - width * 0.5f, center.y - height * 0.5f),
            ImVec2(center.x + width * 0.5f, center.y + height * 0.5f)
        );
    }

    static ImRect GetButtonRect(const ImRect& panel) {
        const float width = 145.f;
        const float height = 30.f;

        return ImRect(
            ImVec2(panel.GetCenter().x - width * 0.5f, panel.Min.y - height - 10.f),
            ImVec2(panel.GetCenter().x + width * 0.5f, panel.Min.y - 10.f)
        );
    }

    void DrawPanel(
        ImDrawList* draw,
        ImFont* font,
        const ImRect& rect,
        float a,
        const char* name,
        bool isNpc,
        bool isSleeping,
        bool isAiming,
        float distance
    ) {
        if (!draw || !font || !name)
            return;

        const float maxWidth = ImMin(rect.GetWidth(), 240.f);
        const float boxHeight = 28.f;
        const float gap = 6.f;
        const float padX = 16.f;

        const float totalHeight = boxHeight * 3.f + gap * 2.f;
        const float centerX = rect.GetCenter().x;
        const float startY = rect.GetCenter().y - totalHeight * 0.5f;

        if (!std::isfinite(distance))
            distance = 0.f;

        const char* distanceLabel = "Дистанция:";

        char distanceValue[32]{};
        std::snprintf(distanceValue, sizeof(distanceValue), "%.0f М", distance);

        auto drawText = [&](
            float fontSize,
            const ImVec2& pos,
            const ImVec4& color,
            const char* text
            ) {
                ImVec4 shadowColor(0.f, 0.f, 0.f, 0.85f * a);

                ImVec4 finalColor = color;
                finalColor.w *= a;

                draw->AddText(
                    font,
                    fontSize,
                    ImVec2(pos.x + 1.f, pos.y + 1.f),
                    Color(shadowColor),
                    text
                );

                draw->AddText(
                    font,
                    fontSize,
                    pos,
                    Color(finalColor),
                    text
                );
            };

        auto drawBox = [&](
            const ImRect& box,
            const ImVec4& background,
            const ImVec4& border
            ) {
                ImVec4 bg = background;
                bg.w *= a;

                ImVec4 br = border;
                br.w *= a;

                draw->AddRectFilled(
                    box.Min,
                    box.Max,
                    Color(bg),
                    8.f
                );

                draw->AddRect(
                    ImVec2(box.Min.x + 0.5f, box.Min.y + 0.5f),
                    ImVec2(box.Max.x - 0.5f, box.Max.y - 0.5f),
                    Color(br),
                    8.f,
                    ImDrawFlags_RoundCornersAll,
                    1.f
                );
            };

        auto drawCenteredText = [&](
            const ImRect& box,
            float fontSize,
            const ImVec4& color,
            const char* text
            ) {
                const ImVec2 textSize = font->CalcTextSizeA(
                    fontSize,
                    FLT_MAX,
                    0.f,
                    text
                );

                const ImVec2 textPos(
                    box.GetCenter().x - textSize.x * 0.5f,
                    box.GetCenter().y - textSize.y * 0.5f
                );

                drawText(
                    fontSize,
                    textPos,
                    color,
                    text
                );
            };

        const ImVec4 boxBackground(0.008f, 0.009f, 0.014f, 0.95f);
        const ImVec4 boxBorder(1.f, 1.f, 1.f, 0.08f);

        const ImVec4 npcColor(1.f, 0.6f, 0.2f, 1.f);
        const ImVec4 sleepingColor(0.45f, 0.85f, 1.f, 1.f);
        const ImVec4 playerColor(0.94f, 0.94f, 0.96f, 1.f);

        const ImVec4 distanceLabelColor(0.64f, 0.65f, 0.72f, 1.f);
        const ImVec4 distanceValueColor(0.94f, 0.94f, 0.96f, 1.f);

        const ImVec2 nameSize = font->CalcTextSizeA(
            13.f,
            FLT_MAX,
            0.f,
            name
        );

        const ImVec2 distanceLabelSize = font->CalcTextSizeA(
            12.f,
            FLT_MAX,
            0.f,
            distanceLabel
        );

        const ImVec2 distanceValueSize = font->CalcTextSizeA(
            12.f,
            FLT_MAX,
            0.f,
            distanceValue
        );

        const float nameWidth = ImMin(
            nameSize.x + padX * 2.f,
            maxWidth
        );

        const float statusWidth = ImMin(
            maxWidth,
            maxWidth
        );

        const float distanceWidth = ImMin(
            ImMax(
                distanceLabelSize.x + distanceValueSize.x + padX * 3.f,
                170.f
            ),
            maxWidth
        );

        const ImRect nameRect(
            ImVec2(centerX - nameWidth * 0.5f, startY),
            ImVec2(centerX + nameWidth * 0.5f, startY + boxHeight)
        );

        const ImRect statusRect(
            ImVec2(centerX - statusWidth * 0.5f, startY + boxHeight + gap),
            ImVec2(centerX + statusWidth * 0.5f, startY + boxHeight * 2.f + gap)
        );

        const ImRect distanceRect(
            ImVec2(centerX - distanceWidth * 0.5f, startY + (boxHeight + gap) * 2.f),
            ImVec2(centerX + distanceWidth * 0.5f, startY + boxHeight * 3.f + gap * 2.f)
        );

        drawBox(
            nameRect,
            boxBackground,
            boxBorder
        );

        ImVec4 nameTextColor = playerColor;
        if (isNpc) {
            nameTextColor = npcColor;
        }
        else if (isSleeping) {
            nameTextColor = sleepingColor;
        }

        drawCenteredText(
            nameRect,
            13.f,
            nameTextColor,
            name
        );

        drawBox(
            statusRect,
            boxBackground,
            boxBorder
        );

        const char* statusText = "Игрок";
        ImVec4 statusTextColor = playerColor;

        if (isNpc) {
            statusText = "NPC";
            statusTextColor = npcColor;
        }
        else if (isSleeping) {
            statusText = "Спит";
            statusTextColor = sleepingColor;
        }
        else {
            if (isAiming) {
                statusText = "Целится";
                statusTextColor = ImVec4(1.f, 0.35f, 0.35f, 1.f); // Красный
            }
            else {
                statusText = "Не целится";
                statusTextColor = ImVec4(0.35f, 1.f, 0.35f, 1.f); // Зеленый
            }
        }

        drawCenteredText(
            statusRect,
            12.f,
            statusTextColor,
            statusText
        );

        drawBox(
            distanceRect,
            boxBackground,
            boxBorder
        );

        const ImVec2 distanceLabelPos(
            distanceRect.Min.x + padX,
            distanceRect.GetCenter().y - distanceLabelSize.y * 0.5f
        );

        const ImVec2 distanceValuePos(
            distanceRect.Max.x - padX - distanceValueSize.x,
            distanceRect.GetCenter().y - distanceValueSize.y * 0.5f
        );

        drawText(
            12.f,
            distanceLabelPos,
            distanceLabelColor,
            distanceLabel
        );

        drawText(
            12.f,
            distanceValuePos,
            distanceValueColor,
            distanceValue
        );
    }

    void DrawButton(
        ImDrawList* draw,
        ImFont* font,
        const ImRect& panel,
        float a
    ) {
        if (!draw || !font || a <= 0.001f)
            return;

        const ImRect button = GetButtonRect(panel);
        const char* label = enabled ? "Скрыть" : "Показать";

        draw->AddRectFilled(
            button.Min,
            button.Max,
            Color(ImVec4(0.012f, 0.012f, 0.020f, 0.96f * a)),
            8.f
        );

        draw->AddRect(
            ImVec2(button.Min.x + 0.5f, button.Min.y + 0.5f),
            ImVec2(button.Max.x - 0.5f, button.Max.y - 0.5f),
            Color(ImVec4(1.f, 1.f, 1.f, 0.085f * a)),
            8.f,
            ImDrawFlags_RoundCornersAll,
            1.f
        );

        const ImVec2 textSize = font->CalcTextSizeA(
            12.f,
            FLT_MAX,
            0.f,
            label
        );

        const ImVec2 textPos(
            button.GetCenter().x - textSize.x * 0.5f,
            button.GetCenter().y - textSize.y * 0.5f
        );

        draw->AddText(
            font,
            12.f,
            ImVec2(textPos.x + 1.f, textPos.y + 1.f),
            Color(ImVec4(0.f, 0.f, 0.f, 0.80f * a)),
            label
        );

        draw->AddText(
            font,
            12.f,
            textPos,
            Color(ImVec4(colors::accent.x, colors::accent.y, colors::accent.z, a)),
            label
        );
    }

public:
    bool enabled = true;
    float animationSpeed = 12.f;
    float buttonAnimationSpeed = 16.f;

    static TargetHud& Get() {
        static TargetHud instance;
        return instance;
    }

    void Update(
        const RenderSnapshot& snap,
        const WorldToScreenUtils::CameraSnapshot& cam,
        uintptr_t target
    ) {
        if (!enabled) {
            activeTarget = 0;
            hasCached = false;
            return;
        }

        if (target != activeTarget) {
            activeTarget = target;
        }

        if (activeTarget == 0) {
            hasCached = false;
            return;
        }

        bool found = false;

        for (const auto& player : snap.players) {
            if (player.entityId != activeTarget)
                continue;

            if (!player.valid || !player.isAlive)
                break;

            found = true;
            cachedName = player.name ? player.name : "";
            cachedIsNpc = player.isNpc;
            cachedIsSleeping = player.isSleeping;
            cachedIsAiming = PlayerFlagsUtils::IsAiming(player.entityId);

            if (cam.valid) {
                const float dx = player.position.x - cam.position.x;
                const float dy = player.position.y - cam.position.y;
                const float dz = player.position.z - cam.position.z;
                const float dist = std::sqrt(dx * dx + dy * dy + dz * dz);

                if (std::isfinite(dist))
                    cachedDistance = dist;
            }

            hasCached = true;
            break;
        }

        if (!found) {
            hasCached = false;
            return;
        }
    }

    void DrawInterface(
        ImDrawList* draw,
        ImFont* font,
        const ImRect& rect,
        float externalAlpha,
        bool menuPreview,
        bool interactive
    ) {
        if (!draw || !font)
            return;

        float targetAlpha = 0.f;

        if (menuPreview) {
            targetAlpha = externalAlpha * (enabled ? 1.f : 0.35f);
        }
        else if (enabled && activeTarget != 0 && hasCached) {
            targetAlpha = externalAlpha;
        }

        alpha = Animate(alpha, targetAlpha, animationSpeed);

        const ImRect panel = GetPanelRect(rect);
        const ImRect button = GetButtonRect(panel);

        if (interactive) {
            const ImVec2 mouse = ImGui::GetIO().MousePos;
            bool buttonClicked = false;

            if (buttonAlpha > 0.05f && button.Contains(mouse) && ImGui::IsMouseReleased(ImGuiMouseButton_Left)) {
                enabled = !enabled;
                showButton = false;
                buttonClicked = true;
            }

            if (panel.Contains(mouse)) {
                if (ImGui::IsMouseReleased(ImGuiMouseButton_Right)) {
                    showButton = !showButton;
                }
                else if (showButton && ImGui::IsMouseReleased(ImGuiMouseButton_Left) && !buttonClicked) {
                    showButton = false;
                }
            }
            else if (showButton && ImGui::IsMouseReleased(ImGuiMouseButton_Left) && !button.Contains(mouse)) {
                showButton = false;
            }
        }

        bool shouldShowButton = showButton;
        if (menuPreview && !enabled) {
            shouldShowButton = true;
        }

        buttonAlpha = Animate(
            buttonAlpha,
            (menuPreview && interactive && shouldShowButton) ? alpha : 0.f,
            buttonAnimationSpeed
        );

        if (alpha <= 0.001f) {
            if (!menuPreview)
                showButton = false;
            return;
        }

        if (menuPreview) {
            DrawPanel(
                draw,
                font,
                rect,
                alpha,
                "Target Player",
                false,
                false,
                true,
                27.f
            );
        }
        else {
            DrawPanel(
                draw,
                font,
                rect,
                alpha,
                cachedName.empty() ? "Unknown" : cachedName.c_str(),
                cachedIsNpc,
                cachedIsSleeping,
                cachedIsAiming,
                cachedDistance
            );
        }

        if (buttonAlpha > 0.001f) {
            DrawButton(
                draw,
                font,
                panel,
                buttonAlpha
            );
        }
    }
};