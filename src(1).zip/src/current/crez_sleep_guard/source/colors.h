#pragma once

#include "imgui.h"

namespace colors
{

    inline constexpr ImVec4 accent = { 0.690f, 0.090f, 0.145f, 1.f }; // #B01825
    inline constexpr ImVec4 accent_soft = { 0.360f, 0.045f, 0.075f, 1.f };

    inline constexpr ImVec4 bg = { 0.022f, 0.022f, 0.026f, 1.f };
    inline constexpr ImVec4 panel = { 0.029f, 0.029f, 0.034f, 1.f };
    inline constexpr ImVec4 sidebar = { 0.034f, 0.034f, 0.040f, 1.f };
    inline constexpr ImVec4 box = { 0.043f, 0.043f, 0.050f, 1.f };
    inline constexpr ImVec4 control = { 0.053f, 0.053f, 0.061f, 1.f };
    inline constexpr ImVec4 control_hover = { 0.090f, 0.090f, 0.102f, 1.f };
    inline constexpr ImVec4 circle_checkbox_hover = { 0.245f, 0.085f, 0.105f, 1.f };
    inline constexpr ImVec4 widget = control;
    inline constexpr ImVec4 widget_hover = control_hover;

    inline constexpr ImVec4 text = { 0.925f, 0.925f, 0.940f, 1.f };
    inline constexpr ImVec4 text_muted = { 0.405f, 0.405f, 0.435f, 1.f };
    inline constexpr ImVec4 header_text = { 0.650f, 0.650f, 0.690f, 1.f };
    inline constexpr ImVec4 separator = { 0.115f, 0.115f, 0.130f, 0.72f };
    inline constexpr ImVec4 sidebar_sep = { 0.095f, 0.095f, 0.110f, 0.78f };
    inline constexpr ImVec4 dropdown_bg = { 0.038f, 0.038f, 0.045f, 1.f };
    inline constexpr ImVec4 config_sel = { 1.f, 1.f, 1.f, 0.045f };
    inline constexpr ImVec4 config_hover = { 1.f, 1.f, 1.f, 0.028f };
    inline constexpr ImVec4 success = { 0.330f, 0.720f, 0.490f, 1.f };
    inline constexpr ImVec4 danger = { 0.820f, 0.220f, 0.270f, 1.f };
}
