#pragma once
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "types.h"
#include "Offsets.h"
#include "decryptors.h"
#include "Driver/Driver.h"
#include "base_networkable.h"
#include <vector>
#include <chrono>
#include <thread>
#include <mutex>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cctype>
#include <unordered_map>
#include <unordered_set>
#include <string>

extern uintptr_t gBase;

enum class OreType : uint8_t { None = 0, Metal, Sulfur, Stone, Hqm };
enum class CollectType : uint8_t { None = 0, Wood };

struct WorldEntityData {
    uintptr_t entityId{};
    Vector3     position{};
    Vector3     bounds{};
    bool        valid{};
    std::string shortName{};
    std::string iconName{};

    bool     isOre{ false };
    bool     isVehicle{ false };

    OreType     oreType{ OreType::None };
    CollectType collectType{ CollectType::None };
};

class WorldManager {
public:
    WorldManager() {
        entityBuffers[0].reserve(512);
        entityBuffers[1].reserve(512);
        threadRunning.store(true, std::memory_order_release);
        updateThread = std::thread(&WorldManager::UpdateLoop, this);
    }

    ~WorldManager() {
        threadRunning.store(false, std::memory_order_release);
        if (updateThread.joinable()) updateThread.join();
    }

    static WorldManager& Get() {
        static WorldManager instance;
        return instance;
    }

    std::vector<WorldEntityData> GetAllEntities() {
        std::lock_guard<std::mutex> lock(bufferSwapMutex);
        return entityBuffers[readBufferIdx];
    }
    void GetAllEntities(std::vector<WorldEntityData>& out) {
        std::lock_guard<std::mutex> lock(bufferSwapMutex);
        out = entityBuffers[readBufferIdx];
    }

private:
    std::vector<WorldEntityData> entityBuffers[2];
    int                          readBufferIdx = 0;
    std::mutex                   bufferSwapMutex;
    std::thread                  updateThread;
    std::atomic<bool>            threadRunning{ false };

    std::unordered_map<uintptr_t, std::string> prefabCache;
    std::unordered_map<uintptr_t, std::string> classCache;
    std::unordered_map<uint32_t, std::string>  prefabIdNameCache;

    static constexpr int UPDATE_INTERVAL_MS = 25;
    static constexpr float ORE_MIN_Y = 0.5f;
    static constexpr uintptr_t OFF_PREFAB_ID = 0x54;
    static constexpr uintptr_t OFF_PREFAB_NAME = 0x48;
    static constexpr uintptr_t OFF_PREFAB_NAME_NO_EXT = 0x28;
    static constexpr uintptr_t OFF_BOUNDS_CENTER = 0x18C;
    static constexpr uintptr_t OFF_BOUNDS_EXTENTS = 0x198;
    static constexpr uintptr_t OFF_POSITION_SPAWN = 0x168;
    static constexpr uintptr_t OFF_MODEL = 0x1B8;
    static constexpr uintptr_t OFF_KLASS = 0x0;
    static constexpr uintptr_t OFF_KLASS_NAME = 0x10;
    static constexpr uintptr_t OFF_STR_LEN = 0x10;
    static constexpr uintptr_t OFF_STR_CHARS = 0x14;

    static bool valid_pos(const Vector3& p) {
        if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z)) return false;
        if (std::abs(p.x) > 4500.0f || std::abs(p.z) > 4500.0f) return false;
        if (p.y < -100.0f || p.y > 1500.0f) return false;
        if (std::abs(p.x) < 5.0f && std::abs(p.z) < 5.0f) return false;
        if (std::abs(p.x - 1.0f) < 0.01f && std::abs(p.y - 1.0f) < 0.01f && std::abs(p.z - 1.0f) < 0.01f) return false;
        return true;
    }

    static bool has(const std::string& s, const char* sub) {
        return s.find(sub) != std::string::npos;
    }

    static Vector3 ReadTransformChain(uintptr_t t) {
        if (!Decryption::is_valid_ptr(t)) return {};
        uintptr_t ind = kernelHandler.readmem<uintptr_t>(t + 0x28);
        if (!Decryption::is_valid_ptr(ind)) return {};
        uintptr_t acc = kernelHandler.readmem<uintptr_t>(ind + 0x28);
        if (!Decryption::is_valid_ptr(acc)) return {};
        uintptr_t dat = kernelHandler.readmem<uintptr_t>(acc + 0x18);
        if (!Decryption::is_valid_ptr(dat)) return {};
        Vector3 p = kernelHandler.readmem<Vector3>(dat + 0x90);
        return valid_pos(p) ? p : Vector3{};
    }

    Vector3 GetTransformLivePos(uintptr_t ent) {
        uintptr_t cached = kernelHandler.readmem<uintptr_t>(ent + 0x10);
        if (!Decryption::is_valid_ptr(cached)) return {};
        uintptr_t go = kernelHandler.readmem<uintptr_t>(cached + 0x20);
        if (!Decryption::is_valid_ptr(go)) return {};
        uintptr_t comps = kernelHandler.readmem<uintptr_t>(go + 0x20);
        int cnt = kernelHandler.readmem<int>(go + 0x30);
        if (!Decryption::is_valid_ptr(comps) || cnt <= 0 || cnt > 128) return {};

        static const uintptr_t offsets[] = { 0x80, 0x90, 0xA0 };
        for (int i = 0; i < cnt; ++i) {
            uintptr_t comp = kernelHandler.readmem<uintptr_t>(comps + (uintptr_t)i * 0x10 + 0x8);
            if (!Decryption::is_valid_ptr(comp)) continue;
            uintptr_t native = kernelHandler.readmem<uintptr_t>(comp + 0x10);
            uintptr_t candidates[2] = { comp, native };
            for (uintptr_t t : candidates) {
                if (!Decryption::is_valid_ptr(t)) continue;
                Vector3 p = ReadTransformChain(t);
                if (valid_pos(p)) return p;
                for (uintptr_t off : offsets) {
                    Vector3 p2 = kernelHandler.readmem<Vector3>(t + off);
                    if (valid_pos(p2)) return p2;
                }
            }
        }
        return {};
    }

    Vector3 GetEntityPosition(uintptr_t ent, const WorldEntityData& d, const std::string& klass, uintptr_t& outOffset) {
        outOffset = 0;

        bool isStaticLoot =
            d.isOre ||
            d.collectType != CollectType::None;

        if (isStaticLoot) {
            Vector3 bc = kernelHandler.readmem<Vector3>(ent + OFF_BOUNDS_CENTER);
            if (valid_pos(bc)) { outOffset = OFF_BOUNDS_CENTER; return bc; }
            Vector3 sp = kernelHandler.readmem<Vector3>(ent + OFF_POSITION_SPAWN);
            if (valid_pos(sp)) { outOffset = OFF_POSITION_SPAWN; return sp; }
        }

        uintptr_t model = kernelHandler.readmem<uintptr_t>(ent + OFF_MODEL);
        if (Decryption::is_valid_ptr(model)) {
            static const uintptr_t boneArrOffs[] = { 0x50, 0x98 };
            for (uintptr_t barrof : boneArrOffs) {
                uintptr_t boneArr = kernelHandler.readmem<uintptr_t>(model + barrof);
                if (!Decryption::is_valid_ptr(boneArr)) continue;

                int len = kernelHandler.readmem<int>(boneArr + 0x18);
                if (len <= 0 || len > 300) continue;

                uintptr_t data = kernelHandler.readmem<uintptr_t>(boneArr + 0x20);
                if (!Decryption::is_valid_ptr(data)) continue;

                int check = len < 4 ? len : 4;
                for (int i = 0; i < check; ++i) {
                    uintptr_t bone = kernelHandler.readmem<uintptr_t>(data + (uintptr_t)i * 8);
                    if (!Decryption::is_valid_ptr(bone)) continue;

                    uintptr_t bsrcArr[2] = { bone, kernelHandler.readmem<uintptr_t>(bone + 0x10) };
                    for (uintptr_t bsrc : bsrcArr) {
                        if (!Decryption::is_valid_ptr(bsrc)) continue;
                        Vector3 p = ReadTransformChain(bsrc);
                        if (valid_pos(p)) {
                            outOffset = 0x30000 | (barrof & 0xFF) | ((uintptr_t)i << 8);
                            return p;
                        }
                    }
                }
            }

            Vector3 mp = ReadTransformChain(model);
            if (valid_pos(mp)) { outOffset = 0x20000; return mp; }

            static const uintptr_t mdlPos[] = { 0x2F8 };
            for (uintptr_t off : mdlPos) {
                Vector3 p = kernelHandler.readmem<Vector3>(model + off);
                if (valid_pos(p)) { outOffset = 0x10000 | off; return p; }
            }
        }

        Vector3 tlive2 = GetTransformLivePos(ent);
        if (valid_pos(tlive2)) { outOffset = 0x20000; return tlive2; }

        Vector3 sp = kernelHandler.readmem<Vector3>(ent + OFF_POSITION_SPAWN);
        if (valid_pos(sp)) { outOffset = OFF_POSITION_SPAWN; return sp; }

        if (!isStaticLoot) {
            Vector3 bc = kernelHandler.readmem<Vector3>(ent + OFF_BOUNDS_CENTER);
            if (valid_pos(bc)) { outOffset = OFF_BOUNDS_CENTER; return bc; }
        }

        return {};
    }

    std::string ReadUnityString(uintptr_t strPtr) {
        if (!Decryption::is_valid_ptr(strPtr)) return {};
        int length = kernelHandler.readmem<int>(strPtr + OFF_STR_LEN);
        if (length <= 0 || length > 128) return {};
        wchar_t wbuf[129]{};
        kernelHandler.read_memory(strPtr + OFF_STR_CHARS,
            reinterpret_cast<uint64_t>(wbuf), length * sizeof(wchar_t));
        std::string result;
        result.reserve(length);
        for (int i = 0; i < length; ++i) {
            if (wbuf[i] == 0) break;
            result += static_cast<char>(wbuf[i]);
        }
        return result;
    }

    std::string GetPrefabName(uintptr_t ent) {
        auto it = prefabCache.find(ent);
        if (it != prefabCache.end() && !it->second.empty())
            return it->second;

        uint32_t prefabID = kernelHandler.readmem<uint32_t>(ent + OFF_PREFAB_ID);
        bool validID = (prefabID != 0 && prefabID != 0xFFFFFFFF);

        if (validID) {
            auto idIt = prefabIdNameCache.find(prefabID);
            if (idIt != prefabIdNameCache.end() && !idIt->second.empty()) {
                prefabCache[ent] = idIt->second;
                return idIt->second;
            }
        }

        std::string name = ReadUnityString(kernelHandler.readmem<uintptr_t>(ent + OFF_PREFAB_NAME));
        if (name.empty())
            name = ReadUnityString(kernelHandler.readmem<uintptr_t>(ent + OFF_PREFAB_NAME_NO_EXT));

        if (!name.empty()) {
            prefabCache[ent] = name;
            if (validID)
                prefabIdNameCache[prefabID] = name;
        }
        else {
            prefabCache.erase(ent);
        }

        return name;
    }

    std::string GetEntityClass(uintptr_t ent) {
        auto it = classCache.find(ent);
        if (it != classCache.end() && !it->second.empty())
            return it->second;

        uintptr_t klass = kernelHandler.readmem<uintptr_t>(ent + OFF_KLASS);
        if (!Decryption::is_valid_ptr(klass)) return {};

        uintptr_t namePtr = kernelHandler.readmem<uintptr_t>(klass + OFF_KLASS_NAME);
        if (!Decryption::is_valid_ptr(namePtr)) return {};

        char buf[64]{};
        kernelHandler.read_memory(namePtr, (uint64_t)buf, 63);
        buf[63] = '\0';

        std::string name(buf);
        if (!name.empty())
            classCache[ent] = name;
        else
            classCache.erase(ent);

        return name;
    }

    void ClassifyEntity(WorldEntityData& d, const std::string& k, const std::string& pl) {
        // ===== ДРОВА =====
        if (has(pl, "wood-pile") || has(pl, "wood_pile") || has(pl, "woodpile")) {
            d.collectType = CollectType::Wood;
            d.shortName = "Дрова"; d.iconName = "wood";
            return;
        }

        // ===== РУДЫ =====
        bool isTreeLike =
            has(k, "TreeEntity") || has(k, "Tree") ||
            has(pl, "tree") || has(pl, "bush") || has(pl, "foliage") ||
            has(pl, "palm") || has(pl, "pine") || has(pl, "oak") ||
            has(pl, "birch") || has(pl, "redwood") || has(pl, "cactus") ||
            has(pl, "bamboo") || has(pl, "/trees/") || has(pl, "tree_");

        bool isOreClass = has(k, "OreResourceEntity");
        bool oreByName =
            !isTreeLike &&
            (has(pl, "metal-ore") || has(pl, "metal.ore") ||
                has(pl, "sulfur-ore") || has(pl, "sulfur.ore") ||
                has(pl, "stone-ore") || has(pl, "stone.ore") ||
                has(pl, "hq-metal-ore") || has(pl, "hq.metal.ore") ||
                has(pl, "hqmetal"));

        if (!isTreeLike && (isOreClass || oreByName)) {
            if (!has(pl, "wood") && !has(pl, "log")) {
                bool isHqm =
                    has(pl, "hq-metal") || has(pl, "hq_metal") ||
                    has(pl, "hq.metal") || has(pl, "hqmetal") ||
                    has(pl, "hqm") || has(pl, "highquality");

                if (isHqm)               d.oreType = OreType::Hqm;
                else if (has(pl, "sulfur")) d.oreType = OreType::Sulfur;
                else if (has(pl, "metal"))  d.oreType = OreType::Metal;
                else if (has(pl, "stone") || has(pl, "rock")) d.oreType = OreType::Stone;

                switch (d.oreType) {
                case OreType::Metal:  d.shortName = "Металлическая руда"; d.iconName = "metal.ore";    break;
                case OreType::Sulfur: d.shortName = "Серная руда";        d.iconName = "sulfur.ore";   break;
                case OreType::Stone:  d.shortName = "Каменная руда";      d.iconName = "stones";       break;
                case OreType::Hqm:    d.shortName = "Мвк руда";           d.iconName = "hq.metal.ore"; break;
                default:              d.shortName = "Руда";               d.iconName = "";             break;
                }
                d.isOre = true;
                return;
            }
        }

        // ===== ЛОШАДИ =====
        if (has(pl, "horse")) {
            d.isVehicle = true;
            d.shortName = "Лошадь"; d.iconName = "horse";
            return;
        }
    }

    void UpdateLoop() {
        while (threadRunning.load(std::memory_order_relaxed)) {
            const auto startTime = std::chrono::steady_clock::now();
            auto cachedEntities = BaseNetworkable::Get().GetCachedEntities();

            int writeIdx;
            {
                std::lock_guard<std::mutex> lock(bufferSwapMutex);
                writeIdx = 1 - readBufferIdx;
            }

            auto& out = entityBuffers[writeIdx];
            out.clear();
            if (out.capacity() < 512) out.reserve(512);

            std::unordered_set<uintptr_t> seenIds;
            seenIds.reserve(cachedEntities.size());

            for (uintptr_t ent : cachedEntities) {
                if (!Decryption::is_valid_ptr(ent)) continue;
                seenIds.insert(ent);

                std::string klass = GetEntityClass(ent);
                if (klass.empty()) continue;
                if (has(klass, "BasePlayer")) continue;

                std::string prefab = GetPrefabName(ent);
                std::string pl = prefab;
                for (auto& c : pl) c = (char)std::tolower((unsigned char)c);

                WorldEntityData d{};
                d.entityId = ent;
                ClassifyEntity(d, klass, pl);

                if (!(d.isOre || d.isVehicle ||
                    d.collectType != CollectType::None))
                    continue;

                uintptr_t off = 0;
                Vector3 pos = GetEntityPosition(ent, d, klass, off);
                d.position = pos;
                d.valid = valid_pos(pos);

                if (!d.valid)
                    continue;

                if (d.isOre && d.position.y < ORE_MIN_Y)
                    continue;

                d.bounds = kernelHandler.readmem<Vector3>(ent + OFF_BOUNDS_EXTENTS);

                out.push_back(std::move(d));
            }

            for (auto it = prefabCache.begin(); it != prefabCache.end();) {
                if (seenIds.find(it->first) == seenIds.end()) it = prefabCache.erase(it);
                else ++it;
            }
            for (auto it = classCache.begin(); it != classCache.end();) {
                if (seenIds.find(it->first) == seenIds.end()) it = classCache.erase(it);
                else ++it;
            }

            if (prefabIdNameCache.size() > 5000) prefabIdNameCache.clear();

            {
                std::lock_guard<std::mutex> lock(bufferSwapMutex);
                readBufferIdx = writeIdx;
            }

            const auto elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now() - startTime).count();
            if (elapsedMs < UPDATE_INTERVAL_MS)
                std::this_thread::sleep_for(std::chrono::milliseconds(UPDATE_INTERVAL_MS - elapsedMs));
        }
    }
};