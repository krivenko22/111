#pragma once
#ifndef ANTI_SCREEN_H
#define ANTI_SCREEN_H

#include <windows.h>

#ifndef WDA_NONE
#define WDA_NONE 0x00000000
#endif
#ifndef WDA_EXCLUDEFROMCAPTURE
#define WDA_EXCLUDEFROMCAPTURE 0x00000011
#endif

namespace AntiScreen
{
    namespace detail
    {
        using Fn = BOOL(WINAPI*)(HWND, DWORD);

        inline Fn GetProc()
        {
            static Fn fn = []() -> Fn {
                HMODULE m = ::GetModuleHandleW(L"user32.dll");
                if (!m) return nullptr;
                return (Fn)::GetProcAddress(m, "SetWindowDisplayAffinity");
                }();
            return fn;
        }
    }

    inline bool Apply(HWND hwnd)
    {
        auto fn = detail::GetProc();
        if (!fn || !hwnd || !::IsWindow(hwnd))
            return false;
        return fn(hwnd, WDA_EXCLUDEFROMCAPTURE) == TRUE;
    }

    inline bool Remove(HWND hwnd)
    {
        auto fn = detail::GetProc();
        if (!fn || !hwnd || !::IsWindow(hwnd))
            return false;
        return fn(hwnd, WDA_NONE) == TRUE;
    }
}

#endif