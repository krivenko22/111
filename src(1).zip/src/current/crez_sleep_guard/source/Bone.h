#pragma once
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "Offsets.h"
#include "decryptors.h"
#include "Driver/Driver.h"
#include <vector>
#include <chrono>
#include <unordered_map>
#include <cmath>
#include <mutex>
#include <algorithm>
#include <climits>
#include <cstdint>

struct AoS {
    float px, py, pz, pad0;
    float rx, ry, rz, rw;
    float sx, sy, sz, pad1;
};

struct BoneStructureCache {
    struct BoneInfo {
        int index = -1;
        std::vector<int> hierarchy;
    };

    uintptr_t transforms_ptr = 0;
    uintptr_t shared_td = 0;
    uintptr_t index_base = 0;
    uintptr_t matrix_base = 0;
    int max_index = 0;
    int min_matrix_idx = 0;
    int max_matrix_idx = -1;
    bool structure_valid = false;
    bool rebuilding = false;
    double rebuild_last = 0.0;
    double last_attempt = 0.0;

    std::vector<BoneInfo> bones;
};

struct BonePositionCache {
    Vector3 pos[64] = {};
    Vector3 rawPos[64] = {};
    bool ok = false;
    double refresh = 0.0;
    double last_seen = 0.0;
};

class BoneManager {
public:
    static BoneManager& Get() {
        static BoneManager instance;
        return instance;
    }

    BonePositionCache* GetBonePositions(uintptr_t ent, float /*predictTime*/, const Vector3& /*velocity*/, bool /*isSleeping*/) {
        std::lock_guard<std::mutex> lock(cacheMutex);
        return GetBonePositionsLocked(ent);
    }

    void CleanupStaleEntries() {
        std::lock_guard<std::mutex> lock(cacheMutex);
        CleanupStaleEntriesLocked();
    }

private:
    std::unordered_map<uintptr_t, BoneStructureCache> boneStructureCache;
    std::unordered_map<uintptr_t, BonePositionCache> bonePositionCache;
    std::mutex cacheMutex;
    double lastCleanup = 0.0;

    static double now_s() {
        return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
    }

    void CleanupStaleEntriesLocked() {
        double now = now_s();

        for (auto it = bonePositionCache.begin(); it != bonePositionCache.end(); ) {
            if (now - it->second.last_seen > 5.0) it = bonePositionCache.erase(it);
            else ++it;
        }
        for (auto it = boneStructureCache.begin(); it != boneStructureCache.end(); ) {
            if (now - it->second.rebuild_last > 60.0 && !it->second.structure_valid) it = boneStructureCache.erase(it);
            else ++it;
        }
    }

    BonePositionCache* GetBonePositionsLocked(uintptr_t ent) {
        const double now = now_s();

        auto it = bonePositionCache.find(ent);
        if (it != bonePositionCache.end() && it->second.ok && (now - it->second.refresh) < 0.016) {
            it->second.last_seen = now;
            return &it->second;
        }

        uintptr_t model = kernelHandler.readmem<uintptr_t>(ent + offsets::base_entity::model);
        if (!Decryption::is_valid_ptr(model)) return nullptr;

        uint32_t lifeState = kernelHandler.readmem<uint32_t>(ent + offsets::base_combat_entity::lifestate);
        if (lifeState != 0) return nullptr;

        BoneStructureCache* structure = GetBoneStructureCacheLocked(model, now);
        if (!structure || !structure->structure_valid) return nullptr;

        return GetBonePositionCacheLocked(ent, *structure, now);
    }

    BoneStructureCache* GetBoneStructureCacheLocked(uintptr_t model, double now) {
        if (now - lastCleanup > 10.0) {
            CleanupStaleEntriesLocked();
            lastCleanup = now;
        }

        auto it = boneStructureCache.find(model);
        if (it != boneStructureCache.end() && it->second.structure_valid && !it->second.rebuilding) {
            if (now - it->second.rebuild_last < 30.0) return &it->second;
        }

        BoneStructureCache& sc = boneStructureCache[model];
        if (sc.rebuilding) return sc.structure_valid ? &sc : nullptr;
        // Failed or invalid skeletons must not repeatedly trigger a large batch
        // of driver reads on every rendered frame.
        if (sc.last_attempt > 0.0 && now - sc.last_attempt < 0.100)
            return sc.structure_valid ? &sc : nullptr;
        sc.last_attempt = now;
        sc.rebuilding = true;

        uintptr_t transforms = kernelHandler.readmem<uintptr_t>(model + offsets::model::boneTransforms);
        if (!Decryption::is_valid_ptr(transforms)) {
            sc.rebuilding = false;
            return sc.structure_valid ? &sc : nullptr;
        }

        int bone_count = kernelHandler.readmem<int>(transforms + offsets::model::bone_array_count_off);
        if (bone_count <= 0 || bone_count > 512) {
            sc.rebuilding = false;
            return sc.structure_valid ? &sc : nullptr;
        }

        uintptr_t bone_array = transforms + offsets::model::bone_array_data_off;
        bool needsRebuild = (transforms != sc.transforms_ptr) || (now - sc.rebuild_last > 30.0) || !sc.structure_valid;

        if (needsRebuild) {
            sc.shared_td = 0;
            sc.index_base = 0;
            sc.matrix_base = 0;
            sc.max_index = 0;
            sc.min_matrix_idx = 0;
            sc.max_matrix_idx = -1;
            sc.bones.assign(64, BoneStructureCache::BoneInfo{});

            constexpr int BONE_IDS[] = {
                static_cast<int>(offsets::model::pelvis),
                static_cast<int>(offsets::model::l_hip),
                static_cast<int>(offsets::model::l_knee),
                static_cast<int>(offsets::model::l_foot),
                static_cast<int>(offsets::model::r_hip),
                static_cast<int>(offsets::model::r_knee),
                static_cast<int>(offsets::model::r_foot),
                static_cast<int>(offsets::model::spine2),
                static_cast<int>(offsets::model::spine4),
                static_cast<int>(offsets::model::l_clav),
                static_cast<int>(offsets::model::l_upperarm),
                static_cast<int>(offsets::model::l_forearm),
                static_cast<int>(offsets::model::l_hand),
                static_cast<int>(offsets::model::neck),
                static_cast<int>(offsets::model::head),
                static_cast<int>(offsets::model::r_clav),
                static_cast<int>(offsets::model::r_upperarm),
                static_cast<int>(offsets::model::r_forearm),
                static_cast<int>(offsets::model::r_hand)
            };
            constexpr int NBONES = sizeof(BONE_IDS) / sizeof(BONE_IDS[0]);

            std::vector<uintptr_t> all_bones(bone_count);
            kernelHandler.read_memory(bone_array, (uint64_t)all_bones.data(), bone_count * sizeof(uintptr_t));

            int validBones = 0;
            for (int i = 0; i < NBONES; ++i) {
                int id = BONE_IDS[i];
                if (id >= bone_count) continue;
                uintptr_t bone = all_bones[id];
                if (!Decryption::is_valid_ptr(bone)) continue;

                uintptr_t transform_ptr = kernelHandler.readmem<uintptr_t>(bone + offsets::bone_transform::transform_ptr);
                if (!Decryption::is_valid_ptr(transform_ptr)) continue;

                uintptr_t td = kernelHandler.readmem<uintptr_t>(transform_ptr + offsets::bone_transform::transform_data);
                int idx = kernelHandler.readmem<int>(transform_ptr + offsets::bone_transform::transform_index);

                if (idx < 0 || idx >= 4096) continue;
                sc.bones[i].index = idx;
                if (td && !sc.shared_td) sc.shared_td = td;
                ++validBones;
            }

            if (!sc.shared_td || validBones < 3) {
                sc.rebuilding = false;
                return sc.structure_valid ? &sc : nullptr;
            }

            sc.index_base = kernelHandler.readmem<uintptr_t>(sc.shared_td + offsets::bone_transform::index_base);
            sc.matrix_base = kernelHandler.readmem<uintptr_t>(sc.shared_td + offsets::bone_transform::matrix_base);
            if (!Decryption::is_valid_ptr(sc.index_base) || !Decryption::is_valid_ptr(sc.matrix_base)) {
                sc.rebuilding = false;
                return sc.structure_valid ? &sc : nullptr;
            }

            int cur_max = 0;
            int cur_min = INT_MAX;
            for (int i = 0; i < NBONES; ++i) {
                int idx = sc.bones[i].index;
                if (idx < 0) continue;
                if (idx > cur_max) cur_max = idx;
                if (idx < cur_min) cur_min = idx;
                sc.bones[i].hierarchy.clear();

                int ti = kernelHandler.readmem<int>(sc.index_base + (uintptr_t)idx * 4);
                int depth = 0;
                while (ti >= 0 && ti < 4096 && depth++ < 128) {
                    sc.bones[i].hierarchy.push_back(ti);
                    if (ti > cur_max) cur_max = ti;
                    if (ti < cur_min) cur_min = ti;
                    ti = kernelHandler.readmem<int>(sc.index_base + (uintptr_t)ti * 4);
                }
            }
            sc.max_index = cur_max;
            sc.min_matrix_idx = (cur_min == INT_MAX) ? 0 : cur_min;
            sc.max_matrix_idx = cur_max;
            sc.transforms_ptr = transforms;
            sc.rebuild_last = now;
        }

        sc.structure_valid = (sc.shared_td != 0 && sc.matrix_base != 0 && sc.max_index > 0);
        sc.rebuilding = false;
        return sc.structure_valid ? &sc : nullptr;
    }

    BonePositionCache* GetBonePositionCacheLocked(uintptr_t ent, const BoneStructureCache& sc, double now) {
        BonePositionCache& pc = bonePositionCache[ent];
        pc.refresh = now;
        pc.last_seen = now;
        pc.ok = false;

        constexpr int NBONES = 19;
        if (sc.max_matrix_idx < sc.min_matrix_idx) return nullptr;

        const int minIdx = sc.min_matrix_idx;
        const int maxIdx = sc.max_matrix_idx;
        const int range = maxIdx - minIdx + 1;
        if (range <= 0 || range > 2048) return nullptr;

        static thread_local std::vector<AoS> matrixBuffer;
        static thread_local std::vector<uint8_t> matrixValid;

        matrixBuffer.resize(range);
        kernelHandler.read_memory(
            sc.matrix_base + (uintptr_t)minIdx * sizeof(AoS),
            (uint64_t)matrixBuffer.data(),
            (uint64_t)range * sizeof(AoS));

        matrixValid.assign(range, 0);

        auto get_matrix = [&](int idx) -> const AoS* {
            if (idx < minIdx || idx > maxIdx) return nullptr;
            const int local = idx - minIdx;
            if (matrixValid[local] == 0) {
                const AoS& t = matrixBuffer[local];
                const bool scaleOk = (t.sx > 0.001f && t.sy > 0.001f && t.sz > 0.001f);
                const bool rotOk = (std::abs(t.rx) < 2.f && std::abs(t.ry) < 2.f && std::abs(t.rz) < 2.f && std::abs(t.rw) < 2.f);
                const bool posOk = std::isfinite(t.px) && std::isfinite(t.py) && std::isfinite(t.pz);
                matrixValid[local] = (scaleOk && rotOk && posOk) ? 1 : 2;
            }
            return matrixValid[local] == 1 ? &matrixBuffer[local] : nullptr;
            };

        int got = 0;
        for (int i = 0; i < NBONES; ++i) {
            pc.pos[i] = { 0, 0, 0 };
            pc.rawPos[i] = { 0, 0, 0 };

            int idx = sc.bones[i].index;
            if (idx < 0) continue;

            const AoS* xfm = get_matrix(idx);
            if (!xfm) continue;

            Vector3 world{ xfm->px, xfm->py, xfm->pz };
            bool ok = true;

            for (int pidx : sc.bones[i].hierarchy) {
                const AoS* pp = get_matrix(pidx);
                if (!pp) { ok = false; break; }

                float l = std::sqrt(pp->rx * pp->rx + pp->ry * pp->ry + pp->rz * pp->rz + pp->rw * pp->rw);
                if (l < 1e-6f) { ok = false; break; }
                float nx = pp->rx / l, ny = pp->ry / l, nz = pp->rz / l, nw = pp->rw / l;

                float x = world.x, y = world.y, z = world.z;
                float rx = x * (nw * nw + nx * nx - ny * ny - nz * nz) + 2 * y * (nx * ny - nw * nz) + 2 * z * (nx * nz + nw * ny);
                float ry = 2 * x * (nx * ny + nw * nz) + y * (nw * nw - nx * nx + ny * ny - nz * nz) + 2 * z * (ny * nz - nw * nx);
                float rz = 2 * x * (nx * nz - nw * ny) + 2 * y * (ny * nz + nw * nx) + z * (nw * nw - nx * nx - ny * ny + nz * nz);

                world = { pp->px + rx * pp->sx, pp->py + ry * pp->sy, pp->pz + rz * pp->sz };
            }

            if (ok && std::isfinite(world.x) && std::isfinite(world.y) && std::isfinite(world.z)) {
                pc.rawPos[i] = world;
                pc.pos[i] = world;
                ++got;
            }
        }

        pc.ok = (got >= 3);
        return pc.ok ? &pc : nullptr;
    }
};