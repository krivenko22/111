#pragma once
#include <cmath>
#include <algorithm>
namespace RecoilMath {
struct Movement {int x=0,y=0;};
struct State {float rx=0,ry=0;double elapsed=0;void reset(){rx=ry=0;elapsed=0;}};
// Relative mouse counts/sec. This is a user-calibrated open-loop pull, NOT
// recoil measurement or a guarantee of in-game compensation.
inline Movement Step(State& s,float vertical,float horizontal,int mode,float dt){
 if(!std::isfinite(vertical)||!std::isfinite(horizontal)||!std::isfinite(dt)||dt<=0.f||dt>0.1f||vertical<0||vertical>300||std::abs(horizontal)>100||(mode!=0&&mode!=1)){s.reset();return {};}
 dt=(std::min)(dt,0.033f);s.elapsed+=dt;
 float fraction=(mode==1)?0.88f:1.f;
 float vx=horizontal*fraction,vy=vertical*fraction;
 if(mode==1 && vertical>0.f){
  // Zero-mean tiny motion; 0.88 is the baseline before this perturbation.
  float jitter=(std::min)(2.f,vertical*0.025f);
  vx+=jitter*std::sin((float)s.elapsed*19.f);
  vy+=jitter*std::sin((float)s.elapsed*13.f);
 }
 float x=(std::max)(-8.f,(std::min)(8.f,vx*dt+s.rx));
 float y=(std::max)(-8.f,(std::min)(8.f,vy*dt+s.ry));
 int ix=(int)std::lround(x),iy=(int)std::lround(y);s.rx=x-ix;s.ry=y-iy;return {ix,iy};
}
}
