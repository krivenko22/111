#pragma once
#include <algorithm>
#include <cmath>
#include "imgui/imgui.h"
// Game-local projected vertices -> monitor-local overlay. No scaling: projection
// still uses the game's original client size, including when it is windowed.
namespace OverlayCoordinates {
struct Area {int left,top,right,bottom;};
inline bool Valid(Area a){return a.right>a.left&&a.bottom>a.top;}
inline ImVec2 Offset(Area game,Area monitor){return {float(game.left-monitor.left),float(game.top-monitor.top)};}
inline void Translate(ImDrawList* list,int firstVertex,int firstCommand,int endCommand,ImVec2 offset,ImVec2 display){
 if(!list || firstVertex<0 || firstCommand<0 || endCommand<firstCommand)return;
 for(int i=firstVertex;i<list->VtxBuffer.Size;++i){list->VtxBuffer[i].pos.x+=offset.x;list->VtxBuffer[i].pos.y+=offset.y;}
 for(int i=firstCommand;i<endCommand && i<list->CmdBuffer.Size;++i){auto& c=list->CmdBuffer[i].ClipRect;
  c.x=std::clamp(c.x+offset.x,0.f,display.x);c.y=std::clamp(c.y+offset.y,0.f,display.y);
  c.z=std::clamp(c.z+offset.x,0.f,display.x);c.w=std::clamp(c.w+offset.y,0.f,display.y);
 }
}
}
