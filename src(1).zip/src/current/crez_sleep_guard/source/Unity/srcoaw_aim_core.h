#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
// Target selection and FOV-dependent smoothing from srcoaw, adapted to mouse
// movement. Priority classes are available in the math, but the current game
// cache only reliably offers ordinary player candidates.
namespace SrcoawAimCore {
struct Candidate{uint64_t id=0;float sx=0,sy=0,distance=0;int priority=0;};
struct Choice{Candidate candidate{};float score=std::numeric_limits<float>::infinity(),fov=0;int priority=99;bool locked=false;};
inline float TargetFov(float radius,float distance,bool scaling){
 if(!std::isfinite(radius)||!std::isfinite(distance)||radius<=0||distance<0)return 0;
 return scaling&&distance>20.f?(std::max)(1.f,radius*20.f/distance):radius;
}
inline float EffectiveSmoothing(float smoothing,float screenDistance,float radius){
 if(!std::isfinite(smoothing)||!std::isfinite(screenDistance)||!std::isfinite(radius)||smoothing<1.f||radius<=0)return 0.f;
 return smoothing*(1.f+4.f*(std::max)(0.f,(std::min)(1.f,screenDistance/radius)));
}
inline void Consider(Choice& out,const Candidate& c,float width,float height,float radius,bool scaling,uint64_t lock){
 if(!c.id||!std::isfinite(c.sx)||!std::isfinite(c.sy)||!std::isfinite(c.distance)||width<=0||height<=0||c.distance<0||c.priority<0||c.priority>2||c.sx<0||c.sy<0||c.sx>=width||c.sy>=height)return;
 float dx=c.sx-width*.5f,dy=c.sy-height*.5f,screen=std::sqrt(dx*dx+dy*dy),fov=TargetFov(radius,c.distance,scaling);
 bool same=lock&&c.id==lock;
 if(!std::isfinite(screen)||fov<=0||screen>fov*(same?1.5f:1.f))return;
 if((same&&!out.locked)||(!out.locked&&!same&&(c.priority<out.priority||(c.priority==out.priority&&screen<=out.score))))out={c,screen,fov,c.priority,same};
}
struct Movement{int x=0,y=0;};
struct MoveState{float residualX=0,residualY=0,lastX=0,lastY=0;void Reset(){residualX=residualY=lastX=lastY=0;}};
inline Movement Step(float dx,float dy,float gain,float smoothing,float radius,float dt,MoveState& state){
 float distance=std::sqrt(dx*dx+dy*dy),effective=EffectiveSmoothing(smoothing,distance,radius);
 if(!std::isfinite(dx)||!std::isfinite(dy)||!std::isfinite(gain)||!std::isfinite(dt)||gain<0||effective<1.f||dt<=0||dt>.1f){state.Reset();return {};}
 dt=(std::min)(dt,.033f);float fraction=1.f-std::exp(-60.f*dt/effective),cap=(std::min)(4.f,240.f*dt);
 auto axis=[&](float error,float& residual,float& previous){
  if(std::abs(error)<2.f){residual=previous=0;return 0;}
  if(previous*error<0)residual=0;previous=error;
  float step=(std::max)(-cap,(std::min)(cap,error*gain*10.f*fraction))+residual;
  int out=(std::max)(-4,(std::min)(4,(int)std::lround(step)));residual=step-out;return out;
 };
 return{axis(dx,state.residualX,state.lastX),axis(dy,state.residualY,state.lastY)};
}
}
