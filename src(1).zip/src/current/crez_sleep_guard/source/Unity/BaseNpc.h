#pragma once

#include "Offsets.h"
#include "decryptors.h"
#include "Driver/Driver.h"
#include "flags.h"

#include <cstdint>

namespace BaseNpcUtils {

    inline bool IsNpcByUserID(uintptr_t ent) {
        uint64_t userID = kernelHandler.readmem<uint64_t>(ent + offsets::base_player::userID);
        return userID < 70000000000000000ULL;
    }

    inline bool IsNpcByFlags(uintptr_t ent) {
        return !PlayerFlagsUtils::IsConnected(ent);
    }

    inline bool IsNpcByModel(uintptr_t ent) {
        uintptr_t playerModel = kernelHandler.readmem<uintptr_t>(ent + offsets::base_player::player_model);
        if (!Decryption::is_valid_ptr(playerModel)) return false;

        uint8_t isNpc = kernelHandler.readmem<uint8_t>(playerModel + offsets::player_model::isNpc);
        return isNpc != 0;
    }

    inline bool IsNpc(uintptr_t ent) {
        if (!Decryption::is_valid_ptr(ent)) return false;

        if (PlayerFlagsUtils::IsSleeping(ent)) return false;

        if (IsNpcByUserID(ent)) return true;

        if (IsNpcByFlags(ent)) return true;

        return IsNpcByModel(ent);
    }
}