#pragma once
#include "types.h"
#include <cstdint>
#include <cmath>
#include <cstring>
// Read-only corroboration based on one live sample, not proof of local identity.
namespace LocalInputCandidate {
inline bool ptr(uint64_t p){return p>=0x10000 && p<0x7ffffffff000ULL;}
template<class Read,class T> bool get(Read& read,uint64_t address,T& out){out={};return ptr(address)&&read(address,&out,sizeof(out));}
template<class Read> bool Angles(Read read,uint64_t player,Vector3& angles){
 angles={};uint64_t input=0,klass=0,name=0,owner=0;char type[12]{};
 if(!ptr(player)||!get(read,player+0x678,input)||!ptr(input)||
    !get(read,input,klass)||!ptr(klass)||!get(read,klass+0x10,name)||!ptr(name)||
    !get(read,input+0x20,owner)||owner!=player||!read(name,type,sizeof(type))||
    std::memcmp(type,"PlayerInput",12)!=0||!get(read,input+0x44,angles))return false;
 return std::isfinite(angles.x)&&std::isfinite(angles.y)&&std::isfinite(angles.z)&&
        std::abs(angles.x)<=90.f&&std::abs(angles.y)<=3600.f&&std::abs(angles.z)<=360.f;
}
}
