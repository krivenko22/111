#pragma once
#include <cstdint>
#include <cstring>
#include <string>
#include <windows.h>
#include "Offsets.h"
#include "decryptors.h"
namespace PlayerNameCandidate {
// Offsets are metadata candidates, not identified player-name fields.
constexpr uintptr_t offsets[]={0,0x518,0x600,0x810};
template<class Reader> bool Read(Reader read,uintptr_t entity,int choice,std::string& out){
 out.clear();if(choice<1||choice>3||!Decryption::is_valid_ptr(entity))return false;
 uintptr_t str=0,klass=0,name=0,ns=0;int32_t n=0;char c[7]{},s[7]{};
 if(!read(entity+offsets[choice],&str,sizeof(str))||!Decryption::is_valid_ptr(str)||
 !read(str,&klass,sizeof(klass))||!Decryption::is_valid_ptr(klass)||
 !read(klass+offsets::klass_layout::name_ptr,&name,sizeof(name))||!Decryption::is_valid_ptr(name)||
 !read(klass+offsets::klass_layout::name_ptr+8,&ns,sizeof(ns))||!Decryption::is_valid_ptr(ns)||
 !read(name,c,sizeof(c))||std::memcmp(c,"String",7)||!read(ns,s,sizeof(s))||std::memcmp(s,"System",7)||
 !read(str+0x10,&n,sizeof(n))||n<1||n>32)return false;
 wchar_t w[33]{};if(!read(str+0x14,w,size_t(n)*2))return false;
 for(int i=0;i<n;i++){unsigned u=(unsigned)w[i];if(u<32||u==127||u==0x2028||u==0x2029)return false;}
 int bytes=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w,n,nullptr,0,nullptr,nullptr);
 if(bytes<=0||bytes>128)return false;out.resize(bytes);
 if(WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w,n,out.data(),bytes,nullptr,nullptr)!=bytes){out.clear();return false;}
 return true;
}
}
