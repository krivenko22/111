#pragma once
#include "srcoaw_aim_core.h"
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace HumanizedAim {
// Smoothly varying speed without fake misses, angular noise, or extra settings.
// This does not guarantee human-like behavior or conceal automated input.
struct State {
    float vx=0.f, vy=0.f, rx=0.f, ry=0.f, phase=0.f;
    float variation=1.f, variationTarget=1.f, changeIn=0.f;
    uint32_t rng=0x9e3779b9u;
    void Reset() { vx=vy=rx=ry=phase=changeIn=0.f; variation=variationTarget=1.f; rng=0x9e3779b9u; }
    void Seed(uint64_t seed) {
        uint32_t v=static_cast<uint32_t>(seed)^static_cast<uint32_t>(seed>>32)^0xa341316cu;
        rng=v?v:0x9e3779b9u;
    }
    float NextUnit() {
        rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
        return float(rng >> 8) / 16777215.f;
    }
};
inline SrcoawAimCore::Movement Step(float dx, float dy, float gain, float smoothing,
                                     float radius, float dt, State& s) {
    const float distance=std::hypot(dx,dy);
    if(!std::isfinite(dx)||!std::isfinite(dy)||!std::isfinite(gain)||!std::isfinite(smoothing)||
       !std::isfinite(radius)||!std::isfinite(dt)||gain<0.f||smoothing<1.f||radius<=0.f||dt<=0.f||dt>.1f){
        s.Reset(); return {};
    }
    const float smoothingBlend=(std::max)(0.f,(std::min)(1.f,(smoothing-1.f)/4.f));
    const float fovRatio=(std::min)(1.f,distance/radius);
    const float divisor=smoothing*(1.f+4.f*smoothingBlend*fovRatio);
    dt=(std::min)(dt,.033f);
    s.phase=std::fmod(s.phase+dt,100.f);
    s.changeIn-=dt;
    if(s.changeIn<=0.f){
        s.variationTarget=.90f+.20f*s.NextUnit();
        s.changeIn=.10f+.18f*s.NextUnit();
    }
    s.variation+=(s.variationTarget-s.variation)*(1.f-std::exp(-dt/.12f));
    const float variation=(std::max)(.90f,(std::min)(1.10f,s.variation));
    // Ease in and ease near the target, but retain most tracking speed.
    const float approach=.84f+.16f*distance/(distance+18.f);
    const float alpha=1.f-std::exp(-dt/(.026f+.035f*smoothingBlend));
    const float pitchScale=std::abs(dx)<2.f ? 1.f :
        .20f+.80f*std::abs(dy)/(std::abs(dx)+std::abs(dy)+1.f);
    auto axis=[&](float error,float scale,float& velocity,float& residual){
        if(std::abs(error)<2.f){velocity=residual=0.f;return 0;}
        if(velocity*error<0.f) velocity=residual=0.f;
        const float desired=(std::max)(-1600.f,(std::min)(1600.f,error*gain*600.f/divisor*scale*variation*approach));
        velocity+=(desired-velocity)*alpha;
        if(std::abs(velocity)>std::abs(desired))velocity=desired;
        float step=velocity*dt+residual;
        step=(std::max)(-32.f,(std::min)(32.f,step));
        int sent=static_cast<int>(std::lround(step));
        if(sent*error<0.f)sent=0;
        residual=step-sent;
        return sent;
    };
    return {axis(dx,1.f,s.vx,s.rx),axis(dy,pitchScale,s.vy,s.ry)};
}
}
