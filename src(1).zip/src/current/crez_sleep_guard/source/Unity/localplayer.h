#pragma once

#include "types.h"
#include "Offsets.h"
#include "decryptors.h"
#include "world_to_screen.h"
#include "Driver/Driver.h"
#include "base_networkable.h"

#include <vector>
#include <cstdint>
#include <cmath>

extern uintptr_t gBase;

namespace LocalPlayerUtils
{
    inline uintptr_t cachedLocalPlayer = 0;

    inline Vector3 GetCamPos()
    {
        return WorldToScreenUtils::GetCamPos();
    }

    inline bool IsValidLocalPlayer(uintptr_t ent)
    {
        if (!Decryption::is_valid_ptr(ent))
            return false;

        uintptr_t klass = kernelHandler.readmem<uintptr_t>(ent);

        if (!Decryption::is_valid_ptr(klass))
            return false;

        uintptr_t model = kernelHandler.readmem<uintptr_t>(
            ent + offsets::base_entity::model
        );

        if (!Decryption::is_valid_ptr(model))
            return false;

        return true;
    }

    inline uintptr_t FindLocalPlayer(
        const std::vector<PlayerRenderData>& players)
    {
        if (players.empty())
            return 0;

        Vector3 camPos{};
        if (!WorldToScreenUtils::TryGetCamPos(camPos)) return 0;

        uintptr_t bestPlayer = 0;
        float bestDistSq = 3.4e38f;

        for (const auto& p : players)
        {
            if (!p.valid)
                continue;

            if (!p.isAlive)
                continue;

            if (p.isNpc)
                continue;

            if (!Decryption::is_valid_ptr(p.entityId))
                continue;

            float dx = p.position.x - camPos.x;
            float dy = p.position.y - camPos.y;
            float dz = p.position.z - camPos.z;

            float distSq =
                dx * dx +
                dy * dy +
                dz * dz;

            if (!std::isfinite(distSq))
                continue;

            if (distSq < bestDistSq)
            {
                bestDistSq = distSq;
                bestPlayer = p.entityId;
            }
        }

        // Reject unrelated players when the candidate camera position is wrong.
        if (bestDistSq > 16.f || !IsValidLocalPlayer(bestPlayer))
            return 0;

        return bestPlayer;
    }

    inline uintptr_t GetLocalPlayerPointer(
        const std::vector<PlayerRenderData>& players)
    {
        if (cachedLocalPlayer != 0)
        {
            bool stillPresent = false;
            for (const auto& p : players) if (p.valid && p.entityId == cachedLocalPlayer) { stillPresent = true; break; }
            if (stillPresent && IsValidLocalPlayer(cachedLocalPlayer))
                return cachedLocalPlayer;

            cachedLocalPlayer = 0;
        }

        uintptr_t localPlayer = FindLocalPlayer(players);

        if (localPlayer == 0)
            return 0;

        cachedLocalPlayer = localPlayer;

        return cachedLocalPlayer;
    }

    inline uintptr_t GetLocalPlayerId(
        const std::vector<PlayerRenderData>& players)
    {
        return GetLocalPlayerPointer(players);
    }

    inline bool IsLocalPlayer(
        uintptr_t ent,
        const std::vector<PlayerRenderData>& players)
    {
        if (ent == 0)
            return false;

        uintptr_t localPlayer =
            GetLocalPlayerPointer(players);

        return localPlayer != 0 &&
            localPlayer == ent;
    }

    inline void ClearCache()
    {
        cachedLocalPlayer = 0;
    }
}