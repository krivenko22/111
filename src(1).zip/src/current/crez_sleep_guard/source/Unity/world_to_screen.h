#pragma once
#include "types.h"
#include "Offsets.h"
#include "Driver/Driver.h"
#include "decryptors.h"
#include "imgui/imgui.h"
#include <cmath>

extern uintptr_t gBase;

namespace WorldToScreenUtils {

    struct CameraSnapshot {
        Matrix4x4 viewMatrix{};
        Vector3   position{};
        bool      valid{ false };
    };

    inline uintptr_t GetNativeCamera() {
        if (!gBase) return 0;

        uintptr_t mainCameraClass = kernelHandler.readmem<uintptr_t>(gBase + offsets::camera::main_camera);
        if (!Decryption::is_valid_ptr(mainCameraClass)) return 0;

        uintptr_t staticFields = kernelHandler.readmem<uintptr_t>(mainCameraClass + offsets::klass_layout::static_fields);
        if (!Decryption::is_valid_ptr(staticFields)) return 0;

        uintptr_t cameraObject = kernelHandler.readmem<uintptr_t>(staticFields + offsets::camera::camera_object);
        if (!Decryption::is_valid_ptr(cameraObject)) return 0;

        uintptr_t nativeCamera = kernelHandler.readmem<uintptr_t>(cameraObject + offsets::object::m_CachedPtr);
        if (!Decryption::is_valid_ptr(nativeCamera)) return 0;

        return nativeCamera;
    }

    inline bool TryGetCamPos(Vector3& out) {
        out = {};
        const uintptr_t native = GetNativeCamera();
        return native && kernelHandler.read_memory(native + offsets::camera::position,
            reinterpret_cast<uint64_t>(&out), sizeof(out)) &&
            std::isfinite(out.x) && std::isfinite(out.y) && std::isfinite(out.z) &&
            std::abs(out.x) <= 8000.f && std::abs(out.z) <= 8000.f && std::abs(out.y) <= 2000.f;
    }

    inline bool PlausibleMatrix(const Matrix4x4& m) {
        float sum = 0.f, w = 0.f;
        for (int r = 0; r < 4; ++r) for (int c = 0; c < 4; ++c) {
            if (!std::isfinite(m.m[r][c]) || std::abs(m.m[r][c]) > 1000000.f) return false;
            sum += std::abs(m.m[r][c]);
            if (c == 3) w += std::abs(m.m[r][c]);
        }
        return sum > 0.001f && w > 0.001f;
    }

    inline CameraSnapshot GetCameraSnapshot() {
        CameraSnapshot snap{};
        const uintptr_t native = GetNativeCamera();
        if (!native) return snap;
        const bool matrixOk = kernelHandler.read_memory(native + offsets::camera::view_matrix,
            reinterpret_cast<uint64_t>(&snap.viewMatrix), sizeof(snap.viewMatrix));
        const bool posOk = kernelHandler.read_memory(native + offsets::camera::position,
            reinterpret_cast<uint64_t>(&snap.position), sizeof(snap.position));
        snap.valid = matrixOk && posOk && PlausibleMatrix(snap.viewMatrix) &&
            std::isfinite(snap.position.x) && std::isfinite(snap.position.y) && std::isfinite(snap.position.z) &&
            std::abs(snap.position.x) <= 8000.f && std::abs(snap.position.z) <= 8000.f && std::abs(snap.position.y) <= 2000.f;
        return snap;
    }

    inline Matrix4x4 GetViewMatrix() { return GetCameraSnapshot().viewMatrix; }
    inline Vector3 GetCamPos() { Vector3 pos{}; TryGetCamPos(pos); return pos; }

    inline bool WorldToScreen(const Vector3& world, const Matrix4x4& m, ImVec2& screen, int width, int height) {
        const float clip_x = world.x * m.m[0][0] + world.y * m.m[1][0] + world.z * m.m[2][0] + m.m[3][0];
        const float clip_y = world.x * m.m[0][1] + world.y * m.m[1][1] + world.z * m.m[2][1] + m.m[3][1];
        const float clip_w = world.x * m.m[0][3] + world.y * m.m[1][3] + world.z * m.m[2][3] + m.m[3][3];

        if (width <= 0 || height <= 0 || !std::isfinite(clip_x) || !std::isfinite(clip_y) || !std::isfinite(clip_w) || clip_w < 0.001f) return false;

        const float inv_w = 1.0f / clip_w;
        const float ndc_x = clip_x * inv_w;
        const float ndc_y = clip_y * inv_w;

        screen.x = (width * 0.5f) + (ndc_x * width * 0.5f);
        screen.y = (height * 0.5f) - (ndc_y * height * 0.5f);
        return true;
    }
}