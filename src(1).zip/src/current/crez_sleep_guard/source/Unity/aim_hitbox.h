#pragma once
#include "Offsets.h"
#include "transform_position.h"
#include <cstdint>

// Bone indices come from the existing Rust skeleton table; neither the table
// nor its interpretation is verified for the target server/build. Missing
// bones fail closed rather than silently aiming at a different body part.
namespace AimHitbox {
enum Selection { Head = 0, Neck = 1, Torso = 2, Chest = 3 };

template<class Read>
bool Position(Read read, uint64_t model, int selected, Vector3& out) {
    out = {};
    using TransformPosition::get;
    using TransformPosition::validptr;
    if (!validptr(model) || selected < Head || selected > Chest) return false;
    uint64_t transform = 0;
    if (selected == Head) {
        if (!get(read, model + offsets::model::headBone, transform)) return false;
    } else {
        const uint64_t bone = selected == Neck ? offsets::model::neck :
                              selected == Torso ? offsets::model::spine2 : offsets::model::spine4;
        uint64_t array = 0, count = 0;
        if (!get(read, model + offsets::model::boneTransforms, array) || !validptr(array) ||
            !get(read, array + offsets::model::bone_array_count_off, count) ||
            count > 512 || bone >= count ||
            !get(read, array + offsets::model::bone_array_data_off + bone * offsets::model::bone_array_elem_size, transform))
            return false;
    }
    return TransformPosition::WorldPosition(read, transform, out);
}
}
