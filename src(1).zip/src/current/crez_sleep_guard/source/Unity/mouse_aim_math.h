#pragma once
#include <algorithm>
#include <cmath>
namespace MouseAimMath {
struct Movement { int x{},y{}; };
struct SmoothState { float vx=0,vy=0,rx=0,ry=0; void reset(){vx=vy=rx=ry=0;} };
inline bool InRadius(float x,float y,float width,float height,float radius){
 if(!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(width)||!std::isfinite(height)||!std::isfinite(radius)||width<=0||height<=0||radius<=0)return false;
 float dx=x-width*.5f,dy=y-height*.5f;return x>=0&&x<width&&y>=0&&y<height&&dx*dx+dy*dy<=radius*radius;
}
// Source scales the FOV beyond 20m: max(1px, FOV * 20 / distance).
inline float DistanceFov(float fov,float distance,bool enabled){
 if(!std::isfinite(fov)||!std::isfinite(distance)||fov<=0||distance<0)return 0.f;
 return enabled && distance>20.f ? (std::max)(1.f,fov*20.f/distance) : fov;
}
inline Movement Move(float dx,float dy,float gain,float dt,float& residualX,float& residualY){
 if(!std::isfinite(dx)||!std::isfinite(dy)||!std::isfinite(gain)||!std::isfinite(dt)||gain<0||dt<=0){residualX=residualY=0;return {};}
 if(dx*dx+dy*dy<9.f){residualX=residualY=0;return {};}
 float factor=gain*(std::min)(dt,0.033f)*60.f;
 float mx=(std::max)(-8.f,(std::min)(8.f,dx*factor+residualX));
 float my=(std::max)(-8.f,(std::min)(8.f,dy*factor+residualY));
 int ix=(int)std::lround(mx),iy=(int)std::lround(my);residualX=mx-ix;residualY=my-iy;
 return {ix,iy};
}
// Short velocity filter, in mouse counts/sec; no averaging of stale screen coordinates.
// Fractional movement is accumulated so high frame rates do not lose tiny steps.
inline Movement StableMove(float dx,float dy,float gain,float smooth,float dt,SmoothState& s){
 if(!std::isfinite(dx)||!std::isfinite(dy)||!std::isfinite(gain)||!std::isfinite(smooth)||!std::isfinite(dt)||gain<0||smooth<1||dt<=0||dt>0.1f){s.reset();return {};}
 dt=(std::min)(dt,0.033f);
 const float tau=.012f+(std::min)(smooth,20.f)*.0015f;
 const float alpha=1.f-std::exp(-dt/tau);
 auto axis=[&](float error,float& v,float& residual){
   if(std::abs(error)<2.f){v=0;residual=0;return 0;}
   if(v*error<0.f){v=0;residual=0;}
   const float desired=(std::max)(-240.f,(std::min)(240.f,error*gain*60.f));
   v+=alpha*(desired-v);
   float step=(std::max)(-4.f,(std::min)(4.f,v*dt+residual));
   int out=(int)std::lround(step);residual=step-out;return out;
 };
 return {axis(dx,s.vx,s.rx),axis(dy,s.vy,s.ry)};
}
// Low-pass pointer velocity in counts/sec. Unlike screen-point interpolation,
// it doesn't reuse a stale camera matrix. Reset immediately on release or loss.
inline Movement SmoothMove(float dx,float dy,float gain,float smooth,float dt,SmoothState& s){
 if(!std::isfinite(dx)||!std::isfinite(dy)||!std::isfinite(gain)||!std::isfinite(smooth)||!std::isfinite(dt)||gain<0||smooth<1||dt<=0||dt>0.1f){s.reset();return {};}
 if(dx*dx+dy*dy<9.f){s.reset();return {};}
 dt=(std::min)(dt,0.033f);
 const float tau=0.005f+(std::min)(smooth,20.f)*0.003f;
 const float alpha=1.f-std::exp(-dt/tau);
 const float desiredX=(std::max)(-480.f,(std::min)(480.f,dx*gain*60.f));
 const float desiredY=(std::max)(-480.f,(std::min)(480.f,dy*gain*60.f));
 if(s.vx*dx<0.f)s.vx=0.f;
 if(s.vy*dy<0.f)s.vy=0.f;
 s.vx+=alpha*(desiredX-s.vx);s.vy+=alpha*(desiredY-s.vy);
 float mx=(std::max)(-8.f,(std::min)(8.f,s.vx*dt+s.rx));
 float my=(std::max)(-8.f,(std::min)(8.f,s.vy*dt+s.ry));
 int x=(int)std::lround(mx),y=(int)std::lround(my);s.rx=mx-x;s.ry=my-y;return {x,y};
}

}
