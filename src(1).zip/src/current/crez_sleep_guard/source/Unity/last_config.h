#pragma once
#include "config_store.h"
#include <windows.h>
#include <string>
#include <chrono>

class LastConfig : public ConfigStore {
 std::wstring dir,path;std::string saved;bool safe=false;const char* status="Last config: unavailable";std::chrono::steady_clock::time_point lastAttempt{};
public:
 const char* Status() const {return status;}
 bool Init(){
  DWORD needed=GetEnvironmentVariableW(L"LOCALAPPDATA",nullptr,0);if(!needed||needed>32760)return false;
  std::wstring p(needed,L'\0');DWORD n=GetEnvironmentVariableW(L"LOCALAPPDATA",p.data(),needed);if(!n||n>=needed)return false;p.resize(n);
  dir=p+L"\\Crez";path=dir+L"\\last.cfg";
  if(!CreateDirectoryW(dir.c_str(),nullptr)&&GetLastError()!=ERROR_ALREADY_EXISTS)return false;
  HANDLE f=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
  if(f==INVALID_HANDLE_VALUE){if(GetLastError()!=ERROR_FILE_NOT_FOUND)return false;safe=true;saved=Snapshot();status="Last config: auto-save";return true;}
  LARGE_INTEGER size{};if(!GetFileSizeEx(f,&size)||size.QuadPart<0||size.QuadPart>131072){CloseHandle(f);return false;}
  std::string text(static_cast<size_t>(size.QuadPart),'\0');DWORD bytes=0;bool ok=ReadFile(f,text.data(),DWORD(text.size()),&bytes,nullptr)&&bytes==text.size();CloseHandle(f);
  if(!ok||!Load(text))return false;safe=true;saved=Snapshot();status="Last config: auto-save";return true;
 }
 bool Tick(bool force=false){
  if(!safe)return false;
  auto now=std::chrono::steady_clock::now();if(!force&&lastAttempt.time_since_epoch().count()&&now-lastAttempt<std::chrono::milliseconds(500))return true;
  lastAttempt=now;const std::string value=Snapshot();if(value==saved)return true;
  const auto temp=path+L".tmp";
  HANDLE f=CreateFileW(temp.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);if(f==INVALID_HANDLE_VALUE){status="Last config: SAVE ERROR";return false;}
  DWORD written=0;bool ok=WriteFile(f,value.data(),DWORD(value.size()),&written,nullptr)&&written==value.size()&&FlushFileBuffers(f);
  if(!CloseHandle(f))ok=false;
  if(ok)ok=MoveFileExW(temp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;
  if(!ok){DeleteFileW(temp.c_str());status="Last config: SAVE ERROR";return false;}saved=value;status="Last config: auto-save";return true;
 }
};
