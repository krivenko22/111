#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>

// Elysium-inspired selection (crosshair or distance, locked-target preference)
// and fraction-of-error smoothing, adapted for bounded relative mouse input.
namespace ElysiumAimCore {
struct Candidate {uint64_t id=0;float sx=0,sy=0,distance=0;};
struct Choice {Candidate candidate{};float score=std::numeric_limits<float>::infinity();bool locked=false;};
inline void Consider(Choice& out,const Candidate& c,float width,float height,float radius,int priority,uint64_t lock){
 if(!c.id||!std::isfinite(c.sx)||!std::isfinite(c.sy)||!std::isfinite(c.distance)||!std::isfinite(radius)||width<=0||height<=0||radius<=0||c.distance<0||c.sx<0||c.sy<0||c.sx>=width||c.sy>=height)return;
 float dx=c.sx-width*.5f,dy=c.sy-height*.5f,screen=std::sqrt(dx*dx+dy*dy);bool same=lock && c.id==lock;
 if(!std::isfinite(screen)||screen>radius*(same?1.5f:1.f))return;
 float score=priority==1?c.distance:screen;
 if((same&&!out.locked)||(!out.locked&&!same&&score<out.score)){out={c,score,same};}
}
struct Movement {int x=0,y=0;};
struct MoveState {float residualX=0,residualY=0,lastX=0,lastY=0;void Reset(){residualX=0;residualY=0;lastX=0;lastY=0;}};
inline Movement Step(float dx,float dy,float gain,float smoothing,float dt,MoveState& state){
 if(!std::isfinite(dx)||!std::isfinite(dy)||!std::isfinite(gain)||!std::isfinite(smoothing)||!std::isfinite(dt)||gain<0||smoothing<1.f||dt<=0||dt>.1f){state.Reset();return {};}
 dt=(std::min)(dt,.033f);const float fraction=1.f-std::exp(-60.f*dt/smoothing);
 const float cap=(std::min)(4.f,240.f*dt);
 auto axis=[&](float err,float& residual,float& previous){
   if(std::abs(err)<2.f){residual=0;previous=0;return 0;}
   if(previous*err<0.f)residual=0;
   previous=err;
   float step=(std::max)(-cap,(std::min)(cap,err*gain*10.f*fraction))+residual;
   int output=(int)std::lround(step);output=(std::max)(-4,(std::min)(4,output));residual=step-output;return output;
 };
 return {axis(dx,state.residualX,state.lastX),axis(dy,state.residualY,state.lastY)};
}
}
