#pragma once
#include "camera_pose.h"
#include <cstring>
// Evidence from one live sample, not a generally verified Unity ABI.
namespace CameraCandidate {
struct Refs {uint64_t camera=0,nativeCamera=0,transform=0;};
template<class Read> bool classIs(Read& read,uint64_t object,const char* expected,size_t len){
 uint64_t k=0,n=0;char name[16]{};using TransformPosition::get;using TransformPosition::validptr;
 return len<sizeof(name)&&validptr(object)&&get(read,object,k)&&validptr(k)&&get(read,k+0x10,n)&&validptr(n)&&read(n,name,len+1)&&std::memcmp(name,expected,len+1)==0;
}
template<class Read> bool Acquire(Read read,uint64_t base,Refs& refs){
 refs={};uint64_t klass=0,st=0,camera=0,transform=0,native=0;
 using TransformPosition::get;using TransformPosition::validptr;
 if(!validptr(base)||!get(read,base+0xF0C83A0ULL,klass)||!validptr(klass)||!get(read,klass+0xB8,st)||!validptr(st)||
    !get(read,st+0x60,camera)||!classIs(read,camera,"Camera",6)||
    !get(read,st+0x68,transform)||!classIs(read,transform,"Transform",9)||
    !get(read,camera+0x10,native)||!validptr(native))return false;
 refs={camera,native,transform};return true;
}
template<class Read> bool Projection(Read read,const Refs& refs,Matrix4x4& p){
 p={};float x=0,y=0,ox=0,oy=0;
 return TransformPosition::validptr(refs.nativeCamera) && read(refs.nativeCamera+0xB0,&p,sizeof(p)) && CameraPose::Projection(p,x,y,ox,oy);
}
}
