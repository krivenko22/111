#pragma once
#include <atomic>
#include <chrono>
#include <functional>
#include <mutex>
#include <thread>
#include <utility>

// Tick owns its camera cache and locks aim/menu state only when required.
// Tick must not access ImGui. No overlay frame cap.
class AimWorker {
    std::atomic<bool> stop_{false};
    std::atomic<unsigned long long> ticks_{0};
    std::thread thread_;
public:
    AimWorker() = default;
    AimWorker(const AimWorker&) = delete;
    AimWorker& operator=(const AimWorker&) = delete;
    ~AimWorker() { Stop(); }
    template<class F> void Start(F tick) {
        stop_.store(false, std::memory_order_release);
        thread_ = std::thread([this, tick=std::move(tick)]() mutable {
            while (!stop_.load(std::memory_order_acquire)) {
                tick();
                ticks_.fetch_add(1, std::memory_order_relaxed);
                // Throttle kernel reads, not overlay FPS. Actual cadence is
                // subject to Windows scheduling and synchronous driver calls.
                std::this_thread::sleep_for(std::chrono::milliseconds(2));
            }
        });
    }
    void Stop() {
        stop_.store(true, std::memory_order_release);
        if (thread_.joinable()) thread_.join();
    }
    unsigned long long Ticks() const { return ticks_.load(std::memory_order_relaxed); }
};
