#pragma once
#include <string>
#include <map>
#include <functional>
#include <sstream>
#include <iomanip>
#include <locale>
#include <cmath>
#include <algorithm>
#include <limits>
#include <type_traits>
#include <utility>
#include <cstdint>

// Portable validated field registry, with stable text keys rather than raw object dumps.
class ConfigStore {
 struct Entry {std::function<double()> read;std::function<void(double)> write;double lo,hi;bool integer;};
 std::map<std::string,Entry> entries;
public:
 void Bind(const std::string& key,std::function<double()> get,std::function<void(double)> set,double lo,double hi,bool integer=false){entries.insert_or_assign(key,Entry{std::move(get),std::move(set),lo,hi,integer});}
 void Bool(const std::string& k,bool& v){Bind(k,[&v]{return v?1.:0.;},[&v](double n){v=n!=0.;},0,1,true);}
 void Int(const std::string& k,int& v,int lo,int hi){Bind(k,[&v]{return double(v);},[&v](double n){v=int(n);},lo,hi,true);}
 void Float(const std::string& k,float& v,float lo,float hi){Bind(k,[&v]{return double(v);},[&v](double n){v=float(n);},lo,hi);}
 template<class E>void Enum(const std::string& k,E& v,int lo,int hi){static_assert(std::is_enum<E>::value);Bind(k,[&v]{return double(static_cast<int>(v));},[&v](double n){v=static_cast<E>(static_cast<int>(n));},lo,hi,true);}
 void Color(const std::string& k,float (&v)[4]){for(int i=0;i<4;++i)Float(k+"."+std::to_string(i),v[i],0.f,1.f);}
 std::string Snapshot() const {
  std::ostringstream out;out.imbue(std::locale::classic());out<<"CREZ_LAST_CONFIG_V1\n"<<std::setprecision(std::numeric_limits<float>::max_digits10);
  for(const auto& [key,e]:entries){double n=e.read();if(std::isfinite(n)&&n>=e.lo&&n<=e.hi&&(!e.integer||std::floor(n)==n))out<<key<<"="<<n<<"\n";}
  return out.str();
 }
 bool Load(const std::string& text){
  if(text.size()>131072)return false;
  std::istringstream in(text);in.imbue(std::locale::classic());std::string line;
  if(!std::getline(in,line))return false;if(!line.empty()&&line.back()=='\r')line.pop_back();
  if(line!="CREZ_LAST_CONFIG_V1")return false;
  while(std::getline(in,line)){
   if(!line.empty()&&line.back()=='\r')line.pop_back();auto pos=line.find('=');if(pos==std::string::npos)continue;
   auto it=entries.find(line.substr(0,pos));if(it==entries.end())continue;
   std::istringstream val(line.substr(pos+1));val.imbue(std::locale::classic());double n=0;
   if(!(val>>n))continue;val>>std::ws;if(!val.eof())continue;const auto& e=it->second;
   if(!std::isfinite(n)||(e.integer&&std::floor(n)!=n))continue;
   const double epsilon=e.integer ? 0.0 : 1e-6*(std::max)(1.0,(std::max)(std::abs(e.lo),std::abs(e.hi)));
   if(n<e.lo-epsilon||n>e.hi+epsilon)continue;
   n=(std::max)(e.lo,(std::min)(e.hi,n));e.write(n);
  }
  return true;
 }
};
