#pragma once
#include "srcoaw_aim_core.h"
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace SnapAim {
// Relative mouse correction only: the game's sensitivity determines the
// real angular response; pixel error is not equivalent to mouse counts.
inline SrcoawAimCore::Movement Calculate(float dx,float dy,float gain){
 if(!std::isfinite(dx)||!std::isfinite(dy)||!std::isfinite(gain)||gain<0.f||gain>.15f)return {};
 auto axis=[&](float e){
  if(std::abs(e)<2.f)return 0;
  // 0.035 is the existing default gain; at this setting request a
  // one-to-one screen-error correction, capped for safety.
  float v=(std::max)(-64.f,(std::min)(64.f,e*(gain/.035f)));
  return int(std::lround(v));
 };
 return {axis(dx),axis(dy)};
}
// Avoid issuing duplicate snap deltas before a prior movement is reflected in
// the sampled camera direction. Allows bounded retry for stationary cameras.
struct Gate {
 bool sent=false;float x=0.f,y=0.f,z=0.f;int64_t lastMicros=0;
 void Reset(){sent=false;x=y=z=0;lastMicros=0;}
 bool Ready(float nx,float ny,float nz,int64_t now)const{
  if(!std::isfinite(nx)||!std::isfinite(ny)||!std::isfinite(nz)||now<=0)return false;
  if(!sent||now<lastMicros)return true;
  int64_t age=now-lastMicros;if(age<2000)return false;
  float dx=nx-x,dy=ny-y,dz=nz-z;
  return dx*dx+dy*dy+dz*dz>1e-10f || age>=20000;
 }
 void Sent(float nx,float ny,float nz,int64_t now){sent=true;x=nx;y=ny;z=nz;lastMicros=now;}
};
}
