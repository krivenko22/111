#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>

// Recorded in canvas pixels relative to the first point. The playback applies
// a user-selected percentage of that displacement, capped near the target. It loops with
// a short return segment; a missing/invalid profile has no effect.
namespace AimTrace {
constexpr int MaxPoints=96;
constexpr float MaxDuration=8.f;
constexpr float DefaultStrengthPercent=8.8f;
struct Point {float x=0.f,y=0.f,time=0.f;};
struct Profile {
    Point points[MaxPoints]{};
    int count=0;
    uint32_t revision=0;
    void Clear() {count=0;++revision;}
    bool Add(float x,float y,float t) {
        if(!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(t)||t<0.f||t>MaxDuration || std::abs(x)>4096.f || std::abs(y)>4096.f) return false;
        if(count<0 || count>MaxPoints)Clear();
        if(count>0){
            const auto& p=points[count-1];
            if(t<=p.time)return false;
            const float dx=x-p.x,dy=y-p.y;
            if(dx*dx+dy*dy<1.f && t-p.time<.05f)return false;
        }
        if(count==MaxPoints){
            // Preserve the beginning, evenly reduce stored samples and include
            // the previous end so long traces don't stop recording early.
            int write=1;
            for(int i=2;i<MaxPoints-1;i+=2)points[write++]=points[i];
            points[write++]=points[MaxPoints-1];count=write;
        }
        points[count++]={x,y,t};++revision;return true;
    }
    bool Valid() const {
        if(count<2 || count>MaxPoints)return false;
        for(int i=0;i<count;i++){
            const auto& p=points[i];
            if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.time)||
               std::abs(p.x)>4096.f||std::abs(p.y)>4096.f||p.time<0.f||p.time>MaxDuration||
               (i>0 && p.time<=points[i-1].time))return false;
        }
        return points[count-1].time-points[0].time>=.01f;
    }
};
struct Player {float elapsed=0.f;uint32_t revision=0;void Reset(){elapsed=0.f;revision=0;}};
struct Error {float x=0.f,y=0.f;};
inline Error Apply(const Profile& profile, Player& player, float dx,float dy,float dt,
                   float strengthPercent=DefaultStrengthPercent) {
    Error base{dx,dy};
    if(!std::isfinite(dx)||!std::isfinite(dy)||!std::isfinite(dt)||!std::isfinite(strengthPercent)||dt<=0.f||dt>.1f||!profile.Valid())return base;
    const float influence=(std::max)(0.f,(std::min)(100.f,strengthPercent))*.01f;
    if(player.revision!=profile.revision){player.elapsed=0.f;player.revision=profile.revision;}
    const auto& first=profile.points[0];const auto& last=profile.points[profile.count-1];
    const float duration=last.time-first.time,returnTime=.16f,period=duration+returnTime;
    player.elapsed=std::fmod(player.elapsed+(std::min)(dt,.033f),period);
    const float t=player.elapsed;
    float x=0.f,y=0.f;
    if(t<=duration){
        const float absolute=first.time+t;
        int right=1;while(right<profile.count-1&&profile.points[right].time<absolute)++right;
        const Point &a=profile.points[right-1],&b=profile.points[right];
        const float u=(std::max)(0.f,(std::min)(1.f,(absolute-a.time)/(b.time-a.time)));
        x=a.x+(b.x-a.x)*u-first.x;y=a.y+(b.y-a.y)*u-first.y;
    }else{
        const float u=(std::max)(0.f,(std::min)(1.f,(t-duration)/returnTime));
        x=(last.x-first.x)*(1.f-u);y=(last.y-first.y)*(1.f-u);
    }
    float ox=x*influence,oy=y*influence;
    const float error=std::hypot(dx,dy),length=std::hypot(ox,oy);
    if(!std::isfinite(error)||!std::isfinite(length))return base;
    const float cap=error*influence;
    if(length>cap && length>0.f){ox*=cap/length;oy*=cap/length;}
    return {dx+ox,dy+oy};
}
}
