#pragma once
#include "Offsets.h"
#include "decryptors.h"
#include "Driver/Driver.h"
#include <cstdint>

namespace PlayerFlagsUtils {

    inline bool TryPlayerFlags(uintptr_t ent, uint32_t& flags) {
        flags=0;return Decryption::is_valid_ptr(ent) && kernelHandler.read_memory(ent+offsets::base_player::player_flags,reinterpret_cast<uint64_t>(&flags),sizeof(flags));
    }
    inline bool TryModelStateFlags(uintptr_t ent, uint32_t& flags, uintptr_t& state) {
        flags=0;state=0;
        return Decryption::is_valid_ptr(ent) && kernelHandler.read_memory(ent+offsets::base_player::model_state,reinterpret_cast<uint64_t>(&state),sizeof(state)) &&
            Decryption::is_valid_ptr(state) && kernelHandler.read_memory(state+offsets::model_state::flags,reinterpret_cast<uint64_t>(&flags),sizeof(flags));
    }
    inline uint32_t GetPlayerFlags(uintptr_t ent) { uint32_t flags=0;TryPlayerFlags(ent,flags);return flags; }
    inline uint32_t GetModelStateFlags(uintptr_t ent) { uint32_t flags=0;uintptr_t state=0;TryModelStateFlags(ent,flags,state);return flags; }

    inline bool IsAdmin(uintptr_t ent) {
        return (GetPlayerFlags(ent) & offsets::base_player_flags::IsAdmin) != 0;
    }

    inline bool IsReceivingSnapshot(uintptr_t ent) {
        return (GetPlayerFlags(ent) & offsets::base_player_flags::ReceivingSnapshot) != 0;
    }

    inline bool IsSleepingFlag(uintptr_t ent) {
        return (GetPlayerFlags(ent) & offsets::base_player_flags::Sleeping) != 0;
    }

    inline bool IsSpectating(uintptr_t ent) {
        return (GetPlayerFlags(ent) & offsets::base_player_flags::Spectating) != 0;
    }

    inline bool IsWounded(uintptr_t ent) {
        return (GetPlayerFlags(ent) & offsets::base_player_flags::Wounded) != 0;
    }

    inline bool IsDeveloper(uintptr_t ent) {
        return (GetPlayerFlags(ent) & offsets::base_player_flags::IsDeveloper) != 0;
    }

    inline bool IsConnected(uintptr_t ent) {
        return (GetPlayerFlags(ent) & offsets::base_player_flags::Connected) != 0;
    }

    inline bool IsThirdPerson(uintptr_t ent) {
        return (GetPlayerFlags(ent) & offsets::base_player_flags::ThirdPersonViewmode) != 0;
    }

    inline bool IsDucked(uintptr_t ent) {
        return (GetModelStateFlags(ent) & offsets::modelstate_flags::ducked) != 0;
    }

    inline bool IsJumped(uintptr_t ent) {
        return (GetModelStateFlags(ent) & offsets::modelstate_flags::jumped) != 0;
    }

    inline bool IsOnGround(uintptr_t ent) {
        return (GetModelStateFlags(ent) & offsets::modelstate_flags::OnGround) != 0;
    }

    inline bool IsSleepingModelState(uintptr_t ent) {
        return (GetModelStateFlags(ent) & offsets::modelstate_flags::Sleeping) != 0;
    }

    inline bool IsSprinting(uintptr_t ent) {
        return (GetModelStateFlags(ent) & offsets::modelstate_flags::sprinting) != 0;
    }

    inline bool IsOnLadder(uintptr_t ent) {
        return (GetModelStateFlags(ent) & offsets::modelstate_flags::onLadder) != 0;
    }

    inline bool IsFlying(uintptr_t ent) {
        return (GetModelStateFlags(ent) & offsets::modelstate_flags::Flying) != 0;
    }

    inline bool IsAiming(uintptr_t ent) {
        return (GetModelStateFlags(ent) & offsets::modelstate_flags::aiming) != 0;
    }

    inline bool IsMounted(uintptr_t ent) {
        return (GetModelStateFlags(ent) & offsets::modelstate_flags::Mounted) != 0;
    }

    inline bool IsCrawling(uintptr_t ent) {
        return (GetModelStateFlags(ent) & offsets::modelstate_flags::crawling) != 0;
    }

    inline bool HasParachute(uintptr_t ent) {
        return (GetModelStateFlags(ent) & offsets::modelstate_flags::hasParachute) != 0;
    }

    inline bool IsSleeping(uintptr_t ent) {
        return IsSleepingFlag(ent) && IsSleepingModelState(ent);
    }

    inline bool IsAlive(uintptr_t ent) {
        if (!Decryption::is_valid_ptr(ent)) return false;
        int lifestate = -1;
        if (!kernelHandler.read_memory(ent + offsets::base_combat_entity::lifestate,
            reinterpret_cast<uint64_t>(&lifestate), sizeof(lifestate))) return false;
        return lifestate == 0;
    }

    inline bool IsMoving(uintptr_t ent) {
        return IsSprinting(ent) || IsJumped(ent) || !IsOnGround(ent);
    }

    inline bool IsThreat(uintptr_t ent) {
        if (IsSleeping(ent)) return false;
        return IsAiming(ent) || IsSprinting(ent) || IsWounded(ent);
    }

    inline thread_local uint64_t cachedTeamSteamIDs[20] = {};
    inline thread_local int cachedTeamCount = 0;
    inline thread_local uintptr_t cachedTeamPtr = 0;

    inline uint64_t GetRealSteamID(uintptr_t ent) {
        if (!Decryption::is_valid_ptr(ent)) return 0;

        uintptr_t strPtr = kernelHandler.readmem<uintptr_t>(ent + offsets::base_player::userIDString);
        if (!Decryption::is_valid_ptr(strPtr)) return 0;

        int len = kernelHandler.readmem<int>(strPtr + offsets::unity_string::m_stringLength);
        if (len <= 0 || len > 20) return 0;

        wchar_t buf[24] = {};
        kernelHandler.read_memory(strPtr + offsets::unity_string::first_char, (uint64_t)buf, len * sizeof(wchar_t));

        uint64_t result = 0;
        for (int i = 0; i < len; ++i) {
            if (buf[i] < L'0' || buf[i] > L'9') return 0;
            result = result * 10 + (buf[i] - L'0');
        }

        return result;
    }

    inline void UpdateTeamCache(uintptr_t localPlayerPtr) {
        if (!Decryption::is_valid_ptr(localPlayerPtr)) {
            cachedTeamCount = 0;
            cachedTeamPtr = 0;
            return;
        }

        uintptr_t localTeam = kernelHandler.readmem<uintptr_t>(localPlayerPtr + offsets::base_player::player_team);
        if (!Decryption::is_valid_ptr(localTeam)) {
            cachedTeamCount = 0;
            cachedTeamPtr = 0;
            return;
        }

        if (localTeam == cachedTeamPtr && cachedTeamCount > 0) return;
        cachedTeamPtr = localTeam;

        uintptr_t memberListPtr = kernelHandler.readmem<uintptr_t>(localTeam + offsets::player_team::memberList);
        if (!Decryption::is_valid_ptr(memberListPtr)) {
            cachedTeamCount = 0;
            return;
        }

        int count = kernelHandler.readmem<int>(memberListPtr + offsets::system_list::size);
        if (count <= 0 || count > 20) {
            cachedTeamCount = 0;
            return;
        }

        uintptr_t arrayPtr = kernelHandler.readmem<uintptr_t>(memberListPtr + offsets::system_list::array);
        if (!Decryption::is_valid_ptr(arrayPtr)) {
            cachedTeamCount = 0;
            return;
        }

        cachedTeamCount = count;
        for (int i = 0; i < count; ++i) {
            uintptr_t memberObj = kernelHandler.readmem<uintptr_t>(
                arrayPtr + offsets::system_list::array_first_element + (i * offsets::player_team::member_stride));
            if (Decryption::is_valid_ptr(memberObj)) {
                cachedTeamSteamIDs[i] = kernelHandler.readmem<uint64_t>(memberObj + offsets::player_team::member_steam_id);
            }
            else {
                cachedTeamSteamIDs[i] = 0;
            }
        }
    }

    inline bool IsTeammateCached(uintptr_t ent, uintptr_t localPlayerPtr);

    inline bool IsTeammate(uintptr_t ent, uintptr_t localPlayerPtr) {
        if (!Decryption::is_valid_ptr(ent) || !Decryption::is_valid_ptr(localPlayerPtr)) return false;
        if (ent == localPlayerPtr) return false;

        UpdateTeamCache(localPlayerPtr);
        return IsTeammateCached(ent, localPlayerPtr);
    }

    // Caller already refreshed the local team once for the current render.
    inline bool IsTeammateSteamIdCached(uint64_t targetSteamID, uintptr_t ent, uintptr_t localPlayerPtr) {
        if (!Decryption::is_valid_ptr(ent) || !Decryption::is_valid_ptr(localPlayerPtr) || ent == localPlayerPtr) return false;
        if (cachedTeamCount <= 1) return false;
        if (targetSteamID == 0) return false;

        for (int i = 0; i < cachedTeamCount; ++i) {
            if (cachedTeamSteamIDs[i] == targetSteamID) {
                return true;
            }
        }

        return false;
    }

    // Legacy fallback for call sites that do not already carry a cached ID.
    inline bool IsTeammateCached(uintptr_t ent, uintptr_t localPlayerPtr) {
        if (cachedTeamCount <= 1) return false;
        return IsTeammateSteamIdCached(GetRealSteamID(ent), ent, localPlayerPtr);
    }
}