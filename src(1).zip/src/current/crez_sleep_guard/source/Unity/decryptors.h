#pragma once
#include <cstdint>
#include <array>
#include <bit>
#include <cstring>
#include <functional>
#include "Driver/Driver.h"
#include "Offsets.h"

namespace Decryption {

    inline bool is_valid_ptr(uintptr_t ptr) {
        return ptr > 0x10000000 && ptr < 0x7FFFFFFFFFFF;
    }

    inline uintptr_t Il2cppGetHandle(uintptr_t handle_ptr) {
        if (!is_valid_ptr(handle_ptr)) return 0;

        uint64_t page_base = handle_ptr & 0xFFFFFFFFFFFFE000ULL;
        uint8_t type = kernelHandler.readmem<uint8_t>(page_base + 0x20);
        if (type >= 4) return 0;

        int64_t slot = (int64_t)(handle_ptr - page_base - 0x28) >> 3;
        uint32_t size = kernelHandler.readmem<uint32_t>(page_base + 0x1C);
        if ((uint32_t)slot >= size) return 0;

        uint64_t bitmap_ptr = kernelHandler.readmem<uint64_t>(page_base + 0x10);
        if (!is_valid_ptr(bitmap_ptr)) return 0;

        uint32_t bitmask = kernelHandler.readmem<uint32_t>(bitmap_ptr + 4 * ((uint32_t)slot >> 5));
        if (!((bitmask >> (slot & 0x1F)) & 1)) return 0;

        uint64_t entry = kernelHandler.readmem<uint64_t>(page_base + 8 * ((uint32_t)slot + 5));
        return (type > 1) ? entry : ~entry;
    }

    // The raw value is a pointer to an object slot when the low bit is 0.
    // The 2026-11 live probe validated that branch and the ROR9 inverse for
    // this user's build; low-bit 1 is only partially reconstructed.
    inline uintptr_t ResolveRealmHandle(uint64_t raw) {
        if (!is_valid_ptr(raw)) return 0;
        if (!(raw & 1)) {
            uintptr_t object = 0;
            if (!kernelHandler.read_memory(raw, reinterpret_cast<uint64_t>(&object), sizeof(object))) return 0;
            return is_valid_ptr(object) ? object : 0;
        }
        const uint64_t page = raw & ~uint64_t(0x1FFF);
        const uint64_t delta = raw - page;
        if (delta < 0x28 || !is_valid_ptr(page)) return 0;
        const uint32_t slot = static_cast<uint32_t>((delta - 0x28) >> 3);
        if (slot >= 1024) return 0;
        uint8_t type = 0; uint32_t count = 0; uint64_t bitmap = 0;
        if (!kernelHandler.read_memory(page+0x20, reinterpret_cast<uint64_t>(&type), sizeof(type)) ||
            !kernelHandler.read_memory(page+0x1c, reinterpret_cast<uint64_t>(&count), sizeof(count)) ||
            !kernelHandler.read_memory(page+0x10, reinterpret_cast<uint64_t>(&bitmap), sizeof(bitmap))) return 0;
        // Type 0/1 calls an unresolved helper; never invent a target.
        if (type < 2 || type >= 4 || slot >= count || !is_valid_ptr(bitmap)) return 0;
        uint32_t bits = 0;
        if (!kernelHandler.read_memory(bitmap + 4ull*(slot>>5), reinterpret_cast<uint64_t>(&bits), sizeof(bits)) ||
            !(bits & (1u << (slot & 31)))) return 0;
        uintptr_t object = 0;
        if (!kernelHandler.read_memory(page + 8ull*(uint64_t(slot)+5), reinterpret_cast<uint64_t>(&object), sizeof(object))) return 0;
        // This external read cannot acquire the game's lock; result can race.
        return is_valid_ptr(object) ? object : 0;
    }

    inline std::uint64_t client_entities(std::uint64_t wrapper) {
        if (!is_valid_ptr(wrapper)) return 0;
        uint8_t flag = 0; uint64_t encoded = 0;
        if (!kernelHandler.read_memory(wrapper+0x14, reinterpret_cast<uint64_t>(&flag), sizeof(flag)) || !flag ||
            !kernelHandler.read_memory(wrapper+0x18, reinterpret_cast<uint64_t>(&encoded), sizeof(encoded)) || !encoded) return 0;
        auto words = std::bit_cast<std::array<std::uint32_t, 2>>(encoded);
        for (auto& word : words) word = std::rotr(std::rotl(word, 8) ^ 0x9CCF7239u, 9);
        return ResolveRealmHandle(std::bit_cast<std::uint64_t>(words));
    }

    inline std::uint64_t entity_list(std::uint64_t wrapper) {
        if (!is_valid_ptr(wrapper)) return 0;
        uint8_t flag = 0; uint64_t encoded = 0;
        if (!kernelHandler.read_memory(wrapper+0x14, reinterpret_cast<uint64_t>(&flag), sizeof(flag)) || !flag ||
            !kernelHandler.read_memory(wrapper+0x18, reinterpret_cast<uint64_t>(&encoded), sizeof(encoded)) || !encoded) return 0;
        auto words = std::bit_cast<std::array<std::uint32_t, 2>>(encoded);
        for (auto& word : words) word = std::rotl(word + 0x5333BDC6u, 12) + 0x19A12C8Fu;
        return ResolveRealmHandle(std::bit_cast<std::uint64_t>(words));
    }

    // 3. local_player (LocalPlayerStatic)
    inline uintptr_t local_player(uint64_t static_field_ptr) {
        if (!static_field_ptr) return 0;
        if (is_valid_ptr(static_field_ptr)) {
            const auto handle = kernelHandler.readmem<uint64_t>(static_field_ptr + 0x18);
            if (handle && is_valid_ptr(handle)) {
                auto words = std::bit_cast<std::array<std::uint32_t, 2>>(handle);
                for (auto& word : words) {
                    word = std::rotl(word, 4);
                    word += 0x7c1cdd1du;
                    word = std::rotl(word, 27);
                }
                uintptr_t h = Il2cppGetHandle(std::bit_cast<std::uint64_t>(words));
                if (is_valid_ptr(h)) return h;
            }
        }
        if (is_valid_ptr(static_field_ptr)) {
            uintptr_t klass = kernelHandler.readmem<uintptr_t>(static_field_ptr + 0x0);
            if (is_valid_ptr(klass)) {
                uintptr_t namePtr = kernelHandler.readmem<uintptr_t>(klass + 0x10);
                if (is_valid_ptr(namePtr)) {
                    uint32_t tag = kernelHandler.readmem<uint32_t>(namePtr);
                    if (tag == 0x65736142u) return static_field_ptr;
                }
            }
        }
        auto words = std::bit_cast<std::array<std::uint32_t, 2>>(static_field_ptr);
        for (auto& word : words) {
            word += 0xa158d76cu;
            word ^= 0xc8b59642u;
            word = std::rotl(word, 28);
            word += 0x560fcee8u;
        }
        uintptr_t h = Il2cppGetHandle(std::bit_cast<std::uint64_t>(words));
        if (is_valid_ptr(h)) return h;
        return Il2cppGetHandle(static_field_ptr);
    }

    // 4. player_eyes
    inline uintptr_t player_eyes(uint64_t field_ptr) {
        if (!is_valid_ptr(field_ptr)) return 0;
        if (!kernelHandler.readmem<uint8_t>(field_ptr + 0x14)) return 0;
        const auto handle = kernelHandler.readmem<uint64_t>(field_ptr + 0x18);
        if (!handle) return 0;
        auto words = std::bit_cast<std::array<std::uint32_t, 2>>(handle);
        for (auto& word : words) {
            word ^= 0x5bff5766u;
            word += 0x32c24580u;
            word = std::rotl(word, 31);
            word += 0x466ea300u;
        }
        return Il2cppGetHandle(std::bit_cast<std::uint64_t>(words));
    }

    // 5. player_inventory
    inline uintptr_t player_inventory(uint64_t field_ptr) {
        if (!is_valid_ptr(field_ptr)) return 0;
        if (!kernelHandler.readmem<uint8_t>(field_ptr + 0x14)) return 0;
        const auto handle = kernelHandler.readmem<uint64_t>(field_ptr + 0x18);
        if (!handle) return 0;
        auto words = std::bit_cast<std::array<std::uint32_t, 2>>(handle);
        for (auto& word : words) {
            word = std::rotl(word, 23);
            word ^= 0x1f73d79u;
            word += 0x18ab70e6u;
            word ^= 0x368ff21au;
        }
        return Il2cppGetHandle(std::bit_cast<std::uint64_t>(words));
    }

    // 6. clActiveItem
    inline std::uint64_t clActiveItem(std::uint64_t value) {
        auto words = std::bit_cast<std::array<std::uint32_t, 2>>(value);
        for (auto& word : words) {
            word = std::rotl(word, 21);
            word += 0xc9975d85u;
            word ^= 0x25b3e47bu;
            word += 0x8b767b68u;
        }
        return std::bit_cast<std::uint64_t>(words);
    }

    inline uintptr_t TryDecryptInventory(uintptr_t player) {
        if (!is_valid_ptr(player)) return 0;
        uintptr_t field_val = kernelHandler.readmem<uintptr_t>(player + offsets::base_player::player_inventory);
        uintptr_t inv1 = player_inventory(player + offsets::base_player::player_inventory);
        if (is_valid_ptr(inv1)) return inv1;
        if (is_valid_ptr(field_val)) {
            uintptr_t inv2 = player_inventory(field_val);
            if (is_valid_ptr(inv2)) return inv2;
            return field_val;
        }
        return 0;
    }

    namespace AttackEntity {
        inline float decrypt_last_tick_time(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word = std::rotl(word, 1); word += 0x8cc93133u; word = std::rotl(word, 9); word += 0xeaf57e55u; }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline float decrypt_next_attack_time(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word = std::rotl(word, 9); word += 0x3a042607u; word = std::rotl(word, 26); word += 0xb3128e8au; }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline float decrypt_next_tick_time(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word = std::rotl(word, 20); word += 0x29a9b960u; word = std::rotl(word, 22); }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline float decrypt_time_since_deploy(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word ^= 0xe8166227u; word = std::rotl(word, 25); word ^= 0xc88ac13du; word = std::rotl(word, 25); }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
    }

    namespace BaseNetworkableStatic {
        inline std::uint64_t decrypt_client_entities(std::uint64_t value) {
            const auto handle = kernelHandler.readmem<std::uint64_t>(value + 0x18);
            auto words = std::bit_cast<std::array<std::uint32_t, 2>>(handle);
            for (auto& word : words) { word ^= 0x1d967507u; word = std::rotl(word, 8); word += 0xbd23cb5au; }
            return Il2cppGetHandle(std::bit_cast<std::uint64_t>(words));
        }
    }

    namespace BasePlayer {
        inline std::uint64_t decrypt_clactiveitem(std::uint64_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 2>>(value);
            for (auto& word : words) { word += 0xa0efb54u; word = std::rotl(word, 12); word ^= 0x7f547310u; }
            return std::bit_cast<std::uint64_t>(words);
        }
        inline float decrypt_lastsentticktime(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word += 0x40bc0469u; word ^= 0xd5c64446u; word = std::rotl(word, 15); }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline std::uint64_t decrypt_user_id(std::uint64_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 2>>(value);
            for (auto& word : words) { word ^= 0x93aa4414u; word = std::rotl(word, 30); word += 0x2f178b9bu; word = std::rotl(word, 13); }
            return std::bit_cast<std::uint64_t>(words);
        }
    }

    namespace BaseProjectile {
        inline float decrypt_next_reload_time(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word = std::rotl(word, 8); word += 0xbf4224b4u; word ^= 0x63680624u; }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline float decrypt_start_reload_time(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word += 0x5bd0cf5cu; word = std::rotl(word, 9); word += 0xee5fae14u; word = std::rotl(word, 23); }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
    }

    namespace ConvarGraphicsStatic {
        inline float decrypt_fov(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word = std::rotl(word, 4); word += 0x47991a80u; word = std::rotl(word, 30); word += 0xf89acf8au; }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline std::uint32_t encrypt_fov(float value) {
            std::uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result += 0x7653076u; result = std::rotl(result, 2); result += 0xb866e580u; result = std::rotl(result, 28); return result;
        }
    }

    namespace ConvarPlayerStatic {
        inline float decrypt_client_tick_interval(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word = std::rotl(word, 4); word += 0x47991a80u; word = std::rotl(word, 30); word += 0xf89acf8au; }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline std::uint32_t encrypt_client_tick_interval(float value) {
            std::uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result += 0x7653076u; result = std::rotl(result, 2); result += 0xb866e580u; result = std::rotl(result, 28); return result;
        }
    }

    namespace EntityRealm {
        inline std::uint64_t decrypt_entity_list(std::uint64_t value) {
            const auto handle = kernelHandler.readmem<std::uint64_t>(value + 0x18);
            auto words = std::bit_cast<std::array<std::uint32_t, 2>>(handle);
            for (auto& word : words) { word += 0x43a97588u; word = std::rotl(word, 11); word ^= 0xedbcb0b2u; }
            return Il2cppGetHandle(std::bit_cast<std::uint64_t>(words));
        }
    }

    namespace LocalPlayerStatic {
        inline std::uint64_t decrypt_localplayer(std::uint64_t value) {
            const auto handle = kernelHandler.readmem<std::uint64_t>(value + 0x18);
            auto words = std::bit_cast<std::array<std::uint32_t, 2>>(handle);
            for (auto& word : words) { word ^= 0x1d967507u; word = std::rotl(word, 8); word += 0xbd23cb5au; }
            return Il2cppGetHandle(std::bit_cast<std::uint64_t>(words));
        }
    }

    namespace PlayerEyes {
        inline std::array<std::uint32_t, 3> decrypt_viewoffset(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word += 0xb7468b84u; word ^= 0x3a45858bu; word += 0x900fdbf5u; }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }
        inline std::array<std::uint32_t, 3> encrypt_viewoffset(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word += 0x6ff0240bu; word ^= 0x3a45858bu; word += 0x48b9747cu; }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }
    }

    namespace PlayerWalkMovement {
        // Booleans
        inline uint32_t encrypt_grounded(bool value) { uint32_t v = value ? 1u : 0u; v ^= 0x4E950628u; v += 0x5025DDFAu; v ^= 0xE0887AA0u; v -= 0x69094678u; return v; }
        inline bool decrypt_grounded(uint32_t value) { value += 0x69094678u; value ^= 0xE0887AA0u; value -= 0x5025DDFAu; value ^= 0x4E950628u; return value != 0; }
        inline uint32_t encrypt_flying(bool value) { uint32_t v = value ? 1u : 0u; v = std::rotl(v, 10); v += 0x41C361D3u; v = std::rotl(v, 4); v += 0x7BA47834u; return v; }
        inline bool decrypt_flying(uint32_t value) { value -= 0x7BA47834u; value = std::rotr(value, 4); value -= 0x41C361D3u; value = std::rotr(value, 10); return value != 0; }
        inline uint32_t encrypt_climbing(bool value) { uint32_t v = value ? 1u : 0u; v ^= 0x5C7A9B21u; v += 0x3E4D8F12u; v ^= 0xA1B2C3D4u; return v; }
        inline bool decrypt_climbing(uint32_t value) { value ^= 0xA1B2C3D4u; value -= 0x3E4D8F12u; value ^= 0x5C7A9B21u; return value != 0; }

        // Floats & Vectors
        inline float decrypt_ground_angle(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word += 0xa42c611au; word = std::rotl(word, 19); word += 0x63622af5u; word = std::rotl(word, 6); }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline std::uint32_t encrypt_ground_angle(float value) {
            std::uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result = std::rotl(result, 26); result += 0x9c9dd50bu; result = std::rotl(result, 13); result += 0x5bd39ee6u; return result;
        }

        inline float decrypt_ground_angle_new(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word += 0xc53ef4e1u; word ^= 0xd02a5685u; word += 0x2fa9f7fcu; word ^= 0x4e261e4bu; }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline std::uint32_t encrypt_ground_angle_new(float value) {
            std::uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result ^= 0x4e261e4bu; result += 0xd0560804u; result ^= 0xd02a5685u; result += 0x3ac10b1fu; return result;
        }

        inline std::array<std::uint32_t, 3> decrypt_ground_normal(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word ^= 0xdabe2220u; word = std::rotl(word, 1); word += 0xfe3c59a2u; }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }
        inline std::array<std::uint32_t, 3> encrypt_ground_normal(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word += 0x1c3a65eu; word = std::rotl(word, 31); word ^= 0xdabe2220u; }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }

        inline std::array<std::uint32_t, 3> decrypt_ground_normal_new(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word = std::rotl(word, 13); word += 0xde1f5357u; word = std::rotl(word, 20); word ^= 0x7b5a8e6du; }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }
        inline std::array<std::uint32_t, 3> encrypt_ground_normal_new(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word ^= 0x7b5a8e6du; word = std::rotl(word, 12); word += 0x21e0aca9u; word = std::rotl(word, 19); }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }

        inline float decrypt_ground_time(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word += 0x14c1151eu; word ^= 0xb6aacf01u; word += 0x717aff93u; }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline std::uint32_t encrypt_ground_time(float value) {
            std::uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result += 0x8e85006du; result ^= 0xb6aacf01u; result += 0xeb3eeae2u; return result;
        }

        inline std::array<std::uint32_t, 3> decrypt_ground_velocity(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word = std::rotl(word, 18); word += 0x24f4fe5cu; word = std::rotl(word, 29); word += 0x8cd21f06u; }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }
        inline std::array<std::uint32_t, 3> encrypt_ground_velocity(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word += 0x732de0fau; word = std::rotl(word, 3); word += 0xdb0b01a4u; word = std::rotl(word, 14); }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }

        inline std::array<std::uint32_t, 3> decrypt_ground_velocity_new(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word = std::rotl(word, 25); word += 0x9347f566u; word = std::rotl(word, 29); word ^= 0x2bdec09au; }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }
        inline std::array<std::uint32_t, 3> encrypt_ground_velocity_new(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word ^= 0x2bdec09au; word = std::rotl(word, 3); word += 0x6cb80a9au; word = std::rotl(word, 7); }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }

        inline float decrypt_jump_time(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word ^= 0x4355f590u; word += 0xf26d02d7u; word = std::rotl(word, 30); word ^= 0x9a7a1938u; }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline std::uint32_t encrypt_jump_time(float value) {
            std::uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result ^= 0x9a7a1938u; result = std::rotl(result, 2); result += 0xd92fd29u; result ^= 0x4355f590u; return result;
        }

        inline float decrypt_land_time(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word += 0xbe6799e2u; word = std::rotl(word, 31); word ^= 0xa21168beu; }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline std::uint32_t encrypt_land_time(float value) {
            std::uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result ^= 0xa21168beu; result = std::rotl(result, 1); result += 0x4198661eu; return result;
        }

        inline float decrypt_max_velocity(std::uint32_t value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 1>>(value);
            for (auto& word : words) { word += 0x5bd0cf5cu; word = std::rotl(word, 9); word += 0xee5fae14u; word = std::rotl(word, 23); }
            float result = 0.0f; std::memcpy(&result, words.data(), sizeof(result)); return result;
        }
        inline std::uint32_t encrypt_max_velocity(float value) {
            std::uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result = std::rotl(result, 9); result += 0x11a051ecu; result = std::rotl(result, 23); result += 0xa42f30a4u; return result;
        }

        inline std::array<std::uint32_t, 3> decrypt_previous_inherited_velocity(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word = std::rotl(word, 23); word += 0xb405a4a3u; word = std::rotl(word, 9); }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }
        inline std::array<std::uint32_t, 3> encrypt_previous_inherited_velocity(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word = std::rotl(word, 23); word += 0x4bfa5b5du; word = std::rotl(word, 9); }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }

        inline std::array<std::uint32_t, 3> decrypt_previous_position(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word ^= 0x363ba41bu; word = std::rotl(word, 15); word += 0x462bab78u; }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }
        inline std::array<std::uint32_t, 3> encrypt_previous_position(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word += 0xb9d45488u; word = std::rotl(word, 17); word ^= 0x363ba41bu; }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }
        inline std::array<std::uint32_t, 3> decrypt_previous_velocity(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word ^= 0x58234691u; word = std::rotl(word, 31); word += 0xdb78c1b0u; word = std::rotl(word, 28); }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }
        inline std::array<std::uint32_t, 3> encrypt_previous_velocity(std::array<std::uint32_t, 3> value) {
            auto words = std::bit_cast<std::array<std::uint32_t, 3>>(value);
            for (auto& word : words) { word = std::rotl(word, 4); word += 0x24873e50u; word = std::rotl(word, 1); word ^= 0x58234691u; }
            return std::bit_cast<std::array<std::uint32_t, 3>>(words);
        }
        inline uint32_t encrypt_last_tick_time(float value) {
            uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result += 0x150a81abu; result = std::rotl(result, 23);
            result += 0x7336cecdu; result = std::rotl(result, 31);
            return result;
        }

        inline uint32_t encrypt_next_attack_time(float value) {
            uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result += 0x4ced7176u; result = std::rotl(result, 6);
            result += 0xc5fbd9f9u; result = std::rotl(result, 23);
            return result;
        }

        inline uint32_t encrypt_next_reload_time(float value) {
            uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result ^= 0x63680624u; result += 0x40bddb4cu;
            result = std::rotl(result, 24); return result;
        }

        inline uint32_t encrypt_next_tick_time(float value) {
            uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result = std::rotl(result, 10); result += 0xd65646a0u;
            result = std::rotl(result, 12); return result;
        }

        inline uint32_t encrypt_start_reload_time(float value) {
            uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result = std::rotl(result, 9); result += 0x11a051ecu;
            result = std::rotl(result, 23); result += 0xa42f30a4u;
            return result;
        }

        inline uint32_t encrypt_time_since_deploy(float value) {
            uint32_t result; std::memcpy(&result, &value, sizeof(result));
            result = std::rotl(result, 7); result ^= 0xc88ac13du;
            result = std::rotl(result, 7); result ^= 0xe8166227u;
            return result;
        }
    }
}