#pragma once
#include <cstdint>
#include <atomic>
namespace AimActivation {
enum Mode { None=0, Hold=1, Toggle=2, Always=3 };
// Set by overlay: aim is suppressed while its menu is open. Generation changes
// whenever its loop stops rendering because the game lost focus/disappeared.
inline std::atomic<bool> menuOpen{false};
inline std::atomic<uint64_t> focusGeneration{0};
struct Runtime {
 int lastMode=-1,lastKey=-1;bool previousDown=false,toggled=false,wasAvailable=false;
 uint64_t seenGeneration=0;
 void Reset(){toggled=false;previousDown=false;wasAvailable=false;}
 bool Update(int mode,int key,bool down,bool available,uint64_t generation){
  if(generation!=seenGeneration){Reset();seenGeneration=generation;}
  if(mode!=lastMode||key!=lastKey){Reset();lastMode=mode;lastKey=key;}
  if(!available){Reset();return false;}
  if(!wasAvailable){previousDown=down;wasAvailable=true;}
  else {if(mode==Toggle && key>0 && down && !previousDown)toggled=!toggled;previousDown=down;}
  if(mode==Always)return true;
  if(mode==Hold)return key>0 && down;
  if(mode==Toggle)return key>0 && toggled;
  return false;
 }
 bool ActiveNow(int mode,int key,bool down,bool available) const {
  if(!available||mode!=lastMode||key!=lastKey)return false;
  if(mode==Always)return true;
  if(mode==Hold)return key>0 && down;
  if(mode==Toggle)return key>0 && toggled;
  return false;
 }
};
}
