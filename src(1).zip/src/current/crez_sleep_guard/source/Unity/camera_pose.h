#pragma once
#include "transform_position.h"
#include "head_projection.h"
#include <cstdint>
#include <cmath>
#include <initializer_list>
// Live-derived candidate: MainCamera statics +60 Camera, +68 Transform.
// These are not yet confirmed as the final on-screen view on this client.
namespace CameraPose {
struct Quaternion { float x,y,z,w; };
struct Pose {Vector3 position{};Quaternion rotation{};};
inline bool normalized(Quaternion& q){
 float n=q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w;
 if(!std::isfinite(n)||n<0.8f||n>1.2f)return false;
 float inv=1.f/std::sqrt(n);q.x*=inv;q.y*=inv;q.z*=inv;q.w*=inv;return true;
}
inline Quaternion mul(Quaternion a,Quaternion b){return {a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z};}
inline Vector3 rotate(Quaternion q,Vector3 v){
 float x=2*(q.y*v.z-q.z*v.y),y=2*(q.z*v.x-q.x*v.z),z=2*(q.x*v.y-q.y*v.x);
 return {v.x+q.w*x+q.y*z-q.z*y,v.y+q.w*y+q.z*x-q.x*z,v.z+q.w*z+q.x*y-q.y*x};
}
template<class Read> bool World(Read read,uint64_t managed,Pose& out){
 out={};uint64_t mats=0,parents=0;int32_t idx=-1;
 using namespace TransformPosition;
 if(!ReadLayout(read,managed,mats,parents,idx))return false;
 Matrix mat{};if(!get(read,mats+uint64_t(idx)*48,mat))return false;
 Vector3 p{mat.px,mat.py,mat.pz};Quaternion q{mat.qx,mat.qy,mat.qz,mat.qw};
 if(!validpos(p)||!normalized(q))return false;
 int32_t seen[128];int n=0;
 for(;;){
  if(n==128)return false;
  for(int i=0;i<n;++i)if(seen[i]==idx)return false;
  seen[n++]=idx;int32_t parent=-1;if(!get(read,parents+uint64_t(idx)*4,parent))return false;
  if(parent==-1)break;
  if(parent<0||parent>=4096||!get(read,mats+uint64_t(parent)*48,mat))return false;
  Quaternion parentQ{mat.qx,mat.qy,mat.qz,mat.qw};
  if(!normalized(parentQ)||!std::isfinite(mat.sx)||!std::isfinite(mat.sy)||!std::isfinite(mat.sz)||
     std::abs(mat.sx)>1000||std::abs(mat.sy)>1000||std::abs(mat.sz)>1000)return false;
  Vector3 rotated=rotate(parentQ,{p.x*mat.sx,p.y*mat.sy,p.z*mat.sz});
  p={mat.px+rotated.x,mat.py+rotated.y,mat.pz+rotated.z};if(!validpos(p))return false;
  q=mul(parentQ,q);if(!normalized(q))return false;idx=parent;
 }
 out={p,q};return true;
}
// Candidate raw Unity projection at Camera native +0xB0 in live report.
inline bool Projection(const Matrix4x4& p,float& fx,float& fy,float& ox,float& oy){
 const float* m=&p.m[0][0];for(int i=0;i<16;i++)if(!std::isfinite(m[i])||std::abs(m[i])>10000)return false;
 if(m[0]<0.05f||m[0]>50.f||m[5]<0.05f||m[5]>50.f||std::abs(m[15])>0.001f||
    std::abs(std::abs(m[11])-1.f)>0.03f||std::abs(m[8])>1.f||std::abs(m[9])>1.f)return false;
 for(int i:{1,2,3,4,6,7,12,13})if(std::abs(m[i])>0.001f)return false;
 fx=m[0];fy=m[5];ox=m[8];oy=m[9];return true;
}
inline bool Build(const Pose& p,const Matrix4x4& proj,Matrix4x4& out){
 out={};float fx=0,fy=0,ox=0,oy=0;Quaternion q=p.rotation;
 if(!TransformPosition::validpos(p.position)||!normalized(q)||!Projection(proj,fx,fy,ox,oy))return false;
 Vector3 r=rotate(q,{1,0,0}),u=rotate(q,{0,1,0}),f=rotate(q,{0,0,1});
 Vector3 c[3]={{fx*r.x-ox*f.x,fx*r.y-ox*f.y,fx*r.z-ox*f.z},{fy*u.x-oy*f.x,fy*u.y-oy*f.y,fy*u.z-oy*f.z},f};
 const int col[3]={0,1,3};
 for(int i=0;i<3;i++){int k=col[i];out.m[0][k]=c[i].x;out.m[1][k]=c[i].y;out.m[2][k]=c[i].z;out.m[3][k]=-(p.position.x*c[i].x+p.position.y*c[i].y+p.position.z*c[i].z);}
 return true;
}
}
