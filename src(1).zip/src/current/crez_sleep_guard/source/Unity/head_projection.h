#pragma once
#include "types.h"
#include <cmath>

// Experimental pinhole approximation. Rust offsets, FOV and angle conventions
// remain unverified: this is not a substitute for the real camera matrix.
namespace HeadProjection {
inline bool finite3(const Vector3& v) {
    return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z);
}
inline bool Build(const Vector3& eye, const Vector3& angles, float aspect,
                  float verticalFovDegrees, Matrix4x4& out) {
    out = {};
    if (!finite3(eye) || !finite3(angles) || !std::isfinite(aspect) ||
        !std::isfinite(verticalFovDegrees) || aspect < 0.25f || aspect > 8.f ||
        verticalFovDegrees < 10.f || verticalFovDegrees > 140.f ||
        std::abs(angles.x) > 90.f || std::abs(angles.y) > 3600.f || std::abs(angles.z) > 360.f)
        return false;
    constexpr float radians = 0.017453292519943295f;
    const float pitch = angles.x * radians, yaw = angles.y * radians;
    const float sp = std::sin(pitch), cp = std::cos(pitch);
    const float sy = std::sin(yaw), cy = std::cos(yaw);
    const Vector3 right{cy, 0.f, -sy};
    const Vector3 up{sy * sp, cp, cy * sp};
    const Vector3 forward{sy * cp, -sp, cy * cp};
    const float fy = 1.f / std::tan(verticalFovDegrees * radians * 0.5f);
    const float fx = fy / aspect;
    const Vector3 c[3] = {{right.x * fx, right.y * fx, right.z * fx},
                          {up.x * fy, up.y * fy, up.z * fy}, forward};
    const int columns[3] = {0, 1, 3};
    for (int i = 0; i < 3; ++i) {
        int k = columns[i];
        out.m[0][k] = c[i].x; out.m[1][k] = c[i].y; out.m[2][k] = c[i].z;
        out.m[3][k] = -(eye.x*c[i].x + eye.y*c[i].y + eye.z*c[i].z);
    }
    return true;
}
}
