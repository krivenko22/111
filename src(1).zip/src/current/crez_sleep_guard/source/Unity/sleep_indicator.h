#pragma once
#include "types.h"
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
// Sleep offsets in this build are candidates, not confirmed facts. Never turn
// a failed/untrusted read into a SLEEP assertion.
namespace SleepIndicator {
inline std::atomic<uintptr_t> localPlayer{0};
inline std::atomic<uintptr_t> calibratedClass{0};
constexpr uint32_t PlayerSleeping=0x10, ModelSleeping=0x8;
inline bool validptr(uint64_t p){return p>=0x10000&&p<0x7ffffffff000ULL;}
template<class Read,class T> bool get(Read& read,uint64_t a,T& out){out={};return validptr(a)&&read(a,&out,sizeof(out));}
template<class Read> uintptr_t Calibrate(Read read,uint64_t local,uint64_t playerFlagsOffset,uint64_t modelStateOffset,uint64_t modelFlagsOffset){
 uint64_t state=0,klass=0,namePtr=0;uint32_t player=0,model=0;char name[11]{};
 if(!validptr(local)||!get(read,local+playerFlagsOffset,player)||!get(read,local+modelStateOffset,state)||!validptr(state)||
    !get(read,state,klass)||!validptr(klass)||!get(read,klass+0x10,namePtr)||!validptr(namePtr)||
    !read(namePtr,name,sizeof(name))||std::memcmp(name,"ModelState",sizeof(name))!=0||
    !get(read,state+modelFlagsOffset,model)||(player&PlayerSleeping)||(model&ModelSleeping))return 0;
 return uintptr_t(klass);
}
inline bool Both(uint32_t player,uint32_t model){return (player&PlayerSleeping)&&(model&ModelSleeping);}
struct Tracker {
 uintptr_t identity=0; bool candidate=false, confirmed=false; Vector3 anchor{}; int64_t startMs=0,lastMs=0; int observations=0;
 void Reset(){candidate=false;confirmed=false;anchor={};startMs=lastMs=0;observations=0;}
 bool Observe(uintptr_t modelIdentity,int64_t nowMs,bool trusted,bool flagsAgree,bool posOk,Vector3 p,bool graceAllowed=false){
  if(modelIdentity!=identity){Reset();identity=modelIdentity;}
  if(!posOk||!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z)||!validptr(modelIdentity)||nowMs<=0){Reset();return false;}
  const float x=p.x-anchor.x,y=p.y-anchor.y,z=p.z-anchor.z;
  const float delta=x*x+y*y+z*z;
  // A single failed remote read doesn't flash an already-confirmed marker.
  // Never grace explicit waking, a changed model, movement, or lost calibration.
  if(!trusted){
   if(graceAllowed && confirmed && nowMs>=lastMs && nowMs-lastMs<=150 && std::isfinite(delta) && delta<=.0036f)return true;
   Reset();return false;
  }
  if(!flagsAgree){Reset();return false;}
  if(!candidate||nowMs<lastMs||nowMs-lastMs>1500){candidate=true;anchor=p;startMs=lastMs=nowMs;observations=1;return false;}
  if(!std::isfinite(delta)||delta>.0036f){anchor=p;startMs=lastMs=nowMs;observations=1;confirmed=false;return false;}
  lastMs=nowMs;if(observations<100000)++observations;
  confirmed=observations>=3 && nowMs-startMs>=500;
  return confirmed;
 }
};
}
