#pragma once
#include "imgui/imgui.h"
#include <cmath>
#include <algorithm>
namespace SrcoawVisuals {
inline bool ValidBox(ImVec2 a, ImVec2 b) {
 return std::isfinite(a.x)&&std::isfinite(a.y)&&std::isfinite(b.x)&&std::isfinite(b.y)&&b.x-a.x>=4.f&&b.y-a.y>=4.f&&b.x-a.x<100000.f&&b.y-a.y<100000.f;
}
inline void Fill(ImDrawList* d, ImVec2 a, ImVec2 b, ImU32 top, ImU32 bottom){
 if(!d||!ValidBox(a,b))return;
 a.x+=2.f;a.y+=2.f;b.x-=2.f;b.y-=2.f;
 if(b.x>a.x&&b.y>a.y)d->AddRectFilledMultiColor(a,b,top,top,bottom,bottom);
}
inline void GradientBorder(ImDrawList* d,ImVec2 a,ImVec2 b,ImU32 top,ImU32 bottom,float t){
 if(!d||!ValidBox(a,b)||!std::isfinite(t)||t<=0)return;
 t=(std::min)(t,(std::min)((b.x-a.x)*.25f,(b.y-a.y)*.25f));
 d->AddRectFilled({a.x,a.y},{b.x,a.y+t},top);
 d->AddRectFilled({a.x,b.y-t},{b.x,b.y},bottom);
 d->AddRectFilledMultiColor({a.x,a.y+t},{a.x+t,b.y-t},top,top,bottom,bottom);
 d->AddRectFilledMultiColor({b.x-t,a.y+t},{b.x,b.y-t},top,top,bottom,bottom);
}
inline void SnapLine(ImDrawList* d,ImVec2 a,ImVec2 b,float width,float height,int align,ImU32 color){
 if(!d||!ValidBox(a,b)||!std::isfinite(width)||!std::isfinite(height)||width<=0||height<=0)return;
 float y=align==0?0.f:align==1?height*.5f:height;
 d->AddLine({width*.5f,y},{(a.x+b.x)*.5f,b.y},color,1.f);
}
inline void HeadCircle(ImDrawList* d,ImVec2 head,ImVec2 neck,ImU32 color){
 if(!d||!std::isfinite(head.x)||!std::isfinite(head.y)||!std::isfinite(neck.x)||!std::isfinite(neck.y))return;
 float dx=head.x-neck.x,dy=head.y-neck.y,r=std::sqrt(dx*dx+dy*dy);
 if(r>=1.f&&r<=200.f)d->AddCircle(head,r,color,32,1.5f);
}
}
