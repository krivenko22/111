#pragma once
#include "Offsets.h"
#include "decryptors.h"
#include "Driver/Driver.h"
#include <cstdint>
#include <string>
#include <windows.h>

namespace Game {
    class BasePlayer {
    private:
        uintptr_t m_entityAddress = 0;

    public:
        BasePlayer() = default;
        explicit BasePlayer(uintptr_t address) : m_entityAddress(address) {}

        bool IsValid() const {
            return Decryption::is_valid_ptr(m_entityAddress);
        }

        uintptr_t GetEntity() const {
            return m_entityAddress;
        }

        bool IsGarbage() const {

            if (!IsValid()) return true;

            uintptr_t pModel = kernelHandler.readmem<uintptr_t>(
                m_entityAddress + offsets::base_player::player_model
            );
            if (!Decryption::is_valid_ptr(pModel)) return true;

            uintptr_t multiMesh = kernelHandler.readmem<uintptr_t>(
                pModel + offsets::player_model::_multiMesh
            );
            if (!Decryption::is_valid_ptr(multiMesh)) return true;

            uintptr_t rendererList = kernelHandler.readmem<uintptr_t>(
                multiMesh + offsets::skinned_multi_mesh::RendererList
            );
            if (!Decryption::is_valid_ptr(rendererList)) return true;

            int rendererCount = kernelHandler.readmem<int>(
                rendererList + offsets::system_list::size
            );
            if (rendererCount <= 0 || rendererCount > 200) return true;

            uintptr_t boneTransforms = kernelHandler.readmem<uintptr_t>(
                pModel + offsets::player_model::boneTransforms
            );
            if (!Decryption::is_valid_ptr(boneTransforms)) return true;

            std::wstring name = ReadPlayerNameWide();
            if (name.empty()) return true;
            if (name.size() > 64) return true;

            return false;
        }

        std::wstring ReadPlayerNameWide() const {
            if (!IsValid()) return L"";
            uintptr_t displayNamePtr = kernelHandler.readmem<uintptr_t>(
                m_entityAddress + offsets::base_player::display_name
            );
            if (!Decryption::is_valid_ptr(displayNamePtr)) return L"";

            std::wstring name = kernelHandler.ReadUnicode(displayNamePtr);
            while (!name.empty() && (name.back() == L'\0' || name.back() == L' ')) {
                name.pop_back();
            }
            return name;
        }

        std::string ReadPlayerName() const {
            std::wstring wide = ReadPlayerNameWide();
            if (wide.empty()) return "";

            int len = WideCharToMultiByte(
                CP_UTF8, 0,
                wide.c_str(), static_cast<int>(wide.size()),
                nullptr, 0, nullptr, nullptr
            );
            if (len <= 0) return "";

            std::string result(static_cast<size_t>(len), '\0');
            WideCharToMultiByte(
                CP_UTF8, 0,
                wide.c_str(), static_cast<int>(wide.size()),
                result.data(), len, nullptr, nullptr
            );
            return result;
        }

        explicit operator bool() const { return IsValid(); }

        bool operator==(const BasePlayer& other) const {
            return m_entityAddress == other.m_entityAddress;
        }

        bool operator!=(const BasePlayer& other) const {
            return m_entityAddress != other.m_entityAddress;
        }
    };
}