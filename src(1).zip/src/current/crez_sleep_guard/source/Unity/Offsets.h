#pragma once


#include <cstdint>

namespace offsets {

    namespace rust_globals {
        inline constexpr uintptr_t il2cpphandle = 0x868BB0;
        inline constexpr uintptr_t gchandle_get_target = 0x868BB0;
        inline constexpr uintptr_t base_networkable_static = 0xF067418; // build 2636: holder TypeInfo slot (statics+0x38 -> realm wrapper), disasm .cctor 0x4B26010
        inline constexpr uintptr_t main_camera_c = 0xF083218; // build 2636: SingletonComponent<MainCamera> TypeInfo slot (unverified statics slot)
        inline constexpr uintptr_t local_player_static = 0xF209810; // build 2636: SingletonComponent<Client> TypeInfo slot (unverified)
        inline constexpr uintptr_t tod_sky = 0x10BACC40;
        inline constexpr uintptr_t convar_graphics = 0x10BF2568;
        inline constexpr uintptr_t game_manager_static = 0x10BAB750;
        inline constexpr uintptr_t string_pool = 0x10CCA488;

        // New dump metadata
        inline constexpr uintptr_t timestamp = 0x6AB9A172;
    }

    namespace game_assembly {
        inline constexpr uintptr_t il2cpp_gchandle_get_target = 0x868BB0;

        inline constexpr uintptr_t il2cpp_resolve_icall = 0x867740;
        inline constexpr uintptr_t il2cpp_array_new = 0x867760;
        inline constexpr uintptr_t il2cpp_assembly_get_image = 0x3A60;
        inline constexpr uintptr_t il2cpp_class_from_name = 0x851950;
        inline constexpr uintptr_t il2cpp_class_get_method_from_name = 0x867B60;
        inline constexpr uintptr_t il2cpp_class_get_type = 0x74EE60;
        inline constexpr uintptr_t il2cpp_domain_get = 0x868480;
        inline constexpr uintptr_t il2cpp_domain_get_assemblies = 0x8684A0;
        inline constexpr uintptr_t il2cpp_gchandle_new = 0x868B60;
        inline constexpr uintptr_t il2cpp_gchandle_free = 0x868C50;
        inline constexpr uintptr_t il2cpp_method_get_name = 0xC8D0;
        inline constexpr uintptr_t il2cpp_object_new = 0x8694F0;
        inline constexpr uintptr_t il2cpp_type_get_object = 0x86A5D0;
        inline constexpr uintptr_t il2cpp_gchandle_get_target_new = 0x868BB0;
    }

    namespace il2cpp_api {
        inline constexpr uintptr_t gchandle_get_target = 0x868BB0;

        inline constexpr uintptr_t domain_get = 0x868480;
        inline constexpr uintptr_t domain_get_assemblies = 0x8684A0;
        inline constexpr uintptr_t domain_assembly_open = 0x868490;
        inline constexpr uintptr_t assembly_get_image = 0x3A60;
        inline constexpr uintptr_t class_from_name = 0x851950;
        inline constexpr uintptr_t image_get_class_count = 0xBE70;
        inline constexpr uintptr_t image_get_class = 0x86A8B0;
        inline constexpr uintptr_t class_get_methods = 0x867AD0;
        inline constexpr uintptr_t class_get_method_from_name = 0x867B60;
        inline constexpr uintptr_t class_get_fields = 0x867880;
        inline constexpr uintptr_t class_get_nested_types = 0x867900;
        inline constexpr uintptr_t class_get_type = 0x74EE60;
        inline constexpr uintptr_t class_get_name = 0xBE50;
        inline constexpr uintptr_t class_get_namespace = 0xC8D0;
        inline constexpr uintptr_t class_get_parent = 0x1E180;
        inline constexpr uintptr_t class_get_interfaces = 0x867910;
        inline constexpr uintptr_t class_get_image = 0x3A60;
        inline constexpr uintptr_t class_get_flags = 0x867BB0;
        inline constexpr uintptr_t class_is_valuetype = 0x1BB860;
        inline constexpr uintptr_t class_array_element_size = 0x867BF0;
        inline constexpr uintptr_t class_get_static_field_data = 0x2770;
        inline constexpr uintptr_t class_from_il2cpp_type = 0x867860;
        inline constexpr uintptr_t type_get_object = 0x86A5D0;
        inline constexpr uintptr_t type_get_class_or_element_class = 0x86A5F0;
        inline constexpr uintptr_t type_get_name = 0x86A620;
        inline constexpr uintptr_t type_get_attrs = 0x86A840;
        inline constexpr uintptr_t method_get_param_count = 0x869120;
        inline constexpr uintptr_t method_get_name = 0xC8D0;
        inline constexpr uintptr_t method_get_param = 0x869130;
        inline constexpr uintptr_t method_get_return_type = 0xE0C0;
        inline constexpr uintptr_t method_get_class = 0xC990;
        inline constexpr uintptr_t method_get_flags = 0x8691E0;
        inline constexpr uintptr_t field_get_offset = 0x7F7620;
        inline constexpr uintptr_t field_get_type = 0x469A50;
        inline constexpr uintptr_t field_get_parent = 0xBE50;
        inline constexpr uintptr_t field_get_name = 0x3A60;
        inline constexpr uintptr_t field_get_flags = 0x868720;
        inline constexpr uintptr_t field_static_get_value = 0x868880;
        inline constexpr uintptr_t object_get_class = 0x3A60;
        inline constexpr uintptr_t object_new = 0x8694F0;
        inline constexpr uintptr_t resolve_icall = 0x867740;
        inline constexpr uintptr_t gchandle_new = 0x868B60;
        inline constexpr uintptr_t gchandle_free = 0x868C50;
        inline constexpr uintptr_t array_new = 0x867760;
        inline constexpr uintptr_t string_new = 0x869610;
    }

    namespace gc_handles {
        inline constexpr uintptr_t table = 0x110258C0;
        inline constexpr uintptr_t table_prev = 0x11E93210;
        inline constexpr uintptr_t table_rx = 0x11E78950;
        inline constexpr uintptr_t get_target = 0x868BB0;
    }

    namespace klass_rvas {
        inline constexpr uintptr_t BaseNetworkable_TypeInfo = 0x10BE9150;
        inline constexpr uintptr_t BaseNetworkable = 0x10BE9150;
        inline constexpr uintptr_t BaseEntity = 0x10C90F90;
        inline constexpr uintptr_t BaseCombatEntity = 0x10BE1E80;
        inline constexpr uintptr_t BasePlayer = 0x10BE9128;
        inline constexpr uintptr_t BaseNpc = 0x10BA91A0;
        inline constexpr uintptr_t BaseVehicle = 0x10CC3348;
        inline constexpr uintptr_t DroppedItemContainer = 0x10C5FC70;
        inline constexpr uintptr_t OreResourceEntity = 0x10C5FC68;
        inline constexpr uintptr_t CollectibleEntity = 0x10C62460;
        inline constexpr uintptr_t BuildingBlock = 0x10BE1EC0;
        inline constexpr uintptr_t BuildingPrivlidge = 0x10BB5700;
        inline constexpr uintptr_t Door = 0x10BD77D0;
        inline constexpr uintptr_t WorldItem = 0x10C61E10;
        inline constexpr uintptr_t Signage = 0x10C051B0;
        inline constexpr uintptr_t MainCamera = 0x10BF2548;
        inline constexpr uintptr_t PlayerEyes = 0x10C612C0;
        inline constexpr uintptr_t PlayerModel = 0x10C03C68;
        inline constexpr uintptr_t TOD_Sky = 0x10BACC40;
        inline constexpr uintptr_t Item = 0x10C2E970;
        inline constexpr uintptr_t ItemId = 0x10C75468;
        inline constexpr uintptr_t ConsoleSystem_Command = 0x10C2BB58;
        inline constexpr uintptr_t PlayerInventory = 0x10C60030;
        inline constexpr uintptr_t PlayerInventory_typenav = 0x10C60030;
        inline constexpr uintptr_t LocalPlayer_Static = 0x10CB0570;
        inline constexpr uintptr_t ListComponent_Projectile = 0x10BBD5B0;
        inline constexpr uintptr_t ConVar_Graphics_Static = 0x10BF2568;
        inline constexpr uintptr_t GameManager_Static = 0x10BAB750;
        inline constexpr uintptr_t StringPool = 0x10CCA488;
        inline constexpr uintptr_t ProgressBar = 0x10BE53E8;
        inline constexpr uintptr_t ItemIcon = 0x10C1A9D0;
        inline constexpr uintptr_t ConVar_Admin = 0x10C336A0;
        inline constexpr uintptr_t MapView_Static = 0x10BD23D0;
        inline constexpr uintptr_t RustWorld = 0x10BF80B8;

        inline constexpr uintptr_t BaseEntity_TypeInfo = 0x10C90F90;
        inline constexpr uintptr_t BasePlayer_TypeInfo = 0x10BE9128;
        inline constexpr uintptr_t PlayerEyes_TypeInfo = 0x10C612C0;
        inline constexpr uintptr_t PlayerInventory_TypeInfo = 0x10C60030;
        inline constexpr uintptr_t PlayerModel_TypeInfo = 0x10C03C68;
        inline constexpr uintptr_t ModelState_TypeInfo = 0x10BBD798;
        inline constexpr uintptr_t PlayerInput_TypeInfo = 0x10BBE588;
        inline constexpr uintptr_t BaseProjectile_TypeInfo = 0x10BA6080;
        inline constexpr uintptr_t HitTest_TypeInfo = 0x10BC2280;
        inline constexpr uintptr_t HeldEntity_TypeInfo = 0x10C628B0;
        inline constexpr uintptr_t BaseViewModel_TypeInfo = 0x10B9D9D0;
        inline constexpr uintptr_t GameManager_Static_TypeInfo = 0x10BAB750;
    }

    namespace PhysX {
        constexpr std::uintptr_t type_info = 0x10BFA428;
        constexpr std::uintptr_t static_fields = 0xB8;
        constexpr std::uintptr_t global_ptr_rva = 0x217F8E8;
    }

    namespace list_component_projectile {
        inline constexpr uintptr_t type_info = 0x111C53C8; // UPDATED from new dump: 0x10BBD5B0 -> 0x111C53C8
        inline constexpr uintptr_t static_fields = 0xB8;
        inline constexpr uintptr_t InstanceList = 0x38;
        inline constexpr uintptr_t ListItems = 0x10;
        inline constexpr uintptr_t ListCount = 0x18;
        inline constexpr uintptr_t instance = 0x20;
        inline constexpr uintptr_t BufferList_ptr = 0x10;
        inline constexpr uintptr_t vals_in_hashset = 0x10;
    }

    namespace game_manager {
        inline constexpr uintptr_t game_manager = 0x10BAB750;
        inline constexpr uintptr_t static_fields = 0xB8;
        inline constexpr uintptr_t CreatePrefab = 0x2151700; // NEW from new dump
    }

    namespace klass_layout {
        inline constexpr uintptr_t name_ptr = 0x10;
        inline constexpr uintptr_t parent = 0x58;
        inline constexpr uintptr_t static_fields = 0xB8;
    }

    namespace ListComponent_Projectile
    {
        constexpr std::uintptr_t static_fields = 0xB8;
        constexpr std::uintptr_t InstanceList = 0x38;
        constexpr std::uintptr_t ListItems = 0x10;
        constexpr std::uintptr_t ListCount = 0x18;
        constexpr std::uintptr_t instance = 0x20;
        constexpr std::uintptr_t BufferList_ptr = 0x10;
        constexpr std::uintptr_t vals_in_hashset = 0x10;
    }

    namespace base_networkable {
        inline constexpr uintptr_t base_networkable = 0x10BE9150;
        inline constexpr uintptr_t static_fields = 0xB8;
        inline constexpr uintptr_t wrapper_class_ptr = 0x18;
        inline constexpr uintptr_t client_entities = 0x18;
        inline constexpr uintptr_t entity_list = 0x18;
        inline constexpr uintptr_t parent_static_fields = 0x18;
        inline constexpr uintptr_t hv_offset = 0x18;
        inline constexpr uintptr_t decrypt_gate = 0x14;
        inline constexpr uintptr_t entities = 0x18;
        inline constexpr uintptr_t entity = 0x18;
        inline constexpr uintptr_t buffer = 0x18;
        inline constexpr uintptr_t buffer_list_array = 0x10;
        inline constexpr uintptr_t buffer_list_size = 0x18;
        inline constexpr uintptr_t il2cpp_array_data = 0x28;
        inline constexpr uintptr_t list_vals = 0x18;
        inline constexpr uintptr_t prefabID = 0x54;
        inline constexpr uintptr_t prefabName = 0x28;
        inline constexpr uintptr_t net = 0x70;
        inline constexpr uintptr_t parentEntity = 0x38;
        inline constexpr uintptr_t children = 0x88; // UPDATED from new dump: 0x68 -> 0x88
        inline constexpr uintptr_t globalBroadcast = 0x58;
        inline constexpr uintptr_t networkRange = 0x64;

        inline constexpr uintptr_t client_entities_decryption = 0x6F6A610;
        inline constexpr uintptr_t entity_list_decryption = 0x6F6A8F0;
    }

    namespace SkinnedMultiMesh {
        constexpr std::uintptr_t RendererList = 0x40;
        constexpr std::uintptr_t Renderers = 0x40;
    }

    namespace Object {
        constexpr std::uintptr_t m_CachedPtr = 0x10;
    }

    namespace camera {
        inline constexpr uintptr_t main_camera = 0xF083218; // build 2636: SingletonComponent<MainCamera> TypeInfo slot
        inline constexpr uintptr_t camera_static = 0xB8;
        inline constexpr uintptr_t static_fields = 0xB8;
        inline constexpr uintptr_t camera_object = 0x28; // build 2636: statics slot candidate (unverified, live-FILL)
        inline constexpr uintptr_t native = 0x10;
        inline constexpr uintptr_t instance = 0x8;
        inline constexpr uintptr_t main_camera_field_alt = 0x28;
        inline constexpr uintptr_t entity = 0x10;
        inline constexpr uintptr_t position = 0x444;
        inline constexpr uintptr_t viewMatrix = 0x2FC;
        inline constexpr uintptr_t view_matrix = 0x2FC;
        inline constexpr uintptr_t viewProjectionMatrix = 0x2FC;
        inline constexpr uintptr_t clipMatrix = 0x2FC;
        inline constexpr uintptr_t projectionMatrix = 0x18C;
        inline constexpr uintptr_t projection_layout = 0x1;
        inline constexpr uintptr_t fieldOfView = 0x170;
        inline constexpr uintptr_t field_of_view = 0x170;
        inline constexpr uintptr_t worldToCameraMatrix = 0x70;
        inline constexpr uintptr_t cullingMask = 0x42C;
        inline constexpr uintptr_t culling_mask = 0x42C;
        inline constexpr uintptr_t aspect = 0x4E0;
        inline constexpr uintptr_t nearClip = 0x430;
        inline constexpr uintptr_t farClip = 0x458;
    }

    namespace base_player {
        inline constexpr uintptr_t player_model = 0x710; // UPDATED from new dump: 0x4F8 -> 0x710
        inline constexpr uintptr_t currentGesture = 0x318;
        inline constexpr uintptr_t movement = 0x548; // UPDATED from new dump: 0x5A0 -> 0x548
        inline constexpr uintptr_t base_movement = 0x5A0;
        inline constexpr uintptr_t visiblePlayerList = 0x368;
        inline constexpr uintptr_t player_team = 0x558;
        inline constexpr uintptr_t frozen = 0x398;
        inline constexpr uintptr_t PlayerInventory = 0x4A8; // UPDATED from new dump: 0x5A8 -> 0x4A8
        inline constexpr uintptr_t player_inventory = 0x4A8; // UPDATED from new dump: 0x5A8 -> 0x4A8
        inline constexpr uintptr_t Belt = 0x520;
        inline constexpr uintptr_t player_rigidbody = 0x6F0;
        inline constexpr uintptr_t modelState = 0x340; // UPDATED from new dump: 0x3A0 -> 0x340
        inline constexpr uintptr_t model_state = 0x340; // UPDATED from new dump: 0x3A0 -> 0x340
        inline constexpr uintptr_t _lookingAt = 0x7B8; // UPDATED from new dump: 0x740 -> 0x7B8
        inline constexpr uintptr_t lookingAt = 0x7B8; // UPDATED from new dump: 0x740 -> 0x7B8
        inline constexpr uintptr_t display_name = 0x7F0; // UPDATED from new dump: 0x4C8 -> 0x7F0
        inline constexpr uintptr_t current_team = 0x558;
        inline constexpr uintptr_t clActiveItem = 0x590; // UPDATED from new dump: 0x588 -> 0x590
        inline constexpr uintptr_t cl_active_item = 0x590; // UPDATED from new dump: 0x588 -> 0x590
        inline constexpr uintptr_t lookingAtEntity = 0x5A8;
        inline constexpr uintptr_t mounted = 0x5E8; // UPDATED from new dump: 0x5E0 -> 0x5E8
        inline constexpr uintptr_t heldEntity = 0x630;
        inline constexpr uintptr_t lastSentTickTime = 0x6A0; // UPDATED from new dump: 0x698 -> 0x6A0
        inline constexpr uintptr_t playerFlags = 0x6E0; // UPDATED from new dump: 0x6D8 -> 0x6E0
        inline constexpr uintptr_t player_flags = 0x6E0; // UPDATED from new dump: 0x6D8 -> 0x6E0
        inline constexpr uintptr_t player_input = 0x620; // UPDATED from new dump: 0x6E8 -> 0x620
        inline constexpr uintptr_t lastSentTick = 0x638; // UPDATED from new dump: 0x3E8 -> 0x638
        inline constexpr uintptr_t blueprints = 0x7A8;
        inline constexpr uintptr_t metabolism = 0x4C0;
        inline constexpr uintptr_t PlayerEyes = 0x4A0; // UPDATED from new dump: 0x3F0 -> 0x4A0
        inline constexpr uintptr_t player_eyes = 0x4A0; // UPDATED from new dump: 0x3F0 -> 0x4A0
        inline constexpr uintptr_t userID = 0x720;
        inline constexpr uintptr_t user_id = 0x720;
        inline constexpr uintptr_t userIDString = 0x3F0;
        inline constexpr uintptr_t weaponMoveSpeedScale = 0x7C8; // UPDATED from new dump: 0x7B8 -> 0x7C8
        inline constexpr uintptr_t clothingBlocksAiming = 0x7BC;
        inline constexpr uintptr_t clothingMoveSpeedReduction = 0x7D0; // UPDATED from new dump: 0x7C0 -> 0x7D0
        inline constexpr uintptr_t clothingWaterSpeedBonus = 0x7D4; // UPDATED from new dump: 0x7C4 -> 0x7D4
        inline constexpr uintptr_t equippingBlocked = 0x7CC;
        inline constexpr uintptr_t modifiers = 0x5D0; // UPDATED from new dump: 0x3F8 -> 0x5D0
        inline constexpr uintptr_t OnViewModeChanged = 0x33E3140; // NEW from new dump
        inline constexpr uintptr_t eyes = 0x4A0; // NEW from new dump
        inline constexpr uintptr_t input = 0x620; // NEW from new dump
        inline constexpr uintptr_t inventory = 0x4A8; // NEW from new dump
    }

    namespace base_combat_entity {
        inline constexpr uintptr_t model = 0x1D0; // build 2636 dump
        inline constexpr uintptr_t skeletonProperties = 0x238; // UPDATED from new dump: 0x230 -> 0x238
        inline constexpr uintptr_t baseProtection = 0x240; // UPDATED from new dump: 0x238 -> 0x240
        inline constexpr uintptr_t lifestate = 0x2C0; // build 2636: confirmed statically (BaseCombatEntity.lifestate)
        inline constexpr uintptr_t markAttackerHostile = 0x2B6; // UPDATED from new dump: 0x2AE -> 0x2B6
        inline constexpr uintptr_t _health = 0x2BC; // UPDATED from new dump: 0x2B4 -> 0x2BC
        inline constexpr uintptr_t _maxHealth = 0x2C0; // UPDATED from new dump: 0x2B8 -> 0x2C0
        inline constexpr uintptr_t startHealth = 0x248; // UPDATED from new dump: 0x240 -> 0x248
    }

    namespace base_entity {
        inline constexpr uintptr_t triggers = 0x160;
        inline constexpr uintptr_t bounds = 0x1A4; // build 2636 dump: UnityEngine.Bounds bounds @0x1A4
        inline constexpr uintptr_t model = 0x1D0; // build 2636 dump: typed `public Model model` @0x1D0
        inline constexpr uintptr_t flags = 0x1D8; // build 2636 dump: BaseEntity.Flags @0x1D8
        inline constexpr uintptr_t positionLerp = 0x138;
        inline constexpr uintptr_t position = 0x168;
        inline constexpr uintptr_t SendSignalBroadcast = 0x71703E0; // NEW from new dump
        inline constexpr uintptr_t ServerRPC = 0x72059E0; // NEW from new dump
    }

    namespace base_entity_flags {
        inline constexpr uint32_t Placeholder = 0x1;
        inline constexpr uint32_t On = 0x2;
        inline constexpr uint32_t OnFire = 0x4;
        inline constexpr uint32_t Open = 0x8;
        inline constexpr uint32_t Locked = 0x10;
        inline constexpr uint32_t Debugging = 0x20;
        inline constexpr uint32_t Disabled = 0x40;
        inline constexpr uint32_t Reserved1 = 0x80;
        inline constexpr uint32_t Reserved2 = 0x100;
        inline constexpr uint32_t Reserved3 = 0x200;
        inline constexpr uint32_t Reserved4 = 0x400;
        inline constexpr uint32_t Reserved5 = 0x800;
    }

    namespace base_player_flags {
        inline constexpr uint32_t Unused1 = 0x1;
        inline constexpr uint32_t Unused2 = 0x2;
        inline constexpr uint32_t IsAdmin = 0x4;
        inline constexpr uint32_t ReceivingSnapshot = 0x8;
        inline constexpr uint32_t Sleeping = 0x10;
        inline constexpr uint32_t Spectating = 0x20;
        inline constexpr uint32_t Wounded = 0x40;
        inline constexpr uint32_t IsDeveloper = 0x80;
        inline constexpr uint32_t Connected = 0x100;
        inline constexpr uint32_t ThirdPersonViewmode = 0x400;
    }

    namespace model_state {
        inline constexpr uintptr_t lookDir = 0x18; // UPDATED from new dump: 0x2C -> 0x18

        // UPDATED FROM NEW DUMP:
        inline constexpr uintptr_t flags = 0x60; // UPDATED from new dump: 0x14 -> 0x60

        inline constexpr uintptr_t waterLevel = 0x40; // UPDATED from new dump: 0x38 -> 0x40
    }

    namespace modelstate_flags {
        inline constexpr uint32_t ducked = 0x1;
        inline constexpr uint32_t jumped = 0x2;
        inline constexpr uint32_t OnGround = 0x4;
        inline constexpr uint32_t Sleeping = 0x8;
        inline constexpr uint32_t sprinting = 0x10;
        inline constexpr uint32_t onLadder = 0x20;
        inline constexpr uint32_t Flying = 0x40;
        inline constexpr uint32_t aiming = 0x80;
        inline constexpr uint32_t Mounted = 0x200;
        inline constexpr uint32_t crawling = 0x1000;
        inline constexpr uint32_t hasParachute = 0x8000;
    }

    namespace item_container {
        inline constexpr uintptr_t itemCount = 0x18;
        inline constexpr uintptr_t ItemList = 0x18; // UPDATED from new dump: 0x40 -> 0x18
        inline constexpr uintptr_t flags = 0x78; // UPDATED from new dump: 0x20 -> 0x78
        inline constexpr uintptr_t uid = 0x30; // UPDATED from new dump: 0x50 -> 0x30
    }

    namespace item_definition {
        inline constexpr uintptr_t itemid = 0x20;
        inline constexpr uintptr_t phraseEnglish = 0x20;
        inline constexpr uintptr_t shortname = 0x28;
        inline constexpr uintptr_t displayName = 0x40;
        inline constexpr uintptr_t iconSprite = 0x50;
        inline constexpr uintptr_t category = 0x58;
        inline constexpr uintptr_t stackable = 0x78;
        inline constexpr uintptr_t rarity = 0x94;
        inline constexpr uintptr_t condition = 0xB8;
        inline constexpr uintptr_t ItemModWearable = 0x198;
    }

    namespace item {
        inline constexpr uintptr_t HeldEntity = 0x70; // UPDATED from new dump: 0x50 -> 0x70
        inline constexpr uintptr_t held_entity = 0x70; // UPDATED from new dump: 0x50 -> 0x70
        inline constexpr uintptr_t clientAmmo = 0x2C;
        inline constexpr uintptr_t contents = 0x38;
        inline constexpr uintptr_t amount = 0xDC; // UPDATED from new dump: 0xAC -> 0xDC
        inline constexpr uintptr_t maxCondition = 0x44;
        inline constexpr uintptr_t info = 0x10; // UPDATED from new dump: 0xB8 -> 0x10
        inline constexpr uintptr_t itemdefinition = 0xB8;
        inline constexpr uintptr_t definition = 0xB8;
        inline constexpr uintptr_t position = 0xD8; // UPDATED from new dump: 0xA4 -> 0xD8
        inline constexpr uintptr_t worldEnt = 0xC8; // UPDATED from new dump: 0x40 -> 0xC8
        inline constexpr uintptr_t uid = 0x38; // UPDATED from new dump: 0x88 -> 0x38
        inline constexpr uintptr_t condition = 0xE0;

        // Added from new dump
        inline constexpr uintptr_t ammoCount = 0x10;
        inline constexpr uintptr_t shortname = 0x28;
        inline constexpr uintptr_t category = 0x58;
    }

    namespace item_id {
        inline constexpr uintptr_t value = 0x10;
    }

    namespace item_held {
        inline constexpr uintptr_t wrapper_primary = 0x10;
        inline constexpr uintptr_t wrapper_alt = 0x78;
        inline constexpr uintptr_t wrapper_uid = 0x88;
    }

    namespace entity_ref {
        inline constexpr uintptr_t slot_a = 0x10;
        inline constexpr uintptr_t slot_b = 0x18;
        inline constexpr uintptr_t slot_c = 0x28;
    }

    namespace attack_entity {
        inline constexpr uintptr_t deployDelay = 0x2F0; // UPDATED from new dump: 0x2E8 -> 0x2F0
        inline constexpr uintptr_t repeatDelay = 0x2F4; // UPDATED from new dump: 0x2EC -> 0x2F4
        inline constexpr uintptr_t animationDelay = 0x2F8; // UPDATED from new dump: 0x2F0 -> 0x2F8
        inline constexpr uintptr_t effectiveRange = 0x2FC; // UPDATED from new dump: 0x2F4 -> 0x2FC
        inline constexpr uintptr_t attackSpacing = 0x304;
        inline constexpr uintptr_t nextAttackTime = 0x348; // UPDATED from new dump: 0x340 -> 0x348
        inline constexpr uintptr_t lastTickTime = 0x350; // UPDATED from new dump: 0x348 -> 0x350
        inline constexpr uintptr_t nextTickTime = 0x358; // UPDATED from new dump: 0x350 -> 0x358
        inline constexpr uintptr_t timeSinceDeploy = 0x360; // UPDATED from new dump: 0x358 -> 0x360
        inline constexpr uintptr_t noHeadshots = 0x346; // UPDATED from new dump: 0x33E -> 0x346
    }

    namespace base_projectile {
        inline constexpr uintptr_t projectileVelocityScale = 0x39C; // UPDATED from new dump: 0x394 -> 0x39C
        inline constexpr uintptr_t automatic = 0x3A0; // UPDATED from new dump: 0x398 -> 0x3A0
        inline constexpr uintptr_t reloadTime = 0x3E0; // UPDATED from new dump: 0x3D8 -> 0x3E0
        inline constexpr uintptr_t canUnloadAmmo = 0x3DC;
        inline constexpr uintptr_t primaryMagazine = 0x3E8; // UPDATED from new dump: 0x3E0 -> 0x3E8
        inline constexpr uintptr_t magazine = 0x3E0;
        inline constexpr uintptr_t fractionalReload = 0x3F0; // UPDATED from new dump: 0x3E8 -> 0x3F0
        inline constexpr uintptr_t reloadStartDuration = 0x3F4; // UPDATED from new dump: 0x3EC -> 0x3F4
        inline constexpr uintptr_t reloadFractionDuration = 0x3F8; // UPDATED from new dump: 0x3F0 -> 0x3F8
        inline constexpr uintptr_t reloadEndDuration = 0x3FC; // UPDATED from new dump: 0x3F4 -> 0x3FC
        inline constexpr uintptr_t aimSway = 0x408; // UPDATED from new dump: 0x400 -> 0x408
        inline constexpr uintptr_t aimSwaySpeed = 0x40C; // UPDATED from new dump: 0x404 -> 0x40C
        inline constexpr uintptr_t recoil = 0x410; // UPDATED from new dump: 0x408 -> 0x410
        inline constexpr uintptr_t aimCone = 0x420; // UPDATED from new dump: 0x418 -> 0x420
        inline constexpr uintptr_t hipAimCone = 0x424; // UPDATED from new dump: 0x41C -> 0x424
        inline constexpr uintptr_t aimconePenaltyPerShot = 0x428; // UPDATED from new dump: 0x420 -> 0x428
        inline constexpr uintptr_t aimConePenaltyMax = 0x42C; // UPDATED from new dump: 0x424 -> 0x42C
        inline constexpr uintptr_t stancePenaltyScale = 0x438; // UPDATED from new dump: 0x430 -> 0x438
        inline constexpr uintptr_t hasADS = 0x434;
        inline constexpr uintptr_t noAimingWhileCycling = 0x435;
        inline constexpr uintptr_t manualCycle = 0x436;
        inline constexpr uintptr_t isBurstWeapon = 0x447; // UPDATED from new dump: 0x43F -> 0x447
        inline constexpr uintptr_t canChangeFireModes = 0x448; // UPDATED from new dump: 0x440 -> 0x448
        inline constexpr uintptr_t internalBurstFireRateScale = 0x448;
        inline constexpr uintptr_t internalBurstAimConeScale = 0x44C;
        inline constexpr uintptr_t numShotsFired = 0x45C; // UPDATED from new dump: 0x454 -> 0x45C
        inline constexpr uintptr_t nextReloadTime = 0x460; // UPDATED from new dump: 0x458 -> 0x460
        inline constexpr uintptr_t startReloadTime = 0x468; // UPDATED from new dump: 0x460 -> 0x468
        inline constexpr uintptr_t stancePenalty = 0x470; // UPDATED from new dump: 0x458 -> 0x470
        inline constexpr uintptr_t aimconePenalty = 0x474; // UPDATED from new dump: 0x460 -> 0x474
        inline constexpr uintptr_t sightAimConeScale = 0x474;
        inline constexpr uintptr_t sightAimConeOffset = 0x478;
        inline constexpr uintptr_t hipAimConeScale = 0x47C;
        inline constexpr uintptr_t hipAimConeOffset = 0x480;
        inline constexpr uintptr_t isReloading = 0x48C; // UPDATED from new dump: 0x484 -> 0x48C
        inline constexpr uintptr_t currentBurst = 0x4C0; // UPDATED from new dump: 0x4B8 -> 0x4C0

        // Added from new dump
        inline constexpr uintptr_t aimconeCurve = 0x410;
        inline constexpr uintptr_t cachedModHash = 0x470;
        inline constexpr uintptr_t ShotFired = 0x607EDE0;
        inline constexpr uintptr_t BeginCycle = 0x606FD30;
        inline constexpr uintptr_t LaunchProjectile = 0x696C010; // NEW from new dump
        inline constexpr uintptr_t UpdateAmmoDisplay = 0x69759D0; // NEW from new dump
    }

    namespace compound_bow_weapon {
        inline constexpr uintptr_t stringBonusDamage = 0x4F4; // UPDATED from new dump: 0x4EC -> 0x4F4
        inline constexpr uintptr_t stringBonusDistance = 0x4F8; // UPDATED from new dump: 0x4F0 -> 0x4F8
        inline constexpr uintptr_t stringBonusVelocity = 0x4FC; // UPDATED from new dump: 0x4F4 -> 0x4FC
        inline constexpr uintptr_t movementPenaltyRampUpTime = 0x500; // UPDATED from new dump: 0x4F8 -> 0x500
        inline constexpr uintptr_t conditionLossPerSecondHeld = 0x504; // UPDATED from new dump: 0x4FC -> 0x504
        inline constexpr uintptr_t conditionLossHeldDelay = 0x508; // UPDATED from new dump: 0x500 -> 0x508
        inline constexpr uintptr_t stringHoldDurationMax = 0x4F0; // UPDATED from new dump: 0x4E8 -> 0x4F0
        inline constexpr uintptr_t movementPenalty = 0x538; // NEW from new dump
        inline constexpr uintptr_t stringHoldTimeStart = 0x544; // NEW from new dump
    }

    namespace projectile {
        inline constexpr uintptr_t initialVelocity = 0x28;
        inline constexpr uintptr_t drag = 0x34;
        inline constexpr uintptr_t gravityModifier = 0x38;
        inline constexpr uintptr_t thickness = 0x3C;
        inline constexpr uintptr_t initialDistance = 0x44;
        inline constexpr uintptr_t initialOrientation = 0x48;
        inline constexpr uintptr_t ricochetChance = 0x64;
        inline constexpr uintptr_t penetrationPower = 0x68;
        inline constexpr uintptr_t swimScale = 0xF0;
        inline constexpr uintptr_t swimSpeed = 0xFC;
        inline constexpr uintptr_t mod = 0x1E0;
        inline constexpr uintptr_t owner = 0x120;
        inline constexpr uintptr_t hitTest = 0x108;
        inline constexpr uintptr_t projectileID = 0x130;
        inline constexpr uintptr_t integrity = 0x13C;
        inline constexpr uintptr_t maxDistance = 0x1AC;
        inline constexpr uintptr_t currentVelocity = 0x164;
        inline constexpr uintptr_t currentPosition = 0x170;
        inline constexpr uintptr_t traveledDistance = 0x17C;
        inline constexpr uintptr_t traveledTime = 0x180;
        inline constexpr uintptr_t launchTime = 0x140;
        inline constexpr uintptr_t sentPosition = 0x188;
        inline constexpr uintptr_t previousPosition = 0x194;
        inline constexpr uintptr_t previousVelocity = 0x1A0;
        inline constexpr uintptr_t previousTraveledTime = 0x184;
        inline constexpr uintptr_t sourceProjectilePrefab = 0x110;
    }

    namespace hit_test {
        inline constexpr uintptr_t gameobject = 0x90;
        inline constexpr uintptr_t besthit = 0xA8;
        inline constexpr uintptr_t attackray = 0xC0;
        inline constexpr uintptr_t collider = 0xB0;
        inline constexpr uintptr_t hitnormal = 0x10;
        inline constexpr uintptr_t ignoreentity = 0x48;
        inline constexpr uintptr_t hitpoint = 0x9C;
        inline constexpr uintptr_t didhit = 0xBC;
        inline constexpr uintptr_t maxdistance = 0x50;
        inline constexpr uintptr_t rayhit = 0x1C;
        inline constexpr uintptr_t damageproperties = 0x78;
        inline constexpr uintptr_t hitentity = 0x58;
        inline constexpr uintptr_t hitdistance = 0x84;
        inline constexpr uintptr_t hitpart = 0xB8;
        inline constexpr uintptr_t hittransform = 0x68;
        inline constexpr uintptr_t type = 0x80;

        // Added from new dump
        inline constexpr uintptr_t ignoredtypes = 0x70;
        inline constexpr uintptr_t hitmaterial = 0xD8;
        inline constexpr uintptr_t multihit = 0x98;
        inline constexpr uintptr_t radius = 0xE0;
        inline constexpr uintptr_t forgivness = 0x60;
    }

    namespace base_melee {
        inline constexpr uintptr_t maxDistance = 0x3A8; // UPDATED from new dump: 0x3A0 -> 0x3A8
        inline constexpr uintptr_t attackRadius = 0x3AC; // UPDATED from new dump: 0x3A4 -> 0x3AC
        inline constexpr uintptr_t isAutomatic = 0x3A8;
        inline constexpr uintptr_t blockSprintOnAttack = 0x3B1; // UPDATED from new dump: 0x3A9 -> 0x3B1
        inline constexpr uintptr_t canThrowAsProjectile = 0x388; // UPDATED from new dump: 0x380 -> 0x388
        inline constexpr uintptr_t damageProperties = 0x390; // UPDATED from new dump: 0x388 -> 0x390
        inline constexpr uintptr_t gathering = 0x3E8; // UPDATED from new dump: 0x3E0 -> 0x3E8
    }

    namespace gather_properties {
        inline constexpr uintptr_t tree = 0x10;
        inline constexpr uintptr_t ore = 0x18;
        inline constexpr uintptr_t flesh = 0x20;
    }

    namespace gather_entry {
        inline constexpr uintptr_t gatherDamage = 0x10;
        inline constexpr uintptr_t destroyFraction = 0x14;
        inline constexpr uintptr_t conditionLost = 0x18;
    }

    namespace item_mod_projectile {
        inline constexpr uintptr_t projectileObject = 0x20;
        inline constexpr uintptr_t ammoType = 0x30;
        inline constexpr uintptr_t ammoSubType = 0x34;
        inline constexpr uintptr_t numProjectiles = 0x38;
        inline constexpr uintptr_t projectileSpread = 0x3C;
        inline constexpr uintptr_t projectileVelocity = 0x40;
        inline constexpr uintptr_t projectileVelocitySpread = 0x44;
        inline constexpr uintptr_t useCurve = 0x48;
        inline constexpr uintptr_t spreadScalar = 0x50;
        inline constexpr uintptr_t attackEffectOverride = 0x58;
        inline constexpr uintptr_t category = 0x68;
    }

    namespace recoil_properties {
        constexpr std::uintptr_t recoilYawMin = 0x18;
        constexpr std::uintptr_t recoilYawMax = 0x1C;
        constexpr std::uintptr_t recoilPitchMin = 0x20;
        constexpr std::uintptr_t recoilPitchMax = 0x24;
        constexpr std::uintptr_t timeToTakeMin = 0x28;
        constexpr std::uintptr_t timeToTakeMax = 0x2C;
        constexpr std::uintptr_t ADSScale = 0x30;
        constexpr std::uintptr_t movementPenalty = 0x34;
        constexpr std::uintptr_t clampPitch = 0x38;
        constexpr std::uintptr_t pitchCurve = 0x40;
        constexpr std::uintptr_t yawCurve = 0x48;
        constexpr std::uintptr_t ammoAimconeScaleMultiProjectile = 0x78;
        constexpr std::uintptr_t ammoAimconeScaleSingleProjectile = 0x7C;
        constexpr std::uintptr_t newRecoilOverride = 0x80;
        constexpr std::uintptr_t overrideAimconeWithCurve = 0x5C;
        constexpr std::uintptr_t aimconeProbabilityCurve = 0x70;
        constexpr std::uintptr_t aimconeCurveScale = 0x60;
    }

    namespace flint_strike_weapon {
        inline constexpr uintptr_t successFraction = 0x4C8; // UPDATED from new dump: 0x4C0 -> 0x4C8
        inline constexpr uintptr_t successIncrease = 0x4CC; // UPDATED from new dump: 0x4C4 -> 0x4CC
        inline constexpr uintptr_t strikeRecoil = 0x4C8;
        inline constexpr uintptr_t _didSparkThisFrame = 0x4D8; // UPDATED from new dump: 0x4D0 -> 0x4D8
        inline constexpr uintptr_t _isStriking = 0x4D9; // UPDATED from new dump: 0x4D1 -> 0x4D9
        inline constexpr uintptr_t strikes = 0x4DC; // UPDATED from new dump: 0x4D4 -> 0x4DC
    }

    namespace bow_weapon {
        inline constexpr uintptr_t attackReady = 0x4E0; // UPDATED from new dump: 0x4D8 -> 0x4E0
        inline constexpr uintptr_t arrowBack = 0x4E4; // UPDATED from new dump: 0x4DC -> 0x4E4
        inline constexpr uintptr_t wasAiming = 0x4E8; // UPDATED from new dump: 0x4E0 -> 0x4E8
    }

    namespace player_eyes {
        inline constexpr uintptr_t viewOffset = 0x40;
        inline constexpr uintptr_t bodyRotation = 0x50;
        inline constexpr uintptr_t headAngles = 0x60;
    }

    namespace player_input {
        inline constexpr uintptr_t state = 0x28;
        inline constexpr uintptr_t bodyAngles = 0x44;
        inline constexpr uintptr_t yaw = 0x60;
    }

    namespace player_model {
        inline constexpr uintptr_t collision = 0xD0;
        inline constexpr uintptr_t jawBone = 0xE8;
        inline constexpr uintptr_t neckBone = 0xF0;
        inline constexpr uintptr_t headBone = 0xF8;
        inline constexpr uintptr_t eyeBone = 0x120;
        inline constexpr uintptr_t rootBone = 0x98;
        inline constexpr uintptr_t boneTransforms = 0x98;
        inline constexpr uintptr_t fullMask = 0x208;
        inline constexpr uintptr_t position = 0x2F8;
        inline constexpr uintptr_t newVelocity = 0x31C;
        inline constexpr uintptr_t new_velocity = 0x31C;
        inline constexpr uintptr_t heldEntity = 0x448;
        inline constexpr uintptr_t _multiMesh = 0x520; // UPDATED from new dump: 0x3C8 -> 0x520
        inline constexpr uintptr_t skinned_mesh = 0x3C8;
        inline constexpr uintptr_t isNpc = 0x388;

        // Added from new dump
        inline constexpr uintptr_t visibleNullable = 0xC4;
    }

    namespace skinned_multi_mesh {
        inline constexpr uintptr_t Renderers = 0x40;
        inline constexpr uintptr_t RendererList = 0x40;
    }

    namespace chams {
        inline constexpr uintptr_t player_model_multi_mesh = 0x3C8;
        inline constexpr uintptr_t multi_mesh_renderer_list = 0x40;
        inline constexpr uintptr_t renderer_material_array = 0x140;
        inline constexpr uintptr_t renderer_material_count = 0x150;
        inline constexpr uintptr_t material_saved_props = 0x60;
        inline constexpr uintptr_t material_colors_list_off = 0x10;
        inline constexpr uintptr_t list_items = 0x10;
        inline constexpr uintptr_t list_size = 0x18;
        inline constexpr uintptr_t colorprop_stride = 0x18;
        inline constexpr uintptr_t colorprop_value_off = 0x8;
    }

    namespace player_inventory {
        inline constexpr uintptr_t containerMain = 0x30; // UPDATED from new dump: 0x78 -> 0x30
        inline constexpr uintptr_t container_main = 0x30; // UPDATED from new dump: 0x78 -> 0x30
        inline constexpr uintptr_t loot = 0x48;
        inline constexpr uintptr_t containerWear = 0x60; // UPDATED from new dump: 0x58 -> 0x60
        inline constexpr uintptr_t container_wear = 0x60; // UPDATED from new dump: 0x58 -> 0x60
        inline constexpr uintptr_t containerBelt = 0x58; // UPDATED from new dump: 0x38 -> 0x58
        inline constexpr uintptr_t container_belt = 0x58; // UPDATED from new dump: 0x38 -> 0x58
    }

    namespace movement {
        inline constexpr uintptr_t Owner = 0x30;
        inline constexpr uintptr_t InheritedVelocity = 0x38;
        inline constexpr uintptr_t targetMovement = 0x44;
        inline constexpr uintptr_t running = 0x50;
        inline constexpr uintptr_t ducking = 0x54;
        inline constexpr uintptr_t crawling = 0x58;
        inline constexpr uintptr_t Grounded = 0x5C;
        inline constexpr uintptr_t lastTeleportedTime = 0x60;
        inline constexpr uintptr_t adminCheat = 0x20;
    }

    namespace player_walk_movement {
        inline constexpr uintptr_t zeroFrictionMaterial = 0x68;
        inline constexpr uintptr_t highFrictionMaterial = 0x70;

        inline constexpr uintptr_t capsuleHeight = 0x78;
        inline constexpr uintptr_t capsuleCenter = 0x80;
        inline constexpr uintptr_t capsuleHeightDucked = 0x88;
        inline constexpr uintptr_t capsuleCenterDucked = 0x90;
        inline constexpr uintptr_t capsuleHeightCrawling = 0x98;
        inline constexpr uintptr_t capsuleCenterCrawling = 0xA0;

        inline constexpr uintptr_t gravityTestRadius = 0xA8;
        inline constexpr uintptr_t gravityMultiplier = 0xB0;
        inline constexpr uintptr_t gravityMultiplierSwimming = 0xB8;
        inline constexpr uintptr_t maxAngleWalking = 0xC0;
        inline constexpr uintptr_t maxAngleClimbing = 0xC8;
        inline constexpr uintptr_t maxAngleSliding = 0xD0;
        inline constexpr uintptr_t maxStepHeight = 0xD8;

        inline constexpr uintptr_t ladder = 0xE0;
        inline constexpr uintptr_t collisionDetectionMode = 0xE8;
        inline constexpr uintptr_t body = 0xF0;
        inline constexpr uintptr_t capsule = 0xF8;

        inline constexpr uintptr_t maxVelocity = 0x100;
        inline constexpr uintptr_t groundAngle = 0x108;
        inline constexpr uintptr_t groundAngleNew = 0x110;
        inline constexpr uintptr_t groundTime = 0x118;
        inline constexpr uintptr_t jumpTime = 0x120;
        inline constexpr uintptr_t landTime = 0x128;

        inline constexpr uintptr_t previousPosition = 0x130;
        inline constexpr uintptr_t previousVelocity = 0x140;
        inline constexpr uintptr_t previousInheritedVelocity = 0x150;

        inline constexpr uintptr_t velocity = 0x130;
        inline constexpr uintptr_t groundNormal = 0x160;
        inline constexpr uintptr_t groundNormalNew = 0x170;

        inline constexpr uintptr_t groundVelocity = 0x180;
        inline constexpr uintptr_t groundVelocityNew = 0x190;

        inline constexpr uintptr_t nextSprintTime = 0x1A0;
        inline constexpr uintptr_t lastSprintTime = 0x1A8;
        inline constexpr uintptr_t sprintForced = 0x1B0;
        inline constexpr uintptr_t attemptedMountTime = 0x1B8;
        inline constexpr uintptr_t modify = 0x1C0;

        inline constexpr uintptr_t grounded = 0x1C4;
        inline constexpr uintptr_t climbing = 0x1CC;
        inline constexpr uintptr_t sliding = 0x1D4;
        inline constexpr uintptr_t swimming = 0x1DC;
        inline constexpr uintptr_t wasSwimming = 0x1E4;
        inline constexpr uintptr_t jumping = 0x1EC;
        inline constexpr uintptr_t wasJumping = 0x1F4;
        inline constexpr uintptr_t falling = 0x1FC;
        inline constexpr uintptr_t wasFalling = 0x204;
        inline constexpr uintptr_t flying = 0x20C;
        inline constexpr uintptr_t wasFlying = 0x214;
        inline constexpr uintptr_t forcedDuckDelta = 0x21C;
    }

    namespace world_item {
        inline constexpr uintptr_t allowPickup = 0x208; // UPDATED from new dump: 0x200 -> 0x208
        inline constexpr uintptr_t item = 0x210; // UPDATED from new dump: 0x208 -> 0x210
    }

    namespace mapview {
        inline constexpr uintptr_t static_fields_off = 0xB8;
        inline constexpr uintptr_t RVA_RustWorld = 0x10BF80B8;
        inline constexpr uintptr_t World_Size_off = 0x25C;
        inline constexpr uintptr_t World_Seed_off = 0xA0;
        inline constexpr uintptr_t World_Name_off = 0x40;

        inline constexpr uintptr_t RVA_MapInterface = 0x10BD23D0;
        inline constexpr uintptr_t MI_Instance_off = 0x20;
        inline constexpr uintptr_t MI_View_off = 0x60;
        inline constexpr uintptr_t MV_mapImage_off = 0x20;
        inline constexpr uintptr_t MV_scrollRect_off = 0x40;
        inline constexpr uintptr_t RawImage_UVRect = 0xE8;

        inline constexpr uintptr_t SR_ContentBounds = 0x90;
        inline constexpr uintptr_t SR_ViewBounds = 0xA8;
    }

    namespace auto_turret {
        inline constexpr uintptr_t authorizedPlayers = 0x3C0;
        inline constexpr uintptr_t gunFireEffect = 0x3F0;
        inline constexpr uintptr_t bulletEffect = 0x3F8;
        inline constexpr uintptr_t bulletSpeed = 0x400;
        inline constexpr uintptr_t lastYaw = 0x440;
        inline constexpr uintptr_t targetTrigger = 0x480;
        inline constexpr uintptr_t target = 0x4A0;
        inline constexpr uintptr_t muzzlePos = 0x4B0;
        inline constexpr uintptr_t gun_yaw = 0x4C8;
        inline constexpr uintptr_t gun_pitch = 0x4D0;
        inline constexpr uintptr_t sightRange = 0x4D8;
        inline constexpr uintptr_t aimCone = 0x538;
    }

    namespace patrol_helicopter {
        inline constexpr uintptr_t weakspots = 0x2D0;
        inline constexpr uintptr_t rotorPivot = 0x2D8;
        inline constexpr uintptr_t mainRotor = 0x2E0;
        inline constexpr uintptr_t tailRotor = 0x2F8;
        inline constexpr uintptr_t rocket_tube_left = 0x310;
        inline constexpr uintptr_t rocket_tube_right = 0x318;
        inline constexpr uintptr_t left_gun_yaw = 0x320;
        inline constexpr uintptr_t left_gun_pitch = 0x328;
        inline constexpr uintptr_t myAI = 0x3C8;
        inline constexpr uintptr_t spotlightTarget = 0x400;
    }

    namespace bradley_apc {
        inline constexpr uintptr_t engineSound = 0x2D0;
        inline constexpr uintptr_t chasisLurchAngleDelta = 0x318;
        inline constexpr uintptr_t chasisLurchSpeedDelta = 0x31C;
        inline constexpr uintptr_t viewDistance = 0x3C4;
        inline constexpr uintptr_t searchRange = 0x3C8;
    }

    namespace local_player_static {
        inline constexpr uintptr_t local_player = 0x10CB0570;
        inline constexpr uintptr_t static_fields = 0xB8;

        // UPDATED FROM NEW DUMP:
        inline constexpr uintptr_t entity = 0x2F8; // UPDATED from new dump: 0x100 -> 0x2F8

        inline constexpr uintptr_t hv_in_wrapper = 0xB8;
        inline constexpr uintptr_t is_wrapped = 0x1;
    }

    namespace magazine {
        inline constexpr uintptr_t definition = 0x10;
        inline constexpr uintptr_t capacity = 0x18;
        inline constexpr uintptr_t contents = 0x1C;
        inline constexpr uintptr_t ammoType = 0x20;
        inline constexpr uintptr_t allowPlayerReloading = 0x28;
        inline constexpr uintptr_t allowAmmoSwitching = 0x29;
    }

    namespace timed_explosive {
        inline constexpr uintptr_t timerAmountMin = 0x200;
        inline constexpr uintptr_t timerAmountMax = 0x204;
        inline constexpr uintptr_t minExplosionRadius = 0x208;
        inline constexpr uintptr_t explosionRadius = 0x20C;
        inline constexpr uintptr_t explodeOnContact = 0x210;
        inline constexpr uintptr_t canStick = 0x211;
        inline constexpr uintptr_t onlyDamageParent = 0x213;
        inline constexpr uintptr_t explosionEffectOffset = 0x224;
        inline constexpr uintptr_t explosionMatchesNormal = 0x230;
        inline constexpr uintptr_t damageTypes = 0x278;
    }

    namespace base_launcher {
        inline constexpr uintptr_t initialSpeedMultiplier = 0x4C0;
    }

    namespace storage_container {
        inline constexpr uintptr_t inventorySlots = 0x320;
        inline constexpr uintptr_t isLootable = 0x32D;
        inline constexpr uintptr_t isLockable = 0x32E;
        inline constexpr uintptr_t isMonitorable = 0x32F;
        inline constexpr uintptr_t panelName = 0x330;
        inline constexpr uintptr_t panelTitle = 0x338;
        inline constexpr uintptr_t dropsLoot = 0x324;
        inline constexpr uintptr_t dropLootDestroyPercent = 0x328;
        inline constexpr uintptr_t allowedContents = 0x340;
        inline constexpr uintptr_t allowedItem = 0x348;
        inline constexpr uintptr_t maxStackSize = 0x368;
        inline constexpr uintptr_t needsBuildingPrivilegeToUse = 0x36C;
        inline constexpr uintptr_t onlyAcceptCategory = 0x398;
        inline constexpr uintptr_t onlyOneUser = 0x39C;
        inline constexpr uintptr_t dropPosition = 0x380;
        inline constexpr uintptr_t dropVelocity = 0x38C;
    }

    namespace loot_container {
        inline constexpr uintptr_t destroyOnEmpty = 0x3A8;
        inline constexpr uintptr_t lootDefinition = 0x3B0;
        inline constexpr uintptr_t maxDefinitionsToSpawn = 0x3B8;
        inline constexpr uintptr_t minSecondsBetweenRefresh = 0x3BC;
        inline constexpr uintptr_t maxSecondsBetweenRefresh = 0x3C0;
        inline constexpr uintptr_t initialLootSpawn = 0x3C4;
        inline constexpr uintptr_t xpLootedScale = 0x3C8;
        inline constexpr uintptr_t scrapAmount = 0x3D4;
        inline constexpr uintptr_t LootSpawnSlots = 0x3E0;
        inline constexpr uintptr_t SpawnType = 0x3E8;
        inline constexpr uintptr_t clanScoreEventForFirstLooter = 0x3EC;
    }

    namespace ore_resource_entity {
        inline constexpr uintptr_t bonusPrefab = 0x248;
        inline constexpr uintptr_t finishEffect = 0x250;
        inline constexpr uintptr_t bonusFailEffect = 0x258;
        inline constexpr uintptr_t useHotspotMinigame = 0x260;
        inline constexpr uintptr_t bonusSound = 0x268;
        inline constexpr uintptr_t heightOffset = 0x270;
    }

    namespace resource_entity {
        inline constexpr uintptr_t startHealth = 0x200;
        inline constexpr uintptr_t baseProtection = 0x208;
        inline constexpr uintptr_t skipDecorComponents = 0x214;
    }

    namespace collectible_entity {
        inline constexpr uintptr_t itemName = 0x200;
        inline constexpr uintptr_t itemList = 0x208;
        inline constexpr uintptr_t pickupEffect = 0x210;
        inline constexpr uintptr_t xpScale = 0x218;
        inline constexpr uintptr_t suppressGatherRateMultiplier = 0x21C;
    }

    namespace growable_entity {
        inline constexpr uintptr_t plantSkin = 0x338;
        inline constexpr uintptr_t properties = 0x348;
        inline constexpr uintptr_t sourceItemDef = 0x350;
        inline constexpr uintptr_t state = 0x358;

        inline constexpr uintptr_t Properties = 0x348;
        inline constexpr uintptr_t SourceItemDef = 0x350;
    }

    namespace player_corpse {
        inline constexpr uintptr_t playerName = 0x328;
        inline constexpr uintptr_t playerSteamID = 0x318;

        // Existing alias retained
        inline constexpr uintptr_t containers = 0x350;

        // New dump name
        inline constexpr uintptr_t clientClothing = 0x350;

        inline constexpr uintptr_t underwearSkin = 0x350; // UPDATED from new dump: 0x340 -> 0x350
    }

    namespace lootable_corpse {
        inline constexpr uintptr_t playerSteamID = 0x318;
        inline constexpr uintptr_t playerName = 0x328;
        inline constexpr uintptr_t lootPanelName = 0x320; // UPDATED from new dump: 0x310 -> 0x320

        inline constexpr uintptr_t _playerName = 0x328;
    }

    namespace hackable_locked_crate {
        inline constexpr uintptr_t timerText = 0x400;
        inline constexpr uintptr_t hackSeconds = 0x410;
    }

    namespace held_entity {
        inline constexpr uintptr_t punchAdded = 0x208;
        inline constexpr uintptr_t worldModelAnimation = 0x218;
        inline constexpr uintptr_t viewModel = 0x2E0; // UPDATED from new dump: 0x250 -> 0x2E0
        inline constexpr uintptr_t viewModel_inner = 0x28;
        inline constexpr uintptr_t viewModel_wrapper_kind = 0x4;
        inline constexpr uintptr_t handBone = 0x260;
        inline constexpr uintptr_t holdInfo = 0x270;
        inline constexpr uintptr_t isBuildingTool = 0x28C;
        inline constexpr uintptr_t forcedOwner = 0x290;
        inline constexpr uintptr_t hostileScore = 0x2AC;
        inline constexpr uintptr_t _punches = 0x2D8;
        inline constexpr uintptr_t ownerItemUID = 0x2E0;
        inline constexpr uintptr_t itemOwner = 0x240;
    }

    namespace item_icon {
        inline constexpr uintptr_t item_icon_c = 0x10C1A9D0;
        inline constexpr uintptr_t type_info = 0x10C1A9D0;
        inline constexpr uintptr_t static_fields = 0xB8;
        inline constexpr uintptr_t iconImage = 0xA8;
        inline constexpr uintptr_t backgroundImage = 0xE8;
        inline constexpr uintptr_t containerLootStartTimes = 0x28;
    }

    namespace dictionary_entry_array {
        inline constexpr uintptr_t length = 0x18;
        inline constexpr uintptr_t data = 0x20;

        inline constexpr uintptr_t hashCode = 0x0;
        inline constexpr uintptr_t key = 0x8;
        inline constexpr uintptr_t value = 0x10;
        inline constexpr uintptr_t stride = 0x18;
    }

    namespace dictionary {
        inline constexpr uintptr_t entries = 0x18;
        inline constexpr uintptr_t count = 0x20;
    }

    namespace view_model {
        inline constexpr uintptr_t instance = 0x28;
        inline constexpr uintptr_t viewmodel_instance = 0x28;
    }

    namespace base_view_model {
        inline constexpr uintptr_t useViewModelCamera = 0x40;
        inline constexpr uintptr_t skinPieces = 0x78;
        inline constexpr uintptr_t animator = 0x98; // UPDATED from new dump: 0xD0 -> 0x98
        inline constexpr uintptr_t aspectOffset = 0xD0; // UPDATED from new dump: 0x100 -> 0xD0
        inline constexpr uintptr_t bob = 0xF0; // UPDATED from new dump: 0xB8 -> 0xF0
        inline constexpr uintptr_t lower = 0x88; // UPDATED from new dump: 0xA0 -> 0x88
        inline constexpr uintptr_t punch = 0xC8; // UPDATED from new dump: 0x98 -> 0xC8
        inline constexpr uintptr_t sway = 0xE0; // UPDATED from new dump: 0xC8 -> 0xE0

        inline constexpr uintptr_t model = 0x90;
        inline constexpr uintptr_t ironSights = 0x108;
    }

    namespace model {
        inline constexpr uintptr_t collision = 0x20;
        inline constexpr uintptr_t rootBone = 0x28;
        inline constexpr uintptr_t headBone = 0x30;
        inline constexpr uintptr_t eyeBone = 0x38;
        inline constexpr uintptr_t animator = 0x40;
        inline constexpr uintptr_t skeleton = 0x48;
        inline constexpr uintptr_t boneTransforms = 0x50;
        inline constexpr uintptr_t bone_transform = 0x50;
        inline constexpr uintptr_t boneNames = 0x58;
        inline constexpr uintptr_t position = 0x60; // build 2636: HYPOTHESIS - 16-byte slot after boneNames (Vector3+pad), obfuscator hid the type; verify live
        inline constexpr uintptr_t rotation = 0x70; // build 2636: HYPOTHESIS - next 16-byte slot (Quaternion)
        inline constexpr uintptr_t bone_array_count_off = 0x18;
        inline constexpr uintptr_t bone_array_data_off = 0x20;
        inline constexpr uintptr_t bone_array_elem_size = 0x8;

        inline constexpr uintptr_t pelvis = 0x00;
        inline constexpr uintptr_t l_hip = 0x01;
        inline constexpr uintptr_t l_knee = 0x03;
        inline constexpr uintptr_t l_foot = 0x04;
        inline constexpr uintptr_t r_hip = 0x0E;
        inline constexpr uintptr_t r_knee = 0x10;
        inline constexpr uintptr_t r_foot = 0x11;
        inline constexpr uintptr_t spine2 = 0x15;
        inline constexpr uintptr_t spine4 = 0x17;
        inline constexpr uintptr_t l_clav = 0x18;
        inline constexpr uintptr_t l_upperarm = 0x19;
        inline constexpr uintptr_t l_forearm = 0x1A;
        inline constexpr uintptr_t l_hand = 0x1D;
        inline constexpr uintptr_t neck = 0x34;
        inline constexpr uintptr_t head = 0x35;
        inline constexpr uintptr_t r_clav = 0x3C;
        inline constexpr uintptr_t r_upperarm = 0x3D;
        inline constexpr uintptr_t r_forearm = 0x3E;
        inline constexpr uintptr_t r_hand = 0x41;
        inline constexpr uintptr_t neck_bone_idx = 0x34;
        inline constexpr uintptr_t head_bone_idx = 0x35;
    }

    namespace bone_transform {
        inline constexpr uintptr_t transform_ptr = 0x10;
        inline constexpr uintptr_t transform_data = 0x28;
        inline constexpr uintptr_t transform_index = 0x30;
        inline constexpr uintptr_t index_base = 0x20;
        inline constexpr uintptr_t matrix_base = 0x18;
    }

    namespace tod_sky_static {
        inline constexpr uintptr_t tod_sky_c = 0x10BACC40;
        inline constexpr uintptr_t nested_static_rva = 0x10BACC40;
        inline constexpr uintptr_t static_fields = 0xB8;
        inline constexpr uintptr_t instances = 0x68; // UPDATED from new dump: 0x50 -> 0x68
        inline constexpr uintptr_t instance_field = 0x98;
        inline constexpr uintptr_t listItems = 0x10;
        inline constexpr uintptr_t listSize = 0x18;
        inline constexpr uintptr_t arrayData = 0x20;
    }

    namespace tod_sky {
        inline constexpr uintptr_t Cycle = 0x40;
        inline constexpr uintptr_t Atmosphere = 0x50;
        inline constexpr uintptr_t Day = 0x58;
        inline constexpr uintptr_t Night = 0x60;
        inline constexpr uintptr_t Stars = 0x78;
        inline constexpr uintptr_t Clouds = 0x80;
        inline constexpr uintptr_t Ambient = 0x98;
        inline constexpr uintptr_t timeSinceAmbientUpdate = 0x23C;
        inline constexpr uintptr_t timeSinceReflectionUpdate = 0x240;
        inline constexpr uintptr_t Fog = 0x90; // NEW from new dump
        inline constexpr uintptr_t Light = 0x88; // NEW from new dump
        inline constexpr uintptr_t Moon = 0x70; // NEW from new dump
        inline constexpr uintptr_t Sun = 0x68; // NEW from new dump
    }

    namespace tod_cycle_parameters {
        inline constexpr uintptr_t Hour = 0x10;
        inline constexpr uintptr_t Day = 0x14;
        inline constexpr uintptr_t Month = 0x18;
        inline constexpr uintptr_t Year = 0x1C;
    }

    namespace tod_ambient_parameters {
        inline constexpr uintptr_t Saturation = 0x14;
        inline constexpr uintptr_t Mode = 0x10; // NEW from new dump
        inline constexpr uintptr_t UpdateInterval = 0x18; // NEW from new dump
    }

    namespace tod_night_parameters {
        inline constexpr uintptr_t AmbientMultiplier = 0x5C;
        inline constexpr uintptr_t AmbientColor = 0x48; // NEW from new dump
        inline constexpr uintptr_t CloudColor = 0x38; // NEW from new dump
        inline constexpr uintptr_t FogColor = 0x40; // NEW from new dump
        inline constexpr uintptr_t LightColor = 0x20; // NEW from new dump
        inline constexpr uintptr_t LightIntensity = 0x50; // NEW from new dump
        inline constexpr uintptr_t MoonColor = 0x10; // NEW from new dump
        inline constexpr uintptr_t MoonColorRed = 0x18; // NEW from new dump
        inline constexpr uintptr_t RayColor = 0x28; // NEW from new dump
        inline constexpr uintptr_t ReflectionMaxClamp = 0x6C; // NEW from new dump
        inline constexpr uintptr_t ReflectionMultiplier = 0x64; // NEW from new dump
        inline constexpr uintptr_t ShadowStrength = 0x58; // NEW from new dump
        inline constexpr uintptr_t SkyColor = 0x30; // NEW from new dump
        inline constexpr uintptr_t runtimeAmbientMultiplier = 0x60; // NEW from new dump
        inline constexpr uintptr_t runtimeLightIntensity = 0x54; // NEW from new dump
        inline constexpr uintptr_t runtimeReflectionMultiplier = 0x68; // NEW from new dump
    }

    namespace tod_stars {
        inline constexpr uintptr_t Size = 0x10;
        inline constexpr uintptr_t Brightness = 0x14;
    }

    namespace object {
        inline constexpr uintptr_t m_CachedPtr = 0x10;
    }

    namespace unity_component {
        inline constexpr uintptr_t native = 0x10;
        inline constexpr uintptr_t game_object = 0x20;
        inline constexpr uintptr_t GetGameObject = 0xBEA00; // NEW from new dump
    }

    namespace unity_game_object {
        inline constexpr uintptr_t components = 0x20;
        inline constexpr uintptr_t obj_transform = 0x8;
        inline constexpr uintptr_t component_count = 0x30;
        inline constexpr uintptr_t component_stride = 0x10;
        inline constexpr uintptr_t component_ptr_in_entry = 0x8;
        inline constexpr uintptr_t component_handle_in_native = 0x18;
        inline constexpr uintptr_t tag = 0x54;
        inline constexpr uintptr_t m_IsActive = 0x46; // NEW from new dump
    }

    namespace unity_transform {
        inline constexpr uintptr_t indirect_ptr_off = 0x28;
        inline constexpr uintptr_t world_pos_off = 0x90;
    }

    namespace unity_transform_native {
        inline constexpr uintptr_t access_struct_off = 0x28;
    }

    namespace transform_data {
        inline constexpr uintptr_t pos_base_off = 0x18;
        inline constexpr uintptr_t indices_b_off = 0x20;
        inline constexpr uintptr_t root_pos_off = 0x90;
        inline constexpr uintptr_t root_quat_off = 0xA0;
        inline constexpr uintptr_t matrix_stride = 0x30;
        inline constexpr uintptr_t slot_pos_off = 0x00;
        inline constexpr uintptr_t slot_quat_off = 0x10;
        inline constexpr uintptr_t slot_scale_off = 0x20;
        inline constexpr uintptr_t walker_max_depth = 0x10;
        inline constexpr uintptr_t slot_pad_off = 0xC;
        inline constexpr uintptr_t slot_pos_quat_size = 0x20;
    }

    namespace unity_string {
        inline constexpr uintptr_t m_stringLength = 0x10;
        inline constexpr uintptr_t first_char = 0x14;
    }

    namespace system_list {
        inline constexpr uintptr_t array = 0x10;
        inline constexpr uintptr_t size = 0x18;
        inline constexpr uintptr_t array_first_element = 0x20;
        inline constexpr uintptr_t element_size = 0x8;
    }

    namespace entitylist {
        inline constexpr uintptr_t array = 0x10;
        inline constexpr uintptr_t size = 0x18;
        inline constexpr uintptr_t first_elem = 0x20;
    }

    namespace convar_graphics {
        inline constexpr uintptr_t convar_graphics = 0x10BF2568;
        inline constexpr uintptr_t convar_graphics_instance = 0xB8;
        inline constexpr uintptr_t _fov = 0x370;
    }

    namespace convar_admin {
        inline constexpr uintptr_t convar_admin = 0x10C336A0;
        inline constexpr uintptr_t playerIds = 0x20;
    }

    namespace progress_bar {
        inline constexpr uintptr_t type_info = 0x10BE53E8;
        inline constexpr uintptr_t instance = 0x18; // UPDATED from new dump: 0x8 -> 0x18
        inline constexpr uintptr_t timeFinished = 0x28; // UPDATED from new dump: 0x20 -> 0x28
        inline constexpr uintptr_t timeCounter = 0x2C; // UPDATED from new dump: 0x24 -> 0x2C
        inline constexpr uintptr_t leftField = 0x48; // UPDATED from new dump: 0x40 -> 0x48
    }

    namespace door {
        inline constexpr uintptr_t knockEffect = 0x358;
        inline constexpr uintptr_t canTakeLock = 0x360;
        inline constexpr uintptr_t hasHatch = 0x361;
        inline constexpr uintptr_t canTakeCloser = 0x362;
        inline constexpr uintptr_t canTakeKnocker = 0x363;
        inline constexpr uintptr_t canNpcOpen = 0x364;
        inline constexpr uintptr_t canHandOpen = 0x365;
        inline constexpr uintptr_t isSecurityDoor = 0x366;
        inline constexpr uintptr_t canReverseOpen = 0x367;
    }

    namespace code_lock {
        inline constexpr uintptr_t keyCodeEntry = 0x238;
        inline constexpr uintptr_t hasCode = 0x270;
    }

    namespace building_block {
        inline constexpr uintptr_t apartmentList = 0x20;
        inline constexpr uintptr_t grade = 0x350;
        inline constexpr uintptr_t gradeSecondary = 0x354;
        inline constexpr uintptr_t cachedMesh = 0x360;
        inline constexpr uintptr_t construction = 0x368;
        inline constexpr uintptr_t skin = 0x3B8;
    }

    namespace player_metabolism {
        inline constexpr uintptr_t component = 0x710;
        inline constexpr uintptr_t calories = 0x20;
        inline constexpr uintptr_t hydration = 0x28;
        inline constexpr uintptr_t heartrate = 0x30;
        inline constexpr uintptr_t poison = 0x50;
        inline constexpr uintptr_t radiationLevel = 0x58;
        inline constexpr uintptr_t radiationPoison = 0x60;
        inline constexpr uintptr_t oxygen = 0x78;
        inline constexpr uintptr_t bleeding = 0x80;
    }

    namespace sprite {
        inline constexpr uintptr_t m_RD = 0x20;
    }

    namespace texture2d {
        inline constexpr uintptr_t width = 0x10;
        inline constexpr uintptr_t height = 0x14;
        inline constexpr uintptr_t image_data = 0x18;
    }

    namespace metabolism_attr {
        inline constexpr uintptr_t min = 0x18;
        inline constexpr uintptr_t max = 0x1C;
        inline constexpr uintptr_t value = 0x20;
    }

    namespace BasePlayer_Offsets
    {
        inline constexpr uintptr_t playerTeam = 0x558;
    }

    namespace PlayerTeam_Offsets
    {
        inline constexpr uintptr_t TeamMembers = 0x50;
    }

    namespace sprite_render_data {
        inline constexpr uintptr_t texture = 0x00;
        inline constexpr uintptr_t second_texture = 0x08;
    }

    namespace player_team {
        inline constexpr uintptr_t memberList = 0x50;
        inline constexpr uintptr_t classSize = 0x58;
        inline constexpr uintptr_t member_steam_id = 0x38;
        inline constexpr uintptr_t member_stride = 0x8;
    }

    namespace skeleton_properties {
        inline constexpr uintptr_t bones = 0x20;
    }

    namespace input_state {
        inline constexpr uintptr_t current = 0x18;
        inline constexpr uintptr_t previous = 0x20;
    }

    namespace input_message {
        inline constexpr uintptr_t mouseDelta = 0x24;
        inline constexpr uintptr_t buttons = 0x1C; // UPDATED from new dump: 0x14 -> 0x1C
        inline constexpr uintptr_t aimAngles = 0x10; // UPDATED from new dump: 0x18 -> 0x10
    }

    namespace interpolator {
        inline constexpr uintptr_t last = 0x10;
        inline constexpr uintptr_t list = 0x30;
    }

    namespace position_lerp {
        inline constexpr uintptr_t interpolator = 0x48; // UPDATED from new dump: 0x40 -> 0x48
    }

    namespace npc_player {
        inline constexpr uintptr_t MovementTickStartDelay = 0x7F8; // UPDATED from new dump: 0x7E8 -> 0x7F8
        inline constexpr uintptr_t finalDestination = 0x808; // UPDATED from new dump: 0x7F8 -> 0x808
        inline constexpr uintptr_t LegacyNavigation = 0x834; // UPDATED from new dump: 0x824 -> 0x834
        inline constexpr uintptr_t damageScale = 0x840; // UPDATED from new dump: 0x830 -> 0x840
        inline constexpr uintptr_t shortRange = 0x844; // UPDATED from new dump: 0x834 -> 0x844
        inline constexpr uintptr_t attackLengthMaxShortRangeScale = 0x848; // UPDATED from new dump: 0x838 -> 0x848
    }

    namespace human_npc {
        inline constexpr uintptr_t AdditionalLosBlockingLayer = 0x858; // UPDATED from new dump: 0x848 -> 0x858
        inline constexpr uintptr_t aimConeScale = 0x868; // UPDATED from new dump: 0x858 -> 0x868
        inline constexpr uintptr_t lastDismountTime = 0x86C; // UPDATED from new dump: 0x85C -> 0x86C
    }

    namespace scientist_npc {
        inline constexpr uintptr_t deathStatName = 0x888; // UPDATED from new dump: 0x878 -> 0x888
        inline constexpr uintptr_t IdleChatterRepeatRange = 0x890; // UPDATED from new dump: 0x880 -> 0x890
        inline constexpr uintptr_t radioChatterType = 0x898; // UPDATED from new dump: 0x888 -> 0x898
    }

    namespace trigger_ladder {
        inline constexpr uintptr_t Type = 0x50;
        inline constexpr uintptr_t ForceLookAt = 0x54;
        inline constexpr uintptr_t RequireJumpToMount = 0x55;
    }

    namespace trigger_movement {
        inline constexpr uintptr_t losEyes = 0x50;
        inline constexpr uintptr_t movementModify = 0x58;
        inline constexpr uintptr_t scale = 0x5C;
    }

    namespace ui_text {
        inline constexpr uintptr_t m_Text = 0xE8;
    }

    namespace viewmodel_bob {
        inline constexpr uintptr_t bobSpeedWalk = 0x20;
        inline constexpr uintptr_t bobSpeedRun = 0x24;
        inline constexpr uintptr_t bobAmountWalk = 0x28;
        inline constexpr uintptr_t bobAmountRun = 0x2C;
        inline constexpr uintptr_t leftOffsetRun = 0x30;
    }

    namespace viewmodel_lower {
        inline constexpr uintptr_t lowerOnSprint = 0x20;
        inline constexpr uintptr_t forceLower = 0x22;
        inline constexpr uintptr_t lowerWhenCantAttack = 0x21;
        inline constexpr uintptr_t lowerScale = 0x24;
        inline constexpr uintptr_t shouldLower = 0x28;
    }

    namespace viewmodel_punch {
        inline constexpr uintptr_t punchDuration = 0x34;
        inline constexpr uintptr_t punchMagnitude = 0x38;
        inline constexpr uintptr_t punchStartTime = 0x3C;
    }

    namespace viewmodel_sway {
        inline constexpr uintptr_t positionalSwaySpeed = 0x20;
        inline constexpr uintptr_t positionalSwayAmount = 0x24;
        inline constexpr uintptr_t rotationSwaySpeed = 0x28;
        inline constexpr uintptr_t rotationSwayAmount = 0x2C;
        inline constexpr uintptr_t rotateAmountTest = 0x30;
    }

    namespace projectile_weapon_mod {
        inline constexpr uintptr_t ConditionLossMultiplier = 0x200;
        inline constexpr uintptr_t additiveEffect = 0x208;
        inline constexpr uintptr_t defaultSilencerEffect = 0x210;
        inline constexpr uintptr_t isSilencer = 0x220; // UPDATED from new dump: 0x218 -> 0x220
        inline constexpr uintptr_t silencerType = 0x224; // UPDATED from new dump: 0x21C -> 0x224
        inline constexpr uintptr_t repeatDelay = 0x220;
        inline constexpr uintptr_t projectileVelocity = 0x234; // UPDATED from new dump: 0x22C -> 0x234
        inline constexpr uintptr_t projectileDamage = 0x238;
        inline constexpr uintptr_t projectileDistance = 0x244;
        inline constexpr uintptr_t aimsway = 0x250;
        inline constexpr uintptr_t aimswaySpeed = 0x25C;
        inline constexpr uintptr_t recoil = 0x268;
        inline constexpr uintptr_t sightAimCone = 0x274;
        inline constexpr uintptr_t hipAimCone = 0x280;
        inline constexpr uintptr_t isLight = 0x28C;
        inline constexpr uintptr_t isMuzzleBrake = 0x28D;
        inline constexpr uintptr_t isMuzzleBoost = 0x28E;
        inline constexpr uintptr_t isScope = 0x28F;
        inline constexpr uintptr_t zoomAmountDisplayOnly = 0x290;
        inline constexpr uintptr_t magazineCapacity = 0x294;
        inline constexpr uintptr_t needsOnForEffects = 0x2A0;
        inline constexpr uintptr_t burstCount = 0x2A4;
        inline constexpr uintptr_t timeBetweenBursts = 0x2A8;
        inline constexpr uintptr_t zoomLevels = 0x2B0;
        inline constexpr uintptr_t fovChangeEffect = 0x2B8;
        inline constexpr uintptr_t allowPings = 0x2C0;
    }

    namespace server_projectile {
        inline constexpr uintptr_t drag = 0x34;
        inline constexpr uintptr_t gravityModifier = 0x38;
        inline constexpr uintptr_t speed = 0x3C;
        inline constexpr uintptr_t radius = 0x5C;
    }

    namespace player_projectile_update {
        inline constexpr uintptr_t Dispose = 0xC1CA0B0;
        inline constexpr uintptr_t _disposed = 0x24;
        inline constexpr uintptr_t ShouldPool = 0x14;
    }

    namespace player_projectile_attack {
        inline constexpr uintptr_t hitDistance = 0x24;
        inline constexpr uintptr_t hitVelocity = 0x18;
        inline constexpr uintptr_t travelTime = 0x2C;
    }

    namespace player_attack {
        inline constexpr uintptr_t projectileID = 0x14;
    }

    namespace network {
        inline constexpr uintptr_t CLIENT_CONNECTION = 0x108;
        inline constexpr uintptr_t CLIENT_CONNECTED_ADDRESS = 0xE0;
        inline constexpr uintptr_t CLIENT_CONNECTED_PORT = 0xF4;
        inline constexpr uintptr_t CLIENT_CONNECTION_WRAPPER = 0x110;
        inline constexpr uintptr_t RAKNET_HANDLE_IN_WRAPPER = 0x10;
        inline constexpr uintptr_t CONNECTION_SERVER_GUID = 0xA8;
    }

    namespace console_system {
        inline constexpr uintptr_t find = 0x3E6D7B0;
        inline constexpr uintptr_t get_override = 0x50;
        inline constexpr uintptr_t set_override = 0x10;
        inline constexpr uintptr_t call = 0x80;
    }

    namespace singleton_typeinfos {
        inline constexpr uintptr_t SingletonComponent_UI_LoadingScreen = 0x10CB2D70;
        inline constexpr uintptr_t SingletonComponent_MixerSnapshotManager = 0x10C5DA00;
    }

    namespace magazine_new {
        inline constexpr uintptr_t capacity = 0x18;
        inline constexpr uintptr_t contents = 0x1C;
        inline constexpr uintptr_t ammoType = 0x20;
        inline constexpr uintptr_t definition = 0x10;
        inline constexpr uintptr_t allowAmmoSwitching = 0x29; // NEW from new dump
        inline constexpr uintptr_t allowPlayerReloading = 0x28; // NEW from new dump
    }

    namespace storage_container_new {
        inline constexpr uintptr_t inventorySlots = 0x320;
        inline constexpr uintptr_t panelName = 0x330;
        inline constexpr uintptr_t panelTitle = 0x338;
        inline constexpr uintptr_t isLootable = 0x32D;
        inline constexpr uintptr_t isLockable = 0x32E;
        inline constexpr uintptr_t isMonitorable = 0x32F;
        inline constexpr uintptr_t dropsLoot = 0x324;
        inline constexpr uintptr_t dropLootDestroyPercent = 0x328;
        inline constexpr uintptr_t allowedContents = 0x340;
        inline constexpr uintptr_t allowedItem = 0x348;
        inline constexpr uintptr_t maxStackSize = 0x368;
        inline constexpr uintptr_t needsBuildingPrivilegeToUse = 0x36C;
        inline constexpr uintptr_t onlyAcceptCategory = 0x398;
        inline constexpr uintptr_t onlyOneUser = 0x39C;
        inline constexpr uintptr_t dropPosition = 0x380;
        inline constexpr uintptr_t dropVelocity = 0x38C;
    }

    namespace timed_explosive_new {
        inline constexpr uintptr_t timerAmountMin = 0x200;
        inline constexpr uintptr_t timerAmountMax = 0x204;
        inline constexpr uintptr_t minExplosionRadius = 0x208;
        inline constexpr uintptr_t explosionRadius = 0x20C;
        inline constexpr uintptr_t explodeOnContact = 0x210;
        inline constexpr uintptr_t canStick = 0x211;
        inline constexpr uintptr_t onlyDamageParent = 0x213;
        inline constexpr uintptr_t damageTypes = 0x278;
        inline constexpr uintptr_t explosionEffectOffset = 0x224;
        inline constexpr uintptr_t explosionMatchesNormal = 0x230;
    }

    namespace base_launcher_new {
        inline constexpr uintptr_t initialSpeedMultiplier = 0x4C0;
    }

    namespace base_player_new {
        inline constexpr uintptr_t clActiveItem = 0x590; // UPDATED from new dump: 0x588 -> 0x590
        inline constexpr uintptr_t PlayerEyes = 0x4A0; // UPDATED from new dump: 0x3F0 -> 0x4A0
        inline constexpr uintptr_t PlayerInventory = 0x4A8; // UPDATED from new dump: 0x5A8 -> 0x4A8
        inline constexpr uintptr_t current_team = 0x558;
        inline constexpr uintptr_t movement = 0x548; // UPDATED from new dump: 0x5A0 -> 0x548
        inline constexpr uintptr_t player_model = 0x710; // UPDATED from new dump: 0x4F8 -> 0x710
        inline constexpr uintptr_t playerFlags = 0x6E0; // UPDATED from new dump: 0x6D8 -> 0x6E0
        inline constexpr uintptr_t userID = 0x560;
        inline constexpr uintptr_t display_name = 0x7F0; // UPDATED from new dump: 0x4C8 -> 0x7F0
        inline constexpr uintptr_t player_input = 0x620; // UPDATED from new dump: 0x6E8 -> 0x620
        inline constexpr uintptr_t modelState = 0x340; // UPDATED from new dump: 0x3A0 -> 0x340
        inline constexpr uintptr_t mounted = 0x5E8; // UPDATED from new dump: 0x5E0 -> 0x5E8
        inline constexpr uintptr_t Belt = 0x520;
        inline constexpr uintptr_t _lookingAt = 0x7B8; // UPDATED from new dump: 0x740 -> 0x7B8
        inline constexpr uintptr_t weaponMoveSpeedScale = 0x7C8; // UPDATED from new dump: 0x7B8 -> 0x7C8
        inline constexpr uintptr_t clothingBlocksAiming = 0x7BC;
        inline constexpr uintptr_t clothingMoveSpeedReduction = 0x7D0; // UPDATED from new dump: 0x7C0 -> 0x7D0
        inline constexpr uintptr_t player_rigidbody = 0x6F0;
        inline constexpr uintptr_t frozen = 0x398;
        inline constexpr uintptr_t currentGesture = 0x318;
        inline constexpr uintptr_t lastSentTick = 0x638; // UPDATED from new dump: 0x3E8 -> 0x638
        inline constexpr uintptr_t metabolism = 0x4C0;
        inline constexpr uintptr_t blueprints = 0x7A8;
        inline constexpr uintptr_t OnViewModeChanged = 0x33E3140; // NEW from new dump
        inline constexpr uintptr_t clothingWaterSpeedBonus = 0x7D4; // NEW from new dump
        inline constexpr uintptr_t eyes = 0x4A0; // NEW from new dump
        inline constexpr uintptr_t input = 0x620; // NEW from new dump
        inline constexpr uintptr_t inventory = 0x4A8; // NEW from new dump
        inline constexpr uintptr_t lastSentTickTime = 0x6A0; // NEW from new dump
        inline constexpr uintptr_t modifiers = 0x5D0; // NEW from new dump
    }

    namespace base_mountable {
        inline constexpr uintptr_t pitchClamp = 0x2FC;
        inline constexpr uintptr_t yawClamp = 0x304;
        inline constexpr uintptr_t canWieldItems = 0x30C;
    }

    namespace player_team_offsets {
        inline constexpr uintptr_t TeamMembers = 0x50;
    }

    namespace attack_entity_new {
        inline constexpr uintptr_t repeatDelay = 0x2F4; // UPDATED from new dump: 0x2EC -> 0x2F4
        inline constexpr uintptr_t nextAttackTime = 0x348; // UPDATED from new dump: 0x340 -> 0x348
        inline constexpr uintptr_t animationDelay = 0x2F8; // NEW from new dump
        inline constexpr uintptr_t deployDelay = 0x2F0; // NEW from new dump
        inline constexpr uintptr_t effectiveRange = 0x2FC; // NEW from new dump
        inline constexpr uintptr_t lastTickTime = 0x350; // NEW from new dump
        inline constexpr uintptr_t nextTickTime = 0x358; // NEW from new dump
        inline constexpr uintptr_t noHeadshots = 0x346; // NEW from new dump
        inline constexpr uintptr_t timeSinceDeploy = 0x360; // NEW from new dump
    }

    namespace modelstate_new {
        inline constexpr uintptr_t flags = 0x60; // UPDATED from new dump: 0x24 -> 0x60
        inline constexpr uintptr_t waterLevel = 0x40; // UPDATED from new dump: 0x38 -> 0x40
        inline constexpr uintptr_t lookDir = 0x18; // UPDATED from new dump: 0x2C -> 0x18
    }

    namespace base_entity_new {
        inline constexpr uintptr_t bounds = 0x1A4; // build 2636 dump
        inline constexpr uintptr_t model = 0x1D0; // build 2636 dump
        inline constexpr uintptr_t flags = 0x1D8; // build 2636 dump
        inline constexpr uintptr_t triggers = 0x160;
        inline constexpr uintptr_t position = 0x168;
        inline constexpr uintptr_t positionLerp = 0x138; // UPDATED from new dump: 0xA0 -> 0x138
        inline constexpr uintptr_t SendSignalBroadcast = 0x71703E0; // NEW from new dump
        inline constexpr uintptr_t ServerRPC = 0x72059E0; // NEW from new dump
    }

    namespace base_combat_entity_new {
        inline constexpr uintptr_t skeletonProperties = 0x238; // UPDATED from new dump: 0x230 -> 0x238
        inline constexpr uintptr_t baseProtection = 0x240; // UPDATED from new dump: 0x238 -> 0x240
        inline constexpr uintptr_t lifestate = 0x2C0; // build 2636: confirmed statically (BaseCombatEntity.lifestate)
        inline constexpr uintptr_t markAttackerHostile = 0x2C6; // build 2636: lifestate+6
        inline constexpr uintptr_t model = 0x1D0; // build 2636 dump
        inline constexpr uintptr_t _health = 0x2BC; // UPDATED from new dump: 0x2B4 -> 0x2BC
        inline constexpr uintptr_t _maxHealth = 0x2C0; // UPDATED from new dump: 0x2B8 -> 0x2C0
        inline constexpr uintptr_t startHealth = 0x248; // NEW from new dump
    }

    namespace base_view_model_new {
        inline constexpr uintptr_t useViewModelCamera = 0x40;
        inline constexpr uintptr_t model = 0x90;
        inline constexpr uintptr_t bob = 0xF0; // UPDATED from new dump: 0xB8 -> 0xF0
        inline constexpr uintptr_t lower = 0x88; // UPDATED from new dump: 0xA0 -> 0x88
        inline constexpr uintptr_t sway = 0xE0; // UPDATED from new dump: 0xC8 -> 0xE0
        inline constexpr uintptr_t ironSights = 0x108;
        inline constexpr uintptr_t animator = 0x98; // NEW from new dump
        inline constexpr uintptr_t aspectOffset = 0xD0; // NEW from new dump
        inline constexpr uintptr_t punch = 0xC8; // NEW from new dump
    }

    namespace player_model_new {
        inline constexpr uintptr_t _multiMesh = 0x520; // UPDATED from new dump: 0x3C8 -> 0x520
        inline constexpr uintptr_t collision = 0xD0;
        inline constexpr uintptr_t fullMask = 0x208;
        inline constexpr uintptr_t position = 0x2F8;
        inline constexpr uintptr_t newVelocity = 0x31C;
        inline constexpr uintptr_t visibleNullable = 0xC4;
    }

    namespace player_input_new {
        inline constexpr uintptr_t state = 0x28;
        inline constexpr uintptr_t bodyAngles = 0x44;
        inline constexpr uintptr_t yaw = 0x60;
    }

    namespace player_eyes_new {
        inline constexpr uintptr_t viewOffset = 0x40;
        inline constexpr uintptr_t bodyRotation = 0x50;
        inline constexpr uintptr_t headAngles = 0x60;
    }

    namespace held_entity_new {
        inline constexpr uintptr_t viewModel = 0x2E0; // UPDATED from new dump: 0x250 -> 0x2E0
        inline constexpr uintptr_t worldModelAnimation = 0x218;
        inline constexpr uintptr_t handBone = 0x260;
        inline constexpr uintptr_t holdInfo = 0x270;
        inline constexpr uintptr_t isBuildingTool = 0x28C;
        inline constexpr uintptr_t forcedOwner = 0x290;
        inline constexpr uintptr_t hostileScore = 0x2AC;
        inline constexpr uintptr_t itemOwner = 0x240;
        inline constexpr uintptr_t ownerItemUID = 0x2E0;
        inline constexpr uintptr_t _punches = 0x2D8;
    }

    namespace base_projectile_new {
        inline constexpr uintptr_t ShotFired = 0x607EDE0;
        inline constexpr uintptr_t BeginCycle = 0x606FD30;
        inline constexpr uintptr_t aimCone = 0x420; // UPDATED from new dump: 0x418 -> 0x420
        inline constexpr uintptr_t hipAimCone = 0x424; // UPDATED from new dump: 0x41C -> 0x424
        inline constexpr uintptr_t aimSway = 0x408; // UPDATED from new dump: 0x400 -> 0x408
        inline constexpr uintptr_t aimSwaySpeed = 0x40C; // UPDATED from new dump: 0x404 -> 0x40C
        inline constexpr uintptr_t recoil = 0x410; // UPDATED from new dump: 0x408 -> 0x410
        inline constexpr uintptr_t projectileVelocityScale = 0x39C; // UPDATED from new dump: 0x394 -> 0x39C
        inline constexpr uintptr_t automatic = 0x3A0; // UPDATED from new dump: 0x398 -> 0x3A0
        inline constexpr uintptr_t reloadTime = 0x3E0; // UPDATED from new dump: 0x3D8 -> 0x3E0
        inline constexpr uintptr_t primaryMagazine = 0x3E8; // UPDATED from new dump: 0x3E0 -> 0x3E8
        inline constexpr uintptr_t magazine = 0x3E0;
        inline constexpr uintptr_t manualCycle = 0x436;
        inline constexpr uintptr_t needsCycle = 0x43C;
        inline constexpr uintptr_t isReloading = 0x48C; // UPDATED from new dump: 0x484 -> 0x48C
        inline constexpr uintptr_t stancePenalty = 0x470; // UPDATED from new dump: 0x468 -> 0x470
        inline constexpr uintptr_t aimconePenalty = 0x474; // UPDATED from new dump: 0x46C -> 0x474
        inline constexpr uintptr_t sightAimConeScale = 0x474;
        inline constexpr uintptr_t sight_aim_cone_scale = 0x474;
        inline constexpr uintptr_t hipAimConeScale = 0x47C;
        inline constexpr uintptr_t hip_aim_cone_scale = 0x47C;
        inline constexpr uintptr_t fractionalReload = 0x3F0; // UPDATED from new dump: 0x3E8 -> 0x3F0
        inline constexpr uintptr_t aimconeCurve = 0x410;
        inline constexpr uintptr_t noAimingWhileCycling = 0x435;
        inline constexpr uintptr_t cachedModHash = 0x470;
        inline constexpr uintptr_t hipAimConeOffset = 0x480;
        inline constexpr uintptr_t sightAimConeOffset = 0x478;
        inline constexpr uintptr_t aimconePenaltyPerShot = 0x428; // UPDATED from new dump: 0x420 -> 0x428
        inline constexpr uintptr_t aimConePenaltyMax = 0x42C; // UPDATED from new dump: 0x424 -> 0x42C
        inline constexpr uintptr_t aimconePenaltyRecoverTime = 0x428;
        inline constexpr uintptr_t aimconePenaltyRecoverDelay = 0x42C;
        inline constexpr uintptr_t stancePenaltyScale = 0x438; // UPDATED from new dump: 0x430 -> 0x438
        inline constexpr uintptr_t hasADS = 0x434;
        inline constexpr uintptr_t isBurstWeapon = 0x447; // UPDATED from new dump: 0x43F -> 0x447
        inline constexpr uintptr_t canChangeFireModes = 0x448; // UPDATED from new dump: 0x440 -> 0x448
        inline constexpr uintptr_t internalBurstFireRateScale = 0x448;
        inline constexpr uintptr_t internalBurstAimConeScale = 0x44C;
        inline constexpr uintptr_t LaunchProjectile = 0x696C010; // NEW from new dump
        inline constexpr uintptr_t UpdateAmmoDisplay = 0x69759D0; // NEW from new dump
        inline constexpr uintptr_t currentBurst = 0x4C0; // NEW from new dump
        inline constexpr uintptr_t nextReloadTime = 0x460; // NEW from new dump
        inline constexpr uintptr_t numShotsFired = 0x45C; // NEW from new dump
        inline constexpr uintptr_t reloadEndDuration = 0x3FC; // NEW from new dump
        inline constexpr uintptr_t reloadFractionDuration = 0x3F8; // NEW from new dump
        inline constexpr uintptr_t reloadStartDuration = 0x3F4; // NEW from new dump
        inline constexpr uintptr_t startReloadTime = 0x468; // NEW from new dump
    }

    namespace player_projectile_update_new {
        inline constexpr uintptr_t Dispose = 0xC1CA0B0;
        inline constexpr uintptr_t _disposed = 0x24;
        inline constexpr uintptr_t ShouldPool = 0x14;
    }

    namespace player_projectile_attack_new {
        inline constexpr uintptr_t hitDistance = 0x24;
        inline constexpr uintptr_t hitVelocity = 0x18;
        inline constexpr uintptr_t travelTime = 0x2C;
    }

    namespace player_attack_new {
        inline constexpr uintptr_t projectileID = 0x14;
    }

    namespace recoil_properties_new {
        inline constexpr uintptr_t recoilYawMin = 0x18;
        inline constexpr uintptr_t recoilYawMax = 0x1C;
        inline constexpr uintptr_t recoilPitchMin = 0x20;
        inline constexpr uintptr_t recoilPitchMax = 0x24;
        inline constexpr uintptr_t timeToTakeMin = 0x28;
        inline constexpr uintptr_t timeToTakeMax = 0x2C;
        inline constexpr uintptr_t ADSScale = 0x30;
        inline constexpr uintptr_t movementPenalty = 0x34;
        inline constexpr uintptr_t clampPitch = 0x38;
        inline constexpr uintptr_t pitchCurve = 0x40;
        inline constexpr uintptr_t yawCurve = 0x48;
        inline constexpr uintptr_t ammoAimconeScaleMultiProjectile = 0x78;
        inline constexpr uintptr_t ammoAimconeScaleSingleProjectile = 0x7C;
        inline constexpr uintptr_t newRecoilOverride = 0x80;
        inline constexpr uintptr_t overrideAimconeWithCurve = 0x5C;
        inline constexpr uintptr_t aimconeProbabilityCurve = 0x70;
        inline constexpr uintptr_t aimconeCurveScale = 0x60;
    }

    namespace player_inventory_new {
        inline constexpr uintptr_t loot = 0x48;
        inline constexpr uintptr_t containerBelt = 0x58; // UPDATED from new dump: 0x38 -> 0x58
        inline constexpr uintptr_t containerMain = 0x30; // UPDATED from new dump: 0x78 -> 0x30
        inline constexpr uintptr_t containerWear = 0x60; // UPDATED from new dump: 0x58 -> 0x60
    }

    namespace world_item_new {
        inline constexpr uintptr_t item = 0x210; // UPDATED from new dump: 0x208 -> 0x210
        inline constexpr uintptr_t allowPickup = 0x208; // UPDATED from new dump: 0x200 -> 0x208
    }

    namespace server_projectile_new {
        inline constexpr uintptr_t drag = 0x34;
        inline constexpr uintptr_t gravityModifier = 0x38;
        inline constexpr uintptr_t speed = 0x3C;
        inline constexpr uintptr_t radius = 0x5C;
    }

    namespace projectile_weapon_mod_new {
        inline constexpr uintptr_t ConditionLossMultiplier = 0x200;
        inline constexpr uintptr_t additiveEffect = 0x208;
        inline constexpr uintptr_t defaultSilencerEffect = 0x210;
        inline constexpr uintptr_t isSilencer = 0x220; // UPDATED from new dump: 0x218 -> 0x220
        inline constexpr uintptr_t silencerType = 0x224; // UPDATED from new dump: 0x21C -> 0x224
        inline constexpr uintptr_t repeatDelay = 0x220;
        inline constexpr uintptr_t projectileVelocity = 0x234; // UPDATED from new dump: 0x22C -> 0x234
        inline constexpr uintptr_t projectileDamage = 0x238;
        inline constexpr uintptr_t projectileDistance = 0x244;
        inline constexpr uintptr_t aimsway = 0x250;
        inline constexpr uintptr_t aimswaySpeed = 0x25C;
        inline constexpr uintptr_t recoil = 0x268;
        inline constexpr uintptr_t sightAimCone = 0x274;
        inline constexpr uintptr_t hipAimCone = 0x280;
        inline constexpr uintptr_t isLight = 0x28C;
        inline constexpr uintptr_t isMuzzleBrake = 0x28D;
        inline constexpr uintptr_t isMuzzleBoost = 0x28E;
        inline constexpr uintptr_t isScope = 0x28F;
        inline constexpr uintptr_t zoomAmountDisplayOnly = 0x290;
        inline constexpr uintptr_t magazineCapacity = 0x294;
        inline constexpr uintptr_t needsOnForEffects = 0x2A0;
        inline constexpr uintptr_t burstCount = 0x2A4;
        inline constexpr uintptr_t timeBetweenBursts = 0x2A8;
        inline constexpr uintptr_t zoomLevels = 0x2B0;
        inline constexpr uintptr_t fovChangeEffect = 0x2B8;
        inline constexpr uintptr_t allowPings = 0x2C0;
    }

    namespace local_player_static_new {
        inline constexpr uintptr_t local_player = 0x10CB0570;
        inline constexpr uintptr_t static_fields = 0xB8;
        inline constexpr uintptr_t entity = 0x2F8; // UPDATED from new dump: 0x10 -> 0x2F8
        inline constexpr uintptr_t hv_in_wrapper = 0xB8;
        inline constexpr uintptr_t is_wrapped = 0x1;
    }

    namespace dictionary_new {
        inline constexpr uintptr_t entries = 0x18;
        inline constexpr uintptr_t count = 0x20;
    }

    namespace dictionary_entry_array_new {
        inline constexpr uintptr_t length = 0x18;
        inline constexpr uintptr_t data = 0x20;
        inline constexpr uintptr_t hashCode = 0x0;
        inline constexpr uintptr_t key = 0x8;
        inline constexpr uintptr_t value = 0x10;
        inline constexpr uintptr_t stride = 0x18;
    }

    namespace base_networkable_new {
        inline constexpr uintptr_t base_networkable = 0x10BE9150;
        inline constexpr uintptr_t static_fields = 0xB8;
        inline constexpr uintptr_t wrapper_class_ptr = 0x18;
        inline constexpr uintptr_t parent_static_fields = 0x18;
        inline constexpr uintptr_t hv_offset = 0x18;
        inline constexpr uintptr_t entities = 0x18;
        inline constexpr uintptr_t buffer_list_array = 0x10;
        inline constexpr uintptr_t buffer_list_size = 0x18;
        inline constexpr uintptr_t client_entities_decryption = 0x6F6A610;
        inline constexpr uintptr_t entity_list_decryption = 0x6F6A8F0;
        inline constexpr uintptr_t entity = 0x18;
        inline constexpr uintptr_t buffer = 0x18;
        inline constexpr uintptr_t prefabID = 0x54;
        inline constexpr uintptr_t parentEntity = 0x38;
        inline constexpr uintptr_t children = 0x88; // UPDATED from new dump: 0x68 -> 0x88
        inline constexpr uintptr_t net = 0x70;
        inline constexpr uintptr_t globalBroadcast = 0x58;
        inline constexpr uintptr_t networkRange = 0x64;
    }

    namespace list_component_projectile_new {
        inline constexpr uintptr_t static_fields = 0xB8;
        inline constexpr uintptr_t InstanceList = 0x38;
        inline constexpr uintptr_t ListItems = 0x10;
        inline constexpr uintptr_t ListCount = 0x18;
        inline constexpr uintptr_t instance = 0x20;
        inline constexpr uintptr_t BufferList_ptr = 0x10;
        inline constexpr uintptr_t vals_in_hashset = 0x10;
        inline constexpr uintptr_t TypeInfo = 0x111C53C8; // NEW from new dump
    }

    namespace game_manager_new {
        inline constexpr uintptr_t game_manager = 0x10BAB750;
        inline constexpr uintptr_t static_fields = 0xB8;
        inline constexpr uintptr_t CreatePrefab = 0x2151700; // NEW from new dump
    }

    namespace convar_graphics_new {
        inline constexpr uintptr_t convar_graphics = 0x10BF2568;
        inline constexpr uintptr_t convar_graphics_instance = 0xB8;
        inline constexpr uintptr_t _fov = 0x370;
    }

    namespace convar_admin_new {
        inline constexpr uintptr_t convar_admin = 0x10C336A0;
        inline constexpr uintptr_t playerIds = 0x20;
    }

    namespace item_icon_new {
        inline constexpr uintptr_t item_icon_c = 0x10C1A9D0;
        inline constexpr uintptr_t type_info = 0x10C1A9D0;
        inline constexpr uintptr_t static_fields = 0xB8;
        inline constexpr uintptr_t backgroundImage = 0xE8;
    }

    namespace tod_sky_static_new {
        inline constexpr uintptr_t tod_sky_c = 0x10BACC40;
        inline constexpr uintptr_t static_fields = 0xB8;
        inline constexpr uintptr_t instances = 0x68; // UPDATED from new dump: 0x50 -> 0x68
        inline constexpr uintptr_t listItems = 0x10;
        inline constexpr uintptr_t listSize = 0x18;
        inline constexpr uintptr_t arrayData = 0x20;
    }

    namespace base_projectile_typeinfo {
        inline constexpr uintptr_t value = 0x10BA6080;
    }

    namespace hit_test_typeinfo {
        inline constexpr uintptr_t value = 0x10BC2280;
    }

    namespace held_entity_typeinfo {
        inline constexpr uintptr_t value = 0x10C628B0;
    }

    namespace base_view_model_typeinfo {
        inline constexpr uintptr_t value = 0x10B9D9D0;
    }

    namespace player_model_typeinfo {
        inline constexpr uintptr_t value = 0x10C03C68;
    }

    namespace player_input_typeinfo {
        inline constexpr uintptr_t value = 0x10BBE588;
    }

    namespace model_state_typeinfo {
        inline constexpr uintptr_t value = 0x10BBD798;
    }

    namespace player_eyes_typeinfo {
        inline constexpr uintptr_t value = 0x10C612C0;
    }

    namespace player_inventory_typeinfo {
        inline constexpr uintptr_t value = 0x10C60030;
    }

    namespace base_entity_typeinfo {
        inline constexpr uintptr_t value = 0xF067400; // build 2636: BaseEntity_TypeInfo slot
    }

    namespace base_player_typeinfo {
        inline constexpr uintptr_t value = 0xF116310; // build 2636: BasePlayer_TypeInfo slot
    }

    namespace base_networkable_typeinfo {
        inline constexpr uintptr_t value = 0xF067418; // build 2636: static holder TypeInfo slot (same slot as base_networkable_static)
    }

    namespace rvas {
        inline constexpr uintptr_t TypeToObjectSet = 0x221CFF8; // UPDATED from new dump: 0x221AFF8 -> 0x221CFF8
        inline constexpr uintptr_t TypeManagerInstance = 0x221D020; // UPDATED from new dump: 0x221B020 -> 0x221D020
        inline constexpr uintptr_t m_Instance = 0x21818E8; // NEW from new dump
        inline constexpr uintptr_t rigidActors = 0x23D8; // NEW from new dump
    }

    namespace projectile_list {
        inline constexpr uintptr_t projectile_klass_rva = 0x10BBD5B0;
        inline constexpr uintptr_t klass_static_fields = 0xB8;
        inline constexpr uintptr_t instance_in_static = 0x28;
        inline constexpr uintptr_t vals_in_hashset = 0x10;
    }


    // ========================================================================
    // NEW NAMESPACES FROM THE PROVIDED DUMP
    // ========================================================================

    namespace BaseNetworkableStatic {
        inline static constexpr uintptr_t clientEntities = 0x38; // NEW from new dump
    }

    namespace EntityRealm {
        inline static constexpr uintptr_t entityList = 0x18; // NEW from new dump
    }

    namespace ListDictionary {
        inline static constexpr uintptr_t vals = 0x20; // NEW from new dump
    }

    namespace ListHashSet {
        inline static constexpr uintptr_t vals = 0x10; // NEW from new dump
    }

    namespace MainCamera {
        inline static constexpr uintptr_t mainCamera = 0x88; // NEW from new dump
    }

    namespace SingletonComponentCameraMan {
        inline static constexpr uintptr_t Instance = 0x28; // NEW from new dump
        inline static constexpr uintptr_t TypeInfo = 0x111CD368; // NEW from new dump
    }

    namespace CameraUpdateHookStatic {
        inline static constexpr uintptr_t action = 0xB0; // NEW from new dump
    }

    namespace BaseCorpse {
        inline static constexpr uintptr_t blockDamageIfNotGather = 0x2F8; // NEW from new dump
        inline static constexpr uintptr_t parentEnt = 0x2E0; // NEW from new dump
    }

    namespace BaseMovement {
        inline static constexpr uintptr_t Crawling = 0x58; // NEW from new dump
        inline static constexpr uintptr_t Ducking = 0x54; // NEW from new dump
        inline static constexpr uintptr_t Grounded = 0x5C; // NEW from new dump
        inline static constexpr uintptr_t InheritedVelocity = 0x38; // NEW from new dump
        inline static constexpr uintptr_t Owner = 0x30; // NEW from new dump
        inline static constexpr uintptr_t Running = 0x50; // NEW from new dump
        inline static constexpr uintptr_t TargetMovement = 0x44; // NEW from new dump
        inline static constexpr uintptr_t lastTeleportedTime = 0x60; // NEW from new dump
    }

    namespace Behaviour {
        inline static constexpr uintptr_t set_enabled = 0xE4BCC50; // NEW from new dump
    }

    namespace Component {
        inline static constexpr uintptr_t get_gameObject = 0xE4BD930; // NEW from new dump
    }

    namespace ConvarClientStatic {
        inline static constexpr uintptr_t camlerp = 0x8F8; // NEW from new dump
        inline static constexpr uintptr_t camspeed = 0x178; // NEW from new dump
    }

    namespace ConvarGraphicsStatic {
        inline static constexpr uintptr_t _fov = 0x4F0; // NEW from new dump
    }

    namespace ConvarPlayerStatic {
        inline static constexpr uintptr_t clientTickInterval = 0xC; // NEW from new dump
    }

    namespace GameManagerStatic {
        inline static constexpr uintptr_t client = 0x40; // NEW from new dump
    }

    namespace GameObject {
        inline static constexpr uintptr_t SetActive = 0xE4C2E20; // NEW from new dump
    }

    namespace ItemIconStatic {
        inline static constexpr uintptr_t containerLootStartTimes = 0x8; // NEW from new dump
    }

    namespace ListComponent {
        inline static constexpr uintptr_t InstanceList = 0x40; // NEW from new dump
    }

    namespace LoadingScreen {
        inline static constexpr uintptr_t panel = 0x30; // NEW from new dump
    }

    namespace MixerSnapshotManager {
        inline static constexpr uintptr_t defaultSnapshot = 0x20; // NEW from new dump
        inline static constexpr uintptr_t loadingSnapshot = 0x30; // NEW from new dump
    }

    namespace PlayerTick {
        inline static constexpr uintptr_t activeItem = 0x48; // NEW from new dump
        inline static constexpr uintptr_t eyePos = 0x34; // NEW from new dump
        inline static constexpr uintptr_t inputState = 0x50; // NEW from new dump
        inline static constexpr uintptr_t modelState = 0x40; // NEW from new dump
        inline static constexpr uintptr_t parentID = 0x28; // NEW from new dump
        inline static constexpr uintptr_t position = 0x10; // NEW from new dump
    }

    namespace ServerAdminUGCEntry {
        inline static constexpr uintptr_t ReceivedDataFromServer = 0x3209CA0; // NEW from new dump
    }

    namespace SingletonComponentLoadingScreen {
        inline static constexpr uintptr_t Instance = 0x28; // NEW from new dump
        inline static constexpr uintptr_t TypeInfo = 0x111B93F0; // NEW from new dump
    }

    namespace SingletonComponentMixerSnapshotManager {
        inline static constexpr uintptr_t Instance = 0x28; // NEW from new dump
        inline static constexpr uintptr_t TypeInfo = 0x1125CD78; // NEW from new dump
    }

    namespace SkeletonPropertiesBoneProperty {
        inline static constexpr uintptr_t area = 0x20; // NEW from new dump
        inline static constexpr uintptr_t bone = 0x10; // NEW from new dump
        inline static constexpr uintptr_t boneName = 0x18; // NEW from new dump
    }

    namespace StringPool {
        inline static constexpr uintptr_t toNumber = 0x98; // NEW from new dump
    }

    namespace TodAtmosphereParameters {
        inline static constexpr uintptr_t Brightness = 0x18; // NEW from new dump
        inline static constexpr uintptr_t Contrast = 0x1C; // NEW from new dump
        inline static constexpr uintptr_t Directionality = 0x28; // NEW from new dump
        inline static constexpr uintptr_t Fogginess = 0x2C; // NEW from new dump
        inline static constexpr uintptr_t MieMultiplier = 0x14; // NEW from new dump
        inline static constexpr uintptr_t NightBrightness = 0x20; // NEW from new dump
        inline static constexpr uintptr_t NightContrast = 0x24; // NEW from new dump
        inline static constexpr uintptr_t RayleighMultiplier = 0x10; // NEW from new dump
    }

    namespace TodCloudParameters {
        inline static constexpr uintptr_t Attenuation = 0x24; // NEW from new dump
        inline static constexpr uintptr_t Brightness = 0x30; // NEW from new dump
        inline static constexpr uintptr_t Coloring = 0x20; // NEW from new dump
        inline static constexpr uintptr_t Coverage = 0x18; // NEW from new dump
        inline static constexpr uintptr_t Opacity = 0x14; // NEW from new dump
        inline static constexpr uintptr_t Saturation = 0x28; // NEW from new dump
        inline static constexpr uintptr_t Scattering = 0x2C; // NEW from new dump
        inline static constexpr uintptr_t Sharpness = 0x1C; // NEW from new dump
        inline static constexpr uintptr_t Size = 0x10; // NEW from new dump
    }

    namespace TodDayParameters {
        inline static constexpr uintptr_t AmbientColor = 0x40; // NEW from new dump
        inline static constexpr uintptr_t AmbientMultiplier = 0x54; // NEW from new dump
        inline static constexpr uintptr_t CloudColor = 0x30; // NEW from new dump
        inline static constexpr uintptr_t FogColor = 0x38; // NEW from new dump
        inline static constexpr uintptr_t LightColor = 0x18; // NEW from new dump
        inline static constexpr uintptr_t LightIntensity = 0x48; // NEW from new dump
        inline static constexpr uintptr_t RayColor = 0x20; // NEW from new dump
        inline static constexpr uintptr_t ReflectionMaxClamp = 0x64; // NEW from new dump
        inline static constexpr uintptr_t ReflectionMultiplier = 0x5C; // NEW from new dump
        inline static constexpr uintptr_t ShadowStrength = 0x50; // NEW from new dump
        inline static constexpr uintptr_t SkyColor = 0x28; // NEW from new dump
        inline static constexpr uintptr_t SunColor = 0x10; // NEW from new dump
        inline static constexpr uintptr_t runtimeAmbientMultiplier = 0x58; // NEW from new dump
        inline static constexpr uintptr_t runtimeLightIntensity = 0x4C; // NEW from new dump
        inline static constexpr uintptr_t runtimeReflectionMultiplier = 0x60; // NEW from new dump
    }

    namespace TodFogParameters {
        inline static constexpr uintptr_t HeightBias = 0x14; // NEW from new dump
        inline static constexpr uintptr_t Mode = 0x10; // NEW from new dump
    }

    namespace TodLightParameters {
        inline static constexpr uintptr_t MinimumHeight = 0x14; // NEW from new dump
        inline static constexpr uintptr_t UpdateInterval = 0x10; // NEW from new dump
    }

    namespace TodMoonParameters {
        inline static constexpr uintptr_t HaloBrightness = 0x28; // NEW from new dump
        inline static constexpr uintptr_t HaloSize = 0x24; // NEW from new dump
        inline static constexpr uintptr_t MeshBrightness = 0x18; // NEW from new dump
        inline static constexpr uintptr_t MeshBrightnessDefault = 0x1C; // NEW from new dump
        inline static constexpr uintptr_t MeshContrast = 0x20; // NEW from new dump
        inline static constexpr uintptr_t MeshSize = 0x10; // NEW from new dump
        inline static constexpr uintptr_t MeshSizeRed = 0x14; // NEW from new dump
        inline static constexpr uintptr_t Position = 0x2C; // NEW from new dump
    }

    namespace TodStarParameters {
        inline static constexpr uintptr_t Brightness = 0x14; // NEW from new dump
        inline static constexpr uintptr_t ColorScale = 0x1C; // NEW from new dump
        inline static constexpr uintptr_t Position = 0x18; // NEW from new dump
        inline static constexpr uintptr_t Size = 0x10; // NEW from new dump
    }

    namespace TodSunParameters {
        inline static constexpr uintptr_t MeshBrightness = 0x14; // NEW from new dump
        inline static constexpr uintptr_t MeshBrightnessDefault = 0x18; // NEW from new dump
        inline static constexpr uintptr_t MeshContrast = 0x1C; // NEW from new dump
        inline static constexpr uintptr_t MeshSize = 0x10; // NEW from new dump
    }

    namespace TranslatePhrase {
        inline static constexpr uintptr_t legacyEnglish = 0x20; // NEW from new dump
        inline static constexpr uintptr_t token = 0x10; // NEW from new dump
    }

    namespace UnityEngineUiText {
        inline static constexpr uintptr_t m_Text = 0xE8; // NEW from new dump
    }
}
