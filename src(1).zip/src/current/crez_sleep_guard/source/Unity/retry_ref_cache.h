#pragma once
#include <cstdint>
// Time is monotonic milliseconds. Retain previously acquired addresses briefly,
// never cached projection values. The caller must validate them before each use.
struct RetryRefCache {
 bool attempted=false, hasGood=false, failed=false;
 int64_t lastAttempt=0, failureStart=0;
 bool ShouldTry(int64_t now) const {return !attempted || now<lastAttempt || now-lastAttempt >= (failed?25:250);}
 void Record(int64_t now,bool ok){
  attempted=true;lastAttempt=now;
  if(ok){hasGood=true;failed=false;failureStart=0;}
  else {if(!failed)failureStart=now;failed=true;}
 }
 bool CanUse(int64_t now) const {return hasGood&&(!failed || (now>=failureStart&&now-failureStart<150));}
};
