#pragma once
#include "Feature.h"
#include "types.h"

// recreated stub — original header was missing from the sources
class AlwaysEokaModule : public Module
{
public:
    AlwaysEokaModule()
        : Module(_xorstr("Always Eoka (нет реализации)"), ModuleCategory::Combat, false)
    {
    }

    void OnRenderMenu() override
    {
        RenderFeature::Text(_xorstr("Недоступно: реализация отсутствует"));
    }

    void OnRenderOverlay() override
    {
    }
};
