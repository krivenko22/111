#pragma once
#include "Feature.h"
#include "RenderFeature.h"
#include "base_networkable.h"
#include "world_to_screen.h"
#include "transform_position.h"
#include "srcoaw_aim_core.h"
#include "humanized_aim.h"
#include "snap_aim.h"
#include "aim_hitbox.h"
#include "aim_trace.h"
#include "config_store.h"
#include "aim_activation.h"
#include "flags.h"
#include "imgui/imgui.h"
#include <windows.h>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>

extern std::atomic<uintptr_t> g_currentAimTarget;

// Partial srcoaw aim adaptation. Selection and smoothing use its general
// policy; action is through relative mouse, not unverified game-memory writes.
class AimModule : public Module {
public:
    bool changeBoxColorOnTarget=true;
    float activeTargetColor[4]={1.f,0.f,0.f,1.f};
    bool targetTeammates=false;
    int aimKey=VK_RBUTTON,aimMode=AimActivation::Hold;
    int hitbox=AimHitbox::Head;
    AimTrace::Profile trace;
    float traceStrengthPercent=AimTrace::DefaultStrengthPercent;
    float radius=120.f,gain=.035f,smooth=10.f,maxDistance=200.f;
    bool lockOnTarget=false;
    int targetPriority=0; // retained only for old config compatibility
    bool distanceFovScaling=false,skipSleepers=true,skipWounded=true,showFov=true,targetLine=false;
    float fovColor[4]={1.f,1.f,1.f,.5f},lineColor[4]={1.f,1.f,1.f,.8f};
    bool unavailableSilent=false,unavailableGroups=false;
    bool unavailableScientists=true,unavailableDwellers=true,unavailableAnimals=true;
    AimModule():Module(_xorstr("Aimbot"),ModuleCategory::Combat,true){enabled=false;}
    void RegisterTraceConfig(ConfigStore& config) {
        config.Float("aim.trace.strengthPercent",traceStrengthPercent,0.f,100.f);
        config.Bind("aim.trace.count", [this]{return double(trace.count);},
            [this](double v){trace.count=int(v);++trace.revision;}, 0, AimTrace::MaxPoints, true);
        for(int i=0;i<AimTrace::MaxPoints;i++) {
            const std::string prefix="aim.trace."+std::to_string(i)+".";
            auto& p=trace.points[i];
            config.Float(prefix+"x",p.x,-4096.f,4096.f);
            config.Float(prefix+"y",p.y,-4096.f,4096.f);
            config.Float(prefix+"t",p.time,0.f,AimTrace::MaxDuration);
        }
    }
    bool NeedsAimStateLock() const override { return true; }
    void OnRenderMenu() override {
        const char* modes[]={"None","Hold","Toggle","Always"};
        if (ImGui::BeginTable("##aim_layout", 2, ImGuiTableFlags_SizingStretchSame | ImGuiTableFlags_PadOuterX)) {
            ImGui::TableNextColumn();
            RenderFeature::SectionTitle(_xorstr("НАВЕДЕНИЕ"));
            RenderFeature::Toggle(this,_xorstr("Включить"),&enabled,0);
            ImGui::TextUnformatted(_xorstr("Режим активации"));
            ImGui::SetNextItemWidth(-1.f);
            ImGui::Combo("##aim_mode",&aimMode,modes,IM_ARRAYSIZE(modes));
            const std::string hitboxNames[] = { _xorstr("Голова"), _xorstr("Шея"), _xorstr("Торс"), _xorstr("Грудь") };
            const char* hitboxes[] = { hitboxNames[0].c_str(), hitboxNames[1].c_str(), hitboxNames[2].c_str(), hitboxNames[3].c_str() };
            ImGui::TextUnformatted(_xorstr("Точка наведения"));
            ImGui::SetNextItemWidth(-1.f);
            ImGui::Combo("##aim_hitbox", &hitbox, hitboxes, IM_ARRAYSIZE(hitboxes));
            ImGui::Text(_xorstr("Клавиша: %s"),RenderFeature::GetKeyName(aimKey));
            if(ImGui::Button(waitingKey?_xorstr("Нажми клавишу..."):_xorstr("Назначить клавишу"))&&!waitingKey){
                waitingKey=true;for(int i=1;i<256;i++)captureDown[i]=(GetAsyncKeyState(i)&0x8000)!=0;
            }
            if(waitingKey){for(int i=1;i<256;i++){
                bool down=(GetAsyncKeyState(i)&0x8000)!=0,edge=down&&!captureDown[i];captureDown[i]=down;
                if(!edge)continue;if(i==VK_ESCAPE){waitingKey=false;break;}
                if(i==VK_BACK){aimKey=0;waitingKey=false;break;}
                if(i==VK_DELETE)continue;aimKey=i;waitingKey=false;break;
            }}
            RenderFeature::Text(_xorstr("Esc — отмена, Backspace — сброс"));
            RenderFeature::SliderFloat(this,_xorstr("Радиус FOV"),&radius,20.f,400.f,_xorstr("%.0f px"));
            RenderFeature::SliderFloat(this,_xorstr("Сглаживание"),&smooth,1.f,50.f,_xorstr("%.1f"));
            RenderFeature::Toggle(this,_xorstr("Удерживать цель"),&lockOnTarget,3);

            ImGui::TableNextColumn();
            RenderFeature::SectionTitle(_xorstr("ЦЕЛЬ И ВИЗУАЛ"));
            RenderFeature::Toggle(this,_xorstr("Круг FOV"),&showFov,7);
            if(ImGui::TreeNode(_xorstr("Дополнительно"))){
            RenderFeature::SliderFloat(this,_xorstr("Скорость мыши"),&gain,.005f,.15f,_xorstr("%.3f"));
            RenderFeature::SliderFloat(this,_xorstr("Дальность (500 = без лимита)"),&maxDistance,10.f,500.f,_xorstr("%.0f м"));
            RenderFeature::Toggle(this,_xorstr("FOV по дистанции"),&distanceFovScaling,4);
            RenderFeature::Toggle(this,_xorstr("Пропускать спящих"),&skipSleepers,5);
            RenderFeature::Toggle(this,_xorstr("Пропускать раненых"),&skipWounded,6);
            RenderFeature::Toggle(this,_xorstr("Целиться в тиммейтов"),&targetTeammates,1);
            RenderFeature::Toggle(this,_xorstr("Выделять цель ESP"),&changeBoxColorOnTarget,2);
            if(showFov)RenderFeature::ColorEdit4(this,_xorstr("Цвет круга"),fovColor);
            RenderFeature::Toggle(this,_xorstr("Линия к цели"),&targetLine,8);
            if(targetLine)RenderFeature::ColorEdit4(this,_xorstr("Цвет линии"),lineColor);
            if(ImGui::TreeNode(_xorstr("Недоступные функции"))){
                ImGui::BeginDisabled();
                ImGui::Checkbox("Silent aim",&unavailableSilent);
                ImGui::Checkbox(_xorstr("Настройки по оружию"),&unavailableGroups);
                ImGui::Checkbox("Skip scientists",&unavailableScientists);
                ImGui::Checkbox("Skip dwellers",&unavailableDwellers);
                ImGui::Checkbox("Skip animals",&unavailableAnimals);
                ImGui::EndDisabled();ImGui::TreePop();
            }
            RenderFeature::Text(_xorstr("Видимость и команда не проверены"));
            ImGui::TreePop();
            }
            ImGui::EndTable();
        }
    }
    void OnRenderOverlay() override {
        auto now=Clock::now();bool fg=GameForeground(),active=UpdateActivation(fg);
        if(!enabled){Clear();status="off";return;}
        if(!fg||AimActivation::menuOpen||!active){Note(!fg?"focus lost":AimActivation::menuOpen?"menu opened":"activation off",now);Clear();status=!fg?"focus Rust":AimActivation::menuOpen?"menu open":"activation off";}
        else if(!frameTime.time_since_epoch().count()||now-frameTime>std::chrono::milliseconds(200)){Note("waiting for ESP frame",now);Pause();status="waiting for ESP";}
        ImVec2 size=ImGui::GetIO().DisplaySize;
        if(size.x<=0||size.y<=0)return;
        ImDrawList* d=ImGui::GetBackgroundDrawList();if(!d)return;
        if(showFov)d->AddCircle({size.x*.5f,size.y*.5f},visualFov>0.f?visualFov:radius,ImGui::ColorConvertFloat4ToU32(ImVec4(fovColor[0],fovColor[1],fovColor[2],fovColor[3])),64,1.f);
        if(targetLine&&haveScreen&&frameTime.time_since_epoch().count()&&now-frameTime<std::chrono::milliseconds(150))
            d->AddLine({size.x*.5f,size.y*.5f},targetScreen,ImGui::ColorConvertFloat4ToU32(ImVec4(lineColor[0],lineColor[1],lineColor[2],lineColor[3])),1.f);
        char text[160]{};std::snprintf(text,sizeof(text),"Aim: %s",status);d->AddText({12.f,44.f},IM_COL32(240,180,100,255),text);
        if(lossCount&&now-lastLossTime<std::chrono::seconds(30)){
            std::snprintf(text,sizeof(text),"Aim last dropout: %s | count: %u",lastLossReason,lossCount);d->AddText({12.f,76.f},IM_COL32(255,180,110,255),text);
            if(previousLossTime.time_since_epoch().count()&&now-previousLossTime<std::chrono::seconds(30)){
                std::snprintf(text,sizeof(text),"Previous dropout: %s",previousLossReason);d->AddText({12.f,92.f},IM_COL32(255,180,110,255),text);
            }
        }
    }
    uintptr_t GetCurrentTarget()const{return g_currentAimTarget;}
    const char* GetLastLossReason()const{return lastLossReason;}
    unsigned GetLossCount()const{return lossCount;}

    void OnCameraFrame(const RenderSnapshot& snap,const WorldToScreenUtils::CameraSnapshot& cam,uintptr_t local,int width,int height){
        const auto now=Clock::now();frameTime=now;
        bool fg=GameForeground(),active=UpdateActivation(fg);
        if(!enabled){Clear();status="off";return;}
        if(lastHitbox!=hitbox){Clear();lastHitbox=hitbox;}
        if(!fg||AimActivation::menuOpen||!active){Note(!fg?"focus lost":AimActivation::menuOpen?"menu opened":"activation off",now);Clear();status="activation off";return;}
        if(!cam.valid||!Decryption::is_valid_ptr(local)||width<=0||height<=0){Note("camera or local missing",now);Pause();status="camera/local unavailable";Expire(now);return;}
        if(!Fresh(snap,now)){Note("stale player data",now);Pause();status="stale player data";Expire(now);return;}
        if(!lockOnTarget)ClearLock();
        if(!targetTeammates)PlayerFlagsUtils::UpdateTeamCache(local);
        SrcoawAimCore::Choice choice{};
        uintptr_t chosenModel=0;bool chosenSnapshot=false,chosenSleeping=false;
        const char* reject="target missing from snapshot";
        bool lockedInSnapshot=false;
        const bool holdLock=lockOnTarget&&lockedId&&seenTime.time_since_epoch().count()&&now-seenTime<std::chrono::milliseconds(700);
        auto evaluate=[&](const PlayerRenderData& pd,bool fromSnapshot){
            bool isLocked=holdLock&&pd.entityId==lockedId;
            auto fail=[&](const char* why){if(isLocked)reject=why;};
            if(!pd.valid||!pd.isAlive||pd.entityId==local||pd.isNpc||(skipSleepers&&pd.isSleeping)||(skipWounded&&pd.isWounded)||!Decryption::is_valid_ptr(pd.entityId)){fail("target filtered");return;}
            if(!targetTeammates&&PlayerFlagsUtils::IsTeammateSteamIdCached(pd.steamId,pd.entityId,local)){fail("team filter");return;}
            uintptr_t model=0;
            if(!Read(pd.entityId+offsets::base_entity::model,model)||!Decryption::is_valid_ptr(model)){fail("model read");return;}
            Vector3 point{};
            if(!AimHitbox::Position(ReadBytes,model,hitbox,point)){fail(hitbox==AimHitbox::Head?"head transform/read":"selected bone unavailable");return;}
            float hx=point.x-pd.position.x,hy=point.y-pd.position.y,hz=point.z-pd.position.z;
            if(!std::isfinite(hx*hx+hy*hy+hz*hz)||hx*hx+hy*hy+hz*hz>16.f){fail(hitbox==AimHitbox::Head?"head-position mismatch":"bone-position mismatch");return;}
            float dx=point.x-cam.position.x,dy=point.y-cam.position.y,dz=point.z-cam.position.z;
            float distSq=dx*dx+dy*dy+dz*dz;
            if(!std::isfinite(distSq)||distSq<1.f||(maxDistance<500.f&&distSq>maxDistance*maxDistance)){fail("distance limit");return;}
            ImVec2 screen{};if(!WorldToScreenUtils::WorldToScreen(point,cam.viewMatrix,screen,width,height)){fail("projection failed");return;}
            SrcoawAimCore::Choice next=choice;
            SrcoawAimCore::Consider(next,{pd.entityId,screen.x,screen.y,std::sqrt(distSq),0},float(width),float(height),radius,distanceFovScaling,holdLock?lockedId:0);
            if(next.candidate.id==pd.entityId){choice=next;chosenModel=model;chosenSnapshot=fromSnapshot;chosenSleeping=pd.isSleeping;}
            else fail("outside FOV");
        };
        if(holdLock){
            for(const auto& pd:snap.players)if(pd.entityId==lockedId){lockedInSnapshot=true;evaluate(pd,true);break;}
            if(!lockedInSnapshot && snapshotSeen.time_since_epoch().count() && now-snapshotSeen<std::chrono::milliseconds(250)){
                PlayerRenderData direct{};
                if(ReadLockedDirect(direct))evaluate(direct,false);else reject="direct locked read failed";
            }
            if(!choice.candidate.id){Note(reject,now);Pause();status="waiting for locked target";return;}
        }else{
            if(lockedId)ClearLock();
            for(const auto& pd:snap.players)evaluate(pd,true);
        }
        if(!choice.candidate.id){Note("no target in circle",now);Clear();status="no target in circle";return;}
        auto post=Clock::now();if(!Fresh(snap,post)){Note("stale during selection",post);Pause();status="stale player data";Expire(post);return;}
        uintptr_t id=static_cast<uintptr_t>(choice.candidate.id);
        if(id!=lastTarget){
            humanMove.Reset();
            const auto tick=std::chrono::duration_cast<std::chrono::microseconds>(post.time_since_epoch()).count();
            humanMove.Seed(static_cast<uint64_t>(id)^static_cast<uint64_t>(tick));
            tracePlayer.Reset();snapGate.Reset();lastMove={};lastTarget=id;
        }
        if(lockOnTarget){
            if(id!=lockedId){lockedId=id;lockedClass=0;lockedModel=0;}
            if(chosenSnapshot){
                snapshotSeen=post;lockedSleeping=chosenSleeping;
                if(!lockedClass||lockedModel!=chosenModel){
                    uintptr_t klass=0;if(Read(id,klass)&&Decryption::is_valid_ptr(klass)){lockedClass=klass;lockedModel=chosenModel;}else{lockedClass=lockedModel=0;}
                }
            }
            seenTime=post;
        }
        float dt=lastMove.time_since_epoch().count()?std::chrono::duration<float>(post-lastMove).count():0.f;
        lastMove=post;g_currentAimTarget=id;status=chosenSnapshot?"target selected":"target direct refresh";
        ImVec2 aimScreen{choice.candidate.sx,choice.candidate.sy};
        targetScreen=aimScreen;haveScreen=true;visualFov=choice.fov;
        const bool instant=smooth<=1.01f;
        if(instant!=wasInstant){humanMove.Reset();snapGate.Reset();wasInstant=instant;}
        const float forwardX=cam.viewMatrix.m[0][3],forwardY=cam.viewMatrix.m[1][3],forwardZ=cam.viewMatrix.m[2][3];
        const int64_t micros=std::chrono::duration_cast<std::chrono::microseconds>(post.time_since_epoch()).count();
        SrcoawAimCore::Movement movement{};
        if(instant){
            if(snapGate.Ready(forwardX,forwardY,forwardZ,micros))
                movement=SnapAim::Calculate(aimScreen.x-width*.5f,aimScreen.y-height*.5f,gain);
        }else {
            const auto traced=AimTrace::Apply(trace,tracePlayer,aimScreen.x-width*.5f,aimScreen.y-height*.5f,dt,traceStrengthPercent);
            movement=HumanizedAim::Step(traced.x,traced.y,gain,smooth,radius,dt,humanMove);
        }
        if(!Fresh(snap,Clock::now())){Note("stale during movement",Clock::now());Pause();return;}
        if((movement.x||movement.y)&&ActivationStillValid()){
            INPUT input{};input.type=INPUT_MOUSE;input.mi.dx=movement.x;input.mi.dy=movement.y;input.mi.dwFlags=MOUSEEVENTF_MOVE;
            if(SendInput(1,&input,sizeof(input))!=1){Note("SendInput rejected",Clock::now());Clear();status="mouse input rejected";}
            else if(instant)snapGate.Sent(forwardX,forwardY,forwardZ,micros);
        }
    }
private:
    using Clock=std::chrono::steady_clock;
    uintptr_t lastTarget=0,lockedId=0,lockedClass=0,lockedModel=0;
    bool lockedSleeping=false;
    int lastHitbox=AimHitbox::Head;
    HumanizedAim::State humanMove{};AimTrace::Player tracePlayer{};SnapAim::Gate snapGate{};bool wasInstant=false;AimActivation::Runtime activation{};
    Clock::time_point lastMove{},frameTime{},seenTime{},snapshotSeen{},lastLossTime{},previousLossTime{};
    const char* status="waiting for ESP";const char* lastLossReason="none";const char* previousLossReason="none";
    unsigned lossCount=0;bool waitingKey=false,captureDown[256]{};
    ImVec2 targetScreen{};bool haveScreen=false;float visualFov=0.f;
    static bool ReadBytes(uint64_t address,void* dst,size_t n){return kernelHandler.read_memory(address,reinterpret_cast<uint64_t>(dst),n);}
    template<class T>static bool Read(uint64_t address,T& out){out={};return ReadBytes(address,&out,sizeof(out));}
    static bool Fresh(const RenderSnapshot& s,Clock::time_point now){return s.time.time_since_epoch().count()&&now>=s.time&&now-s.time<=std::chrono::milliseconds(150);}
    static bool GameForeground(){HWND w=GetForegroundWindow();DWORD pid=0;if(w)GetWindowThreadProcessId(w,&pid);return pid&&pid==pId;}
    bool KeyDown()const{return aimKey>0&&aimKey<256&&(GetAsyncKeyState(aimKey)&0x8000)!=0;}
    bool UpdateActivation(bool focus){return activation.Update(aimMode,aimKey,KeyDown(),enabled&&focus&&!AimActivation::menuOpen,AimActivation::focusGeneration);}
    bool ActivationStillValid()const{return activation.seenGeneration==AimActivation::focusGeneration&&activation.ActiveNow(aimMode,aimKey,KeyDown(),enabled&&GameForeground()&&!AimActivation::menuOpen);}
    void Note(const char* reason,Clock::time_point now){if(lastTarget){previousLossReason=lastLossReason;previousLossTime=lastLossTime;lastLossReason=reason;lastLossTime=now;++lossCount;}}
    void Pause(){g_currentAimTarget=0;lastTarget=0;lastMove={};humanMove.Reset();tracePlayer.Reset();snapGate.Reset();haveScreen=false;visualFov=0.f;}
    void ClearLock(){lockedId=lockedClass=lockedModel=0;lockedSleeping=false;seenTime={};snapshotSeen={};}
    void Clear(){Pause();ClearLock();}
    void Expire(Clock::time_point now){if(!seenTime.time_since_epoch().count()||now-seenTime>=std::chrono::milliseconds(700))ClearLock();}
    // On a brief missing snapshot, attempt a fresh read only for the previously
    // selected address; require unchanged class+model, alive and current
    // transforms. Sleep comes from the last confirmed snapshot (<250 ms).
    bool ReadLockedDirect(PlayerRenderData& out){
        if(!Decryption::is_valid_ptr(lockedId)||!Decryption::is_valid_ptr(lockedClass)||!Decryption::is_valid_ptr(lockedModel))return false;
        uintptr_t klass=0,model=0,root=0;int life=-1;uint32_t flags=0;
        if(!Read(lockedId,klass)||klass!=lockedClass||!Read(lockedId+offsets::base_entity::model,model)||model!=lockedModel||
           !Read(lockedId+offsets::base_combat_entity::lifestate,life)||life!=0||
           !Read(lockedId+offsets::base_player::player_flags,flags)||
           !Read(model+offsets::model::rootBone,root))return false;
        Vector3 pos{};if(!TransformPosition::WorldPosition(ReadBytes,root,pos))return false;
        out={};out.entityId=lockedId;out.valid=true;out.isAlive=true;out.position=pos;
        out.steamId=PlayerFlagsUtils::GetRealSteamID(lockedId);
        out.isSleeping=lockedSleeping;
        out.isWounded=(flags&offsets::base_player_flags::Wounded)!=0;return true;
    }
};
