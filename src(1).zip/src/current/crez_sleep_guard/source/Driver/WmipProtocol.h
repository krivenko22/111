#pragma once
#include <windows.h>
#include <cstddef>
#include <cstdint>
// Reconstructed by static analysis of WmipRpc.sys SHA-256
// fcee2d41f0735d8f38d6179a299adf905db5fe0d85b5a8aa8ecdcd6ac2d95921.
// No runtime compatibility or driver safety is asserted.
constexpr DWORD WMIP_HEARTBEAT = 0x220000;
constexpr DWORD WMIP_READ       = 0x220010;
constexpr DWORD WMIP_WRITE      = 0x220014;
constexpr DWORD WMIP_MODULE     = 0x220020;
constexpr DWORD WMIP_ALLOC      = 0x220028;
constexpr DWORD WMIP_PROTECT    = 0x220030;
constexpr DWORD WMIP_VERSION    = 0x00020001;
constexpr size_t WMIP_MAX_BYTES = 4u*1024u*1024u;
constexpr BYTE WMIP_XOR_KEY[4] = {0x5a,0xc3,0x7e,0xa1};
#pragma pack(push,1)
struct WmipHeartbeat { uint32_t version, os_build, offsets_valid, reserved; };
struct WmipMemory { uint32_t pid; uint64_t address; uint32_t size; };
struct WmipModule { uint32_t pid; WCHAR name[260]; uint64_t base; uint32_t image_size; };
struct WmipAlloc { uint32_t pid; uint64_t address; uint64_t size; uint32_t protect; };
struct WmipProtect { uint32_t pid; uint64_t address; uint64_t size; uint32_t new_protect; uint32_t old_protect; };
#pragma pack(pop)
static_assert(sizeof(WmipHeartbeat)==16 && sizeof(WmipMemory)==16 && sizeof(WmipModule)==0x218 && sizeof(WmipAlloc)==0x18 && sizeof(WmipProtect)==0x1c);

static_assert(offsetof(WmipMemory,address)==4 && offsetof(WmipMemory,size)==12 && offsetof(WmipModule,name)==4 && offsetof(WmipModule,base)==0x20c && offsetof(WmipModule,image_size)==0x214);
