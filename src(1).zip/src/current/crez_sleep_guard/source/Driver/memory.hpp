#ifndef _MEMORY_HPP
#define _MEMORY_HPP
#define OBF

#include <windows.h>
#include <cstdint>
#include <vector>
#include <string>
#include <tlhelp32.h>
#include <map>
#include <mutex>
//#include "offsets.hpp"
#include "Driver.h"
 
#define _USERMODE 0

// thread safe std::map
template <typename TKey, typename TVal>
struct ThreadMap
{
    std::map<TKey, TVal> map;
    std::mutex mutex;
};

// thread safe std::vector
template <typename Type>
struct ThreadVec
{
    std::vector<Type> vec;
    std::mutex mutex;
};

// a class for interacting with memory
class Memory
{
public: // member vars
    HANDLE handle = 0;  // holds the handle to rust
    int process_id = 0; // holds rust's process id
    uint64_t up_addy = 0;   // holds the unityplayer.dll address 
    uint64_t ga_addy = 0;   // holds the gameassembly.dll address 
public:
    // constructor for memory class, requires a process id
    Memory(int _process_id)
    {
        // stores the process id
        this->process_id = _process_id;

#if _USERMODE == 1

        // Open a handle to the target process with PROCESS_ALL_ACCESS
        HANDLE _handle = OpenProcess(PROCESS_ALL_ACCESS, false, _process_id);

        // Check if the handle is valid
        if (_handle == INVALID_HANDLE_VALUE)
            return;

        // Store the handle value.
        this->handle = _handle;
#else
        kernelHandler.attach((_xorstr("RustClient.exe")));

        get_process_pid(_xorstr("RustClient.exe"));
#endif
        this->up_addy = GetModuleBase((_xorstr("UnityPlayer.dll")));

        this->ga_addy = GetModuleBase((_xorstr("GameAssembly.dll")));
    }

    // close a handle to the target and remove it
    bool Detach()
    {
#if _USERMODE == 1

        CloseHandle(this->handle);
        this->handle = INVALID_HANDLE_VALUE;
        return true;

#endif
    }

    // read value from memory address by type, specifying a pointer chain to follow
    template<typename Type>
    Type ReadChain(uint64_t address, std::vector<uint64_t> chain)
    {
        uint64_t current = address;
        for (int i = 0; i < chain.size() - 1; i++)
        {
            current = kernelHandler.readmem<uint64_t>(current + chain[i]);
        }
        return kernelHandler.readmem<Type>(current + chain[chain.size() - 1]);
    }




    // get the base address of a module loaded into target proc
    uint64_t GetModuleBase(const char* module_name)
    {
        return kernelHandler.get_module_base(module_name);
    }

    // Implementation for this->scan_for_class
    uint64_t IL2CPPScan(const char* class_name)
    {

        uint64_t base = kernelHandler.get_module_base((_xorstr("GameAssembly.dll")));
        IMAGE_DOS_HEADER dos_header = kernelHandler.readmem<IMAGE_DOS_HEADER>(base);
        IMAGE_SECTION_HEADER data_header = kernelHandler.readmem<IMAGE_SECTION_HEADER>(base + dos_header.e_lfanew + sizeof(IMAGE_NT_HEADERS64) + (3 * 40));
        IMAGE_SECTION_HEADER next_section = kernelHandler.readmem<IMAGE_SECTION_HEADER>(base + dos_header.e_lfanew + sizeof(IMAGE_NT_HEADERS64) + (4 * 40));
        DWORD data_size = next_section.VirtualAddress - data_header.VirtualAddress;

        // Check if this section is .data, if not, return 0
        if (strcmp((char*)data_header.Name, _xorstr(".data")))
        {
            return 0;
        }

        // Scan for the requested class
        for (uint64_t offset = data_size; offset > 0; offset -= 8)
        {
            char klass_name[0x100] = { 0 };
            auto klass = kernelHandler.readmem<uint64_t>(base + data_header.VirtualAddress + offset);
            if (klass == 0) { continue; }
            auto name_pointer = kernelHandler.readmem<uint64_t>(klass + 0x10);
            if (name_pointer == 0) { continue; }
            kernelHandler.read_memory(name_pointer, (uint64_t)klass_name, sizeof(klass_name));
            if (!strcmp(klass_name, class_name))
            {
                return klass;
            }
        }

        return 0;
    }
};

// a class for handling the rust process
class Rust
{
public: // member vars
    int process_id = 0; // holds the process id
    Memory* mem = 0; // memory class for this process
public:
    // constructor for process class, requries a process name
    Rust()
    {
        // get the process id of target process
        this->process_id = Rust::GetPID((_xorstr("RustClient.exe")));

        // Check if process ID is valid
        if (this->process_id == 0) {
            return;
        }

        // create memory class
        this->mem = new Memory(this->process_id);
    }

    int GetPID(const char* process_name)
    {
        PROCESSENTRY32 entry;
        entry.dwSize = sizeof(PROCESSENTRY32);

        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);

        // Check if first process is valid.
        if (!Process32First(snapshot, &entry) == TRUE)
        {
            return 0;
        }

        // Iterate until we either find our process or reach the end of the list.
        while (Process32Next(snapshot, &entry) == TRUE)
        {
            if (strcmp(entry.szExeFile, process_name) == 0)
            {
                return (int)entry.th32ProcessID;
            }
        }

        // Return 0, if we reach this point the process was not found.
        return 0;
    }
};
extern Rust* rust;

#endif // _MEMORY_HPP