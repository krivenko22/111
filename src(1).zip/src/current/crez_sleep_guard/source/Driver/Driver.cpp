#include "Driver.h"
#include "WmipProtocol.h"
#include <algorithm>
#include <cstring>
#include <cwchar>
#include <vector>
#include <new>

#ifndef CREZ_ENABLE_UNVERIFIED_WRITES
#define CREZ_ENABLE_UNVERIFIED_WRITES 1
#endif
kernelmode_proc_handler kernelHandler;

static void transform_bytes(void* data,size_t length) {
    auto* p=static_cast<BYTE*>(data);
    for(size_t i=0;i<length;i++) p[i]^=WMIP_XOR_KEY[i&3];
}
static bool heartbeat(HANDLE h,DWORD* error) {
    WmipHeartbeat reply{};DWORD got=0;
    BOOL ok=DeviceIoControl(h,WMIP_HEARTBEAT,nullptr,0,&reply,sizeof(reply),&got,nullptr);
    if(!ok){if(error)*error=GetLastError();return false;}
    if(got!=sizeof(reply)||reply.version!=WMIP_VERSION){if(error)*error=ERROR_REVISION_MISMATCH;return false;}
    if(error)*error=ERROR_SUCCESS;
    return true;
}
bool ProbeWmipDevice(DWORD* error) {
    HANDLE h=CreateFileW(L"\\\\.\\WmipRpc",GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_EXISTING,0,nullptr);
    if(h==INVALID_HANDLE_VALUE){if(error)*error=GetLastError();return false;}
    bool ok=heartbeat(h,error);CloseHandle(h);return ok;
}
kernelmode_proc_handler::kernelmode_proc_handler():handle{INVALID_HANDLE_VALUE},pid{0}{}
kernelmode_proc_handler::~kernelmode_proc_handler(){if(handle!=INVALID_HANDLE_VALUE)CloseHandle(handle);}
bool kernelmode_proc_handler::is_attached(){return handle!=INVALID_HANDLE_VALUE;}
bool kernelmode_proc_handler::attach(const char* proc_name) {
    if(handle!=INVALID_HANDLE_VALUE){CloseHandle(handle);handle=INVALID_HANDLE_VALUE;}
    pid=get_process_pid(proc_name);if(!pid)return false;
    HANDLE h=CreateFileW(L"\\\\.\\WmipRpc",GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_EXISTING,0,nullptr);
    if(h==INVALID_HANDLE_VALUE)return false;
    if(!heartbeat(h,nullptr)){CloseHandle(h);return false;}
    handle=h;return true;
}
bool kernelmode_proc_handler::read_memory(uint64_t src_addr,uint64_t dst_addr,size_t size) {
    if(!dst_addr||!size||size>WMIP_MAX_BYTES)return false;
    void* dst=reinterpret_cast<void*>(static_cast<uintptr_t>(dst_addr));std::memset(dst,0,size);
    if(!src_addr||handle==INVALID_HANDLE_VALUE)return false;
    try {
        WmipMemory plain{pid,src_addr,static_cast<uint32_t>(size)}, encoded=plain;
        transform_bytes(&encoded,sizeof(encoded));
        // Reads are synchronous; keep a separate reusable buffer per calling
        // thread so small, frequent reads do not allocate on every IOCTL.
        thread_local std::vector<BYTE> response;
        response.resize(sizeof(WmipMemory)+size);
        DWORD got=0;
        if(!DeviceIoControl(handle,WMIP_READ,&encoded,sizeof(encoded),response.data(),static_cast<DWORD>(response.size()),&got,nullptr)||got!=response.size())return false;
        transform_bytes(response.data(),response.size());
        WmipMemory confirmed{};std::memcpy(&confirmed,response.data(),sizeof(confirmed));
        if(confirmed.pid!=plain.pid||confirmed.address!=plain.address||confirmed.size!=plain.size)return false;
        std::memcpy(dst,response.data()+sizeof(confirmed),size);return true;
    } catch(const std::bad_alloc&) { return false; }
}
bool kernelmode_proc_handler::write_memory(uint64_t dst_addr,uint64_t src_addr,size_t size) {
#if CREZ_ENABLE_UNVERIFIED_WRITES
    if(handle==INVALID_HANDLE_VALUE||!dst_addr||!src_addr||!size||size>WMIP_MAX_BYTES)return false;
    try {
        WmipMemory header{pid,dst_addr,static_cast<uint32_t>(size)};
        std::vector<BYTE> request(sizeof(header)+size);
        std::memcpy(request.data(),&header,sizeof(header));
        std::memcpy(request.data()+sizeof(header),reinterpret_cast<void*>(static_cast<uintptr_t>(src_addr)),size);
        transform_bytes(request.data(),request.size());DWORD got=0;
        return DeviceIoControl(handle,WMIP_WRITE,request.data(),static_cast<DWORD>(request.size()),nullptr,0,&got,nullptr) && got==0;
    } catch(const std::bad_alloc&) { return false; }
#else
    (void)dst_addr;(void)src_addr;(void)size;return false;
#endif
}
uint64_t kernelmode_proc_handler::get_module_base(const std::string& module_name) {
    if(handle==INVALID_HANDLE_VALUE||module_name.empty()||module_name.size()>=260)return 0;
    WmipModule req{};req.pid=pid;
    for(size_t i=0;i<module_name.size();i++)req.name[i]=static_cast<unsigned char>(module_name[i]);
    DWORD got=0;
    if(!DeviceIoControl(handle,WMIP_MODULE,&req,sizeof(req),&req,sizeof(req),&got,nullptr)||got!=sizeof(req)||req.pid!=pid)return 0;
    return req.base;
}
uint64_t kernelmode_proc_handler::virtual_alloc(size_t size,uint32_t allocation_type,uint32_t protect,uint64_t address) {
#if CREZ_ENABLE_UNVERIFIED_WRITES
    (void)allocation_type;
    if(handle==INVALID_HANDLE_VALUE||!size)return 0;
    WmipAlloc req{pid,address,static_cast<uint64_t>(size),protect};DWORD got=0;
    if(!DeviceIoControl(handle,WMIP_ALLOC,&req,sizeof(req),&req,sizeof(req),&got,nullptr)||got!=sizeof(req)||req.pid!=pid)return 0;
    return req.address;
#else
    (void)size;(void)allocation_type;(void)protect;(void)address;return 0;
#endif
}
uint32_t kernelmode_proc_handler::virtual_protect(uint64_t address,size_t size,uint32_t protect) {
#if CREZ_ENABLE_UNVERIFIED_WRITES
    if(handle==INVALID_HANDLE_VALUE||!address||!size)return 0;
    WmipProtect req{pid,address,static_cast<uint64_t>(size),protect,0};DWORD got=0;
    if(!DeviceIoControl(handle,WMIP_PROTECT,&req,sizeof(req),&req,sizeof(req),&got,nullptr)||got!=sizeof(req)||req.pid!=pid)return 0;
    return req.old_protect;
#else
    (void)address;(void)size;(void)protect;return 0;
#endif
}
