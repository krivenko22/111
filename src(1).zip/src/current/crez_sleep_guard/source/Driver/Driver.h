#define OBF

#pragma once
#include <windows.h>
#include <cstdint>
#include <tlhelp32.h>
#include <string>
#include "Tools.h"
#include <vector>



static std::uint32_t pId = 0;
static uintptr_t gBase = 0;
static uintptr_t basenetworkable = 0;
static uintptr_t uBase = 0;

// Client for WmipRpc.sys; expected device protocol was reconstructed statically.
bool ProbeWmipDevice(DWORD* error);

class kernelmode_proc_handler {
	HANDLE handle;
	uint32_t pid;
public:
	kernelmode_proc_handler();

	~kernelmode_proc_handler();

	bool is_attached();

	bool attach(const char* proc_name);

	uint64_t get_module_base(const std::string& module_name);

	bool read_memory(uint64_t src_addr, uint64_t dst_addr, size_t size);

	bool write_memory(uint64_t dst_addr, uint64_t src_addr, size_t size);

	uint32_t virtual_protect(uint64_t address, size_t size, uint32_t protect);

	uint64_t virtual_alloc(size_t size, uint32_t allocation_type, uint32_t protect, uint64_t address = 0);



	template <typename type>
	type readmem(uint64_t src) {
		type ret = {};
		read_memory(src, (uint64_t)&ret, sizeof(type));
		return ret;
	}

	template <typename type>
	bool writemem(uint64_t dst_addr, type var) {
		type inp = var;
		return write_memory(dst_addr, (uint64_t)&inp, sizeof(type));
	}

    std::string ReadASCII(uint64_t address)
    {
        // allocate our buffer with string size.
        char buffer[1024] = {};

        // read the string at address into the buffer
        this->read_memory(address, (uint64_t)&buffer, sizeof(buffer) - 1);

        // return buffer string
        return std::string(buffer);
    }

    // Read an ASCII string to an std::string
    std::string ReadMonoString(uint64_t address)
    {
        /* Allocate the buffer for the string */
        char buffer[512] = {};

        /* Read into the ptr */
        address = this->readmem<uint64_t>(address);

        /* Read the string into the buffer */
        this->read_memory(address, (uint64_t)buffer, sizeof(buffer) - 1);

        /* Return the read string */
        return buffer;
    }	
			
	std::wstring ReadUnicode(uint64_t address) {
		if (!address)
			return std::wstring();

		uint32_t length = readmem<uint32_t>(address + 0x10);
		if (length == 0 || length > 512)
			return std::wstring();

		std::vector<wchar_t> buffer(length + 1, 0);
		read_memory(address + 0x14, reinterpret_cast<uint64_t>(buffer.data()), length * sizeof(wchar_t));
		return std::wstring(buffer.data());
	}

    // read a native string
    std::string ReadNative(uint64_t address)
    {
        // allocate our buffer with string size.
        char buffer[1024] = {};

        // read the string at address into the buffer
        this->read_memory(this->readmem<uint64_t>(address), (uint64_t)&buffer, sizeof(buffer) - 1);

        // return buffer string
        return std::string(buffer);
    }

	std::string ReadString(uint64_t address) {
		return ReadMonoString(address);
	}

	uint64_t __fastcall IL2CPPScan(const char* class_name)
	{
		uint64_t base = gBase;
		IMAGE_DOS_HEADER dos_header = this->readmem<IMAGE_DOS_HEADER>(base);
		IMAGE_SECTION_HEADER data_header = this->readmem<IMAGE_SECTION_HEADER>(base + dos_header.e_lfanew + sizeof(IMAGE_NT_HEADERS64) + (3 * 40));
		IMAGE_SECTION_HEADER next_section = this->readmem<IMAGE_SECTION_HEADER>(base + dos_header.e_lfanew + sizeof(IMAGE_NT_HEADERS64) + (4 * 40));
		DWORD data_size = next_section.VirtualAddress - data_header.VirtualAddress;

		if (memcmp(data_header.Name, ".data", 6))
			return 0;

		for (uint64_t offset = data_size; offset > 0; offset -= 8) {
			char klass_name[0x100] = { 0 };
			auto klass = this->readmem<uint64_t>(base + data_header.VirtualAddress + offset);
			if (klass == 0) continue;

			auto name_pointer = this->readmem<uint64_t>(klass + 0x10);
			if (name_pointer == 0) continue;
			this->read_memory(name_pointer, (uint64_t)klass_name, sizeof(klass_name));

			if (!strcmp(klass_name, class_name))
				return klass;
		}

		return 0;
	}
};



extern kernelmode_proc_handler kernelHandler;

 
