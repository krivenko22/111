#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif

#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif

#include <algorithm>
#include <cmath>
#include <functional>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"

#include "colors.h"
#include "RenderFeature.h"

class InterfaceManager
{
public:
    using DrawCallback =
        std::function<
        void(
            ImDrawList* draw,
            const ImRect& rect,
            float alpha,
            float scale
            )
        >;

    struct InterfaceElement
    {
        std::string id;
        std::string name;

        // Позиция относительно main viewport.
        ImVec2 position = {
            0.f,
            0.f
        };

        // Сохранённая позиция после Apply().
        ImVec2 savedPosition = {
            0.f,
            0.f
        };

        // Позиция по умолчанию для Reset().
        ImVec2 defaultPosition = {
            0.f,
            0.f
        };

        // Реальный размер элемента в пикселях.
        ImVec2 size = {
            100.f,
            30.f
        };

        bool visible = true;
        bool draggable = true;

        DrawCallback drawCallback;
    };

private:
    std::vector<InterfaceElement> elements;

    int selectedElement = -1;

    bool dragging = false;

    ImVec2 dragStartMouse = {
        0.f,
        0.f
    };

    ImVec2 dragStartPosition = {
        0.f,
        0.f
    };

    static float Clamp01(
        float value
    )
    {
        if (value < 0.f)
            return 0.f;

        if (value > 1.f)
            return 1.f;

        return value;
    }

    static ImVec4 LerpColor(
        const ImVec4& a,
        const ImVec4& b,
        float t
    )
    {
        t = Clamp01(t);

        return ImVec4(
            a.x + (b.x - a.x) * t,
            a.y + (b.y - a.y) * t,
            a.z + (b.z - a.z) * t,
            a.w + (b.w - a.w) * t
        );
    }

    static ImU32 ColorU32(
        const ImVec4& color
    )
    {
        return ImGui::ColorConvertFloat4ToU32(
            color
        );
    }

    InterfaceElement* GetElement(
        int index
    )
    {
        if (
            index < 0 ||
            index >= static_cast<int>(
                elements.size()
                )
            )
        {
            return nullptr;
        }

        return &elements[
            static_cast<std::size_t>(
                index
                )
        ];
    }

    const InterfaceElement* GetElement(
        int index
    ) const
    {
        if (
            index < 0 ||
            index >= static_cast<int>(
                elements.size()
                )
            )
        {
            return nullptr;
        }

        return &elements[
            static_cast<std::size_t>(
                index
                )
        ];
    }

    static ImVec2 ClampPosition(
        const ImVec2& position,
        const ImVec2& size,
        const ImVec2& viewportSize
    )
    {
        ImVec2 result =
            position;

        const float maxX =
            ImMax(
                0.f,
                viewportSize.x -
                size.x
            );

        const float maxY =
            ImMax(
                0.f,
                viewportSize.y -
                size.y
            );

        result.x =
            ImClamp(
                result.x,
                0.f,
                maxX
            );

        result.y =
            ImClamp(
                result.y,
                0.f,
                maxY
            );

        return result;
    }

    static void DrawWatermark(
        ImDrawList* draw,
        const ImRect& rect,
        float alpha,
        float scale
    )
    {
        if (!draw)
            return;

        alpha =
            Clamp01(
                alpha
            );

        scale =
            ImMax(
                0.001f,
                scale
            );

        ImFont* font =
            ImGui::GetFont();

        if (!font)
            return;

        const float baseFontSize =
            13.f;

        const float fontSize =
            baseFontSize *
            scale;

        const char* title =
            "ELYSIUM";

        const char* suffix =
            "EXTERNAL";

        const ImVec2 titleSize =
            font->CalcTextSizeA(
                fontSize,
                FLT_MAX,
                0.f,
                title
            );

        const ImVec2 suffixSize =
            font->CalcTextSizeA(
                fontSize,
                FLT_MAX,
                0.f,
                suffix
            );

        const float padding =
            19.f *
            scale;

        const float gap =
            8.f *
            scale;

        const float expectedWidth =
            titleSize.x +
            gap +
            suffixSize.x +
            padding * 2.f;

        const float expectedHeight =
            34.f *
            scale;

        const ImVec2 center =
            rect.GetCenter();

        const float width =
            ImMax(
                rect.GetWidth(),
                expectedWidth
            );

        const float height =
            ImMax(
                rect.GetHeight(),
                expectedHeight
            );

        const ImVec2 min(
            center.x -
            width * 0.5f,

            center.y -
            height * 0.5f
        );

        const ImVec2 max(
            center.x +
            width * 0.5f,

            center.y +
            height * 0.5f
        );

        draw->AddRectFilled(
            min,
            max,
            ColorU32(
                ImVec4(
                    0.017f,
                    0.018f,
                    0.028f,
                    0.94f *
                    alpha
                )
            ),
            10.f *
            scale
        );

        draw->AddRect(
            ImVec2(
                min.x + 0.5f,
                min.y + 0.5f
            ),
            ImVec2(
                max.x - 0.5f,
                max.y - 0.5f
            ),
            ColorU32(
                ImVec4(
                    1.f,
                    1.f,
                    1.f,
                    0.04f *
                    alpha
                )
            ),
            10.f *
            scale,
            ImDrawFlags_RoundCornersAll,
            ImMax(
                0.75f,
                scale
            )
        );

        const float contentWidth =
            titleSize.x +
            gap +
            suffixSize.x;

        float x =
            center.x -
            contentWidth *
            0.5f;

        const float y =
            center.y -
            titleSize.y *
            0.5f;

        ImVec4 accent =
            RenderFeature::AccentGradient(
                std::fmod(
                    static_cast<float>(
                        ImGui::GetTime()
                        ) *
                    0.18f,
                    1.f
                )
            );

        accent.w =
            alpha;

        draw->AddText(
            font,
            fontSize,
            ImVec2(
                x,
                y
            ),
            ColorU32(
                accent
            ),
            title
        );

        x +=
            titleSize.x +
            gap;

        draw->AddText(
            font,
            fontSize,
            ImVec2(
                x,
                y
            ),
            ColorU32(
                ImVec4(
                    0.52f,
                    0.53f,
                    0.60f,
                    alpha
                )
            ),
            suffix
        );
    }

public:

    InterfaceManager()
    {
        RegisterWatermark();
    }

    // =========================================================
    // REGISTER
    // =========================================================

    bool RegisterElement(
        const std::string& id,
        const std::string& name,
        const ImVec2& defaultPosition,
        const ImVec2& size,
        DrawCallback drawCallback,
        bool draggable = true,
        bool visible = true
    )
    {
        if (
            id.empty() ||
            !drawCallback
            )
        {
            return false;
        }

        for (
            const auto& element :
            elements
            )
        {
            if (element.id == id)
                return false;
        }

        InterfaceElement element;

        element.id =
            id;

        element.name =
            name;

        element.position =
            defaultPosition;

        element.savedPosition =
            defaultPosition;

        element.defaultPosition =
            defaultPosition;

        element.size =
            ImVec2(
                ImMax(
                    1.f,
                    size.x
                ),
                ImMax(
                    1.f,
                    size.y
                )
            );

        element.visible =
            visible;

        element.draggable =
            draggable;

        element.drawCallback =
            std::move(
                drawCallback
            );

        elements.push_back(
            std::move(
                element
            )
        );

        return true;
    }

    // =========================================================
    // DEFAULT WATERMARK
    // =========================================================

    bool RegisterWatermark()
    {
        return RegisterElement(
            "watermark",
            "Watermark",
            ImVec2(
                16.f,
                16.f
            ),
            ImVec2(
                156.f,
                34.f
            ),
            [](
                ImDrawList* draw,
                const ImRect& rect,
                float alpha,
                float scale
                )
            {
                DrawWatermark(
                    draw,
                    rect,
                    alpha,
                    scale
                );
            }
        );
    }

    // =========================================================
    // OVERLAY
    // =========================================================

    void RenderOverlay(
        float alpha = 1.f
    ) const
    {
        ImGuiViewport* viewport =
            ImGui::GetMainViewport();

        ImDrawList* draw =
            ImGui::GetBackgroundDrawList();

        if (
            !viewport ||
            !draw
            )
        {
            return;
        }

        alpha =
            Clamp01(
                alpha
            );

        if (alpha <= 0.001f)
            return;

        for (
            const auto& element :
            elements
            )
        {
            if (
                !element.visible ||
                !element.drawCallback
                )
            {
                continue;
            }

            const ImVec2 min(
                viewport->Pos.x +
                element.position.x,

                viewport->Pos.y +
                element.position.y
            );

            const ImVec2 max(
                min.x +
                element.size.x,

                min.y +
                element.size.y
            );

            element.drawCallback(
                draw,
                ImRect(
                    min,
                    max
                ),
                alpha,
                1.f
            );
        }
    }

    // =========================================================
    // EDITOR CANVAS
    // =========================================================

    void RenderEditorCanvas(
        const ImRect& panelRect,
        float alpha,
        bool interactive
    )
    {
        ImGuiViewport* viewport =
            ImGui::GetMainViewport();

        ImDrawList* draw =
            ImGui::GetWindowDrawList();

        if (
            !viewport ||
            !draw
            )
        {
            return;
        }

        alpha =
            Clamp01(
                alpha
            );

        if (alpha <= 0.001f)
            return;

        const ImVec2 displaySize =
            viewport->Size;

        if (
            displaySize.x <= 1.f ||
            displaySize.y <= 1.f
            )
        {
            return;
        }

        // =====================================================
        // EDITOR BACKGROUND
        // =====================================================

        draw->AddRectFilled(
            panelRect.Min,
            panelRect.Max,
            ColorU32(
                ImVec4(
                    0.004f,
                    0.005f,
                    0.010f,
                    0.93f *
                    alpha
                )
            ),
            14.f
        );

        draw->AddRect(
            ImVec2(
                panelRect.Min.x + 0.5f,
                panelRect.Min.y + 0.5f
            ),
            ImVec2(
                panelRect.Max.x - 0.5f,
                panelRect.Max.y - 0.5f
            ),
            ColorU32(
                ImVec4(
                    1.f,
                    1.f,
                    1.f,
                    0.055f *
                    alpha
                )
            ),
            14.f,
            ImDrawFlags_RoundCornersAll,
            1.f
        );

        ImFont* font =
            ImGui::GetFont();

        if (font)
        {
            draw->AddText(
                font,
                15.f,
                ImVec2(
                    panelRect.Min.x +
                    24.f,

                    panelRect.Min.y +
                    18.f
                ),
                ColorU32(
                    ImVec4(
                        0.90f,
                        0.91f,
                        0.97f,
                        alpha
                    )
                ),
                "Настройка интерфейса"
            );

            const InterfaceElement*
                selected =
                GetElement(
                    selectedElement
                );

            if (selected)
            {
                draw->AddText(
                    font,
                    12.f,
                    ImVec2(
                        panelRect.Max.x -
                        24.f -
                        font->CalcTextSizeA(
                            12.f,
                            FLT_MAX,
                            0.f,
                            selected->name.c_str()
                        ).x,

                        panelRect.Min.y +
                        21.f
                    ),
                    ColorU32(
                        ImVec4(
                            colors::accent.x,
                            colors::accent.y,
                            colors::accent.z,
                            0.85f *
                            alpha
                        )
                    ),
                    selected->name.c_str()
                );
            }
        }

        // =====================================================
        // CANVAS
        // =====================================================

        const ImRect canvas(
            ImVec2(
                panelRect.Min.x +
                22.f,

                panelRect.Min.y +
                52.f
            ),
            ImVec2(
                panelRect.Max.x -
                22.f,

                panelRect.Max.y -
                76.f
            )
        );

        draw->AddRectFilled(
            canvas.Min,
            canvas.Max,
            ColorU32(
                ImVec4(
                    0.008f,
                    0.009f,
                    0.017f,
                    0.97f *
                    alpha
                )
            ),
            11.f
        );

        draw->PushClipRect(
            canvas.Min,
            canvas.Max,
            true
        );

        const float availableWidth =
            ImMax(
                1.f,
                canvas.GetWidth() -
                20.f
            );

        const float availableHeight =
            ImMax(
                1.f,
                canvas.GetHeight() -
                20.f
            );

        float scale =
            ImMin(
                availableWidth /
                displaySize.x,

                availableHeight /
                displaySize.y
            );

        scale =
            ImClamp(
                scale,
                0.05f,
                1.f
            );

        const ImVec2 screenSize(
            displaySize.x *
            scale,

            displaySize.y *
            scale
        );

        const ImVec2 screenMin(
            canvas.GetCenter().x -
            screenSize.x *
            0.5f,

            canvas.GetCenter().y -
            screenSize.y *
            0.5f
        );

        const ImVec2 screenMax(
            screenMin.x +
            screenSize.x,

            screenMin.y +
            screenSize.y
        );

        // =====================================================
        // OUTER CANVAS
        // =====================================================

        draw->AddRectFilled(
            screenMin,
            screenMax,
            ColorU32(
                ImVec4(
                    0.015f,
                    0.016f,
                    0.026f,
                    0.98f *
                    alpha
                )
            ),
            8.f
        );

        draw->AddRect(
            ImVec2(
                screenMin.x + 0.5f,
                screenMin.y + 0.5f
            ),
            ImVec2(
                screenMax.x - 0.5f,
                screenMax.y - 0.5f
            ),
            ColorU32(
                ImVec4(
                    1.f,
                    1.f,
                    1.f,
                    0.10f *
                    alpha
                )
            ),
            8.f,
            ImDrawFlags_RoundCornersAll,
            1.f
        );

        // =====================================================
        // GRID
        // =====================================================

        constexpr float GRID_STEP = 64.f;
        constexpr float MAJOR_GRID_STEP = 320.f;

        for (
            float x = 0.f;
            x <= displaySize.x;
            x += GRID_STEP
            )
        {
            const bool major =
                std::fmod(
                    x,
                    MAJOR_GRID_STEP
                ) < 0.1f;

            const float lineAlpha =
                major
                ? 0.10f
                : 0.045f;

            const float lineThickness =
                major
                ? 1.0f
                : 0.65f;

            const float screenX =
                screenMin.x +
                x *
                scale;

            draw->AddLine(
                ImVec2(
                    screenX,
                    screenMin.y
                ),
                ImVec2(
                    screenX,
                    screenMax.y
                ),
                ColorU32(
                    ImVec4(
                        0.40f,
                        0.36f,
                        0.58f,
                        lineAlpha *
                        alpha
                    )
                ),
                lineThickness
            );
        }

        for (
            float y = 0.f;
            y <= displaySize.y;
            y += GRID_STEP
            )
        {
            const bool major =
                std::fmod(
                    y,
                    MAJOR_GRID_STEP
                ) < 0.1f;

            const float lineAlpha =
                major
                ? 0.10f
                : 0.045f;

            const float lineThickness =
                major
                ? 1.0f
                : 0.65f;

            const float screenY =
                screenMin.y +
                y *
                scale;

            draw->AddLine(
                ImVec2(
                    screenMin.x,
                    screenY
                ),
                ImVec2(
                    screenMax.x,
                    screenY
                ),
                ColorU32(
                    ImVec4(
                        0.40f,
                        0.36f,
                        0.58f,
                        lineAlpha *
                        alpha
                    )
                ),
                lineThickness
            );
        }

        // =====================================================
        // CENTER LINES
        // =====================================================

        draw->AddLine(
            ImVec2(
                screenMin.x +
                screenSize.x *
                0.5f,

                screenMin.y
            ),
            ImVec2(
                screenMin.x +
                screenSize.x *
                0.5f,

                screenMax.y
            ),
            ColorU32(
                ImVec4(
                    colors::accent.x,
                    colors::accent.y,
                    colors::accent.z,
                    0.12f *
                    alpha
                )
            ),
            1.f
        );

        draw->AddLine(
            ImVec2(
                screenMin.x,
                screenMin.y +
                screenSize.y *
                0.5f
            ),
            ImVec2(
                screenMax.x,
                screenMin.y +
                screenSize.y *
                0.5f
            ),
            ColorU32(
                ImVec4(
                    colors::accent.x,
                    colors::accent.y,
                    colors::accent.z,
                    0.12f *
                    alpha
                )
            ),
            1.f
        );

        // =====================================================
        // SCREEN LABEL
        // =====================================================

        if (font)
        {
            const char* screenLabel =
                "SCREEN";

            draw->AddText(
                font,
                10.f,
                ImVec2(
                    screenMin.x +
                    10.f,

                    screenMin.y +
                    8.f
                ),
                ColorU32(
                    ImVec4(
                        0.60f,
                        0.61f,
                        0.69f,
                        0.45f *
                        alpha
                    )
                ),
                screenLabel
            );
        }

        // =====================================================
        // ELEMENTS
        // =====================================================

        std::vector<ImRect> elementRects;

        elementRects.reserve(
            elements.size()
        );

        for (
            const auto& element :
            elements
            )
        {
            const ImVec2 min(
                screenMin.x +
                element.position.x *
                scale,

                screenMin.y +
                element.position.y *
                scale
            );

            const ImVec2 size(
                element.size.x *
                scale,

                element.size.y *
                scale
            );

            elementRects.emplace_back(
                min,
                ImVec2(
                    min.x + size.x,
                    min.y + size.y
                )
            );
        }

        for (
            std::size_t i = 0;
            i < elements.size();
            ++i
            )
        {
            InterfaceElement& element =
                elements[i];

            if (
                !element.visible ||
                !element.drawCallback
                )
            {
                continue;
            }

            element.drawCallback(
                draw,
                elementRects[i],
                alpha,
                scale
            );

            if (
                static_cast<int>(i) ==
                selectedElement
                )
            {
                const ImRect& rect =
                    elementRects[i];

                draw->AddRect(
                    ImVec2(
                        rect.Min.x -
                        2.f,

                        rect.Min.y -
                        2.f
                    ),
                    ImVec2(
                        rect.Max.x +
                        2.f,

                        rect.Max.y +
                        2.f
                    ),
                    ColorU32(
                        ImVec4(
                            colors::accent.x,
                            colors::accent.y,
                            colors::accent.z,
                            0.95f *
                            alpha
                        )
                    ),
                    6.f,
                    ImDrawFlags_RoundCornersAll,
                    1.5f
                );

                const float handleSize =
                    5.f;

                draw->AddCircleFilled(
                    rect.Max,
                    handleSize,
                    ColorU32(
                        ImVec4(
                            colors::accent.x,
                            colors::accent.y,
                            colors::accent.z,
                            0.95f *
                            alpha
                        )
                    ),
                    12
                );
            }
        }

        // =====================================================
        // MOUSE EDITING
        // =====================================================

        if (interactive)
        {
            const ImVec2 mouse =
                ImGui::GetIO().MousePos;

            bool mouseOverElement =
                false;

            for (
                std::size_t reverse =
                elements.size();
                reverse > 0;
                --reverse
                )
            {
                const std::size_t i =
                    reverse - 1;

                InterfaceElement& element =
                    elements[i];

                if (
                    !element.visible
                    )
                {
                    continue;
                }

                ImRect hitRect =
                    elementRects[i];

                hitRect.Min.x -= 4.f;
                hitRect.Min.y -= 4.f;
                hitRect.Max.x += 4.f;
                hitRect.Max.y += 4.f;

                if (!hitRect.Contains(mouse))
                    continue;

                mouseOverElement =
                    true;

                if (
                    ImGui::IsMouseClicked(
                        ImGuiMouseButton_Left
                    )
                    )
                {
                    selectedElement =
                        static_cast<int>(i);

                    dragging =
                        element.draggable;

                    dragStartMouse =
                        mouse;

                    dragStartPosition =
                        element.position;
                }

                break;
            }

            if (
                ImGui::IsMouseClicked(
                    ImGuiMouseButton_Left
                ) &&
                canvas.Contains(mouse) &&
                !mouseOverElement
                )
            {
                selectedElement =
                    -1;

                dragging =
                    false;
            }

            if (dragging)
            {
                InterfaceElement* selected =
                    GetElement(
                        selectedElement
                    );

                if (
                    !selected ||
                    !selected->draggable
                    )
                {
                    dragging =
                        false;
                }
                else if (
                    !ImGui::IsMouseDown(
                        ImGuiMouseButton_Left
                    )
                    )
                {
                    dragging =
                        false;
                }
                else
                {
                    const ImVec2 delta(
                        (
                            mouse.x -
                            dragStartMouse.x
                            ) /
                        scale,

                        (
                            mouse.y -
                            dragStartMouse.y
                            ) /
                        scale
                    );

                    ImVec2 nextPosition(
                        dragStartPosition.x +
                        delta.x,

                        dragStartPosition.y +
                        delta.y
                    );

                    nextPosition =
                        ClampPosition(
                            nextPosition,
                            selected->size,
                            displaySize
                        );

                    if (
                        std::fabs(
                            nextPosition.x -
                            selected->position.x
                        ) > 0.01f ||
                        std::fabs(
                            nextPosition.y -
                            selected->position.y
                        ) > 0.01f
                        )
                    {
                        selected->position =
                            nextPosition;
                    }
                }
            }
        }

        draw->PopClipRect();

        // =====================================================
        // HINT
        // =====================================================

        if (font)
        {
            const char* hint =
                "Перетаскивайте элементы мышью";

            const ImVec2 hintSize =
                font->CalcTextSizeA(
                    11.f,
                    FLT_MAX,
                    0.f,
                    hint
                );

            draw->AddText(
                font,
                11.f,
                ImVec2(
                    canvas.Max.x -
                    hintSize.x,

                    canvas.Max.y +
                    10.f
                ),
                ColorU32(
                    ImVec4(
                        0.48f,
                        0.49f,
                        0.57f,
                        0.65f *
                        alpha
                    )
                ),
                hint
            );
        }

        if (dragging)
        {
            // Простой визуальный индикатор drag.
            const InterfaceElement*
                selected =
                GetElement(
                    selectedElement
                );

            if (
                selected &&
                font
                )
            {
                const ImVec2 position =
                    selected->position;

                char buffer[96];

                sprintf_s(
                    buffer,
                    "%s  |  X %.0f  Y %.0f",
                    selected->name.c_str(),
                    position.x,
                    position.y
                );

                draw->AddText(
                    font,
                    11.f,
                    ImVec2(
                        panelRect.Min.x +
                        24.f,

                        panelRect.Max.y -
                        48.f
                    ),
                    ColorU32(
                        ImVec4(
                            0.65f,
                            0.66f,
                            0.75f,
                            0.85f *
                            alpha
                        )
                    ),
                    buffer
                );
            }
        }
    }

    // =========================================================
    // STATE
    // =========================================================

    bool HasUnsavedChanges() const
    {
        for (
            const auto& element :
            elements
            )
        {
            if (
                std::fabs(
                    element.position.x -
                    element.savedPosition.x
                ) > 0.01f ||
                std::fabs(
                    element.position.y -
                    element.savedPosition.y
                ) > 0.01f
                )
            {
                return true;
            }
        }

        return false;
    }

    // Применить изменения.
    void Apply()
    {
        for (
            auto& element :
            elements
            )
        {
            element.savedPosition =
                element.position;
        }
    }

    // Сбросить к заводским позициям.
    void ResetToDefaults()
    {
        for (
            auto& element :
            elements
            )
        {
            element.position =
                element.defaultPosition;
        }
    }

    // Отменить несохранённые изменения.
    void DiscardChanges()
    {
        for (
            auto& element :
            elements
            )
        {
            element.position =
                element.savedPosition;
        }

        dragging =
            false;

        selectedElement =
            -1;
    }

    // =========================================================
    // ACCESS
    // =========================================================

    int GetSelectedElement() const
    {
        return selectedElement;
    }

    const char* GetSelectedElementName() const
    {
        const InterfaceElement*
            element =
            GetElement(
                selectedElement
            );

        if (!element)
            return nullptr;

        return element->name.c_str();
    }

    std::vector<
        InterfaceElement
    >& GetElements()
    {
        return elements;
    }

    const std::vector<
        InterfaceElement
    >& GetElements() const
    {
        return elements;
    }

    void ClearSelection()
    {
        selectedElement =
            -1;

        dragging =
            false;
    }
};
