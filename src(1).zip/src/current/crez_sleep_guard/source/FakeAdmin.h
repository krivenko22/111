#pragma once
#include "Feature.h"
#include "RenderFeature.h"
#include "imgui/imgui.h"
// Older implementation wrote player flags even while disabled when it detected
// the admin bit. This build has no verified local identity/flag write address.
class FakeAdminModule : public Module {
public:
    FakeAdminModule():Module(_xorstr("Fake Admin (недоступен)"),ModuleCategory::Player) {}
    void OnRenderMenu() override {
        bool unavailable=false;
        ImGui::BeginDisabled(); ImGui::Checkbox(_xorstr("Fake Admin (запись не проверена)"),&unavailable); ImGui::EndDisabled();
    }
    void OnRenderOverlay() override {}
};
