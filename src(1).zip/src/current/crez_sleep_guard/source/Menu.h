#include "last_config.h"
#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif

#ifdef min
#undef min
#endif
#ifdef max
#undef max
#endif

#include <windows.h>
#include <d3d11.h>

#include <algorithm>
#include <cmath>
#include <cfloat>
#include <cstdint>
#include <cstdio>
#include <functional>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"

#include "FeatureManager.h"
#include "font.h"
#include "colors.h"
#include "layout.h"
#include "playerinventory.h"
#include "ui_scale.h"
#include "icons.h"
#include "fontello_data.h"
#include "RenderFeature.h"
#include "targethud.h"
#include "Network.h"
#include "Radar.h"
#include "aim.h"

namespace ElysiumMenuPalette
{
    static const ImVec4 Accent = ImVec4(0.67f, 0.035f, 0.13f, 1.f);
    static const ImVec4 AccentSoft = ImVec4(0.38f, 0.025f, 0.07f, 1.f);
    static const ImVec4 Surface = ImVec4(0.045f, 0.045f, 0.047f, 1.f);
    static const ImVec4 Sidebar = ImVec4(0.035f, 0.035f, 0.037f, 1.f);
    static const ImVec4 Header = ImVec4(0.050f, 0.050f, 0.052f, 1.f);
    static const ImVec4 Control = ImVec4(0.080f, 0.080f, 0.084f, 1.f);
    static const ImVec4 ControlHover = ImVec4(0.115f, 0.110f, 0.114f, 1.f);
    static const ImVec4 Dropdown = ImVec4(0.065f, 0.065f, 0.068f, 0.99f);
    static const ImVec4 Separator = ImVec4(0.19f, 0.19f, 0.20f, 0.70f);
    static const ImVec4 ConfigHover = ImVec4(0.115f, 0.11f, 0.114f, 1.f);
    static const ImVec4 Text = ImVec4(0.94f, 0.94f, 0.94f, 1.f);
    static const ImVec4 TextMuted = ImVec4(0.64f, 0.63f, 0.64f, 1.f);
}

class InterfaceManager
{
public:
    using DrawCallback = std::function<void(ImDrawList* draw, const ImRect& rect, float alpha, float scale)>;

    struct InterfaceElement
    {
        std::string id;
        std::string name;

        ImVec2 position = { 0.f, 0.f };
        ImVec2 savedPosition = { 0.f, 0.f };
        ImVec2 defaultPosition = { 0.f, 0.f };
        ImVec2 size = { 100.f, 30.f };

        bool visible = true;
        bool draggable = true;

        DrawCallback drawCallback;
    };

private:
    std::vector<InterfaceElement> elements;
    struct SavedAxes {float x=0,y=0;bool hasX=false,hasY=false;};
    std::unordered_map<std::string,SavedAxes> pendingConfigPositions;
    std::vector<ImRect> frameRects;

    int selectedElement = -1;
    bool dragging = false;

    ImVec2 dragGrabOffset = { 0.f, 0.f };
    ImVec2 dragStartMouse = { 0.f, 0.f };
    ImVec2 dragStartPosition = { 0.f, 0.f };


    static float Clamp01(float value)
    {
        return ImClamp(value, 0.f, 1.f);
    }

    static ImVec4 LerpColor(const ImVec4& a, const ImVec4& b, float t)
    {
        t = Clamp01(t);
        return ImVec4(
            a.x + (b.x - a.x) * t,
            a.y + (b.y - a.y) * t,
            a.z + (b.z - a.z) * t,
            a.w + (b.w - a.w) * t
        );
    }

    static ImU32 ColorU32(const ImVec4& color)
    {
        return ImGui::ColorConvertFloat4ToU32(color);
    }

    InterfaceElement* GetElement(int index)
    {
        if (index < 0 || index >= static_cast<int>(elements.size()))
            return nullptr;
        return &elements[static_cast<std::size_t>(index)];
    }

    const InterfaceElement* GetElement(int index) const
    {
        if (index < 0 || index >= static_cast<int>(elements.size()))
            return nullptr;
        return &elements[static_cast<std::size_t>(index)];
    }

    static ImVec2 ClampPosition(const ImVec2& position, const ImVec2& size, const ImVec2& viewportSize)
    {
        ImVec2 result = position;
        const float maxX = ImMax(0.f, viewportSize.x - size.x);
        const float maxY = ImMax(0.f, viewportSize.y - size.y);
        result.x = ImClamp(result.x, 0.f, maxX);
        result.y = ImClamp(result.y, 0.f, maxY);
        return result;
    }

    static void DrawWatermark(ImDrawList* draw, const ImRect& rect, float alpha, float scale)
    {
        if (!draw)
            return;

        alpha = Clamp01(alpha);
        scale = ImMax(0.001f, scale);

        ImFont* font = ImGui::GetFont();
        if (!font)
            return;

        const float fontSize = 14.f * scale;
        const float modeSize_ = 12.f * scale;
        const float timeSize_ = 11.5f * scale;

        const char* brand = "CREZ";
        const char* mode = "External";
        const std::string timeText = Network::GetCurrentTimeString(true);

        const ImVec2 brandSize = font->CalcTextSizeA(fontSize, FLT_MAX, 0.f, brand);
        const ImVec2 modeSize = font->CalcTextSizeA(modeSize_, FLT_MAX, 0.f, mode);
        const ImVec2 timeSize = font->CalcTextSizeA(timeSize_, FLT_MAX, 0.f, timeText.c_str());

        const float paddingX = 15.f * scale;
        const float dotSize = 3.2f * scale;
        const float gap = 9.f * scale;
        const float statusGap = 12.f * scale;


        const float sepWidth = 1.f * scale;
        const float sepPad = 10.f * scale;

        const float width = ImMax(
            rect.GetWidth(),
            paddingX * 2.f
            + dotSize * 2.f
            + brandSize.x
            + gap
            + sepPad * 2.f + sepWidth
            + gap
            + modeSize.x
            + statusGap
            + dotSize * 2.f
            + 5.f * scale
            + timeSize.x
        );

        const float height = ImMax(rect.GetHeight(), 28.f * scale);
        const ImVec2 center = rect.GetCenter();

        const ImVec2 min(
            center.x - width * 0.5f,
            center.y - height * 0.5f
        );

        const ImVec2 max(
            center.x + width * 0.5f,
            center.y + height * 0.5f
        );

        const ImVec4 bg(
            0.014f,
            0.015f,
            0.019f,
            0.94f * alpha
        );

        const ImVec4 border(
            1.f,
            1.f,
            1.f,
            0.055f * alpha
        );

        draw->AddRectFilled(
            min,
            max,
            ColorU32(bg),
            8.f * scale
        );

        draw->AddRect(
            ImVec2(min.x + 0.5f, min.y + 0.5f),
            ImVec2(max.x - 0.5f, max.y - 0.5f),
            ColorU32(border),
            8.f * scale,
            ImDrawFlags_RoundCornersAll,
            ImMax(0.75f, scale)
        );


        const ImVec4 separatorCol(
            1.f,
            1.f,
            1.f,
            0.085f * alpha
        );

        float x = min.x + paddingX;




        {
            const float textY = center.y - brandSize.y * 0.5f;

            draw->AddText(
                font,
                fontSize,
                ImVec2(x, textY),
                ColorU32(ImVec4(
                    0.98f,
                    0.97f,
                    1.00f,
                    alpha
                )),
                brand
            );

            x += brandSize.x + gap;
        }


        {
            const float sepH = height * 0.42f;
            const float sepY = center.y - sepH * 0.5f;

            x += sepPad;

            draw->AddRectFilled(
                ImVec2(x, sepY),
                ImVec2(x + sepWidth, sepY + sepH),
                ColorU32(separatorCol),
                sepWidth * 0.5f
            );

            x += sepWidth + sepPad;
        }




        {
            const float textY = center.y - modeSize.y * 0.5f;

            draw->AddText(
                font,
                modeSize_,
                ImVec2(x, textY),
                ColorU32(ImVec4(
                    0.86f,
                    0.82f,
                    0.93f,
                    alpha
                )),
                mode
            );

            x += modeSize.x + statusGap;
        }




        {
            draw->AddCircleFilled(
                ImVec2(x + dotSize, center.y),
                dotSize,
                ColorU32(ImVec4(
                    0.40f,
                    0.82f,
                    0.60f,
                    alpha
                )),
                16
            );

            x += dotSize * 2.f + 5.f * scale;
        }




        {
            const float textY = center.y - timeSize.y * 0.5f;

            draw->AddText(
                font,
                timeSize_,
                ImVec2(x, textY),
                ColorU32(ImVec4(
                    0.82f,
                    0.84f,
                    0.90f,
                    alpha
                )),
                timeText.c_str()
            );
        }
    }

public:
    InterfaceManager()
    {
        RegisterWatermark();
    }

    float ConfigPosition(const std::string& id,bool y) const {
        for(const auto& e:elements)if(e.id==id)return y?e.position.y:e.position.x;
        auto it=pendingConfigPositions.find(id);if(it==pendingConfigPositions.end())return 0.f;
        return y?it->second.y:it->second.x;
    }
    void SetConfigPosition(const std::string& id,bool y,float v){
        auto& p=pendingConfigPositions[id];if(y){p.y=v;p.hasY=true;}else{p.x=v;p.hasX=true;}
        for(auto& e:elements)if(e.id==id){if(y)e.position.y=e.savedPosition.y=v;else e.position.x=e.savedPosition.x=v;break;}
    }

    bool RegisterElement(
        const std::string& id,
        const std::string& name,
        const ImVec2& defaultPosition,
        const ImVec2& size,
        DrawCallback drawCallback,
        bool draggable = true,
        bool visible = true
    )
    {
        if (id.empty() || !drawCallback)
            return false;

        for (const auto& element : elements)
        {
            if (element.id == id)
                return false;
        }

        InterfaceElement element;
        element.id = id;
        element.name = name;
        element.position = defaultPosition;
        element.savedPosition = defaultPosition;
        element.defaultPosition = defaultPosition;
        element.size = ImVec2(ImMax(1.f, size.x), ImMax(1.f, size.y));
        element.visible = visible;
        element.draggable = draggable;
        element.drawCallback = std::move(drawCallback);

        auto pending=pendingConfigPositions.find(id);
        if(pending!=pendingConfigPositions.end()){
            if(pending->second.hasX)element.position.x=element.savedPosition.x=pending->second.x;
            if(pending->second.hasY)element.position.y=element.savedPosition.y=pending->second.y;
        }
        elements.push_back(std::move(element));
        frameRects.resize(elements.size());
        return true;
    }

    bool RegisterWatermark()
    {
        return RegisterElement(
            "watermark",
            "Watermark",
            ImVec2(16.f, 16.f),
            ImVec2(236.f, 34.f),
            [](ImDrawList* draw, const ImRect& rect, float alpha, float scale)
            {
                DrawWatermark(draw, rect, alpha, scale);
            }
        );
    }

    void RenderOverlay(float alpha = 1.f, bool interactive = false)
    {
        ImGuiViewport* viewport = ImGui::GetMainViewport();
        ImDrawList* draw = ImGui::GetBackgroundDrawList();

        if (!viewport || !draw)
            return;

        alpha = Clamp01(alpha);
        if (alpha <= 0.001f)
            return;

        const ImVec2 viewportSize = viewport->Size;
        const ImVec2 mouse = ImGui::GetIO().MousePos;

        if (!interactive)
        {
            dragging = false;
            selectedElement = -1;
        }

        frameRects.resize(elements.size());

        for (std::size_t i = 0; i < elements.size(); ++i)
        {
            const InterfaceElement& element = elements[i];
            const ImVec2 min(
                viewport->Pos.x + element.position.x,
                viewport->Pos.y + element.position.y
            );
            frameRects[i] = ImRect(
                min,
                ImVec2(min.x + element.size.x, min.y + element.size.y)
            );
        }

        int hoveredElement = -1;

        if (interactive)
        {
            for (std::size_t reverse = elements.size(); reverse > 0; --reverse)
            {
                const std::size_t i = reverse - 1;
                const InterfaceElement& element = elements[i];
                if (!element.visible || !element.draggable)
                    continue;

                ImRect hitRect = frameRects[i];
                hitRect.Min.x -= 4.f;
                hitRect.Min.y -= 4.f;
                hitRect.Max.x += 4.f;
                hitRect.Max.y += 4.f;

                if (hitRect.Contains(mouse))
                {
                    hoveredElement = static_cast<int>(i);
                    break;
                }
            }

            if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && hoveredElement >= 0)
            {
                selectedElement = hoveredElement;
                dragging = false;

                const InterfaceElement* selected = GetElement(selectedElement);
                if (selected)
                {
                    dragGrabOffset = ImVec2(
                        mouse.x - (viewport->Pos.x + selected->position.x),
                        mouse.y - (viewport->Pos.y + selected->position.y)
                    );
                    dragStartMouse = mouse;
                    dragStartPosition = selected->position;
                    dragging = true;
                }
            }

            if (dragging && !ImGui::IsMouseDown(ImGuiMouseButton_Left))
                dragging = false;

            if (dragging)
            {
                InterfaceElement* selected = GetElement(selectedElement);
                if (!selected || !selected->draggable)
                {
                    dragging = false;
                }
                else if (std::isfinite(mouse.x) && std::isfinite(mouse.y))
                {
                    const ImVec2 nextPosition(
                        mouse.x - viewport->Pos.x - dragGrabOffset.x,
                        mouse.y - viewport->Pos.y - dragGrabOffset.y
                    );

                    selected->position = ClampPosition(
                        nextPosition,
                        selected->size,
                        viewportSize
                    );
                }
            }
        }
        else
        {
            dragging = false;
        }

        for (std::size_t i = 0; i < elements.size(); ++i)
        {
            const InterfaceElement& element = elements[i];
            if (!element.visible || !element.drawCallback)
                continue;

            element.drawCallback(draw, frameRects[i], alpha, 1.f);

            if (interactive)
            {


                const bool hovered =
                    static_cast<int>(i) == hoveredElement;
                const bool selectedAndDragging =
                    static_cast<int>(i) == selectedElement && dragging;

                if (hovered || selectedAndDragging)
                {
                    const float borderAlpha =
                        selectedAndDragging ? 0.85f : 0.42f;

                    draw->AddRect(
                        ImVec2(frameRects[i].Min.x - 2.f, frameRects[i].Min.y - 2.f),
                        ImVec2(frameRects[i].Max.x + 2.f, frameRects[i].Max.y + 2.f),
                        ColorU32(ImVec4(
                            ElysiumMenuPalette::Accent.x,
                            ElysiumMenuPalette::Accent.y,
                            ElysiumMenuPalette::Accent.z,
                            borderAlpha * alpha
                        )),
                        7.f,
                        ImDrawFlags_RoundCornersAll,
                        selectedAndDragging ? 1.5f : 1.25f
                    );
                }
            }
        }
    }

    void RenderEditorCanvas(const ImRect& panelRect, float alpha, bool interactive)
    {
        ImGuiViewport* viewport = ImGui::GetMainViewport();
        ImDrawList* draw = ImGui::GetWindowDrawList();

        if (!viewport || !draw)
            return;

        alpha = Clamp01(alpha);
        if (alpha <= 0.001f)
            return;

        const ImVec2 displaySize = viewport->Size;
        if (displaySize.x <= 1.f || displaySize.y <= 1.f)
            return;

        draw->AddRectFilled(
            panelRect.Min,
            panelRect.Max,
            ColorU32(ImVec4(0.004f, 0.005f, 0.010f, 0.93f * alpha)),
            14.f
        );

        draw->AddRect(
            ImVec2(panelRect.Min.x + 0.5f, panelRect.Min.y + 0.5f),
            ImVec2(panelRect.Max.x - 0.5f, panelRect.Max.y - 0.5f),
            ColorU32(ImVec4(1.f, 1.f, 1.f, 0.055f * alpha)),
            14.f,
            ImDrawFlags_RoundCornersAll,
            1.f
        );

        ImFont* font = ImGui::GetFont();
        if (font)
        {
            draw->AddText(
                font,
                15.f,
                ImVec2(panelRect.Min.x + 24.f, panelRect.Min.y + 18.f),
                ColorU32(ImVec4(0.90f, 0.91f, 0.97f, alpha)),
                "Настройка интерфейса"
            );

            const InterfaceElement* selected = GetElement(selectedElement);
            if (selected)
            {
                const ImVec2 size = font->CalcTextSizeA(
                    12.f, FLT_MAX, 0.f, selected->name.c_str()
                );

                draw->AddText(
                    font,
                    12.f,
                    ImVec2(panelRect.Max.x - 24.f - size.x, panelRect.Min.y + 21.f),
                    ColorU32(ImVec4(ElysiumMenuPalette::Accent.x, ElysiumMenuPalette::Accent.y, ElysiumMenuPalette::Accent.z, 0.85f * alpha)),
                    selected->name.c_str()
                );
            }
        }

        const ImRect canvas(
            ImVec2(panelRect.Min.x + 22.f, panelRect.Min.y + 52.f),
            ImVec2(panelRect.Max.x - 22.f, panelRect.Max.y - 76.f)
        );

        draw->AddRectFilled(
            canvas.Min,
            canvas.Max,
            ColorU32(ImVec4(0.008f, 0.009f, 0.017f, 0.97f * alpha)),
            11.f
        );

        draw->PushClipRect(canvas.Min, canvas.Max, true);

        const float availableWidth = ImMax(1.f, canvas.GetWidth() - 20.f);
        const float availableHeight = ImMax(1.f, canvas.GetHeight() - 20.f);
        float scale = ImMin(availableWidth / displaySize.x, availableHeight / displaySize.y);
        scale = ImClamp(scale, 0.05f, 1.f);

        const ImVec2 screenSize(displaySize.x * scale, displaySize.y * scale);
        const ImVec2 screenMin(
            canvas.GetCenter().x - screenSize.x * 0.5f,
            canvas.GetCenter().y - screenSize.y * 0.5f
        );
        const ImVec2 screenMax(screenMin.x + screenSize.x, screenMin.y + screenSize.y);

        draw->AddRectFilled(
            screenMin,
            screenMax,
            ColorU32(ImVec4(0.015f, 0.016f, 0.026f, 0.98f * alpha)),
            8.f
        );

        draw->AddRect(
            ImVec2(screenMin.x + 0.5f, screenMin.y + 0.5f),
            ImVec2(screenMax.x - 0.5f, screenMax.y - 0.5f),
            ColorU32(ImVec4(1.f, 1.f, 1.f, 0.10f * alpha)),
            8.f,
            ImDrawFlags_RoundCornersAll,
            1.f
        );

        constexpr float GRID_STEP = 64.f;
        constexpr float MAJOR_GRID_STEP = 320.f;

        for (float x = 0.f; x <= displaySize.x; x += GRID_STEP)
        {
            const bool major = std::fmod(x, MAJOR_GRID_STEP) < 0.1f;
            const float lineAlpha = major ? 0.10f : 0.045f;
            const float lineThickness = major ? 1.f : 0.65f;
            const float screenX = screenMin.x + x * scale;

            draw->AddLine(
                ImVec2(screenX, screenMin.y),
                ImVec2(screenX, screenMax.y),
                ColorU32(ImVec4(0.40f, 0.36f, 0.58f, lineAlpha * alpha)),
                lineThickness
            );
        }

        for (float y = 0.f; y <= displaySize.y; y += GRID_STEP)
        {
            const bool major = std::fmod(y, MAJOR_GRID_STEP) < 0.1f;
            const float lineAlpha = major ? 0.10f : 0.045f;
            const float lineThickness = major ? 1.f : 0.65f;
            const float screenY = screenMin.y + y * scale;

            draw->AddLine(
                ImVec2(screenMin.x, screenY),
                ImVec2(screenMax.x, screenY),
                ColorU32(ImVec4(0.40f, 0.36f, 0.58f, lineAlpha * alpha)),
                lineThickness
            );
        }

        draw->AddLine(
            ImVec2(screenMin.x + screenSize.x * 0.5f, screenMin.y),
            ImVec2(screenMin.x + screenSize.x * 0.5f, screenMax.y),
            ColorU32(ImVec4(ElysiumMenuPalette::Accent.x, ElysiumMenuPalette::Accent.y, ElysiumMenuPalette::Accent.z, 0.12f * alpha)),
            1.f
        );

        draw->AddLine(
            ImVec2(screenMin.x, screenMin.y + screenSize.y * 0.5f),
            ImVec2(screenMax.x, screenMin.y + screenSize.y * 0.5f),
            ColorU32(ImVec4(ElysiumMenuPalette::Accent.x, ElysiumMenuPalette::Accent.y, ElysiumMenuPalette::Accent.z, 0.12f * alpha)),
            1.f
        );

        if (font)
        {
            draw->AddText(
                font,
                10.f,
                ImVec2(screenMin.x + 10.f, screenMin.y + 8.f),
                ColorU32(ImVec4(0.60f, 0.61f, 0.69f, 0.45f * alpha)),
                "SCREEN"
            );
        }

        std::vector<ImRect> elementRects;
        elementRects.reserve(elements.size());

        for (const auto& element : elements)
        {
            const ImVec2 min(
                screenMin.x + element.position.x * scale,
                screenMin.y + element.position.y * scale
            );
            const ImVec2 size(element.size.x * scale, element.size.y * scale);
            elementRects.emplace_back(min, ImVec2(min.x + size.x, min.y + size.y));
        }



        int hoveredCanvasElement = -1;
        ImVec2 canvasMouse = ImGui::GetIO().MousePos;

        if (interactive)
        {
            for (std::size_t reverse = elements.size(); reverse > 0; --reverse)
            {
                const std::size_t i = reverse - 1;
                const InterfaceElement& element = elements[i];
                if (!element.visible)
                    continue;

                ImRect hitRect = elementRects[i];
                hitRect.Min.x -= 4.f;
                hitRect.Min.y -= 4.f;
                hitRect.Max.x += 4.f;
                hitRect.Max.y += 4.f;

                if (hitRect.Contains(canvasMouse))
                {
                    hoveredCanvasElement = static_cast<int>(i);
                    break;
                }
            }
        }

        for (std::size_t i = 0; i < elements.size(); ++i)
        {
            InterfaceElement& element = elements[i];
            if (!element.visible || !element.drawCallback)
                continue;



            element.drawCallback(draw, elementRects[i], alpha, scale);
        }

        if (interactive)
        {
            bool mouseOverElement = hoveredCanvasElement >= 0;

            if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) &&
                hoveredCanvasElement >= 0)
            {
                InterfaceElement& element = elements[static_cast<std::size_t>(hoveredCanvasElement)];
                selectedElement = hoveredCanvasElement;
                dragging = element.draggable;
                dragStartMouse = canvasMouse;
                dragStartPosition = element.position;
            }

            if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) &&
                canvas.Contains(canvasMouse) &&
                !mouseOverElement)
            {
                selectedElement = -1;
                dragging = false;
            }

            if (dragging)
            {
                InterfaceElement* selected = GetElement(selectedElement);
                if (!selected || !selected->draggable)
                {
                    dragging = false;
                }
                else if (!ImGui::IsMouseDown(ImGuiMouseButton_Left))
                {
                    dragging = false;
                }
                else
                {
                    const ImVec2 delta(
                        (canvasMouse.x - dragStartMouse.x) / scale,
                        (canvasMouse.y - dragStartMouse.y) / scale
                    );

                    ImVec2 nextPosition(
                        dragStartPosition.x + delta.x,
                        dragStartPosition.y + delta.y
                    );

                    nextPosition = ClampPosition(
                        nextPosition,
                        selected->size,
                        displaySize
                    );

                    selected->position = nextPosition;
                }
            }
        }

        draw->PopClipRect();

        if (font)
        {
            const char* hint = "Перетаскивайте элементы мышью";
            const ImVec2 hintSize = font->CalcTextSizeA(11.f, FLT_MAX, 0.f, hint);
            draw->AddText(
                font,
                11.f,
                ImVec2(canvas.Max.x - hintSize.x, canvas.Max.y + 10.f),
                ColorU32(ImVec4(0.48f, 0.49f, 0.57f, 0.65f * alpha)),
                hint
            );
        }

        if (dragging)
        {
            const InterfaceElement* selected = GetElement(selectedElement);
            if (selected && font)
            {
                char buffer[96]{};
                sprintf_s(
                    buffer,
                    "%s  |  X %.0f  Y %.0f",
                    selected->name.c_str(),
                    selected->position.x,
                    selected->position.y
                );

                draw->AddText(
                    font,
                    11.f,
                    ImVec2(panelRect.Min.x + 24.f, panelRect.Max.y - 48.f),
                    ColorU32(ImVec4(0.65f, 0.66f, 0.75f, 0.85f * alpha)),
                    buffer
                );
            }
        }
    }

    bool HasUnsavedChanges() const
    {
        for (const auto& element : elements)
        {
            if (
                std::fabs(element.position.x - element.savedPosition.x) > 0.01f ||
                std::fabs(element.position.y - element.savedPosition.y) > 0.01f
                )
            {
                return true;
            }
        }
        return false;
    }

    void Apply()
    {
        for (auto& element : elements)
            element.savedPosition = element.position;
    }

    void ResetToDefaults()
    {
        for (auto& element : elements)
            element.position = element.defaultPosition;
    }

    void DiscardChanges()
    {
        for (auto& element : elements)
            element.position = element.savedPosition;
        dragging = false;
        selectedElement = -1;
    }

    int GetSelectedElement() const { return selectedElement; }

    const char* GetSelectedElementName() const
    {
        const InterfaceElement* element = GetElement(selectedElement);
        return element ? element->name.c_str() : nullptr;
    }

    std::vector<InterfaceElement>& GetElements() { return elements; }
    const std::vector<InterfaceElement>& GetElements() const { return elements; }

    void ClearSelection()
    {
        selectedElement = -1;
        dragging = false;
    }

    const InterfaceElement* FindElement(const char* id) const
    {
        if (!id)
            return nullptr;

        for (const auto& element : elements)
        {
            if (element.id == id)
                return &element;
        }

        return nullptr;
    }
};

class Menu
{
private:
    static ImRect CloseButtonRect(const ImRect& panelRect)
    {
        const ImVec2 center(panelRect.Max.x - 20.f, panelRect.Min.y + 18.f);
        return ImRect(ImVec2(center.x - 15.f, center.y - 15.f), ImVec2(center.x + 15.f, center.y + 15.f));
    }

    static void drawGearIcon(
        ImDrawList* dl,
        const ImVec2& center,
        ImU32 color,
        float scale = 1.f
    )
    {
        if (!dl)
            return;

        const int teeth = 8;

        const float inner = 5.2f * scale;
        const float outer = 8.0f * scale;

        for (int i = 0; i < teeth; ++i)
        {
            const float a =
                static_cast<float>(i) *
                IM_PI /
                4.f;

            const ImVec2 dir(
                std::cos(a),
                std::sin(a)
            );

            const ImVec2 p1(
                center.x + dir.x * inner,
                center.y + dir.y * inner
            );

            const ImVec2 p2(
                center.x + dir.x * outer,
                center.y + dir.y * outer
            );

            dl->AddLine(
                p1,
                p2,
                color,
                2.2f * scale
            );
        }

        dl->AddCircle(
            center,
            6.1f * scale,
            color,
            16,
            1.8f * scale
        );

        const ImU32 hole =
            ImGui::GetColorU32(
                ImVec4(
                    0.022f,
                    0.022f,
                    0.027f,
                    1.f
                )
            );

        dl->AddCircleFilled(
            center,
            2.5f * scale,
            hole,
            16
        );
    }

    static void drawConfigIcon(
        ImDrawList* dl,
        const ImVec2& center,
        ImU32 color,
        float scale = 1.f
    )
    {
        if (!dl)
            return;

        const float w = 16.f * scale;
        const float h = 12.f * scale;

        const float x = center.x - w * 0.5f;
        const float y = center.y - h * 0.5f;

        dl->AddRect(
            ImVec2(
                x,
                y + 2.f * scale
            ),
            ImVec2(
                x + w,
                y + h
            ),
            color,
            3.f * scale,
            ImDrawFlags_RoundCornersAll,
            1.5f * scale
        );

        dl->AddLine(
            ImVec2(
                x + 2.5f * scale,
                y + 2.f * scale
            ),
            ImVec2(
                x + 5.f * scale,
                y - 0.5f * scale
            ),
            color,
            1.5f * scale
        );

        dl->AddLine(
            ImVec2(
                x + 5.f * scale,
                y - 0.5f * scale
            ),
            ImVec2(
                x + 10.f * scale,
                y - 0.5f * scale
            ),
            color,
            1.5f * scale
        );

        dl->AddLine(
            ImVec2(
                x + 10.f * scale,
                y - 0.5f * scale
            ),
            ImVec2(
                x + 13.f * scale,
                y + 2.f * scale
            ),
            color,
            1.5f * scale
        );
    }

    bool isOpen = true;
    bool initialized = false;
    bool positionInitialized = false;
    bool exitRequested = false;

    bool interfaceEditorActive = false;
    bool interfaceSavePrompt = false;

    float interfaceEditorProgress = 0.f;
    float interfaceEditorVelocity = 0.f;
    float interfacePromptProgress = 0.f;
    float interfacePromptVelocity = 0.f;

    InterfaceManager interfaceManager;
    InventoryOverlay inventoryOverlay;

    bool inventoryElementRegistered = false;
    bool targetHudElementRegistered = false;
    bool radarElementRegistered = false;

    RadarModule* radarModule = nullptr;
    ImVec2 radarLastModulePosition = { 0.f, 0.f };
    ImVec2 radarLastInterfacePosition = { 0.f, 0.f };
    bool radarPositionSyncInitialized = false;

    const RenderSnapshot* inventorySnapshot = nullptr;
    const WorldToScreenUtils::CameraSnapshot* inventoryCamera = nullptr;
    IconsManager* inventoryIcons = nullptr;
    const std::unordered_map<uintptr_t, ImVec2>* inventoryAnchors = nullptr;
    float inventorySlotSize = 34.f;

    ImVec2 panelPos = { 0.f, 0.f };
    bool panelDragging = false;
    ImVec2 panelDragOffset = { 0.f, 0.f };

    static constexpr int TAB_COUNT = 6;

    int currentTab = 0;
    int visualTab = 0;
    int pendingTab = -1;
    int transitionDirection = 0;

    float tabFade = 1.f;
    float tabProgress = 1.f;

    float menuAlpha = 1.f;
    float menuProgress = 1.f;

    float menuVelocity = 0.f;
    float tabFadeVelocity = 0.f;
    float tabProgressVelocity = 0.f;

    float tabIndicatorLocalX = 0.f;
    float tabIndicatorVelocity = 0.f;
    float tabIndicatorWidth = 0.f;
    ImVec4 tabIndicatorColor = ElysiumMenuPalette::Accent;
    bool tabIndicatorInitialized = false;




    float menuOpenSpeed = 0.50f;
    float menuCloseSpeed = 0.80f;
    float menuRevealSpeed = 0.80f;

    bool antiScreenEnabled = true;
    LastConfig* lastConfigStatus = nullptr;

    ImFont* textFont = nullptr;
    ImFont* iconFont = nullptr;

    static constexpr float TEXT_FONT_SIZE = 13.f;
    static constexpr float ICON_FONT_SIZE = 18.f;

    static constexpr float TAB_FADE_OUT_TIME = 0.05f;
    static constexpr float TAB_FADE_IN_TIME = 0.05f;
    static constexpr float TAB_SLIDE_TIME = 0.10f;


    static constexpr float SCROLL_WHEEL_STEP = 85.f;
    static constexpr float SCROLL_SMOOTH_TIME = 0.12f;

    struct ScrollState
    {
        float current = 0.f;
        float target = 0.f;
        float velocity = 0.f;

        float measuredHeight = 0.f;
        float displayHeight = 0.f;
        float heightVelocity = 0.f;

        float lastMaxScroll = 0.f;
        float simulationAccumulator = 0.f;
        float heightSimulationAccumulator = 0.f;
        bool initialized = false;
    };

    ScrollState scrollStates[TAB_COUNT]{};



    ScrollState settingsScrollState{};

    enum class EditorAction
    {
        None,
        Exit,
        Reset,
        Apply
    };

    static float clamp01(float v)
    {
        return ImClamp(v, 0.f, 1.f);
    }

    static float speedToSmoothTime(float speed)
    {
        return ImLerp(
            0.22f,
            0.045f,
            clamp01(speed)
        );
    }

    static ImVec4 lerpColor(
        const ImVec4& a,
        const ImVec4& b,
        float t
    )
    {
        t = clamp01(t);

        return ImVec4(
            a.x + (b.x - a.x) * t,
            a.y + (b.y - a.y) * t,
            a.z + (b.z - a.z) * t,
            a.w + (b.w - a.w) * t
        );
    }

    static ImU32 colorU32(
        const ImVec4& color
    )
    {
        return ImGui::ColorConvertFloat4ToU32(
            color
        );
    }

    static float smoothDamp(
        float current,
        float target,
        float& velocity,
        float smoothTime,
        float maxSpeed,
        float dt
    )
    {
        if (dt <= 0.f)
            return current;

        smoothTime = ImMax(0.0001f, smoothTime);

        const float omega = 2.f / smoothTime;

        const float x = omega * dt;

        const float exp =
            1.f /
            (
                1.f +
                x +
                0.48f * x * x +
                0.235f * x * x * x +
                0.01f * x * x * x * x
                );

        const float maxDelta = maxSpeed * smoothTime;

        const float originalTarget = target;

        float delta = current - target;

        delta = ImClamp(
            delta,
            -maxDelta,
            maxDelta
        );

        const float adjustedTarget = current - delta;

        const float temp =
            (velocity + omega * delta) * dt;

        velocity =
            (velocity - omega * temp) * exp;

        float output =
            adjustedTarget +
            (delta + temp) * exp;

        const bool preventOvershoot =
            (
                (originalTarget - current > 0.f) ==
                (output > originalTarget)
                );

        if (preventOvershoot)
        {
            output = originalTarget;
            velocity = 0.f;
        }

        if (!std::isfinite(output))
            output = originalTarget;

        if (!std::isfinite(velocity))
            velocity = 0.f;

        return output;
    }

    static float easeOutCubic(float t)
    {
        t = clamp01(t);

        const float inv = 1.f - t;

        return 1.f - inv * inv * inv;
    }

    static float easeInOutCubic(float t)
    {
        t = clamp01(t);

        if (t < 0.5f)
            return 4.f * t * t * t;

        const float f = -2.f * t + 2.f;
        return 1.f - (f * f * f) * 0.5f;
    }

    static float smoothstep01(float t)
    {
        t = clamp01(t);

        return t * t * (3.f - 2.f * t);
    }

    static float measureContentHeight(
        ImGuiWindow* window
    )
    {
        if (!window)
            return 0.f;

        const float cursorY =
            ImGui::GetCursorPosY();

        const float cursorMaxY =
            window->DC.CursorMaxPos.y -
            window->DC.CursorStartPos.y;

        return ImMax(
            0.f,
            ImMax(
                cursorY,
                cursorMaxY
            )
        );
    }

    static float getMaxScroll(
        ImGuiWindow* window,
        float contentHeight
    )
    {
        if (!window)
            return 0.f;

        const float visibleHeight =
            window->InnerRect.GetHeight();

        return ImMax(
            0.f,
            contentHeight -
            visibleHeight
        );
    }

    static void drawTextCentered(
        ImDrawList* dl,
        ImFont* font,
        float fontSize,
        const ImRect& rect,
        ImU32 col,
        const char* text
    )
    {
        if (!dl || !font || !text)
            return;

        const ImVec2 ts =
            font->CalcTextSizeA(
                fontSize,
                FLT_MAX,
                0.f,
                text
            );

        const ImVec2 pos = {
            rect.Min.x +
            (rect.GetWidth() - ts.x) * 0.5f,

            rect.Min.y +
            (rect.GetHeight() - ts.y) * 0.5f
        };

        dl->AddText(
            font,
            fontSize,
            pos,
            col,
            text
        );
    }

    void RegisterInventoryElement()
    {
        if (inventoryElementRegistered)
            return;

        ImGuiViewport* viewport =
            ImGui::GetMainViewport();

        if (!viewport)
            return;

        const ImVec2 size(
            390.f,
            145.f
        );

        const ImVec2 position(
            viewport->Size.x * 0.5f -
            size.x * 0.5f,

            viewport->Size.y * 0.62f
        );

        const bool registered =
            interfaceManager.RegisterElement(
                "inventory_overlay",
                "Inventory",
                position,
                size,
                [this](
                    ImDrawList* draw,
                    const ImRect& rect,
                    float alpha,
                    float scale
                    )
                {
                    (void)scale;

                    if (!draw || !textFont)
                        return;

                    InventoryOverlay::SetRenderRect(
                        rect
                    );

                    InventoryOverlay::SetEditorMode(
                        false
                    );

                    const float previewAlpha =
                        ImClamp(
                            menuAlpha,
                            0.f,
                            1.f
                        );

                    InventoryOverlay::SetMenuPreviewActive(
                        previewAlpha > 0.001f
                    );

                    if (previewAlpha > 0.001f)
                    {
                        InventoryOverlay::DrawPreview(
                            draw,
                            textFont,
                            rect,
                            inventorySlotSize,
                            previewAlpha
                        );
                    }
                },
                true,
                true
            );

        if (registered)
            inventoryElementRegistered = true;
    }

    void RegisterRadarElement()
    {
        if (radarElementRegistered)
            return;

        if (!radarModule)
            radarModule = RadarModule::Get();

        if (!radarModule)
            return;

        ImGuiViewport* viewport =
            ImGui::GetMainViewport();

        if (!viewport)
            return;

        const ImVec2 radarElementSize(
            ImMax(40.f, radarModule->size + 20.f),
            ImMax(58.f, radarModule->size + 38.f)
        );

        const ImVec2 radarElementPosition(
            radarModule->posX,
            radarModule->posY
        );

        const bool registered =
            interfaceManager.RegisterElement(
                "radar",
                "Radar",
                radarElementPosition,
                radarElementSize,
                [this](
                    ImDrawList* draw,
                    const ImRect& rect,
                    float alpha,
                    float scale
                    )
                {
                    (void)scale;

                    RadarModule* radar = radarModule;
                    if (!radar)
                        radar = RadarModule::Get();

                    if (!radar || !draw)
                        return;

                    const bool preview =
                        isOpen &&
                        menuAlpha > 0.001f;

                    radar->DrawInterface(
                        draw,
                        rect,
                        alpha,
                        preview
                    );
                },
                true,
                true
            );

        if (registered)
        {
            radarElementRegistered = true;

            radarLastModulePosition =
                radarElementPosition;

            radarLastInterfacePosition =
                radarElementPosition;

            radarPositionSyncInitialized = true;
        }
    }

    void SyncRadarInterfaceElement()
    {
        if (!radarModule)
            radarModule = RadarModule::Get();

        if (!radarModule)
            return;

        InterfaceManager::InterfaceElement* radarElement = nullptr;

        for (auto& element : interfaceManager.GetElements())
        {
            if (element.id == "radar")
            {
                radarElement = &element;
                break;
            }
        }

        if (!radarElement)
            return;

        radarElement->size = ImVec2(
            ImMax(40.f, radarModule->size + 20.f),
            ImMax(58.f, radarModule->size + 38.f)
        );

        const ImVec2 modulePosition(
            radarModule->posX,
            radarModule->posY
        );

        if (!radarPositionSyncInitialized)
        {
            radarElement->position = modulePosition;
            radarLastModulePosition = modulePosition;
            radarLastInterfacePosition = modulePosition;
            radarPositionSyncInitialized = true;
            return;
        }

        const bool modulePositionChanged =
            std::fabs(modulePosition.x - radarLastModulePosition.x) > 0.01f ||
            std::fabs(modulePosition.y - radarLastModulePosition.y) > 0.01f;

        const bool interfacePositionChanged =
            std::fabs(radarElement->position.x - radarLastInterfacePosition.x) > 0.01f ||
            std::fabs(radarElement->position.y - radarLastInterfacePosition.y) > 0.01f;


        if (modulePositionChanged && !interfacePositionChanged)
        {
            ImGuiViewport* viewport =
                ImGui::GetMainViewport();

            if (viewport)
            {
                const float maxX =
                    ImMax(0.f, viewport->Size.x - radarElement->size.x);

                const float maxY =
                    ImMax(0.f, viewport->Size.y - radarElement->size.y);

                radarElement->position = ImVec2(
                    ImClamp(modulePosition.x, 0.f, maxX),
                    ImClamp(modulePosition.y, 0.f, maxY)
                );
            }
            else
            {
                radarElement->position = modulePosition;
            }
        }

        else if (interfacePositionChanged && !modulePositionChanged)
        {
            radarModule->posX = radarElement->position.x;
            radarModule->posY = radarElement->position.y;
        }


        else if (interfacePositionChanged && modulePositionChanged)
        {
            radarModule->posX = radarElement->position.x;
            radarModule->posY = radarElement->position.y;
        }

        radarLastModulePosition = ImVec2(
            radarModule->posX,
            radarModule->posY
        );

        radarLastInterfacePosition =
            radarElement->position;
    }

    void RegisterTargetHudElement()
    {
        if (targetHudElementRegistered)
            return;

        ImGuiViewport* viewport =
            ImGui::GetMainViewport();

        if (!viewport)
            return;

        const bool registered =
            interfaceManager.RegisterElement(
                "target_hud",
                "Target HUD",
                ImVec2(
                    viewport->Size.x * 0.5f -
                    125.f,

                    viewport->Size.y * 0.24f
                ),
                ImVec2(
                    250.f,
                    95.f
                ),
                [this](
                    ImDrawList* draw,
                    const ImRect& rect,
                    float alpha,
                    float scale
                    )
                {
                    (void)scale;

                    if (!draw || !textFont)
                        return;

                    const bool preview =
                        menuAlpha > 0.001f;

                    const float finalAlpha =
                        preview
                        ? ImClamp(
                            menuAlpha,
                            0.f,
                            1.f
                        )
                        : ImClamp(
                            alpha,
                            0.f,
                            1.f
                        );

                    TargetHud::Get().DrawInterface(
                        draw,
                        textFont,
                        rect,
                        finalAlpha,
                        preview,
                        isOpen &&
                        menuAlpha > 0.01f
                    );
                },
                true,
                true
            );

        if (registered)
            targetHudElementRegistered = true;
    }



    void updateSmoothScrollState(
        ScrollState& state,
        float dt,
        bool respectTabTransition
    )
    {
        ImGuiWindow* window =
            ImGui::GetCurrentWindow();

        if (!window)
            return;

        const float measuredHeight =
            measureContentHeight(window) +
            20.f;

        if (!state.initialized)
        {
            state.measuredHeight =
                measuredHeight;

            state.displayHeight =
                measuredHeight;

            const float maxScroll =
                getMaxScroll(
                    window,
                    measuredHeight
                );

            state.current =
                ImClamp(
                    state.current,
                    0.f,
                    maxScroll
                );

            state.target =
                state.current;

            state.velocity =
                0.f;

            state.heightVelocity =
                0.f;

            state.lastMaxScroll =
                maxScroll;

            state.initialized =
                true;
        }

        const float oldMaxScroll =
            state.lastMaxScroll;

        state.displayHeight =
            smoothDamp(
                state.displayHeight,
                measuredHeight,
                state.heightVelocity,
                speedToSmoothTime(
                    menuRevealSpeed
                ),
                20000.f,
                dt
            );

        if (
            std::fabs(
                state.displayHeight -
                measuredHeight
            ) < 0.2f
            )
        {
            state.displayHeight =
                measuredHeight;

            state.heightVelocity =
                0.f;
        }

        const float displayMaxScroll =
            getMaxScroll(
                window,
                state.displayHeight
            );

        const float realMaxScroll =
            getMaxScroll(
                window,
                measuredHeight
            );

        const float maxScroll =
            ImMin(
                displayMaxScroll,
                realMaxScroll
            );

        if (
            std::fabs(
                measuredHeight -
                state.measuredHeight
            ) > 0.01f
            )
        {
            const bool stickToBottom =
                oldMaxScroll > 30.f &&
                (
                    oldMaxScroll -
                    state.target
                    ) <= 14.f &&
                (
                    oldMaxScroll -
                    state.current
                    ) <= 14.f;

            if (stickToBottom)
            {
                state.target =
                    maxScroll;
            }
            else
            {
                state.target =
                    ImClamp(
                        state.target,
                        0.f,
                        maxScroll
                    );

                state.current =
                    ImClamp(
                        state.current,
                        0.f,
                        displayMaxScroll
                    );
            }
        }

        state.measuredHeight =
            measuredHeight;

        state.lastMaxScroll =
            maxScroll;

        bool allowWheel = true;

        if (respectTabTransition)
        {
            allowWheel =
                pendingTab == -1 &&
                tabFade > 0.35f;
        }

        if (
            allowWheel &&
            ImGui::IsWindowHovered(
                ImGuiHoveredFlags_AllowWhenBlockedByActiveItem
            )
            )
        {
            const float wheel =
                ImGui::GetIO().MouseWheel;

            if (
                std::fabs(wheel) >
                0.001f
                )
            {
                state.target -=
                    wheel *
                    SCROLL_WHEEL_STEP;
            }
        }

        state.target =
            ImClamp(
                state.target,
                0.f,
                realMaxScroll
            );

        const float safeDt =
            ImClamp(
                dt,
                0.0001f,
                0.1f
            );

        const float alpha =
            1.f -
            std::exp(
                -safeDt /
                SCROLL_SMOOTH_TIME
            );

        state.current =
            ImLerp(
                state.current,
                state.target,
                alpha
            );

        state.current =
            ImClamp(
                state.current,
                0.f,
                displayMaxScroll
            );

        if (
            std::fabs(
                state.current -
                state.target
            ) < 0.15f
            )
        {
            state.current =
                state.target;

            state.velocity =
                0.f;
        }

        if (
            state.target <= 0.01f &&
            state.current <= 0.15f
            )
        {
            state.current = 0.f;
            state.target = 0.f;
            state.velocity = 0.f;
        }

        if (
            state.target >=
            maxScroll - 0.01f &&
            state.current >=
            maxScroll - 0.15f
            )
        {
            state.current =
                maxScroll;

            state.target =
                maxScroll;

            state.velocity =
                0.f;
        }

        ImGui::SetScrollY(
            state.current
        );
    }

    void updateSmoothScroll(
        int tab,
        float dt
    )
    {
        if (
            tab < 0 ||
            tab >= TAB_COUNT
            )
        {
            return;
        }

        updateSmoothScrollState(
            scrollStates[tab],
            dt,
            true
        );
    }

    void updateSettingsSmoothScroll(
        float dt
    )
    {
        updateSmoothScrollState(
            settingsScrollState,
            dt,
            false
        );
    }

    bool drawOverlayToggle(
        const ImRect& rect,
        const char* id,
        const char* label,
        bool& value,
        float alpha
    )
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        if (!dl || !id || !label)
            return false;

        alpha = clamp01(alpha);

        const ImGuiID widgetId = ImGui::GetID(id);
        ImGui::ItemAdd(rect, widgetId);

        bool hovered = false;
        bool held = false;

        const bool pressed =
            ImGui::ButtonBehavior(
                rect,
                widgetId,
                &hovered,
                &held,
                ImGuiButtonFlags_PressedOnClick
            );

        if (pressed)
            value = !value;

        static float anim = 0.f;
        static float velocity = 0.f;

        const float dt = ImClamp(
            ImGui::GetIO().DeltaTime,
            0.0001f,
            0.1f
        );

        anim = smoothDamp(
            anim,
            value ? 1.f : 0.f,
            velocity,
            0.14f,
            1000.f,
            dt
        );

        anim = clamp01(anim);

        const float hover = hovered ? 1.f : 0.f;
        const float press = held ? 1.f : 0.f;

        ImVec4 bg(
            0.026f,
            0.027f,
            0.034f,
            0.98f
        );

        bg = lerpColor(
            bg,
            ImVec4(
                0.038f,
                0.033f,
                0.046f,
                0.98f
            ),
            anim
        );

        bg = lerpColor(
            bg,
            ElysiumMenuPalette::ControlHover,
            hover * 0.25f
        );

        dl->AddRectFilled(
            rect.Min,
            rect.Max,
            colorU32(ImVec4(bg.x, bg.y, bg.z, bg.w * alpha)),
            10.f
        );

        dl->AddRect(
            ImVec2(rect.Min.x + 0.5f, rect.Min.y + 0.5f),
            ImVec2(rect.Max.x - 0.5f, rect.Max.y - 0.5f),
            colorU32(ImVec4(
                ElysiumMenuPalette::Accent.x,
                ElysiumMenuPalette::Accent.y,
                ElysiumMenuPalette::Accent.z,
                (0.035f + 0.04f * anim + 0.02f * hover) * alpha
            )),
            10.f,
            ImDrawFlags_RoundCornersAll,
            1.f
        );

        if (textFont)
        {
            dl->AddText(
                textFont,
                11.5f,
                ImVec2(
                    rect.Min.x + 12.f,
                    rect.Min.y + 8.f - press * 0.2f
                ),
                colorU32(ImVec4(
                    ElysiumMenuPalette::Text.x,
                    ElysiumMenuPalette::Text.y,
                    ElysiumMenuPalette::Text.z,
                    alpha
                )),
                label
            );

            const char* stateText = value ? "" : "";

            const ImVec2 stateSize = textFont->CalcTextSizeA(
                9.f,
                FLT_MAX,
                0.f,
                stateText
            );

            dl->AddText(
                textFont,
                9.f,
                ImVec2(
                    rect.Min.x + 12.f,
                    rect.Max.y - stateSize.y - 8.f
                ),
                colorU32(ImVec4(
                    0.45f,
                    0.47f,
                    0.53f,
                    0.72f * alpha
                )),
                stateText
            );
        }

        const float switchW = 38.f;
        const float switchH = 20.f;

        const ImRect sw(
            ImVec2(
                rect.Max.x - switchW - 11.f,
                rect.GetCenter().y - switchH * 0.5f
            ),
            ImVec2(
                rect.Max.x - 11.f,
                rect.GetCenter().y + switchH * 0.5f
            )
        );

        const ImVec4 off(
            0.060f,
            0.062f,
            0.073f,
            alpha
        );

        const ImVec4 on(
            ElysiumMenuPalette::Accent.x * 0.46f,
            ElysiumMenuPalette::Accent.y * 0.46f,
            ElysiumMenuPalette::Accent.z * 0.46f,
            alpha
        );

        const ImVec4 switchColor = lerpColor(off, on, anim);

        dl->AddRectFilled(
            sw.Min,
            sw.Max,
            colorU32(switchColor),
            switchH * 0.5f
        );

        const float knobX = ImLerp(
            sw.Min.x + 10.f,
            sw.Max.x - 10.f,
            anim
        );

        dl->AddCircleFilled(
            ImVec2(knobX, sw.GetCenter().y),
            6.f - press * 0.35f,
            colorU32(ImVec4(
                0.96f,
                0.97f,
                1.f,
                alpha
            )),
            20
        );

        return pressed;
    }

    bool drawSettingsSlider(
        const ImRect& rect,
        const char* id,
        const char* label,
        float& value,
        float minValue,
        float maxValue,
        float alpha
    )
    {
        ImDrawList* dl =
            ImGui::GetWindowDrawList();

        if (!dl || !id || !label)
            return false;

        alpha =
            clamp01(alpha);

        const ImGuiID widgetId =
            ImGui::GetID(id);

        ImGui::ItemAdd(
            rect,
            widgetId
        );

        bool hovered = false;
        bool held = false;

        const bool active =
            ImGui::ButtonBehavior(
                rect,
                widgetId,
                &hovered,
                &held,
                ImGuiButtonFlags_PressedOnClick
            );

        ImGuiIO& io =
            ImGui::GetIO();

        if (ImGui::IsItemActive())
        {
            const float mouseX =
                ImClamp(
                    io.MousePos.x,
                    rect.Min.x,
                    rect.Max.x
                );

            const float t =
                clamp01(
                    (mouseX - rect.Min.x) /
                    ImMax(
                        1.f,
                        rect.GetWidth()
                    )
                );

            value =
                minValue +
                (maxValue - minValue) *
                t;
        }

        value =
            ImClamp(
                value,
                minValue,
                maxValue
            );

        const float t =
            maxValue != minValue
            ? clamp01(
                (value - minValue) /
                (maxValue - minValue)
            )
            : 0.f;

        const float labelFontSize =
            11.5f;

        const float valueFontSize =
            10.f;

        if (textFont)
        {
            dl->AddText(
                textFont,
                labelFontSize,
                rect.Min,
                colorU32(
                    ImVec4(
                        hovered
                        ? ElysiumMenuPalette::Text.x
                        : ElysiumMenuPalette::TextMuted.x,

                        hovered
                        ? ElysiumMenuPalette::Text.y
                        : ElysiumMenuPalette::TextMuted.y,

                        hovered
                        ? ElysiumMenuPalette::Text.z
                        : ElysiumMenuPalette::TextMuted.z,

                        alpha
                    )
                ),
                label
            );

            char valueText[32]{};

            sprintf_s(
                valueText,
                "%.2f",
                value
            );

            const ImVec2 valueSize =
                textFont->CalcTextSizeA(
                    valueFontSize,
                    FLT_MAX,
                    0.f,
                    valueText
                );

            dl->AddText(
                textFont,
                valueFontSize,
                ImVec2(
                    rect.Max.x -
                    valueSize.x,
                    rect.Min.y + 1.f
                ),
                colorU32(
                    ImVec4(
                        0.49f,
                        0.50f,
                        0.57f,
                        alpha
                    )
                ),
                valueText
            );
        }

        const float lineY =
            rect.Min.y + 24.f;

        dl->AddRectFilled(
            ImVec2(
                rect.Min.x,
                lineY
            ),
            ImVec2(
                rect.Max.x,
                lineY + 1.f
            ),
            colorU32(
                ImVec4(
                    0.10f,
                    0.10f,
                    0.12f,
                    alpha
                )
            ),
            2.f
        );

        const float filledX =
            rect.Min.x +
            rect.GetWidth() *
            t;

        if (filledX > rect.Min.x)
        {
            dl->AddRectFilled(
                ImVec2(
                    rect.Min.x,
                    lineY
                ),
                ImVec2(
                    filledX,
                    lineY + 1.f
                ),
                colorU32(
                    ImVec4(
                        ElysiumMenuPalette::Accent.x,
                        ElysiumMenuPalette::Accent.y,
                        ElysiumMenuPalette::Accent.z,
                        alpha
                    )
                ),
                2.f
            );
        }

        dl->AddCircleFilled(
            ImVec2(
                filledX,
                lineY + 0.5f
            ),
            hovered || held
            ? 4.2f
            : 3.8f,
            colorU32(
                ImVec4(
                    0.90f,
                    0.89f,
                    0.94f,
                    alpha
                )
            ),
            20
        );

        return active;
    }

    bool traceDrawing = false;
    double traceStartTime = 0.0;

    void drawAimTracePanel(ImDrawList* dl, const ImRect& panel, const ImVec2& display,
                           ModuleManager& manager)
    {
        if (!dl) return;
        AimModule* aim = nullptr;
        for (const auto& mod : manager.GetModules()) {
            if ((aim = dynamic_cast<AimModule*>(mod.get()))) break;
        }
        if (!aim) return;
        const float desiredWidth=240.f, gap=12.f;
        const float w=ImMin(desiredWidth, ImMax(160.f, display.x-panel.Max.x-gap-6.f));
        const float x=ImClamp(panel.Max.x+gap, 0.f, ImMax(0.f,display.x-w-6.f));
        const float h=338.f;
        const float y=ImClamp(panel.Min.y+74.f, 0.f, ImMax(0.f,display.y-h-6.f));
        const ImVec2 pos(x,y), max(x+w,y+h);
        const ImU32 bg=ImGui::GetColorU32(ImVec4(.045f,.045f,.047f,.98f));
        const ImU32 border=ImGui::GetColorU32(ImVec4(1.f,1.f,1.f,.10f));
        const ImU32 text=ImGui::GetColorU32(ImVec4(.90f,.90f,.90f,1.f));
        const ImU32 muted=ImGui::GetColorU32(ImVec4(.58f,.58f,.59f,1.f));
        const ImU32 accent=ImGui::GetColorU32(ElysiumMenuPalette::Accent);
        dl->AddRectFilled(pos,max,bg,7.f);dl->AddRect(pos,max,border,7.f);
        dl->AddText(ImVec2(x+14.f,y+13.f),text,"trace of aimbot");
        dl->AddText(ImVec2(x+14.f,y+35.f),muted,_xorstr("Зажми ЛКМ и нарисуй"));
        const ImVec2 cmin(x+12.f,y+58.f), cmax(x+w-12.f,y+236.f);
        dl->AddRectFilled(cmin,cmax,ImGui::GetColorU32(ImVec4(.025f,.025f,.027f,1.f)),4.f);
        dl->AddRect(cmin,cmax,border,4.f);
        ImGui::SetCursorScreenPos(cmin);
        ImGui::InvisibleButton("##aim_trace_canvas",ImVec2(cmax.x-cmin.x,cmax.y-cmin.y));
        const ImVec2 mouse=ImGui::GetIO().MousePos;
        auto sample = [&] {
            const float sx=ImClamp(mouse.x-cmin.x,0.f,cmax.x-cmin.x);
            const float sy=ImClamp(mouse.y-cmin.y,0.f,cmax.y-cmin.y);
            return ImVec2(sx,sy);
        };
        if (isOpen && ImGui::IsItemActivated() && ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
            aim->trace.Clear();traceDrawing=true;traceStartTime=ImGui::GetTime();
            const auto p=sample();aim->trace.Add(p.x,p.y,0.f);
        }
        if (traceDrawing && isOpen && ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
            const auto p=sample();const float t=float(ImGui::GetTime()-traceStartTime);
            if (t<=AimTrace::MaxDuration) aim->trace.Add(p.x,p.y,t);
        }
        if (!isOpen || !ImGui::IsMouseDown(ImGuiMouseButton_Left)) traceDrawing=false;
        dl->PushClipRect(cmin,cmax,true);
        const int count=ImClamp(aim->trace.count,0,AimTrace::MaxPoints);
        for(int i=1;i<count;i++){
            const auto &a=aim->trace.points[i-1],&b=aim->trace.points[i];
            dl->AddLine(ImVec2(cmin.x+a.x,cmin.y+a.y),ImVec2(cmin.x+b.x,cmin.y+b.y),accent,2.f);
        }
        if(count>0)dl->AddCircleFilled(ImVec2(cmin.x+aim->trace.points[0].x,cmin.y+aim->trace.points[0].y),2.5f,accent);
        dl->PopClipRect();
        dl->AddText(ImVec2(x+14.f,y+246.f),muted,_xorstr("Сила коррекции  |  smooth > 1"));
        ImGui::SetCursorScreenPos(ImVec2(x+12.f,y+265.f));
        ImGui::SetNextItemWidth(w-24.f);
        ImGui::SliderFloat("##aim_trace_strength",&aim->traceStrengthPercent,0.f,100.f,"%.1f%%",ImGuiSliderFlags_AlwaysClamp);
        ImGui::SetCursorScreenPos(ImVec2(x+12.f,y+310.f));
        if(ImGui::Button(_xorstr("Очистить##aim_trace"),ImVec2(w-24.f,21.f))){aim->trace.Clear();traceDrawing=false;}
    }

    void drawSettingsPage()
    {
        if (!ImGui::BeginTable("##settings_layout", 2,
                ImGuiTableFlags_SizingStretchSame | ImGuiTableFlags_PadOuterX)) return;
        ImGui::TableNextColumn();
        RenderFeature::SectionTitle(_xorstr("ОВЕРЛЕЙ"));
        RenderFeature::Toggle(this, "AntiScreen", &antiScreenEnabled, 0);
        RenderFeature::Text(_xorstr("Del — открыть или закрыть меню"));
        ImGui::Spacing();
        RenderFeature::SectionTitle(_xorstr("АНИМАЦИЯ МЕНЮ"));
        RenderFeature::SliderFloat(this, _xorstr("Открытие"), &menuOpenSpeed, 0.f, 1.f, "%.2f");
        RenderFeature::SliderFloat(this, _xorstr("Закрытие"), &menuCloseSpeed, 0.f, 1.f, "%.2f");
        RenderFeature::SliderFloat(this, _xorstr("Раскрытие"), &menuRevealSpeed, 0.f, 1.f, "%.2f");
        ImGui::TableNextColumn();
        RenderFeature::SectionTitle(_xorstr("КОНФИГУРАЦИЯ"));
        ImGui::TextUnformatted(lastConfigStatus ? lastConfigStatus->Status() : "Last config: unavailable");
        RenderFeature::Text(_xorstr("Настройки сохраняются автоматически"));
        ImGui::Spacing();
        ImGui::TextWrapped("%s", _xorstr("Адреса игры не подтверждены."));
        ImGui::EndTable();
    }

    void drawAnimatedBackground(ImDrawList* dl, const ImRect& rect)
    {
        if (!dl) return;
        const float alpha = clamp01(menuAlpha);
        dl->AddRectFilled(rect.Min, rect.Max,
            colorU32(ImVec4(ElysiumMenuPalette::Surface.x, ElysiumMenuPalette::Surface.y,
                            ElysiumMenuPalette::Surface.z, alpha)), 8.f);
        dl->AddRect(ImVec2(rect.Min.x + .5f, rect.Min.y + .5f),
                    ImVec2(rect.Max.x - .5f, rect.Max.y - .5f),
                    colorU32(ImVec4(1.f, 1.f, 1.f, .08f * alpha)), 8.f);
    }

    void drawTopIcon(
        ImDrawList* dl,
        const ImVec2& center,
        int index,
        ImU32 color
    )
    {
        if (!dl)
            return;

        const float time =
            static_cast<float>(
                ImGui::GetTime()
                );

        if (index == 5) { drawGearIcon(dl, center, color, .78f); return; }
        if (index == 0)
        {
            const float s = 6.f;

            dl->AddCircle(
                center,
                s,
                color,
                20,
                1.5f
            );

            dl->AddLine(
                ImVec2(
                    center.x - 9.f,
                    center.y
                ),
                ImVec2(
                    center.x - 3.f,
                    center.y
                ),
                color,
                1.4f
            );

            dl->AddLine(
                ImVec2(
                    center.x + 3.f,
                    center.y
                ),
                ImVec2(
                    center.x + 9.f,
                    center.y
                ),
                color,
                1.4f
            );

            dl->AddLine(
                ImVec2(
                    center.x,
                    center.y - 9.f
                ),
                ImVec2(
                    center.x,
                    center.y - 3.f
                ),
                color,
                1.4f
            );

            dl->AddLine(
                ImVec2(
                    center.x,
                    center.y + 3.f
                ),
                ImVec2(
                    center.x,
                    center.y + 9.f
                ),
                color,
                1.4f
            );

            dl->AddCircleFilled(
                center,
                2.f,
                color,
                12
            );

            return;
        }

        if (index == 1)
        {
            const float pulse =
                0.5f +
                0.5f *
                std::sin(
                    time * 2.2f
                );

            const float eyeW = 9.5f;
            const float eyeH = 6.f;

            dl->PathClear();

            dl->PathLineTo(
                ImVec2(
                    center.x - eyeW,
                    center.y
                )
            );

            dl->PathBezierCubicCurveTo(
                ImVec2(
                    center.x - 5.f,
                    center.y - eyeH
                ),
                ImVec2(
                    center.x + 5.f,
                    center.y - eyeH
                ),
                ImVec2(
                    center.x + eyeW,
                    center.y
                )
            );

            dl->PathStroke(
                color,
                false,
                1.5f
            );

            dl->PathClear();

            dl->PathLineTo(
                ImVec2(
                    center.x + eyeW,
                    center.y
                )
            );

            dl->PathBezierCubicCurveTo(
                ImVec2(
                    center.x + 5.f,
                    center.y + eyeH
                ),
                ImVec2(
                    center.x - 5.f,
                    center.y + eyeH
                ),
                ImVec2(
                    center.x - eyeW,
                    center.y
                )
            );

            dl->PathStroke(
                color,
                false,
                1.5f
            );

            dl->AddCircleFilled(
                center,
                3.2f,
                color,
                18
            );

            dl->AddCircleFilled(
                ImVec2(
                    center.x - 1.1f,
                    center.y - 1.1f
                ),
                0.9f,
                ImGui::GetColorU32(
                    ImVec4(
                        1.f,
                        1.f,
                        1.f,
                        0.75f
                    )
                ),
                8
            );

            const float scanX =
                center.x -
                6.f +
                std::fmod(
                    time * 8.f,
                    12.f
                );

            dl->AddLine(
                ImVec2(
                    scanX,
                    center.y - 3.f
                ),
                ImVec2(
                    scanX,
                    center.y + 3.f
                ),
                ImGui::GetColorU32(
                    ImVec4(
                        1.f,
                        1.f,
                        1.f,
                        0.16f +
                        pulse * 0.12f
                    )
                ),
                1.f
            );

            return;
        }

        if (index == 2)
        {
            dl->AddCircleFilled(
                ImVec2(
                    center.x,
                    center.y - 4.f
                ),
                3.7f,
                color,
                16
            );

            dl->AddRectFilled(
                ImVec2(
                    center.x - 6.f,
                    center.y + 1.5f
                ),
                ImVec2(
                    center.x + 6.f,
                    center.y + 7.f
                ),
                color,
                3.f
            );

            return;
        }

        if (index == 3)
        {
            dl->AddCircleFilled(
                ImVec2(
                    center.x + 1.f,
                    center.y - 6.f
                ),
                3.2f,
                color,
                16
            );

            dl->AddLine(
                ImVec2(
                    center.x + 1.f,
                    center.y - 2.f
                ),
                ImVec2(
                    center.x - 1.f,
                    center.y + 5.f
                ),
                color,
                2.2f
            );

            dl->AddLine(
                ImVec2(
                    center.x,
                    center.y
                ),
                ImVec2(
                    center.x - 6.f,
                    center.y + 3.f
                ),
                color,
                1.8f
            );

            dl->AddLine(
                ImVec2(
                    center.x,
                    center.y
                ),
                ImVec2(
                    center.x + 6.f,
                    center.y - 2.f
                ),
                color,
                1.8f
            );

            dl->AddLine(
                ImVec2(
                    center.x - 1.f,
                    center.y + 5.f
                ),
                ImVec2(
                    center.x - 6.f,
                    center.y + 10.f
                ),
                color,
                2.f
            );

            dl->AddLine(
                ImVec2(
                    center.x - 1.f,
                    center.y + 5.f
                ),
                ImVec2(
                    center.x + 5.f,
                    center.y + 8.f
                ),
                color,
                2.f
            );

            return;
        }

        if (index == 4)
        {
            dl->AddLine(
                ImVec2(
                    center.x - 8.f,
                    center.y - 2.f
                ),
                ImVec2(
                    center.x + 7.f,
                    center.y - 2.f
                ),
                color,
                2.f
            );

            dl->AddLine(
                ImVec2(
                    center.x - 2.f,
                    center.y - 5.f
                ),
                ImVec2(
                    center.x + 6.f,
                    center.y - 5.f
                ),
                color,
                1.5f
            );

            dl->AddLine(
                ImVec2(
                    center.x - 2.f,
                    center.y - 2.f
                ),
                ImVec2(
                    center.x - 5.f,
                    center.y + 7.f
                ),
                color,
                2.2f
            );

            dl->AddLine(
                ImVec2(
                    center.x + 1.f,
                    center.y + 1.f
                ),
                ImVec2(
                    center.x - 1.f,
                    center.y + 4.f
                ),
                color,
                1.4f
            );

            dl->AddRect(
                ImVec2(
                    center.x - 7.f,
                    center.y - 6.f
                ),
                ImVec2(
                    center.x + 4.f,
                    center.y
                ),
                color,
                1.5f,
                ImDrawFlags_RoundCornersAll,
                1.2f
            );

            return;
        }
    }

    void drawTopTab(ImDrawList* dl, const ImRect& rect, const char* label, int index, bool selected)
    {
        if (!dl || !label || index < 0 || index >= TAB_COUNT) return;
        const ImGuiID id = ImGui::GetID(reinterpret_cast<void*>(static_cast<intptr_t>(index + 100)));
        ImGui::ItemAdd(rect, id);
        bool hovered=false, held=false;
        const bool pressed=ImGui::ButtonBehavior(rect,id,&hovered,&held);
        const float alpha=clamp01(menuAlpha);
        if (selected || hovered) {
            const float shade=selected ? .075f : .035f;
            dl->AddRectFilled(rect.Min,rect.Max,colorU32(ImVec4(1.f,1.f,1.f,shade*alpha)),4.f);
        }
        if (selected)
            dl->AddRectFilled(ImVec2(rect.Min.x,rect.Min.y+9.f),ImVec2(rect.Min.x+2.f,rect.Max.y-9.f),
                colorU32(ImVec4(ElysiumMenuPalette::Accent.x,ElysiumMenuPalette::Accent.y,ElysiumMenuPalette::Accent.z,alpha)),1.f);
        ImVec4 icon=selected ? ElysiumMenuPalette::Accent : ElysiumMenuPalette::TextMuted;
        icon.w*=alpha;
        drawTopIcon(dl,ImVec2(rect.Min.x+21.f,rect.GetCenter().y),index,colorU32(icon));
        if(textFont){
            const ImVec2 size=textFont->CalcTextSizeA(TEXT_FONT_SIZE,FLT_MAX,0.f,label);
            ImVec4 color=selected || hovered ? ElysiumMenuPalette::Text : ElysiumMenuPalette::TextMuted;
            color.w*=alpha;
            dl->AddText(textFont,TEXT_FONT_SIZE,ImVec2(rect.Min.x+40.f,rect.GetCenter().y-size.y*.5f),colorU32(color),label);
        }
        if(pressed && index!=visualTab){
            transitionDirection=index>currentTab?1:-1; visualTab=index; pendingTab=index;
            tabFade=1.f;tabFadeVelocity=0.f;tabProgress=0.f;tabProgressVelocity=0.f;
        }
    }

    bool panelDragHandleHovered(
        const ImVec2& mouse,
        const ImRect& bar
    ) const
    {
        return bar.Contains(mouse);
    }

    void drawTopBar(
        ImDrawList* dl,
        const ImRect& panelRect
    )
    {
        if (!dl)
            return;

        const float alpha = clamp01(menuAlpha);

        constexpr float sidebarWidth = 154.f;
        constexpr float headerHeight = 72.f;

        const ImRect sidebar(
            panelRect.Min,
            ImVec2(
                panelRect.Min.x + sidebarWidth,
                panelRect.Max.y
            )
        );

        const ImRect header(
            ImVec2(
                panelRect.Min.x + sidebarWidth,
                panelRect.Min.y
            ),
            ImVec2(panelRect.Max.x, panelRect.Min.y + headerHeight)
        );

        dl->AddRectFilled(
            sidebar.Min,
            sidebar.Max,
            colorU32(ImVec4(
                ElysiumMenuPalette::Sidebar.x,
                ElysiumMenuPalette::Sidebar.y,
                ElysiumMenuPalette::Sidebar.z,
                0.99f * alpha
            )),
            8.f,
            ImDrawFlags_RoundCornersTopLeft |
            ImDrawFlags_RoundCornersBottomLeft
        );

        dl->AddRectFilled(
            ImVec2(
                panelRect.Min.x + sidebarWidth,
                panelRect.Min.y
            ),
            panelRect.Max,
            colorU32(ImVec4(
                ElysiumMenuPalette::Header.x,
                ElysiumMenuPalette::Header.y,
                ElysiumMenuPalette::Header.z,
                0.82f * alpha
            )),
            8.f,
            ImDrawFlags_RoundCornersTopRight |
            ImDrawFlags_RoundCornersBottomRight
        );

        dl->AddLine(
            ImVec2(
                panelRect.Min.x + sidebarWidth - 0.5f,
                panelRect.Min.y + 16.f
            ),
            ImVec2(
                panelRect.Min.x + sidebarWidth - 0.5f,
                panelRect.Max.y - 16.f
            ),
            colorU32(ImVec4(
                1.f,
                1.f,
                1.f,
                0.042f * alpha
            )),
            1.f
        );

        if (textFont)
        {
            dl->AddText(
                textFont,
                16.f,
                ImVec2(
                    sidebar.Min.x + 18.f,
                    sidebar.Min.y + 12.f
                ),
                colorU32(ImVec4(
                    0.98f,
                    0.97f,
                    1.00f,
                    alpha
                )),
                "CREZ"
            );

        }

        const char* labels[TAB_COUNT] = {
            "Аим",
            "ESP",
            "Игрок",
            "Управление",
            "Оружие",
            "Настройки"
        };

        const float tabStartY =
            sidebar.Min.y + 82.f;

        const float tabHeight = 44.f;
        const float tabGap = 6.f;

        const float tabWidth =
            sidebar.GetWidth() - 18.f;

        for (int i = 0; i < TAB_COUNT; ++i)
        {
            const ImRect tabRect(
                ImVec2(
                    sidebar.Min.x + 9.f,
                    tabStartY + i * (tabHeight + tabGap)
                ),
                ImVec2(
                    sidebar.Min.x + 9.f + tabWidth,
                    tabStartY + i * (tabHeight + tabGap) + tabHeight
                )
            );

            drawTopTab(
                dl,
                tabRect,
                labels[i],
                i,
                visualTab == i
            );
        }

        dl->AddLine(
            ImVec2(
                header.Min.x + 18.f,
                header.Min.y + headerHeight - 0.5f
            ),
            ImVec2(
                header.Max.x - 18.f,
                header.Min.y + headerHeight - 0.5f
            ),
            colorU32(ImVec4(
                1.f,
                1.f,
                1.f,
                0.038f * alpha
            )),
            1.f
        );

        if (textFont)
        {
            const char* labels2[TAB_COUNT] = {
                "Аим",
                "ESP",
                "Игрок",
                "Управление",
                "Оружие",
                "Настройки"
            };

            const char* page = labels2[
                ImClamp(
                    currentTab,
                    0,
                    TAB_COUNT - 1
                )
            ];

            dl->AddText(
                textFont,
                16.f,
                ImVec2(
                    header.Min.x + 20.f,
                    header.Min.y + 13.f
                ),
                colorU32(ImVec4(
                    0.92f,
                    0.93f,
                    0.97f,
                    alpha
                )),
                page
            );

            dl->AddText(
                textFont,
                9.f,
                ImVec2(
                    header.Min.x + 21.f,
                    header.Min.y + 38.f
                ),
                colorU32(ImVec4(
                    0.42f,
                    0.44f,
                    0.50f,
                    0.72f * alpha
                )),
                "DEL  /  МЕНЮ"
            );
        }


        const ImRect closeRect = CloseButtonRect(panelRect);
        const ImVec2 closeCenter(panelRect.Max.x - 20.f, panelRect.Min.y + 18.f);
        const ImGuiID closeId = ImGui::GetID("##CrezCloseMenu");
        bool closeHovered = false, closeHeld = false;
        ImGui::ItemAdd(closeRect, closeId);
        const bool closeClicked = ImGui::ButtonBehavior(
            closeRect,
            closeId,
            &closeHovered,
            &closeHeld,
            ImGuiButtonFlags_PressedOnClick
        );
        if (closeClicked)
            exitRequested = true;

        const float closeGlow = clamp01(menuAlpha * (closeHeld ? 1.f : (closeHovered ? 0.92f : 0.72f)));
        const ImU32 closeOuter = IM_COL32(255, 91, 91, static_cast<int>(70.f * closeGlow));
        const ImU32 closeFill = IM_COL32(238, 53, 53, static_cast<int>(255.f * closeGlow));
        const ImU32 closeHighlight = IM_COL32(255, 151, 151, static_cast<int>(180.f * closeGlow));
        dl->AddCircleFilled(closeCenter, closeHovered ? 8.2f : 7.0f, closeOuter, 24);
        dl->AddCircleFilled(closeCenter, closeHovered ? 6.4f : 5.5f, closeFill, 24);
        dl->AddCircleFilled(ImVec2(closeCenter.x - 1.4f, closeCenter.y - 1.5f), 1.25f, closeHighlight, 12);

        const bool dragHovered =
            !closeHovered &&
            header.Contains(
                ImGui::GetIO().MousePos
            );

        if (dragHovered)
        {
            dl->AddRectFilled(
                header.Min,
                header.Max,
                colorU32(ImVec4(
                    ElysiumMenuPalette::Accent.x,
                    ElysiumMenuPalette::Accent.y,
                    ElysiumMenuPalette::Accent.z,
                    0.016f * alpha
                )),
                8.f,
                ImDrawFlags_RoundCornersTopRight |
                ImDrawFlags_RoundCornersBottomRight
            );
        }
    }

    void renderCategory(
        ModuleManager& moduleManager,
        ModuleCategory category
    )
    {
        moduleManager.RenderMenu(
            category
        );

        ImGui::Dummy(
            ImVec2(
                1.f,
                8.f
            )
        );
    }

    void drawActivePage(
        ModuleManager& moduleManager
    )
    {
        if (currentTab == 0)
        {
            renderCategory(
                moduleManager,
                ModuleCategory::Combat
            );
            return;
        }

        if (currentTab == 1)
        {
            renderCategory(
                moduleManager,
                ModuleCategory::Visuals
            );
            return;
        }

        if (currentTab == 2)
        {
            renderCategory(
                moduleManager,
                ModuleCategory::Player
            );
            return;
        }

        if (currentTab == 3)
        {
            renderCategory(
                moduleManager,
                ModuleCategory::Input
            );
            return;
        }

        if (currentTab == 4)
        {
            renderCategory(moduleManager, ModuleCategory::Weapon);
            return;
        }
        if (currentTab == 5) { drawSettingsPage(); return; }
    }

public:
    Menu()
    {
        radarModule = RadarModule::Get();

        InventoryOverlay::SetMenuPreviewActive(
            isOpen
        );
    }

    ~Menu() = default;

    void RegisterLastConfig(LastConfig& c){
        lastConfigStatus=&c;
        c.Bool("menu.antiScreen",antiScreenEnabled);
        c.Float("menu.openSpeed",menuOpenSpeed,0.f,1.f);
        c.Float("menu.closeSpeed",menuCloseSpeed,0.f,1.f);
        c.Float("menu.revealSpeed",menuRevealSpeed,0.f,1.f);
        for(const std::string id : {std::string("watermark"),std::string("radar"),std::string("inventory_overlay"),std::string("target_hud")}){
            for(int axis=0;axis<2;axis++){
                c.Bind("interface."+id+(axis?".y":".x"),[this,id,axis]{return double(interfaceManager.ConfigPosition(id,axis!=0));},
                    [this,id,axis](double v){interfaceManager.SetConfigPosition(id,axis!=0,float(v));},-10000,10000);
            }
        }
    }
    bool IsOpen() const
    {
        return isOpen;
    }

    bool ExitRequested() const
    {
        return exitRequested;
    }

    bool IsInterfaceEditorOpen() const
    {
        return interfaceEditorActive;
    }

    bool IsAntiScreenEnabled() const
    {
        return antiScreenEnabled;
    }

    InterfaceManager& GetInterfaceManager()
    {
        return interfaceManager;
    }

    void SetAntiScreenEnabled(
        bool enabled
    )
    {
        antiScreenEnabled =
            enabled;
    }

    void SetRadarModule(
        RadarModule* radar
    )
    {
        radarModule = radar;
        radarPositionSyncInitialized = false;
    }

    void SetInventoryContext(
        const RenderSnapshot& snap,
        const WorldToScreenUtils::CameraSnapshot& cam,
        IconsManager& icons,
        const std::unordered_map<uintptr_t, ImVec2>& anchorPoints,
        float slotSize = 34.f
    )
    {
        inventorySnapshot = &snap;
        inventoryCamera = &cam;
        inventoryIcons = &icons;
        inventoryAnchors = &anchorPoints;

        inventorySlotSize =
            slotSize > 1.f
            ? slotSize
            : 34.f;

        std::vector<uintptr_t> targets;

        targets.reserve(
            snap.players.size()
        );

        for (const auto& player : snap.players)
        {
            if (player.entityId != 0)
            {
                targets.push_back(
                    player.entityId
                );
            }
        }

        inventoryOverlay.SetTargets(
            targets
        );

        RegisterInventoryElement();
    }

    void Toggle()
    {
        isOpen =
            !isOpen;

        InventoryOverlay::SetMenuPreviewActive(
            isOpen
        );
    }

    void HandleInputs()
    {
        static bool deletePressed =
            false;

        const bool deleteDown =
            (
                GetAsyncKeyState(
                    VK_DELETE
                ) &
                0x8000
                ) != 0;

        if (
            deleteDown &&
            !deletePressed
            )
        {
            isOpen =
                !isOpen;

            InventoryOverlay::SetMenuPreviewActive(
                isOpen
            );
        }

        deletePressed =
            deleteDown;
    }

    void InitFonts(
        float fontSize = 13.f
    )
    {
        ImGuiIO& io =
            ImGui::GetIO();

        if (!io.Fonts)
            return;

        io.Fonts->Clear();

        ImFontConfig cfg{};

        cfg.OversampleH = 1;
        cfg.OversampleV = 1;
        cfg.PixelSnapH = true;
        cfg.FontDataOwnedByAtlas = false;

        static const ImWchar glyphRanges[] = {
            0x0020, 0x00FF,
            0x0100, 0x024F,
            0x0400, 0x052F,
            0x2DE0, 0x2DFF,
            0xA640, 0xA69F,
            0
        };

        textFont =
            io.Fonts->AddFontFromMemoryTTF(
                inter_medium,
                static_cast<int>(
                    sizeof(inter_medium)
                    ),
                fontSize,
                &cfg,
                glyphRanges
            );

        ImFontConfig iconCfg{};

        iconCfg.FontDataOwnedByAtlas =
            false;

        iconCfg.PixelSnapH =
            true;

        iconCfg.OversampleH =
            1;

        iconCfg.OversampleV =
            1;

        static const ImWchar iconRanges[] = {
            0xE000, 0xF8FF,
            0
        };

        iconFont =
            io.Fonts->AddFontFromMemoryTTF(
                fontello_data::ttf,
                static_cast<int>(
                    fontello_data::ttf_size
                    ),
                ICON_FONT_SIZE,
                &iconCfg,
                iconRanges
            );

        if (textFont)
            io.FontDefault =
            textFont;
    }

    void SetupStyle(
        ID3D11Device* device
    )
    {
        (void)device;

        InitFonts(
            TEXT_FONT_SIZE
        );

        ImGuiStyle& style =
            ImGui::GetStyle();

        style.WindowRounding = 8.f;
        style.ChildRounding = 6.f;
        style.FrameRounding = 4.f;
        style.PopupRounding = 5.f;
        style.ScrollbarRounding = 4.f;

        style.WindowBorderSize = 0.f;
        style.ChildBorderSize = 0.f;
        style.FrameBorderSize = 0.f;

        style.WindowPadding =
        {
            0.f,
            0.f
        };

        style.FramePadding =
        {
            9.f,
            6.f
        };

        style.ItemSpacing = { 9.f, 3.f };

        style.ItemInnerSpacing =
        {
            7.f,
            7.f
        };

        style.ScrollbarSize =
            0.f;

        style.Colors[ImGuiCol_Text] =
            ElysiumMenuPalette::Text;

        style.Colors[ImGuiCol_TextDisabled] =
            ElysiumMenuPalette::TextMuted;

        style.Colors[ImGuiCol_WindowBg] =
        {
            0.f,
            0.f,
            0.f,
            0.f
        };

        style.Colors[ImGuiCol_ChildBg] =
        {
            0.f,
            0.f,
            0.f,
            0.f
        };

        style.Colors[ImGuiCol_PopupBg] =
            ElysiumMenuPalette::Dropdown;

        style.Colors[ImGuiCol_Border] =
        {
            1.f,
            1.f,
            1.f,
            0.035f
        };

        style.Colors[ImGuiCol_FrameBg] =
            ElysiumMenuPalette::Control;

        style.Colors[ImGuiCol_FrameBgHovered] =
            ElysiumMenuPalette::ControlHover;

        style.Colors[ImGuiCol_FrameBgActive] =
            ElysiumMenuPalette::ControlHover;

        style.Colors[ImGuiCol_Button] =
            ElysiumMenuPalette::Control;

        style.Colors[ImGuiCol_ButtonHovered] =
            ElysiumMenuPalette::ControlHover;

        style.Colors[ImGuiCol_ButtonActive] =
            ElysiumMenuPalette::ControlHover;

        style.Colors[ImGuiCol_Header] =
            ElysiumMenuPalette::Control;

        style.Colors[ImGuiCol_HeaderHovered] =
            ElysiumMenuPalette::ControlHover;

        style.Colors[ImGuiCol_HeaderActive] =
            ElysiumMenuPalette::ControlHover;

        style.Colors[ImGuiCol_Separator] =
            ElysiumMenuPalette::Separator;

        style.Colors[ImGuiCol_ResizeGrip] =
            ElysiumMenuPalette::ConfigHover;

        style.Colors[ImGuiCol_ResizeGripHovered] =
            ImVec4(
                ElysiumMenuPalette::Accent.x,
                ElysiumMenuPalette::Accent.y,
                ElysiumMenuPalette::Accent.z,
                0.34f
            );

        style.Colors[ImGuiCol_ResizeGripActive] =
            ImVec4(
                ElysiumMenuPalette::Accent.x,
                ElysiumMenuPalette::Accent.y,
                ElysiumMenuPalette::Accent.z,
                0.56f
            );

        style.Colors[ImGuiCol_ScrollbarBg] =
        {
            0.f,
            0.f,
            0.f,
            0.f
        };

        style.Colors[ImGuiCol_ScrollbarGrab] =
            ImVec4(
                ElysiumMenuPalette::Accent.x,
                ElysiumMenuPalette::Accent.y,
                ElysiumMenuPalette::Accent.z,
                0.40f
            );

        style.Colors[ImGuiCol_ScrollbarGrabHovered] =
            ImVec4(
                ElysiumMenuPalette::Accent.x,
                ElysiumMenuPalette::Accent.y,
                ElysiumMenuPalette::Accent.z,
                0.60f
            );

        style.Colors[ImGuiCol_ScrollbarGrabActive] =
            ImVec4(
                ElysiumMenuPalette::Accent.x,
                ElysiumMenuPalette::Accent.y,
                ElysiumMenuPalette::Accent.z,
                0.78f
            );
    }

    void Render(
        ModuleManager& moduleManager
    )
    {
        ImGuiIO& io = ImGui::GetIO();

        // When fully closed no tab animations or menu widgets need updating.
        if (initialized && !isOpen && menuAlpha <= 0.001f) {
            InventoryOverlay::SetMenuPreviewActive(false);
            RegisterInventoryElement(); RegisterTargetHudElement(); RegisterRadarElement();
            SyncRadarInterfaceElement();
            interfaceManager.RenderOverlay(1.f, false);
            return;
        }
        const float dt =
            io.DeltaTime > 0.f
            ? ImClamp(io.DeltaTime, 0.0001f, 0.1f)
            : 1.f / 144.f;

        if (!initialized)
        {
            menuProgress = isOpen ? 1.f : 0.f;
            menuAlpha = menuProgress;
            menuVelocity = 0.f;

            tabFade = 1.f;
            tabProgress = 1.f;
            tabFadeVelocity = 0.f;
            tabProgressVelocity = 0.f;

            initialized = true;
        }





        const float menuTarget = isOpen ? 1.f : 0.f;
        const float menuSpeed = isOpen ? menuOpenSpeed : menuCloseSpeed;

        menuProgress = smoothDamp(
            menuProgress,
            menuTarget,
            menuVelocity,
            speedToSmoothTime(menuSpeed),
            1000.f,
            dt
        );

        if (std::fabs(menuProgress - menuTarget) < 0.001f)
        {
            menuProgress = menuTarget;
            menuVelocity = 0.f;
        }

        const float reveal = easeOutCubic(menuProgress);
        menuAlpha = reveal * reveal;

        InventoryOverlay::SetMenuPreviewActive(
            menuAlpha > 0.001f
        );





        if (pendingTab != -1)
        {
            tabFade = smoothDamp(
                tabFade,
                0.f,
                tabFadeVelocity,
                0.075f,
                1000.f,
                dt
            );

            tabProgress = smoothDamp(
                tabProgress,
                0.f,
                tabProgressVelocity,
                0.095f,
                1000.f,
                dt
            );

            if (tabFade <= 0.015f)
            {
                currentTab = pendingTab;
                pendingTab = -1;

                tabFade = 0.f;
                tabFadeVelocity = 0.f;
                tabProgress = 0.f;
                tabProgressVelocity = 0.f;
            }
        }
        else
        {
            tabFade = smoothDamp(
                tabFade,
                1.f,
                tabFadeVelocity,
                0.095f,
                1000.f,
                dt
            );

            tabProgress = smoothDamp(
                tabProgress,
                1.f,
                tabProgressVelocity,
                0.12f,
                1000.f,
                dt
            );

            if (tabFade >= 0.995f)
            {
                tabFade = 1.f;
                tabFadeVelocity = 0.f;
            }

            if (tabProgress >= 0.995f)
            {
                tabProgress = 1.f;
                tabProgressVelocity = 0.f;
            }
        }

        RegisterInventoryElement();
        RegisterTargetHudElement();
        RegisterRadarElement();
        SyncRadarInterfaceElement();

        interfaceManager.RenderOverlay(
            1.f,
            isOpen && menuAlpha > 0.01f
        );



        SyncRadarInterfaceElement();

        if (menuAlpha <= 0.001f)
            return;

        constexpr float panelWidth = 900.f;
        constexpr float panelHeight = 600.f;
        constexpr float sidebarWidth = 154.f;
        constexpr float headerHeight = 72.f;

        if (!positionInitialized)
        {
            ImGuiViewport* viewport = ImGui::GetMainViewport();

            if (viewport)
            {
                panelPos = {
                    viewport->GetCenter().x - panelWidth * 0.5f,
                    viewport->GetCenter().y - panelHeight * 0.5f
                };
            }

            positionInitialized = true;
        }

        const ImVec2 display = io.DisplaySize;
        const ImVec2 mouse = io.MousePos;
        // Keep the trace panel to the right where the screen permits it.
        if (currentTab==0 && visualTab==0 && display.x>=panelWidth+200.f)
            panelPos.x=ImClamp(panelPos.x,0.f,ImMax(0.f,display.x-panelWidth-192.f));


        const float verticalOffset =
            (1.f - reveal) * 16.f;

        const float horizontalOffset =
            (1.f - reveal) * 5.f;

        const ImVec2 animatedPos(
            panelPos.x - horizontalOffset,
            panelPos.y - verticalOffset
        );

        const ImVec2 panelSize(
            panelWidth,
            panelHeight
        );

        const ImVec2 panelMax(
            animatedPos.x + panelSize.x,
            animatedPos.y + panelSize.y
        );

        const ImRect panelRect(
            animatedPos,
            panelMax
        );
        RenderFeature::SetMenuBounds(
            ImVec2(
                animatedPos.x + sidebarWidth + 12.f,
                animatedPos.y + headerHeight + 8.f
            ),
            ImVec2(
                panelMax.x - 12.f,
                panelMax.y - 12.f
            )
        );


        const ImRect panelDragHandle(
            ImVec2(
                animatedPos.x + sidebarWidth,
                animatedPos.y
            ),
            ImVec2(
                panelMax.x,
                animatedPos.y + headerHeight
            )
        );

        if (!isOpen || menuAlpha <= 0.72f)
        {
            panelDragging = false;
        }
        else
        {
                const bool closeHot = CloseButtonRect(panelRect).Contains(mouse);
            if (
                !panelDragging &&
                !closeHot &&
                ImGui::IsMouseClicked(ImGuiMouseButton_Left) &&
                panelDragHandle.Contains(mouse)
                )
            {
                panelDragging = true;

                panelDragOffset = {
                    mouse.x - panelRect.Min.x,
                    mouse.y - panelRect.Min.y
                };
            }

            if (panelDragging)
            {
                if (!io.MouseDown[ImGuiMouseButton_Left])
                {
                    panelDragging = false;
                }
                else if (
                    std::isfinite(mouse.x) &&
                    std::isfinite(mouse.y)
                    )
                {
                    panelPos.x = mouse.x - panelDragOffset.x;
                    panelPos.y = mouse.y - panelDragOffset.y;

                    const float maxX = ImMax(0.f, display.x - panelWidth);
                    const float maxY = ImMax(0.f, display.y - panelHeight);

                    panelPos.x = ImClamp(panelPos.x, 0.f, maxX);
                    panelPos.y = ImClamp(panelPos.y, 0.f, maxY);
                }
            }
        }

        ImGui::SetNextWindowPos(
            ImVec2(0.f, 0.f),
            ImGuiCond_Always
        );

        ImGui::SetNextWindowSize(
            display,
            ImGuiCond_Always
        );

        ImGui::PushStyleVar(
            ImGuiStyleVar_Alpha,
            menuAlpha
        );

        const ImGuiWindowFlags hostFlags =
            ImGuiWindowFlags_NoTitleBar |
            ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoMove |
            ImGuiWindowFlags_NoScrollbar |
            ImGuiWindowFlags_NoCollapse |
            ImGuiWindowFlags_NoSavedSettings |
            ImGuiWindowFlags_NoBackground;

        if (
            ImGui::Begin(
                "##ElysiumHost",
                nullptr,
                hostFlags
            )
            )
        {
            ImDrawList* dl =
                ImGui::GetWindowDrawList();

            if (dl)
            {
                drawAnimatedBackground(
                    dl,
                    panelRect
                );

                drawTopBar(
                    dl,
                    panelRect
                );
            }

            if (isOpen && currentTab==0 && visualTab==0)
                drawAimTracePanel(dl,panelRect,display,moduleManager);
            else
                traceDrawing=false;

            const float contentFade = clamp01(tabFade);
            const float transitionEase =
                easeOutCubic(clamp01(tabProgress));

            float contentSlideX = 0.f;
            float contentSlideY = 0.f;

            if (pendingTab != -1)
            {
                const float outEase =
                    easeInOutCubic(1.f - contentFade);

                contentSlideX =
                    -static_cast<float>(transitionDirection) *
                    outEase *
                    12.f;

                contentSlideY =
                    outEase *
                    3.f;
            }
            else
            {
                const float inEase = transitionEase;

                contentSlideX =
                    static_cast<float>(transitionDirection) *
                    (1.f - inEase) *
                    14.f;

                contentSlideY =
                    (1.f - inEase) *
                    4.f;
            }

            const ImVec2 contentPos(
                animatedPos.x + sidebarWidth + 20.f + contentSlideX,
                animatedPos.y + headerHeight + 14.f + contentSlideY
            );

            const ImVec2 contentSize(
                panelSize.x - sidebarWidth - 38.f,
                panelSize.y - headerHeight - 28.f
            );

            ImGui::SetCursorScreenPos(
                contentPos
            );

            ImGui::PushStyleVar(
                ImGuiStyleVar_WindowPadding,
                ImVec2(0.f, 0.f)
            );

            const float parentAlpha =
                clamp01(ImGui::GetStyle().Alpha);

            const float contentAlpha =
                clamp01(
                    parentAlpha *
                    contentFade *
                    (0.96f + 0.04f * reveal)
                );

            ImGui::PushStyleVar(
                ImGuiStyleVar_Alpha,
                contentAlpha
            );

            ImGui::PushID(
                currentTab + 1000
            );

            ScrollState& scrollState =
                scrollStates[currentTab];

            if (scrollState.displayHeight > 1.f)
            {
                ImGui::SetNextWindowContentSize(
                    ImVec2(
                        0.f,
                        scrollState.displayHeight
                    )
                );
            }

            const ImGuiWindowFlags contentFlags =
                ImGuiWindowFlags_NoBackground |
                ImGuiWindowFlags_NoScrollWithMouse;

            const bool contentVisible =
                ImGui::BeginChild(
                    "##ElysiumContent",
                    contentSize,
                    ImGuiChildFlags_None,
                    contentFlags
                );

            if (contentVisible)
            {
                drawActivePage(
                    moduleManager
                );

                ImGui::Dummy(
                    ImVec2(1.f, 20.f)
                );

                updateSmoothScroll(
                    currentTab,
                    dt
                );
            }

            ImGui::EndChild();

            ImGui::PopID();
            ImGui::PopStyleVar(2);


        }

        ImGui::End();

        ImGui::PopStyleVar();
    }
};
