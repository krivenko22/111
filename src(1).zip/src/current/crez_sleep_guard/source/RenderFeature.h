#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif

#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif

#include <windows.h>

#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cmath>
#include <string>
#include <unordered_map>
#include <cfloat>

namespace RenderFeature
{




    inline constexpr float GLASS_R = 0.050f;
    inline constexpr float GLASS_G = 0.050f;
    inline constexpr float GLASS_B = 0.052f;

    inline const ImVec4 ACCENT = ImVec4(0.67f, 0.035f, 0.13f, 1.f);
    inline const ImVec4 ACCENT_SOFT = ImVec4(0.38f, 0.025f, 0.07f, 1.f);

    inline const ImVec4 ACCENT_CYAN = ACCENT;
    inline const ImVec4 ACCENT_VIOLET = ACCENT;
    inline const ImVec4 ACCENT_TEAL = ACCENT;
    inline const ImVec4 ACCENT_PINK = ACCENT_SOFT;

    inline const ImVec4 SURFACE = ImVec4(0.045f, 0.045f, 0.047f, 1.f);
    inline const ImVec4 SIDEBAR = ImVec4(0.035f, 0.035f, 0.037f, 1.f);
    inline const ImVec4 HEADER = ImVec4(0.050f, 0.050f, 0.052f, 1.f);

    inline const ImVec4 CONTROL = ImVec4(0.080f, 0.080f, 0.084f, 1.f);
    inline const ImVec4 CONTROL_HOVER = ImVec4(0.115f, 0.110f, 0.114f, 1.f);
    inline const ImVec4 CONTROL_ACTIVE = ImVec4(0.084f, 0.068f, 0.094f, 1.f);
    inline const ImVec4 CIRCLE_HOVER = ImVec4(0.078f, 0.062f, 0.090f, 1.f);

    inline const ImVec4 TEXT = ImVec4(0.94f, 0.94f, 0.94f, 1.f);
    inline const ImVec4 TEXT_MUTED = ImVec4(0.64f, 0.63f, 0.64f, 1.f);
    inline const ImVec4 HEADER_TEXT = ImVec4(0.76f, 0.75f, 0.76f, 1.f);

    inline const ImVec4 SEPARATOR_COLOR = ImVec4(0.19f, 0.19f, 0.20f, 0.70f);
    inline const ImVec4 BORDER = ImVec4(1.f, 1.f, 1.f, 0.055f);
    inline const ImVec4 POPUP_BG = ImVec4(0.020f, 0.018f, 0.028f, 0.985f);





    inline float Clamp01(float value) { return ImClamp(value, 0.f, 1.f); }

    inline float SafeDeltaTime()
    {
        const float dt = ImGui::GetIO().DeltaTime;
        if (dt <= 0.f) return 1.f / 144.f;
        return ImClamp(dt, 0.0001f, 0.1f);
    }

    inline float SmoothTo(float current, float target, float speed, float dt)
    {
        if (dt <= 0.f) return current;
        dt = ImMin(dt, 1.f / 30.f);
        const float factor = 1.f - std::exp(-speed * dt);
        return current + (target - current) * factor;
    }

    inline float EaseOutCubic(float t)
    {
        t = Clamp01(t);
        const float inv = 1.f - t;
        return 1.f - inv * inv * inv;
    }

    inline float EaseInOutCubic(float t)
    {
        t = Clamp01(t);
        if (t < 0.5f) return 4.f * t * t * t;
        const float f = -2.f * t + 2.f;
        return 1.f - (f * f * f) * 0.5f;
    }

    inline float EaseOutQuint(float t)
    {
        t = Clamp01(t);
        const float inv = 1.f - t;
        return 1.f - inv * inv * inv * inv * inv;
    }

    inline float EaseOutBack(float t)
    {
        t = Clamp01(t);
        const float c1 = 1.70158f;
        const float c3 = c1 + 1.f;
        const float x = t - 1.f;
        return 1.f + c3 * x * x * x + c1 * x * x;
    }

    inline float Lerp(float a, float b, float t)
    {
        return a + (b - a) * Clamp01(t);
    }

    inline ImVec4 LerpColor(const ImVec4& a, const ImVec4& b, float t)
    {
        t = Clamp01(t);
        return ImVec4(
            Lerp(a.x, b.x, t),
            Lerp(a.y, b.y, t),
            Lerp(a.z, b.z, t),
            Lerp(a.w, b.w, t)
        );
    }

    inline ImVec4 WithAlpha(ImVec4 color, float alpha)
    {
        color.w *= Clamp01(alpha);
        return color;
    }

    inline float GetParentAlpha()
    {
        return Clamp01(ImGui::GetStyle().Alpha);
    }

    inline float GetAlpha(float localAlpha)
    {
        return Clamp01(localAlpha) * GetParentAlpha();
    }

    inline ImVec4 Alpha(ImVec4 color, float alpha)
    {
        color.w *= GetAlpha(alpha);
        return color;
    }

    inline ImU32 ToU32(const ImVec4& color)
    {
        return ImGui::ColorConvertFloat4ToU32(color);
    }

    inline float Pulse(float speed, float phase = 0.f)
    {
        const float time = static_cast<float>(ImGui::GetTime());
        return 0.5f + 0.5f * std::sin(time * speed + phase);
    }

    inline ImVec4 AccentGradient(float t)
    {
        (void)t;
        return ACCENT;
    }





    struct AnimState
    {
        float value = 0.f;
        float hover = 0.f;
        float press = 0.f;
        float open = 0.f;
        float fill = 0.f;
        float pulse = 0.f;
        float swipe = 0.f;
        float focus = 0.f;
        float click = 0.f;
        float trailing = 0.f;
        float sheen = 0.f;
    };

    inline std::unordered_map<std::uint64_t, AnimState>& GetAnimationStorage()
    {
        static std::unordered_map<std::uint64_t, AnimState> storage;
        return storage;
    }

    inline std::uint64_t HashString(const char* text)
    {
        std::uint64_t hash = 1469598103934665603ULL;
        if (!text) return hash;
        while (*text)
        {
            hash ^= static_cast<std::uint64_t>(static_cast<unsigned char>(*text));
            hash *= 1099511628211ULL;
            ++text;
        }
        return hash;
    }

    inline std::uint64_t MakeKey(const void* owner, const char* label, int index)
    {
        std::uint64_t key = reinterpret_cast<std::uintptr_t>(owner);
        key ^= HashString(label);
        key ^= static_cast<std::uint64_t>(
            static_cast<std::uint32_t>(index)
            ) + 0x9e3779b97f4a7c15ULL;
        return key;
    }

    inline AnimState& GetAnim(const void* owner, const char* label, int index = 0)
    {
        return GetAnimationStorage()[MakeKey(owner, label, index)];
    }





    struct BindState
    {
        int key = 0;

        bool toggle = false;
        bool opened = false;
        bool waiting = false;

        float anim = 0.f;
        float hover = 0.f;
        float press = 0.f;
        float holdAnim = 0.f;
        float toggleAnim = 0.f;
        float bindPulse = 0.f;
        float popupGlow = 0.f;

        ImVec2 popupMin = { 0.f, 0.f };
        ImVec2 popupMax = { 0.f, 0.f };


        bool openUp = true;
        bool openUpValid = false;
    };

    inline std::unordered_map<std::uint64_t, BindState>& GetBindStorage()
    {
        static std::unordered_map<std::uint64_t, BindState> storage;
        return storage;
    }

    inline BindState& GetBindState(const void* owner, const char* label, int index = 0)
    {
        return GetBindStorage()[MakeKey(owner, label, index + 10000)];
    }






    inline ImVec2 g_menuMin = { 0.f, 0.f };
    inline ImVec2 g_menuMax = { 0.f, 0.f };
    inline bool   g_menuBoundsValid = false;

    inline void SetMenuBounds(const ImVec2& mn, const ImVec2& mx)
    {
        g_menuMin = mn;
        g_menuMax = mx;
        g_menuBoundsValid = true;
    }





    inline bool IsMouseOverAnyBindPopup()
    {
        const ImVec2 mouse = ImGui::GetIO().MousePos;

        for (auto& [k, other] : GetBindStorage())
        {
            if (!other.opened) continue;

            if (mouse.x >= other.popupMin.x &&
                mouse.x <= other.popupMax.x &&
                mouse.y >= other.popupMin.y &&
                mouse.y <= other.popupMax.y)
            {
                return true;
            }
        }
        return false;
    }





    struct PopupState
    {
        bool opened = false;
        float anim = 0.f;
    };

    inline std::unordered_map<std::uint64_t, PopupState>& GetPopupStorage()
    {
        static std::unordered_map<std::uint64_t, PopupState> storage;
        return storage;
    }

    inline PopupState& GetPopupState(const void* owner, const char* label, int index = 0)
    {
        return GetPopupStorage()[MakeKey(owner, label, index + 90000)];
    }

    struct SelectState
    {
        bool opened = false;
        float anim = 0.f;
        float hover = 0.f;
        float press = 0.f;
    };

    inline std::unordered_map<std::uint64_t, SelectState>& GetSelectStorage()
    {
        static std::unordered_map<std::uint64_t, SelectState> storage;
        return storage;
    }

    inline SelectState& GetSelectState(const void* owner, const char* label, int index = 0)
    {
        return GetSelectStorage()[MakeKey(owner, label, index + 70000)];
    }





    inline const char* GetKeyName(int vk)
    {
        static char name[32]{};
        if (vk <= 0) return "None";

        switch (vk)
        {
        case VK_LBUTTON:  return "M1";
        case VK_RBUTTON:  return "M2";
        case VK_MBUTTON:  return "M3";
        case VK_XBUTTON1: return "M4";
        case VK_XBUTTON2: return "M5";
        case VK_BACK:     return "Back";
        case VK_TAB:      return "Tab";
        case VK_RETURN:   return "Enter";
        case VK_SHIFT:    return "Shift";
        case VK_CONTROL:  return "Ctrl";
        case VK_MENU:     return "Alt";
        case VK_PAUSE:    return "Pause";
        case VK_CAPITAL:  return "Caps";
        case VK_ESCAPE:   return "Esc";
        case VK_SPACE:    return "Space";
        case VK_PRIOR:    return "PgUp";
        case VK_NEXT:     return "PgDn";
        case VK_END:      return "End";
        case VK_HOME:     return "Home";
        case VK_LEFT:     return "Left";
        case VK_UP:       return "Up";
        case VK_RIGHT:    return "Right";
        case VK_DOWN:     return "Down";
        case VK_INSERT:   return "Ins";
        case VK_DELETE:   return "Del";
        case VK_F1:       return "F1";
        case VK_F2:       return "F2";
        case VK_F3:       return "F3";
        case VK_F4:       return "F4";
        case VK_F5:       return "F5";
        case VK_F6:       return "F6";
        case VK_F7:       return "F7";
        case VK_F8:       return "F8";
        case VK_F9:       return "F9";
        case VK_F10:      return "F10";
        case VK_F11:      return "F11";
        case VK_F12:      return "F12";
        case VK_LSHIFT:   return "LShift";
        case VK_RSHIFT:   return "RShift";
        case VK_LCONTROL: return "LCtrl";
        case VK_RCONTROL: return "RCtrl";
        case VK_LMENU:    return "LAlt";
        case VK_RMENU:    return "RAlt";
        case VK_LWIN:     return "LWin";
        case VK_RWIN:     return "RWin";
        case VK_NUMPAD0:  return "Num0";
        case VK_NUMPAD1:  return "Num1";
        case VK_NUMPAD2:  return "Num2";
        case VK_NUMPAD3:  return "Num3";
        case VK_NUMPAD4:  return "Num4";
        case VK_NUMPAD5:  return "Num5";
        case VK_NUMPAD6:  return "Num6";
        case VK_NUMPAD7:  return "Num7";
        case VK_NUMPAD8:  return "Num8";
        case VK_NUMPAD9:  return "Num9";
        case VK_MULTIPLY: return "Num*";
        case VK_ADD:      return "Num+";
        case VK_SUBTRACT: return "Num-";
        case VK_DECIMAL:  return "Num.";
        case VK_DIVIDE:   return "Num/";
        default: break;
        }

        if (vk >= '0' && vk <= '9') { name[0] = (char)vk; name[1] = '\0'; return name; }
        if (vk >= 'A' && vk <= 'Z') { name[0] = (char)vk; name[1] = '\0'; return name; }
        return "Key";
    }

    inline int FindPressedKey()
    {
        static bool wasDown[256]{};
        int pressed = 0;
        for (int vk = 1; vk < 256; ++vk)
        {
            const bool down = (GetAsyncKeyState(vk) & 0x8000) != 0;
            if (down && !wasDown[vk] && pressed == 0) pressed = vk;
        }
        for (int vk = 1; vk < 256; ++vk)
            wasDown[vk] = (GetAsyncKeyState(vk) & 0x8000) != 0;
        return pressed;
    }

    inline bool IsMouseVirtualKey(int vk)
    {
        return vk == VK_LBUTTON || vk == VK_RBUTTON || vk == VK_MBUTTON ||
            vk == VK_XBUTTON1 || vk == VK_XBUTTON2;
    }





    inline void DrawGlowRect(
        ImDrawList* draw, const ImVec2& min, const ImVec2& max,
        const ImVec4& color, float rounding = 8.f, float alpha = 1.f,
        int layers = 4
    )
    {
        (void)layers;
        if (!draw || alpha <= 0.001f) return;

        draw->AddRect(
            ImVec2(min.x + 0.5f, min.y + 0.5f),
            ImVec2(max.x - 0.5f, max.y - 0.5f),
            ToU32(WithAlpha(color, alpha)),
            rounding, ImDrawFlags_RoundCornersAll, 1.f
        );
    }

    inline void DrawAnimatedSheen(
        ImDrawList* draw, const ImVec2& min, const ImVec2& max,
        float alpha = 1.f, float speed = 0.35f
    )
    {
        (void)draw; (void)min; (void)max; (void)alpha; (void)speed;
    }

    inline void DrawAccentLine(
        ImDrawList* draw, const ImVec2& start, float width,
        float alpha = 1.f, float thickness = 1.f
    )
    {
        if (!draw || width <= 0.f || alpha <= 0.001f) return;
        draw->AddRectFilled(
            start,
            ImVec2(start.x + width, start.y + thickness),
            ToU32(Alpha(ACCENT, alpha * 0.55f)),
            thickness * 0.5f
        );
    }

    inline void GlassPanel(
        ImDrawList* draw, const ImVec2& min, const ImVec2& max,
        float rounding, float alpha, float fillBoost = 0.f
    )
    {
        if (!draw || alpha <= 0.001f) return;
        const float a = GetAlpha(alpha);

        draw->AddRectFilled(
            min, max,
            ToU32(ImVec4(
                Clamp01(GLASS_R + fillBoost),
                Clamp01(GLASS_G + fillBoost),
                Clamp01(GLASS_B + fillBoost),
                0.985f * a
            )),
            rounding
        );
        draw->AddRectFilled(
            ImVec2(min.x + 18.f, min.y + 1.f),
            ImVec2(max.x - 18.f, min.y + 2.f),
            ToU32(WithAlpha(ACCENT, 0.14f * a)),
            1.f
        );
        draw->AddRect(
            ImVec2(min.x + 0.5f, min.y + 0.5f),
            ImVec2(max.x - 0.5f, max.y - 0.5f),
            ToU32(WithAlpha(BORDER, a)),
            rounding, ImDrawFlags_RoundCornersAll, 1.f
        );
    }

    inline void DrawRowHover(
        ImDrawList* draw, const ImVec2& min, const ImVec2& max,
        float amount, float rounding = 7.f
    )
    {
        if (!draw || amount <= 0.001f) return;
        amount = Clamp01(amount);
        const float parent = GetParentAlpha();

        draw->AddRectFilled(
            min, max,
            ToU32(ImVec4(0.080f, 0.064f, 0.091f, 0.55f * amount * parent)),
            rounding
        );
        draw->AddRectFilled(
            ImVec2(min.x + 12.f, max.y - 1.f),
            ImVec2(max.x - 12.f, max.y),
            ToU32(WithAlpha(ACCENT, 0.28f * amount * parent)),
            0.5f
        );
    }

    inline void DrawPill(
        ImDrawList* draw, const ImRect& rect,
        const ImVec4& fill, const ImVec4& border, float alpha = 1.f
    )
    {
        if (!draw) return;
        const float radius = rect.GetHeight() * 0.5f;
        draw->AddRectFilled(rect.Min, rect.Max, ToU32(Alpha(fill, alpha)), radius);
        draw->AddRect(
            ImVec2(rect.Min.x + 0.5f, rect.Min.y + 0.5f),
            ImVec2(rect.Max.x - 0.5f, rect.Max.y - 0.5f),
            ToU32(Alpha(border, alpha)),
            radius, ImDrawFlags_RoundCornersAll, 1.f
        );
    }

    inline void DrawCheckMark(
        ImDrawList* draw, const ImVec2& center,
        float size, float progress, ImU32 color
    )
    {
        if (!draw || progress <= 0.001f) return;
        progress = Clamp01(progress);

        const ImVec2 p1(center.x - size * 0.36f, center.y);
        const ImVec2 p2(center.x - size * 0.07f, center.y + size * 0.28f);
        const ImVec2 p3(center.x + size * 0.42f, center.y - size * 0.34f);

        const float first = ImMin(progress * 2.f, 1.f);
        const float second = Clamp01(progress * 2.f - 1.f);

        const ImVec2 middle(Lerp(p1.x, p2.x, first), Lerp(p1.y, p2.y, first));
        draw->AddLine(p1, middle, color, 2.f);

        if (second > 0.001f)
        {
            const ImVec2 end(Lerp(p2.x, p3.x, second), Lerp(p2.y, p3.y, second));
            draw->AddLine(p2, end, color, 2.f);
        }
    }

    inline void DrawSliderGlow(
        ImDrawList* draw, float x, float y, float radius,
        const ImVec4& color, float alpha
    )
    {
        if (!draw || alpha <= 0.001f) return;
        draw->AddCircle(
            ImVec2(x, y), radius + 3.f,
            ToU32(WithAlpha(color, alpha * 0.22f)), 24, 1.f
        );
    }

    inline void DrawChevron(
        ImDrawList* draw, const ImVec2& center,
        bool opened, float alpha = 1.f, float size = 5.f
    )
    {
        if (!draw) return;
        const ImU32 col = ToU32(Alpha(opened ? ACCENT : TEXT_MUTED, alpha));
        const float s = size;

        if (opened)
        {
            draw->AddLine(ImVec2(center.x - s, center.y - s * 0.25f),
                ImVec2(center.x, center.y + s * 0.45f), col, 1.7f);
            draw->AddLine(ImVec2(center.x, center.y + s * 0.45f),
                ImVec2(center.x + s, center.y - s * 0.25f), col, 1.7f);
        }
        else
        {
            draw->AddLine(ImVec2(center.x - s * 0.25f, center.y - s),
                ImVec2(center.x + s * 0.45f, center.y), col, 1.7f);
            draw->AddLine(ImVec2(center.x + s * 0.45f, center.y),
                ImVec2(center.x - s * 0.25f, center.y + s), col, 1.7f);
        }
    }





    inline void SectionTitle(const char* text, float alpha = 1.f)
    {
        if (!text) return;
        ImDrawList* draw=ImGui::GetWindowDrawList();
        if (!draw) return;
        const ImVec2 pos=ImGui::GetCursorScreenPos();
        const ImVec2 size=ImGui::CalcTextSize(text);
        draw->AddText(pos,ToU32(Alpha(HEADER_TEXT,alpha)),text);
        ImGui::Dummy(ImVec2(0.f,size.y+8.f));
    }

    inline void GradientSeparator(float alpha = 1.f, float height = 1.f)
    {
        ImDrawList* draw = ImGui::GetWindowDrawList();
        if (!draw) return;

        const ImVec2 pos = ImGui::GetCursorScreenPos();
        const float width = ImMax(0.f, ImGui::GetContentRegionAvail().x);

        draw->AddLine(
            pos, ImVec2(pos.x + width, pos.y),
            ToU32(Alpha(SEPARATOR_COLOR, alpha * 0.75f)), height
        );
        ImGui::Dummy(ImVec2(0.f, height + 6.f));
    }





    inline float AnimateReveal(
        const void* owner, const char* id, bool opened, float speed = 11.f
    )
    {
        AnimState& animation = GetAnim(owner, id, 0);
        animation.value = SmoothTo(
            animation.value, opened ? 1.f : 0.f, speed, SafeDeltaTime()
        );
        return Clamp01(animation.value);
    }

    inline float AnimatedReveal(
        const void* owner, const char* id, bool opened, float speed = 12.f
    )
    {
        return AnimateReveal(owner, id, opened, speed);
    }

    inline void AnimatedDummy(float fullHeight, float animation)
    {
        ImGui::Dummy(ImVec2(0.f, fullHeight * EaseOutCubic(animation)));
    }





    struct AnimatedGroupState
    {
        float reveal = 0.f;
        float layoutHeight = 0.f;
        float contentHeight = 0.f;
        ImVec2 startCursor{};
        ImVec2 startScreen{};
        float width = 0.f;
        bool active = false;
    };

    inline std::unordered_map<std::uint64_t, AnimatedGroupState>&
        GetAnimatedGroupStorage()
    {
        static std::unordered_map<std::uint64_t, AnimatedGroupState> storage;
        return storage;
    }

    inline AnimatedGroupState& GetAnimatedGroupState(
        const void* owner, const char* id, int index = 0
    )
    {
        return GetAnimatedGroupStorage()[MakeKey(owner, id, index + 50000)];
    }

    inline float BeginAnimatedGroup(
        const void* owner, const char* id, bool visible,
        int index = 0, float openSpeed = 9.f, float alpha = 1.f
    )
    {
        if (!owner || !id) return 0.f;

        AnimatedGroupState& state = GetAnimatedGroupState(owner, id, index);
        const float dt = SafeDeltaTime();

        const float targetReveal = visible ? 1.f : 0.f;
        const float revealSpeed = visible ? openSpeed : 24.f;

        state.reveal = SmoothTo(state.reveal, targetReveal, revealSpeed, dt);
        state.reveal = Clamp01(state.reveal);

        if (std::fabs(state.reveal - targetReveal) < 0.001f)
            state.reveal = targetReveal;

        const float eased = EaseOutQuint(state.reveal);
        const float targetHeight = state.contentHeight * eased;

        state.layoutHeight = SmoothTo(
            state.layoutHeight, targetHeight, visible ? 11.f : 27.f, dt
        );
        if (std::fabs(state.layoutHeight - targetHeight) < 0.05f)
            state.layoutHeight = targetHeight;

        state.layoutHeight = ImMax(0.f, state.layoutHeight);

        state.startCursor = ImGui::GetCursorPos();
        state.startScreen = ImGui::GetCursorScreenPos();
        state.width = ImMax(0.f, ImGui::GetContentRegionAvail().x);
        state.active = true;

        const float visibleAlpha = EaseOutQuint(state.reveal);

        ImGui::PushStyleVar(
            ImGuiStyleVar_Alpha,
            Clamp01(alpha) * visibleAlpha * GetParentAlpha()
        );
        ImGui::PushClipRect(
            state.startScreen,
            ImVec2(
                state.startScreen.x + state.width,
                state.startScreen.y + state.layoutHeight
            ),
            true
        );

        return visibleAlpha;
    }

    inline void EndAnimatedGroup(
        const void* owner, const char* id, int index = 0
    )
    {
        if (!owner || !id) return;

        AnimatedGroupState& state = GetAnimatedGroupState(owner, id, index);
        if (!state.active) return;

        const ImVec2 endCursor = ImGui::GetCursorPos();
        const float measuredHeight = ImMax(0.f, endCursor.y - state.startCursor.y);

        if (measuredHeight > 0.01f)
        {
            if (state.contentHeight <= 0.01f)
                state.contentHeight = measuredHeight;
            else
                state.contentHeight = SmoothTo(
                    state.contentHeight, measuredHeight, 20.f, SafeDeltaTime()
                );
        }

        const float targetHeight =
            state.contentHeight * EaseOutQuint(state.reveal);

        state.layoutHeight = SmoothTo(
            state.layoutHeight, targetHeight,
            state.reveal > 0.5f ? 11.f : 27.f, SafeDeltaTime()
        );

        if (std::fabs(state.layoutHeight - targetHeight) < 0.05f)
            state.layoutHeight = targetHeight;

        state.layoutHeight = ImMax(0.f, state.layoutHeight);

        ImGui::PopClipRect();
        ImGui::PopStyleVar();

        ImGui::SetCursorPos(
            ImVec2(
                state.startCursor.x,
                state.startCursor.y + state.layoutHeight
            )
        );

        state.active = false;
    }





    inline bool Toggle(
        const void* owner, const char* label,
        bool* value, int index = 0, float alpha = 1.f
    )
    {
        if (!owner || !label || !value) return false;

        AnimState& animation = GetAnim(owner, label, index);
        const float dt = SafeDeltaTime();

        animation.value = SmoothTo(animation.value, *value ? 1.f : 0.f, 18.f, dt);
        animation.click = SmoothTo(animation.click, 0.f, 13.f, dt);

        const float width = ImMax(1.f, ImGui::GetContentRegionAvail().x);
        constexpr float rowHeight = 34.f;

        ImGui::PushID(owner); ImGui::PushID(label); ImGui::PushID(index);
        ImGui::InvisibleButton("##toggle", ImVec2(width, rowHeight));

        const bool blocked = IsMouseOverAnyBindPopup();
        const bool hovered = !blocked && ImGui::IsItemHovered();
        const bool held = !blocked && ImGui::IsItemActive();
        const bool clicked = !blocked && ImGui::IsItemClicked(ImGuiMouseButton_Left);

        if (clicked) { *value = !*value; animation.click = 1.f; }

        animation.hover = SmoothTo(animation.hover, hovered ? 1.f : 0.f, 20.f, dt);
        animation.press = SmoothTo(animation.press, held ? 1.f : 0.f, 28.f, dt);

        const float state = Clamp01(animation.value);
        ImDrawList* draw = ImGui::GetWindowDrawList();

        if (draw)
        {
            const ImVec2 min = ImGui::GetItemRectMin();
            const ImVec2 max = ImGui::GetItemRectMax();

            DrawRowHover(draw, min, max, animation.hover, 8.f);

            ImFont* font = ImGui::GetFont();
            if (font)
            {
                const float fontSize = ImGui::GetFontSize();
                const ImVec2 textSize = font->CalcTextSizeA(
                    fontSize, FLT_MAX, 0.f, label
                );
                draw->AddText(
                    font, fontSize,
                    ImVec2(
                        min.x + 5.f,
                        min.y + (rowHeight - textSize.y) * 0.5f
                        - animation.press * 0.35f
                    ),
                    ToU32(LerpColor(
                        Alpha(TEXT_MUTED, alpha),
                        Alpha(TEXT, alpha),
                        0.55f + 0.45f * animation.hover
                    )),
                    label
                );
            }

            constexpr float switchW = 30.f;
            constexpr float switchH = 17.f;
            const float switchX = max.x - switchW - 2.f;
            const float switchY = min.y + (rowHeight - switchH) * 0.5f
                - animation.press * 0.35f;

            const ImVec2 switchMin(switchX, switchY);
            const ImVec2 switchMax(switchX + switchW, switchY + switchH);

            const ImVec4 track = LerpColor(
                ImVec4(0.060f, 0.058f, 0.082f, 1.f), ACCENT, state
            );

            draw->AddRectFilled(
                switchMin, switchMax, ToU32(Alpha(track, alpha)), switchH * 0.5f
            );
            draw->AddRect(
                switchMin, switchMax,
                ToU32(Alpha(ImVec4(1.f, 1.f, 1.f, 0.055f + 0.06f * state), alpha)),
                switchH * 0.5f, ImDrawFlags_RoundCornersAll, 1.f
            );

            const float knobX = Lerp(switchX + 8.5f, switchX + switchW - 8.5f, state);

            draw->AddCircleFilled(
                ImVec2(knobX, switchY + switchH * 0.5f),
                5.f,
                ToU32(Alpha(ImVec4(0.90f, 0.90f, 0.90f, 1.f), alpha)),
                24
            );
        }

        ImGui::PopID(); ImGui::PopID(); ImGui::PopID();
        return clicked;
    }





    inline bool Checkbox(
        const void* owner, const char* label,
        bool* value, int index = 0, float alpha = 1.f
    )
    {
        if (!owner || !label || !value) return false;

        AnimState& animation = GetAnim(owner, label, index);
        const float dt = SafeDeltaTime();

        animation.value = SmoothTo(animation.value, *value ? 1.f : 0.f, 20.f, dt);
        animation.click = SmoothTo(animation.click, 0.f, 13.f, dt);

        const float width = ImMax(1.f, ImGui::GetContentRegionAvail().x);
        constexpr float rowHeight = 34.f;
        constexpr float boxSize = 19.f;

        ImGui::PushID(owner); ImGui::PushID(label); ImGui::PushID(index);
        ImGui::InvisibleButton("##checkbox", ImVec2(width, rowHeight));

        const bool blocked = IsMouseOverAnyBindPopup();
        const bool hovered = !blocked && ImGui::IsItemHovered();
        const bool held = !blocked && ImGui::IsItemActive();
        const bool clicked = !blocked && ImGui::IsItemClicked(ImGuiMouseButton_Left);

        if (clicked) { *value = !*value; animation.click = 1.f; }

        animation.hover = SmoothTo(animation.hover, hovered ? 1.f : 0.f, 20.f, dt);
        animation.press = SmoothTo(animation.press, held ? 1.f : 0.f, 26.f, dt);

        const float check = Clamp01(animation.value);
        const ImVec2 min = ImGui::GetItemRectMin();
        const ImVec2 max = ImGui::GetItemRectMax();
        ImDrawList* draw = ImGui::GetWindowDrawList();

        if (draw)
        {
            DrawRowHover(draw, min, max, animation.hover * 0.75f, 8.f);

            const ImVec2 boxMin(min.x + 1.f, min.y + (rowHeight - boxSize) * 0.5f);
            const ImVec2 boxMax(boxMin.x + boxSize, boxMin.y + boxSize);

            const ImVec4 boxColor = LerpColor(
                ImVec4(0.055f, 0.052f, 0.075f, 1.f), ACCENT, check
            );

            draw->AddRectFilled(boxMin, boxMax, ToU32(Alpha(boxColor, alpha)), 5.f);
            draw->AddRect(
                boxMin, boxMax,
                ToU32(Alpha(ImVec4(1.f, 1.f, 1.f, 0.07f + 0.035f * animation.hover), alpha)),
                5.f, ImDrawFlags_RoundCornersAll, 1.f
            );

            const ImVec2 checkCenter(
                boxMin.x + boxSize * 0.5f,
                boxMin.y + boxSize * 0.5f
            );

            DrawCheckMark(
                draw, checkCenter, boxSize * 0.78f, EaseOutBack(check),
                ToU32(Alpha(ImVec4(0.97f, 0.96f, 0.99f, 1.f), alpha))
            );

            ImFont* font = ImGui::GetFont();
            if (font)
            {
                const float fontSize = ImGui::GetFontSize();
                const ImVec2 textSize = font->CalcTextSizeA(
                    fontSize, FLT_MAX, 0.f, label
                );
                draw->AddText(
                    font, fontSize,
                    ImVec2(
                        boxMax.x + 11.f,
                        min.y + (rowHeight - textSize.y) * 0.5f
                        - animation.press * 0.2f
                    ),
                    ToU32(LerpColor(
                        Alpha(TEXT_MUTED, alpha),
                        Alpha(TEXT, alpha),
                        0.58f + 0.42f * animation.hover
                    )),
                    label
                );
            }
        }

        ImGui::PopID(); ImGui::PopID(); ImGui::PopID();
        return clicked;
    }





    inline bool SliderFloat(
        const void* owner, const char* label,
        float* value, float minValue, float maxValue,
        const char* format = "%.2f", float alpha = 1.f
    )
    {
        if (!owner || !label || !value) return false;

        ImGuiIO& io = ImGui::GetIO();
        AnimState& animation = GetAnim(owner, label, 2000);
        const float dt = SafeDeltaTime();

        const float width = ImMax(1.f, ImGui::GetContentRegionAvail().x);
        constexpr float height = 40.f;

        ImGui::PushID(owner); ImGui::PushID(label);
        ImGui::InvisibleButton("##slider_float", ImVec2(width, height));

        const bool blocked = IsMouseOverAnyBindPopup();
        const bool hovered = !blocked && ImGui::IsItemHovered();
        const bool active = !blocked && ImGui::IsItemActive();
        const bool clicked = !blocked && ImGui::IsItemClicked(ImGuiMouseButton_Left);

        const ImVec2 min = ImGui::GetItemRectMin();
        const ImVec2 max = ImGui::GetItemRectMax();

        if (active)
        {
            const float mouseX = ImClamp(io.MousePos.x, min.x, max.x);
            const float t = Clamp01((mouseX - min.x) / ImMax(1.f, width));
            *value = minValue + (maxValue - minValue) * t;
        }

        *value = ImClamp(*value, minValue, maxValue);

        const float t = maxValue != minValue
            ? Clamp01((*value - minValue) / (maxValue - minValue))
            : 0.f;

        animation.fill = SmoothTo(animation.fill, t, active ? 32.f : 18.f, dt);
        animation.trailing = SmoothTo(
            animation.trailing, animation.fill, active ? 15.f : 11.f, dt
        );
        animation.hover = SmoothTo(animation.hover, hovered ? 1.f : 0.f, 20.f, dt);
        animation.press = SmoothTo(animation.press, active ? 1.f : 0.f, 26.f, dt);

        ImDrawList* draw = ImGui::GetWindowDrawList();

        if (draw)
        {
            ImFont* font = ImGui::GetFont();
            const float fontSize = ImGui::GetFontSize();
            char valueText[64]{};
            ImFormatString(
                valueText, sizeof(valueText),
                format ? format : "%.2f", *value
            );

            if (font)
            {
                draw->AddText(
                    font, fontSize, ImVec2(min.x + 1.f, min.y + 1.f),
                    ToU32(Alpha(hovered ? TEXT : TEXT_MUTED, alpha)),
                    label
                );

                const ImVec2 valueSize = font->CalcTextSizeA(
                    fontSize, FLT_MAX, 0.f, valueText
                );
                draw->AddText(
                    font, fontSize,
                    ImVec2(max.x - valueSize.x, min.y + 1.f),
                    ToU32(Alpha(TEXT_MUTED, alpha)),
                    valueText
                );
            }

            const float lineY = min.y + 29.f;
            const float trackHeight = (hovered || active) ? 3.f : 2.f;

            draw->AddRectFilled(
                ImVec2(min.x, lineY - trackHeight * 0.5f),
                ImVec2(max.x, lineY + trackHeight * 0.5f),
                ToU32(Alpha(ImVec4(0.065f, 0.061f, 0.088f, 1.f), alpha)),
                trackHeight
            );

            const float filledX = min.x + width * animation.fill;
            if (filledX > min.x)
            {
                draw->AddRectFilled(
                    ImVec2(min.x, lineY - trackHeight * 0.5f),
                    ImVec2(filledX, lineY + trackHeight * 0.5f),
                    ToU32(Alpha(ACCENT, alpha)),
                    trackHeight * 0.5f
                );
            }

            draw->AddCircleFilled(
                ImVec2(filledX, lineY),
                active ? 4.5f : 3.8f,
                ToU32(Alpha(ImVec4(0.96f, 0.95f, 0.98f, 1.f), alpha)),
                24
            );
        }

        ImGui::PopID(); ImGui::PopID();
        return active || clicked;
    }





    inline bool SliderInt(
        const void* owner, const char* label,
        int* value, int minValue, int maxValue,
        const char* format = "%d", float alpha = 1.f
    )
    {
        if (!owner || !label || !value) return false;

        ImGuiIO& io = ImGui::GetIO();
        AnimState& animation = GetAnim(owner, label, 4000);
        const float dt = SafeDeltaTime();

        const float width = ImMax(1.f, ImGui::GetContentRegionAvail().x);
        constexpr float height = 40.f;

        ImGui::PushID(owner); ImGui::PushID(label);
        ImGui::InvisibleButton("##slider_int", ImVec2(width, height));

        const bool blocked = IsMouseOverAnyBindPopup();
        const bool hovered = !blocked && ImGui::IsItemHovered();
        const bool active = !blocked && ImGui::IsItemActive();
        const bool clicked = !blocked && ImGui::IsItemClicked(ImGuiMouseButton_Left);

        const ImVec2 min = ImGui::GetItemRectMin();
        const ImVec2 max = ImGui::GetItemRectMax();

        if (active)
        {
            const float mouseX = ImClamp(io.MousePos.x, min.x, max.x);
            const float t = Clamp01((mouseX - min.x) / ImMax(1.f, width));
            *value = minValue + static_cast<int>(
                std::round((maxValue - minValue) * t)
                );
        }

        *value = ImClamp(*value, minValue, maxValue);

        const float t = maxValue != minValue
            ? Clamp01(
                static_cast<float>(*value - minValue) /
                static_cast<float>(maxValue - minValue)
            )
            : 0.f;

        animation.fill = SmoothTo(animation.fill, t, active ? 32.f : 18.f, dt);
        animation.trailing = SmoothTo(
            animation.trailing, animation.fill, active ? 15.f : 11.f, dt
        );
        animation.hover = SmoothTo(animation.hover, hovered ? 1.f : 0.f, 20.f, dt);
        animation.press = SmoothTo(animation.press, active ? 1.f : 0.f, 26.f, dt);

        ImDrawList* draw = ImGui::GetWindowDrawList();

        if (draw)
        {
            ImFont* font = ImGui::GetFont();
            const float fontSize = ImGui::GetFontSize();
            char valueText[64]{};
            ImFormatString(
                valueText, sizeof(valueText),
                format ? format : "%d", *value
            );

            if (font)
            {
                draw->AddText(
                    font, fontSize, ImVec2(min.x + 1.f, min.y + 1.f),
                    ToU32(Alpha(hovered ? TEXT : TEXT_MUTED, alpha)),
                    label
                );

                const ImVec2 valueSize = font->CalcTextSizeA(
                    fontSize, FLT_MAX, 0.f, valueText
                );
                draw->AddText(
                    font, fontSize,
                    ImVec2(max.x - valueSize.x, min.y + 1.f),
                    ToU32(Alpha(TEXT_MUTED, alpha)),
                    valueText
                );
            }

            const float lineY = min.y + 29.f;
            const float trackHeight = (hovered || active) ? 3.f : 2.f;

            draw->AddRectFilled(
                ImVec2(min.x, lineY - trackHeight * 0.5f),
                ImVec2(max.x, lineY + trackHeight * 0.5f),
                ToU32(Alpha(ImVec4(0.065f, 0.061f, 0.088f, 1.f), alpha)),
                trackHeight
            );

            const float filledX = min.x + width * animation.fill;
            if (filledX > min.x)
            {
                draw->AddRectFilled(
                    ImVec2(min.x, lineY - trackHeight * 0.5f),
                    ImVec2(filledX, lineY + trackHeight * 0.5f),
                    ToU32(Alpha(ACCENT, alpha)),
                    trackHeight * 0.5f
                );
            }

            draw->AddCircleFilled(
                ImVec2(filledX, lineY),
                active ? 4.5f : 3.8f,
                ToU32(Alpha(ImVec4(0.96f, 0.95f, 0.98f, 1.f), alpha)),
                24
            );
        }

        ImGui::PopID(); ImGui::PopID();
        return active || clicked;
    }





    inline bool ColorEdit4(
        const void* owner, const char* label,
        float color[4], float alpha = 1.f
    )
    {
        if (!owner || !label || !color)
            return false;

        AnimState& animation = GetAnim(owner, label, 7000);
        PopupState& popup = GetPopupState(owner, label, 7000);
        const float dt = SafeDeltaTime();

        const float width = ImMax(1.f, ImGui::GetContentRegionAvail().x);
        constexpr float height = 44.f;

        ImGui::PushID(owner);
        ImGui::PushID(label);
        ImGui::InvisibleButton("##color_edit", ImVec2(width, height));

        const bool blocked = IsMouseOverAnyBindPopup();
        const bool hovered = !blocked && ImGui::IsItemHovered();
        const bool clicked = !blocked && ImGui::IsItemClicked(ImGuiMouseButton_Left);

        if (clicked)
            popup.opened = !popup.opened;

        if (popup.opened && ImGui::IsKeyPressed(ImGuiKey_Escape))
            popup.opened = false;

        popup.anim = SmoothTo(
            popup.anim,
            popup.opened ? 1.f : 0.f,
            popup.opened ? 24.f : 28.f,
            dt
        );

        animation.hover = SmoothTo(
            animation.hover,
            hovered ? 1.f : 0.f,
            18.f,
            dt
        );

        animation.open = SmoothTo(
            animation.open,
            popup.opened ? 1.f : 0.f,
            popup.opened ? 26.f : 30.f,
            dt
        );

        const ImVec2 min = ImGui::GetItemRectMin();
        const ImVec2 max = ImGui::GetItemRectMax();
        ImDrawList* draw = ImGui::GetWindowDrawList();

        if (draw)
        {
            DrawRowHover(draw, min, max, animation.hover * 0.65f, 7.f);

            ImFont* font = ImGui::GetFont();
            if (font)
            {
                draw->AddText(
                    font,
                    ImGui::GetFontSize(),
                    ImVec2(min.x + 2.f, min.y + 11.f),
                    ToU32(Alpha(hovered ? TEXT : TEXT_MUTED, alpha)),
                    label
                );
            }

            constexpr float swatchWidth = 48.f;
            constexpr float swatchHeight = 24.f;

            const ImVec2 swatchMin(max.x - swatchWidth, min.y + 10.f);
            const ImVec2 swatchMax(max.x, min.y + 10.f + swatchHeight);
            const float checker = 6.f;

            for (float y = swatchMin.y; y < swatchMax.y; y += checker)
            {
                for (float x = swatchMin.x; x < swatchMax.x; x += checker)
                {
                    const bool even =
                        (
                            static_cast<int>((x - swatchMin.x) / checker) +
                            static_cast<int>((y - swatchMin.y) / checker)
                            ) & 1;

                    draw->AddRectFilled(
                        ImVec2(x, y),
                        ImVec2(
                            ImMin(x + checker, swatchMax.x),
                            ImMin(y + checker, swatchMax.y)
                        ),
                        ToU32(Alpha(
                            even
                            ? ImVec4(0.11f, 0.10f, 0.14f, 1.f)
                            : ImVec4(0.075f, 0.07f, 0.10f, 1.f),
                            alpha
                        ))
                    );
                }
            }

            draw->AddRectFilled(
                swatchMin,
                swatchMax,
                ToU32(ImVec4(color[0], color[1], color[2], GetAlpha(alpha))),
                6.f
            );

            draw->AddRect(
                swatchMin,
                swatchMax,
                ToU32(Alpha(
                    ImVec4(1.f, 1.f, 1.f, 0.12f + 0.06f * animation.hover),
                    alpha
                )),
                6.f,
                ImDrawFlags_RoundCornersAll,
                1.f
            );
        }

        bool changed = false;

        if (popup.anim > 0.01f)
        {
            const float open = EaseOutQuint(Clamp01(popup.anim));
            const float eased = EaseOutCubic(open);
            const float parentAlpha = GetParentAlpha();
            const float popupAlpha = Clamp01(open) * parentAlpha;

            constexpr float popupWidth = 250.f;
            constexpr float estimatedPopupHeight = 276.f;
            constexpr float popupGap = 6.f;
            constexpr float popupMargin = 8.f;

            const ImVec2 display = ImGui::GetIO().DisplaySize;

            ImVec2 boundsMin(popupMargin, popupMargin);
            ImVec2 boundsMax(
                display.x - popupMargin,
                display.y - popupMargin
            );

            if (g_menuBoundsValid)
            {
                boundsMin.x = ImMax(boundsMin.x, g_menuMin.x);
                boundsMin.y = ImMax(boundsMin.y, g_menuMin.y);
                boundsMax.x = ImMin(boundsMax.x, g_menuMax.x);
                boundsMax.y = ImMin(boundsMax.y, g_menuMax.y);
            }

            if (boundsMax.x - boundsMin.x < popupWidth)
            {
                boundsMin.x = popupMargin;
                boundsMax.x = display.x - popupMargin;
            }

            if (boundsMax.y - boundsMin.y < estimatedPopupHeight)
            {
                boundsMin.y = popupMargin;
                boundsMax.y = display.y - popupMargin;
            }

            const float targetBelow = max.y + popupGap;
            const float targetAbove = max.y - estimatedPopupHeight - popupGap;

            float targetY = targetBelow;
            if (targetBelow + estimatedPopupHeight > boundsMax.y && targetAbove >= boundsMin.y)
                targetY = targetAbove;
            else if (targetBelow + estimatedPopupHeight > boundsMax.y)
                targetY = ImClamp(
                    targetBelow,
                    boundsMin.y,
                    ImMax(boundsMin.y, boundsMax.y - estimatedPopupHeight)
                );

            const float slide = 8.f * (1.f - eased);
            const float popupY = popup.opened
                ? targetY - slide
                : targetY + slide;

            ImVec2 popupPos(
                max.x - popupWidth,
                popupY
            );

            popupPos.x = ImClamp(
                popupPos.x,
                boundsMin.x,
                ImMax(boundsMin.x, boundsMax.x - popupWidth)
            );

            popupPos.y = ImClamp(
                popupPos.y,
                boundsMin.y,
                ImMax(boundsMin.y, boundsMax.y - estimatedPopupHeight)
            );

            const std::uint64_t popupHash = MakeKey(owner, label, 7000 + 40000);
            char popupId[64]{};
            ImFormatString(
                popupId,
                sizeof(popupId),
                "##ColorPopupAnim_%llu",
                static_cast<unsigned long long>(popupHash)
            );

            ImGui::SetNextWindowPos(popupPos, ImGuiCond_Always);

            if (popup.opened && popup.anim < 0.5f)
                ImGui::SetNextWindowFocus();

            ImGui::PushStyleVar(
                ImGuiStyleVar_WindowPadding,
                ImVec2(8.f, 8.f)
            );
            ImGui::PushStyleVar(
                ImGuiStyleVar_WindowRounding,
                9.f
            );
            ImGui::PushStyleVar(
                ImGuiStyleVar_ItemSpacing,
                ImVec2(6.f, 6.f)
            );
            ImGui::PushStyleVar(
                ImGuiStyleVar_Alpha,
                ImMax(0.001f, popupAlpha)
            );

            ImGui::PushStyleColor(
                ImGuiCol_WindowBg,
                ImVec4(0.f, 0.f, 0.f, 0.f)
            );
            ImGui::PushStyleColor(ImGuiCol_FrameBg, CONTROL);
            ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, CONTROL_HOVER);
            ImGui::PushStyleColor(ImGuiCol_FrameBgActive, CONTROL_ACTIVE);
            ImGui::PushStyleColor(ImGuiCol_SliderGrab, ACCENT);
            ImGui::PushStyleColor(ImGuiCol_SliderGrabActive, ACCENT_SOFT);
            ImGui::PushStyleColor(ImGuiCol_Text, TEXT);

            const ImGuiWindowFlags popupFlags =
                ImGuiWindowFlags_NoTitleBar |
                ImGuiWindowFlags_NoResize |
                ImGuiWindowFlags_NoMove |
                ImGuiWindowFlags_NoScrollbar |
                ImGuiWindowFlags_NoScrollWithMouse |
                ImGuiWindowFlags_NoCollapse |
                ImGuiWindowFlags_NoSavedSettings |
                ImGuiWindowFlags_NoFocusOnAppearing |
                ImGuiWindowFlags_NoBackground |
                ImGuiWindowFlags_AlwaysAutoResize;

            if (ImGui::Begin(popupId, nullptr, popupFlags))
            {
                ImDrawList* popupDraw = ImGui::GetWindowDrawList();
                const ImVec2 winMin = ImGui::GetWindowPos();
                const ImVec2 winSize = ImGui::GetWindowSize();
                const ImVec2 winMax(
                    winMin.x + winSize.x,
                    winMin.y + winSize.y
                );

                const float bgAlpha = 0.92f * popupAlpha;
                popupDraw->AddRectFilled(
                    winMin,
                    winMax,
                    ToU32(ImVec4(
                        POPUP_BG.x,
                        POPUP_BG.y,
                        POPUP_BG.z,
                        bgAlpha
                    )),
                    9.f
                );

                popupDraw->AddRect(
                    ImVec2(winMin.x + 0.5f, winMin.y + 0.5f),
                    ImVec2(winMax.x - 0.5f, winMax.y - 0.5f),
                    ToU32(WithAlpha(BORDER, popupAlpha)),
                    9.f,
                    ImDrawFlags_RoundCornersAll,
                    1.f
                );

                popupDraw->AddRectFilled(
                    ImVec2(winMin.x + 14.f, winMin.y + 1.f),
                    ImVec2(winMax.x - 14.f, winMin.y + 2.f),
                    ToU32(WithAlpha(ACCENT, 0.45f * popupAlpha)),
                    1.f
                );

                ImGui::PushItemWidth(230.f);
                changed = ImGui::ColorPicker4(
                    "##picker",
                    color,
                    ImGuiColorEditFlags_AlphaBar |
                    ImGuiColorEditFlags_NoSidePreview |
                    ImGuiColorEditFlags_NoSmallPreview |
                    ImGuiColorEditFlags_DisplayRGB
                );
                ImGui::PopItemWidth();

                const bool popupHovered = ImGui::IsWindowHovered(
                    ImGuiHoveredFlags_AllowWhenBlockedByActiveItem
                );

                if (popup.opened &&
                    ImGui::IsMouseClicked(ImGuiMouseButton_Left) &&
                    !hovered &&
                    !popupHovered)
                {
                    popup.opened = false;
                }
            }

            ImGui::End();
            ImGui::PopStyleColor(7);
            ImGui::PopStyleVar(4);
        }

        ImGui::PopID();
        ImGui::PopID();
        return changed;
    }





    inline void Text(const char* text, float alpha = 1.f)
    {
        if (!text) return;
        ImGui::TextColored(Alpha(TEXT, alpha), "%s", text);
    }

    inline void TextDisabled(const char* text, float alpha = 1.f)
    {
        if (!text) return;
        ImGui::TextColored(Alpha(TEXT_MUTED, alpha), "%s", text);
    }

    inline void Separator(float alpha = 1.f)
    {
        ImGui::PushStyleColor(ImGuiCol_Separator, Alpha(SEPARATOR_COLOR, alpha));
        ImGui::Separator();
        ImGui::PopStyleColor();
    }





    inline bool OutlinedButton(
        const char* label,
        const ImVec2& size = ImVec2(0.f, 30.f),
        float rounding = 7.f, float alpha = 1.f
    )
    {
        if (!label) return false;

        static int animationOwner = 0;
        AnimState& animation = GetAnim(&animationOwner, label, 9000);
        const float dt = SafeDeltaTime();

        ImGui::PushID("##outlined_button");

        const bool blocked = IsMouseOverAnyBindPopup();
        const bool pressed = !blocked && ImGui::Button(label, size);
        const bool hovered = !blocked && ImGui::IsItemHovered();
        const bool active = !blocked && ImGui::IsItemActive();

        animation.hover = SmoothTo(animation.hover, hovered ? 1.f : 0.f, 18.f, dt);
        animation.press = SmoothTo(animation.press, active ? 1.f : 0.f, 25.f, dt);

        const ImRect rect(ImGui::GetItemRectMin(), ImGui::GetItemRectMax());
        ImDrawList* draw = ImGui::GetWindowDrawList();

        if (draw)
        {
            draw->AddRect(
                ImVec2(rect.Min.x + 0.5f, rect.Min.y + 0.5f),
                ImVec2(rect.Max.x - 0.5f, rect.Max.y - 0.5f),
                ToU32(Alpha(LerpColor(BORDER, ACCENT, animation.hover * 0.55f), alpha)),
                rounding, ImDrawFlags_RoundCornersAll, active ? 1.35f : 1.f
            );
        }

        ImGui::PopID();
        return pressed;
    }





    inline bool SelectModule(
        const void* owner, const char* label,
        int* currentItem, const char* const items[],
        int itemsCount, int index = 0, float alpha = 1.f
    )
    {
        if (!owner || !label || !currentItem || !items || itemsCount <= 0)
            return false;

        SelectState& state = GetSelectState(owner, label, index);
        const float dt = SafeDeltaTime();

        if (*currentItem < 0) *currentItem = 0;
        if (*currentItem >= itemsCount) *currentItem = itemsCount - 1;

        const float width = ImMax(1.f, ImGui::GetContentRegionAvail().x);
        constexpr float rowHeight = 42.f;

        ImGui::PushID(owner); ImGui::PushID(label); ImGui::PushID(index);
        ImGui::InvisibleButton("##select", ImVec2(width, rowHeight));

        const bool blocked = IsMouseOverAnyBindPopup();
        const bool hovered = !blocked && ImGui::IsItemHovered();
        const bool held = !blocked && ImGui::IsItemActive();
        const bool clicked = !blocked && ImGui::IsItemClicked(ImGuiMouseButton_Left);

        if (clicked) state.opened = !state.opened;
        if (state.opened && ImGui::IsKeyPressed(ImGuiKey_Escape))
            state.opened = false;

        state.hover = SmoothTo(state.hover, hovered ? 1.f : 0.f, 20.f, dt);
        state.press = SmoothTo(state.press, held ? 1.f : 0.f, 26.f, dt);
        state.anim = SmoothTo(state.anim, state.opened ? 1.f : 0.f, 22.f, dt);

        const ImVec2 rowMin = ImGui::GetItemRectMin();
        const ImVec2 rowMax = ImGui::GetItemRectMax();
        ImDrawList* draw = ImGui::GetWindowDrawList();

        if (draw)
        {
            DrawRowHover(draw, rowMin, rowMax, state.hover, 8.f);

            ImFont* font = ImGui::GetFont();
            if (font)
            {
                const float fontSize = ImGui::GetFontSize();
                const ImVec2 labelSize = font->CalcTextSizeA(
                    fontSize, FLT_MAX, 0.f, label
                );

                draw->AddText(
                    font, fontSize,
                    ImVec2(
                        rowMin.x + 5.f,
                        rowMin.y + (rowHeight - labelSize.y) * 0.5f
                        - state.press * 0.3f
                    ),
                    ToU32(Alpha(hovered ? TEXT : TEXT_MUTED, alpha)),
                    label
                );

                const char* current = items[*currentItem];
                const ImVec2 valueSize = font->CalcTextSizeA(
                    fontSize, FLT_MAX, 0.f, current
                );

                constexpr float chevronArea = 26.f;
                const float valueX = rowMax.x - chevronArea - valueSize.x - 4.f;

                draw->AddText(
                    font, fontSize,
                    ImVec2(
                        valueX,
                        rowMin.y + (rowHeight - valueSize.y) * 0.5f
                        - state.press * 0.3f
                    ),
                    ToU32(Alpha(TEXT, alpha)),
                    current
                );

                const ImVec2 chevronCenter(
                    rowMax.x - 13.f,
                    rowMin.y + rowHeight * 0.5f
                );

                DrawChevron(draw, chevronCenter, state.anim > 0.5f, alpha, 4.5f);
            }
        }

        bool changed = false;

        if (state.opened || state.anim > 0.01f)
        {
            const float open = EaseOutQuint(Clamp01(state.anim));
            constexpr float itemHeight = 30.f;
            constexpr float popupPadY = 6.f;
            constexpr float popupGap = 4.f;

            const float popupHeight = itemsCount * itemHeight + popupPadY * 2.f;
            const float targetY = rowMax.y + popupGap;
            const float startY = rowMax.y - 8.f;
            const float popupY = Lerp(startY, targetY, open);

            const ImVec2 popupPos(rowMin.x, popupY);
            const float popupWidth = width;

            const std::uint64_t popupHash = MakeKey(owner, label, index + 40000);
            char popupId[64]{};
            ImFormatString(
                popupId, sizeof(popupId),
                "##SelectOverlay_%llu",
                static_cast<unsigned long long>(popupHash)
            );

            ImGui::SetNextWindowPos(popupPos, ImGuiCond_Always);
            ImGui::SetNextWindowSize(
                ImVec2(popupWidth, popupHeight), ImGuiCond_Always
            );

            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(6.f, popupPadY));
            ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 8.f);
            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.f, 0.f));
            ImGui::PushStyleVar(
                ImGuiStyleVar_Alpha, ImMax(0.001f, open * GetParentAlpha())
            );

            ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.f, 0.f, 0.f, 0.f));
            ImGui::PushStyleColor(ImGuiCol_Header, CONTROL_HOVER);
            ImGui::PushStyleColor(ImGuiCol_HeaderHovered, CONTROL_HOVER);
            ImGui::PushStyleColor(ImGuiCol_HeaderActive, CONTROL_ACTIVE);
            ImGui::PushStyleColor(ImGuiCol_Text, TEXT);

            const ImGuiWindowFlags popupFlags =
                ImGuiWindowFlags_NoTitleBar |
                ImGuiWindowFlags_NoResize |
                ImGuiWindowFlags_NoMove |
                ImGuiWindowFlags_NoScrollbar |
                ImGuiWindowFlags_NoScrollWithMouse |
                ImGuiWindowFlags_NoCollapse |
                ImGuiWindowFlags_NoSavedSettings |
                ImGuiWindowFlags_NoFocusOnAppearing |
                ImGuiWindowFlags_NoBringToFrontOnFocus |
                ImGuiWindowFlags_NoBackground;

            if (ImGui::Begin(popupId, nullptr, popupFlags))
            {
                ImDrawList* popupDraw = ImGui::GetWindowDrawList();
                const ImVec2 winMin = ImGui::GetWindowPos();
                const ImVec2 winMax(winMin.x + popupWidth, winMin.y + popupHeight);

                popupDraw->AddRectFilled(
                    winMin, winMax,
                    ToU32(ImVec4(
                        POPUP_BG.x, POPUP_BG.y, POPUP_BG.z, POPUP_BG.w * open
                    )),
                    8.f
                );
                popupDraw->AddRect(
                    ImVec2(winMin.x + 0.5f, winMin.y + 0.5f),
                    ImVec2(winMax.x - 0.5f, winMax.y - 0.5f),
                    ToU32(WithAlpha(BORDER, open)),
                    8.f, ImDrawFlags_RoundCornersAll, 1.f
                );
                popupDraw->AddRectFilled(
                    ImVec2(winMin.x + 12.f, winMin.y + 1.f),
                    ImVec2(winMax.x - 12.f, winMin.y + 2.f),
                    ToU32(WithAlpha(ACCENT, 0.55f * open)),
                    1.f
                );

                for (int i = 0; i < itemsCount; ++i)
                {
                    ImGui::PushID(i);

                    const bool isSelected = (i == *currentItem);
                    const bool itemClicked = ImGui::Selectable(
                        items[i], isSelected, ImGuiSelectableFlags_None,
                        ImVec2(popupWidth - 12.f, itemHeight)
                    );

                    if (itemClicked && i != *currentItem)
                    {
                        *currentItem = i;
                        state.opened = false;
                        changed = true;
                    }
                    else if (itemClicked)
                    {
                        state.opened = false;
                    }

                    if (isSelected)
                    {
                        const ImVec2 itemMin = ImGui::GetItemRectMin();
                        ImDrawList* idraw = ImGui::GetWindowDrawList();
                        idraw->AddRectFilled(
                            ImVec2(itemMin.x + 1.f, itemMin.y + 6.f),
                            ImVec2(itemMin.x + 3.f, itemMin.y + itemHeight - 6.f),
                            ToU32(WithAlpha(ACCENT, 0.92f * open)),
                            1.f
                        );
                    }

                    ImGui::PopID();
                }

                const bool popupHovered = ImGui::IsWindowHovered(
                    ImGuiHoveredFlags_AllowWhenBlockedByActiveItem
                );

                if (state.opened &&
                    ImGui::IsMouseClicked(ImGuiMouseButton_Left) &&
                    !hovered && !popupHovered)
                {
                    state.opened = false;
                }
            }

            ImGui::End();
            ImGui::PopStyleColor(5);
            ImGui::PopStyleVar(4);
        }

        ImGui::PopID(); ImGui::PopID(); ImGui::PopID();
        return changed;
    }





    inline bool BindButton(
        const void* owner, const char* label,
        int* key, bool* toggleMode,
        int index = 0, float alpha = 1.f
    )
    {
        if (!owner || !label || !key || !toggleMode) return false;

        BindState& state = GetBindState(owner, label, index);

        const bool blockedByOtherPopup =
            !state.opened && IsMouseOverAnyBindPopup();

        if (state.key != *key) state.key = *key;
        state.toggle = *toggleMode;

        const float dt = SafeDeltaTime();

        state.anim = SmoothTo(state.anim, state.opened ? 1.f : 0.f, 22.f, dt);
        state.holdAnim = SmoothTo(state.holdAnim, state.toggle ? 0.f : 1.f, 13.f, dt);
        state.toggleAnim = SmoothTo(state.toggleAnim, state.toggle ? 1.f : 0.f, 13.f, dt);
        state.bindPulse = SmoothTo(state.bindPulse, state.waiting ? 1.f : 0.f, 16.f, dt);

        ImGui::PushID(owner); ImGui::PushID(label); ImGui::PushID(index);

        const float width = ImMax(1.f, ImGui::GetContentRegionAvail().x);
        constexpr float rowHeight = 38.f;

        const bool rowClicked = ImGui::InvisibleButton(
            "##BindButton", ImVec2(width, rowHeight)
        );

        const ImVec2 rowMin = ImGui::GetItemRectMin();
        const ImVec2 rowMax = ImGui::GetItemRectMax();

        const bool hovered = !blockedByOtherPopup && ImGui::IsItemHovered();
        const bool held = !blockedByOtherPopup && ImGui::IsItemActive();

        state.hover = SmoothTo(state.hover, hovered ? 1.f : 0.f, 18.f, dt);
        state.press = SmoothTo(state.press, held ? 1.f : 0.f, 22.f, dt);

        if (rowClicked && !blockedByOtherPopup)
        {
            state.opened = !state.opened;

            if (!state.opened)
            {
                state.waiting = false;
            }
            else
            {

                state.openUpValid = false;
            }
        }

        ImDrawList* draw = ImGui::GetWindowDrawList();
        ImFont* font = ImGui::GetFont();





        if (draw)
        {
            DrawRowHover(draw, rowMin, rowMax, state.hover, 7.f);

            if (font)
            {
                const float fontSize = ImGui::GetFontSize();
                const ImVec2 labelSize = font->CalcTextSizeA(
                    fontSize, FLT_MAX, 0.f, label
                );

                draw->AddText(
                    font, fontSize,
                    ImVec2(
                        rowMin.x + 5.f,
                        rowMin.y + (rowHeight - labelSize.y) * 0.5f
                        - state.press * 0.2f
                    ),
                    ToU32(Alpha(hovered ? TEXT : TEXT_MUTED, alpha)),
                    label
                );

                const char* keyText =
                    state.waiting ? "..." : GetKeyName(state.key);

                const ImVec2 keySize = font->CalcTextSizeA(
                    fontSize - 1.f, FLT_MAX, 0.f, keyText
                );

                const float buttonWidth = ImMax(38.f, keySize.x + 14.f);

                const ImVec2 bindMin(rowMax.x - buttonWidth, rowMin.y + 8.f);
                const ImVec2 bindMax(rowMax.x - 2.f, rowMax.y - 8.f);

                const float wait = Clamp01(state.bindPulse);

                const ImVec4 waitingBg = LerpColor(CONTROL, ACCENT_SOFT, 0.32f);
                const ImVec4 normalBg = LerpColor(
                    CONTROL, CONTROL_HOVER, state.hover * 0.85f
                );
                const ImVec4 bindBg = LerpColor(normalBg, waitingBg, wait);

                draw->AddRectFilled(
                    bindMin, bindMax, ToU32(Alpha(bindBg, alpha)), 5.f
                );

                const ImVec4 borderCol = LerpColor(
                    BORDER, WithAlpha(ACCENT_SOFT, 0.80f), wait
                );

                draw->AddRect(
                    ImVec2(bindMin.x + 0.5f, bindMin.y + 0.5f),
                    ImVec2(bindMax.x - 0.5f, bindMax.y - 0.5f),
                    ToU32(Alpha(borderCol, alpha)),
                    5.f, ImDrawFlags_RoundCornersAll,
                    Lerp(1.f, 1.12f, wait)
                );

                const ImVec4 textCol = LerpColor(HEADER_TEXT, TEXT, wait);

                draw->AddText(
                    font, fontSize - 1.f,
                    ImVec2(
                        bindMin.x + (bindMax.x - bindMin.x - keySize.x) * 0.5f,
                        bindMin.y + (bindMax.y - bindMin.y - keySize.y) * 0.5f
                    ),
                    ToU32(Alpha(textCol, alpha)),
                    keyText
                );
            }
        }









        if (state.opened || state.anim > 0.001f)
        {
            const float anim = Clamp01(state.anim);
            const float ease = EaseOutQuint(anim);
            const float fadeParent = anim * GetParentAlpha();

            if (fadeParent > 0.001f)
            {
                constexpr float popupWidth = 210.f;
                constexpr float popupHeight = 46.f;
                constexpr float popupGap = 6.f;

                const ImVec2 display = ImGui::GetIO().DisplaySize;

                ImVec2 boundMin = g_menuBoundsValid
                    ? g_menuMin
                    : ImVec2(4.f, 4.f);
                ImVec2 boundMax = g_menuBoundsValid
                    ? g_menuMax
                    : ImVec2(display.x - 4.f, display.y - 4.f);


                if (!state.openUpValid)
                {
                    const float roomAbove = rowMin.y - boundMin.y;
                    const float roomBelow = boundMax.y - rowMax.y;

                    const bool fitsAbove = roomAbove >= popupHeight + popupGap;
                    const bool fitsBelow = roomBelow >= popupHeight + popupGap;

                    if (fitsAbove) state.openUp = true;
                    else if (fitsBelow) state.openUp = false;
                    else state.openUp = roomAbove > roomBelow;

                    state.openUpValid = true;
                }

                const bool openUp = state.openUp;


                const float targetX = rowMax.x - popupWidth;
                const float targetY = openUp
                    ? (rowMin.y - popupHeight - popupGap)
                    : (rowMax.y + popupGap);

                const float anchorX = rowMax.x - 20.f;
                const float anchorY = rowMin.y + rowHeight * 0.5f;

                const float targetCenterX = targetX + popupWidth * 0.5f;
                const float targetCenterY = targetY + popupHeight * 0.5f;

                const float cx = Lerp(anchorX, targetCenterX, ease);
                const float cy = Lerp(anchorY, targetCenterY, ease);

                ImVec2 popupPos(cx - popupWidth * 0.5f, cy - popupHeight * 0.5f);



                if (popupPos.x < 4.f) popupPos.x = 4.f;
                if (popupPos.x + popupWidth > display.x - 4.f)
                    popupPos.x = display.x - popupWidth - 4.f;

                const ImVec2 popupMax(
                    popupPos.x + popupWidth,
                    popupPos.y + popupHeight
                );


                const float vTop = ImMax(popupPos.y, boundMin.y);
                const float vBottom = ImMin(popupMax.y, boundMax.y);
                const float vHeight = ImMax(0.f, vBottom - vTop);
                const float coverage = vHeight / popupHeight;

                const float fade = fadeParent * coverage;


                state.popupMin = popupPos;
                state.popupMax = popupMax;

                if (fade > 0.001f && coverage > 0.001f)
                {
                    ImDrawList* fg = ImGui::GetForegroundDrawList();


                    fg->PushClipRect(
                        ImVec2(popupPos.x, vTop),
                        ImVec2(popupMax.x, vBottom),
                        true
                    );


                    fg->AddRectFilled(
                        popupPos, popupMax,
                        ToU32(ImVec4(
                            POPUP_BG.x, POPUP_BG.y,
                            POPUP_BG.z, POPUP_BG.w * fade
                        )),
                        10.f
                    );


                    fg->AddRect(
                        ImVec2(popupPos.x + 0.5f, popupPos.y + 0.5f),
                        ImVec2(popupMax.x - 0.5f, popupMax.y - 0.5f),
                        ToU32(WithAlpha(BORDER, fade)),
                        10.f, ImDrawFlags_RoundCornersAll, 1.f
                    );


                    const ImVec2 mouse = ImGui::GetIO().MousePos;
                    const bool mouseClicked =
                        ImGui::IsMouseClicked(ImGuiMouseButton_Left);
                    const bool mouseDown =
                        ImGui::IsMouseDown(ImGuiMouseButton_Left);


                    auto InRect = [&](const ImVec2& mn, const ImVec2& mx) -> bool
                        {
                            if (mouse.x < mn.x || mouse.x > mx.x) return false;
                            if (mouse.y < mn.y || mouse.y > mx.y) return false;
                            if (mouse.y < vTop || mouse.y > vBottom) return false;
                            return true;
                        };

                    const float innerPad = 6.f;
                    const float spacing = 4.f;
                    const float ctrlH = popupHeight - innerPad * 2.f;

                    const float holdW = 40.f;
                    const float toggleW = 46.f;
                    const float clearW = 40.f;
                    const float innerW = popupWidth - innerPad * 2.f;

                    const float bindW = ImMax(
                        40.f,
                        innerW - holdW - toggleW - clearW - spacing * 3.f
                    );

                    float cx2 = popupPos.x + innerPad;
                    const float cy2 = popupPos.y + innerPad;

                    const ImVec2 holdMin(cx2, cy2);
                    const ImVec2 holdMax(cx2 + holdW, cy2 + ctrlH);
                    cx2 += holdW + spacing;

                    const ImVec2 toggleMin(cx2, cy2);
                    const ImVec2 toggleMax(cx2 + toggleW, cy2 + ctrlH);
                    cx2 += toggleW + spacing;

                    const ImVec2 bindBtnMin(cx2, cy2);
                    const ImVec2 bindBtnMax(cx2 + bindW, cy2 + ctrlH);
                    cx2 += bindW + spacing;

                    const ImVec2 clearMin(cx2, cy2);
                    const ImVec2 clearMax(cx2 + clearW, cy2 + ctrlH);

                    const char* bindBtnText =
                        state.waiting ? "..." : GetKeyName(state.key);

                    int clickedBtn = -1;

                    struct BtnInfo
                    {
                        const ImVec2& mn;
                        const ImVec2& mx;
                        const char* text;
                        ImVec4 baseBg;
                    };

                    BtnInfo infos[4] =
                    {
                        { holdMin, holdMax, "Hold",
                          LerpColor(CONTROL, ACCENT_SOFT, 0.26f * state.holdAnim) },
                        { toggleMin, toggleMax, "Toggle",
                          LerpColor(CONTROL, ACCENT_SOFT, 0.26f * state.toggleAnim) },
                        { bindBtnMin, bindBtnMax, bindBtnText,
                          LerpColor(CONTROL, ACCENT_SOFT,
                              0.32f * Clamp01(state.bindPulse)) },
                        { clearMin, clearMax, "Clear", CONTROL }
                    };

                    for (int i = 0; i < 4; ++i)
                    {
                        const auto& b = infos[i];
                        const bool hov = InRect(b.mn, b.mx);
                        const bool down = hov && mouseDown;

                        ImVec4 bg = b.baseBg;
                        if (hov) bg = LerpColor(bg, CONTROL_HOVER, 0.75f);
                        if (down) bg = CONTROL_ACTIVE;

                        fg->AddRectFilled(
                            b.mn, b.mx,
                            ToU32(WithAlpha(bg, fade)),
                            6.f
                        );
                        fg->AddRect(
                            ImVec2(b.mn.x + 0.5f, b.mn.y + 0.5f),
                            ImVec2(b.mx.x - 0.5f, b.mx.y - 0.5f),
                            ToU32(WithAlpha(BORDER, fade)),
                            6.f, ImDrawFlags_RoundCornersAll, 1.f
                        );

                        if (font)
                        {
                            const float bFont = ImGui::GetFontSize() - 1.f;
                            const ImVec2 tSize = font->CalcTextSizeA(
                                bFont, FLT_MAX, 0.f, b.text
                            );
                            fg->AddText(
                                font, bFont,
                                ImVec2(
                                    b.mn.x + (b.mx.x - b.mn.x - tSize.x) * 0.5f,
                                    b.mn.y + (b.mx.y - b.mn.y - tSize.y) * 0.5f
                                ),
                                ToU32(WithAlpha(TEXT, fade)),
                                b.text
                            );
                        }

                        if (hov && mouseClicked) clickedBtn = i;
                    }

                    fg->PopClipRect();

                    if (clickedBtn == 0)
                    {
                        state.toggle = false;
                        *toggleMode = false;
                        state.waiting = false;
                    }
                    else if (clickedBtn == 1)
                    {
                        state.toggle = true;
                        *toggleMode = true;
                        state.waiting = false;
                    }
                    else if (clickedBtn == 2)
                    {
                        state.waiting = true;
                        FindPressedKey();
                    }
                    else if (clickedBtn == 3)
                    {
                        state.key = 0;
                        *key = 0;
                        state.waiting = false;
                        state.toggle = false;
                        *toggleMode = false;
                    }




                    const bool popupHovered = InRect(popupPos, popupMax);

                    if (state.opened &&
                        !rowClicked &&
                        mouseClicked &&
                        !hovered &&
                        !popupHovered)
                    {
                        state.opened = false;
                        state.waiting = false;
                    }
                }
            }
        }





        if (state.opened && state.waiting)
        {
            const int captured = FindPressedKey();

            if (captured > 0 && captured != VK_ESCAPE)
            {
                state.key = captured;
                *key = captured;
                state.waiting = false;
            }

            if (ImGui::IsKeyPressed(ImGuiKey_Escape))
                state.waiting = false;
        }

        *key = state.key;
        *toggleMode = state.toggle;

        ImGui::PopID(); ImGui::PopID(); ImGui::PopID();

        return rowClicked;
    }
}
