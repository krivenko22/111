#pragma once
#include "Feature.h"
#include "types.h"

// recreated stub — original header was missing from the sources
class SpiderModule : public Module
{
public:
    SpiderModule()
        : Module(_xorstr("Spider (нет реализации)"), ModuleCategory::Player, false)
    {
    }

    void OnRenderMenu() override
    {
        RenderFeature::Text(_xorstr("Недоступно: реализация отсутствует"));
    }

    void OnRenderOverlay() override
    {
    }
};
