#pragma once
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "Offsets.h"
#include "decryptors.h"
#include "Driver/Driver.h"
#include <types.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <sstream>
#include <thread>
#include <mutex>
#include <atomic>

extern uintptr_t gBase;

struct ItemEspData {
    Vector3 pos = {};
    Vector3 smoothedPos = {};
    Vector3 velocity = {};
    std::string label = "";
    int amount = 0;
    uintptr_t entityId = 0;
    float lastSeenTime = 0.f;
    float lastUpdateTime = 0.f;
};

class ItemEspManager {
private:
    static constexpr float NEW_ITEM_AGE_SEC = 0.5f;
    static constexpr float MAX_VELOCITY = 60.f;
    static constexpr int   FAST_TICK_MS = 8;
    static constexpr int   FULL_SCAN_MS = 200;
    static constexpr int   MAX_ENTITIES = 10000;
    static constexpr int   MAX_STRING_LENGTH = 64;
    static constexpr int   PTR_BLOCK = 64;
    static constexpr float POS_READ_GRACE_SEC = 0.25f;
    static constexpr float SCAN_SEEN_GRACE_SEC = 0.35f;

    struct PtrBlock {
        uintptr_t ptr[PTR_BLOCK];
    };
    static_assert(std::is_trivially_copyable<PtrBlock>::value);

    struct CachedItem {
        ItemEspData data;
        float lastSeenTime = 0.f;
        float lastScanSeen = 0.f;
        float spawnTime = 0.f;
        Vector3 lastRawPos = {};
        float lastRawTime = 0.f;
        bool  posValidThisTick = false;
    };

    std::unordered_map<uintptr_t, std::string> klassNames;
    std::unordered_map<uintptr_t, CachedItem> itemCache;
    std::vector<ItemEspData> itemBuffers[2];
    int readBufferIdx = 0;
    std::mutex bufferSwapMutex;
    std::thread updateThread;
    std::atomic<bool> threadRunning{ false };
    std::string debug_info;

    uintptr_t cachedEntityList = 0;
    int cachedSize = 0;
    std::chrono::steady_clock::time_point lastFullScan{};

    static bool SanePos(const Vector3& p) {
        return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z)
            && std::abs(p.x) < 8000.f && std::abs(p.z) < 8000.f && std::abs(p.y) < 2000.f
            && !(p.x == 0.f && p.y == 0.f && p.z == 0.f);
    }

    std::string ReadAscii(uintptr_t ptr, int maxLen) {
        if (!Decryption::is_valid_ptr(ptr)) return "";
        char buf[64] = { 0 };
        int len = (maxLen < 63) ? maxLen : 63;
        kernelHandler.read_memory(ptr, reinterpret_cast<uint64_t>(buf), len);
        return std::string(buf);
    }

    std::string ReadUnityString(uintptr_t stringPtr) {
        if (!Decryption::is_valid_ptr(stringPtr)) return "";
        int length = kernelHandler.readmem<int>(stringPtr + offsets::unity_string::m_stringLength);
        if (length <= 0 || length > MAX_STRING_LENGTH) return "";
        wchar_t wbuf[MAX_STRING_LENGTH + 1] = { 0 };
        kernelHandler.read_memory(stringPtr + offsets::unity_string::first_char,
            reinterpret_cast<uint64_t>(wbuf), (size_t)length * sizeof(wchar_t));
        std::string result;
        result.reserve(length);
        for (int i = 0; i < length; ++i) {
            if (wbuf[i] == 0) break;
            result += static_cast<char>(wbuf[i]);
        }
        return result;
    }

    bool ReadWorldPosition(uintptr_t ent, Vector3& out) {
        uintptr_t nc = kernelHandler.readmem<uintptr_t>(ent + offsets::unity_component::native);
        if (!Decryption::is_valid_ptr(nc)) return false;
        uintptr_t go = kernelHandler.readmem<uintptr_t>(nc + offsets::unity_component::game_object);
        if (!Decryption::is_valid_ptr(go)) return false;
        uintptr_t cd = kernelHandler.readmem<uintptr_t>(go + offsets::unity_game_object::components);
        if (!Decryption::is_valid_ptr(cd)) return false;
        uintptr_t tr = kernelHandler.readmem<uintptr_t>(cd + offsets::unity_game_object::obj_transform);
        if (!Decryption::is_valid_ptr(tr)) return false;
        uintptr_t hi = kernelHandler.readmem<uintptr_t>(tr + offsets::unity_transform::indirect_ptr_off);
        if (!Decryption::is_valid_ptr(hi)) return false;
        out = kernelHandler.readmem<Vector3>(hi + offsets::unity_transform::world_pos_off);
        return SanePos(out);
    }

    bool FindItemBuffer(uintptr_t& outListPtr, int& outSize) {
        outListPtr = 0; outSize = 0;
        if (!gBase) return false;
        uintptr_t bnClass = kernelHandler.readmem<uintptr_t>(gBase + offsets::rust_globals::base_networkable_static);
        if (!Decryption::is_valid_ptr(bnClass)) return false;
        uintptr_t staticFields = kernelHandler.readmem<uintptr_t>(bnClass + offsets::klass_layout::static_fields);
        if (!Decryption::is_valid_ptr(staticFields)) return false;
        uintptr_t clientEntitiesWrapper = kernelHandler.readmem<uintptr_t>(staticFields + offsets::base_networkable::client_entities);
        if (!Decryption::is_valid_ptr(clientEntitiesWrapper)) return false;
        uintptr_t entityRealm = Decryption::client_entities(clientEntitiesWrapper);
        if (!Decryption::is_valid_ptr(entityRealm)) return false;
        uintptr_t entityListWrapper = kernelHandler.readmem<uintptr_t>(entityRealm + offsets::base_networkable::entity_list);
        if (!Decryption::is_valid_ptr(entityListWrapper)) return false;
        uintptr_t listDict = Decryption::entity_list(entityListWrapper);
        if (!Decryption::is_valid_ptr(listDict)) return false;
        uintptr_t bufferList = kernelHandler.readmem<uintptr_t>(listDict + offsets::base_networkable::entities);
        if (!Decryption::is_valid_ptr(bufferList)) return false;
        int size = kernelHandler.readmem<int>(bufferList + offsets::base_networkable::buffer_list_size);
        if (size <= 0 || size > MAX_ENTITIES) return false;
        uintptr_t arrayObj = kernelHandler.readmem<uintptr_t>(bufferList + offsets::base_networkable::buffer_list_array);
        if (!Decryption::is_valid_ptr(arrayObj)) return false;
        outListPtr = arrayObj + offsets::system_list::array_first_element;
        outSize = size;
        return Decryption::is_valid_ptr(outListPtr);
    }

    bool UpdateBufferIfNeeded() {
        const auto now = std::chrono::steady_clock::now();
        const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastFullScan).count();
        const bool needUpdate = !Decryption::is_valid_ptr(cachedEntityList) || cachedSize <= 0 || elapsed >= FULL_SCAN_MS;
        if (!needUpdate) return false;
        uintptr_t newList = 0;
        int newSize = 0;
        if (FindItemBuffer(newList, newSize)) {
            cachedEntityList = newList;
            cachedSize = newSize;
            lastFullScan = now;
            return true;
        }
        return false;
    }

    bool ReadEntityPointers(uintptr_t arrayData, int count, std::vector<uintptr_t>& out) {
        if (count <= 0) { out.clear(); return false; }
        if (out.capacity() < static_cast<size_t>(count)) out.reserve(count);
        out.resize(count);
        const int fullBlocks = count / PTR_BLOCK;
        int offset = 0;
        for (int b = 0; b < fullBlocks; ++b) {
            PtrBlock block = kernelHandler.readmem<PtrBlock>(arrayData + static_cast<size_t>(offset) * sizeof(uintptr_t));
            std::memcpy(out.data() + offset, block.ptr, sizeof(block.ptr));
            offset += PTR_BLOCK;
        }
        for (int i = offset; i < count; ++i) {
            out[i] = kernelHandler.readmem<uintptr_t>(arrayData + static_cast<size_t>(i) * sizeof(uintptr_t));
        }
        return true;
    }

    void ScanForItems(const std::vector<uintptr_t>& entityCache, float nowSec) {
        for (uintptr_t ent : entityCache) {
            if (!Decryption::is_valid_ptr(ent)) continue;

            auto cacheIt = itemCache.find(ent);
            if (cacheIt != itemCache.end()) {
                cacheIt->second.lastScanSeen = nowSec;
                continue;
            }

            uintptr_t klass = kernelHandler.readmem<uintptr_t>(ent + 0x0);
            if (!Decryption::is_valid_ptr(klass)) continue;

            auto kit = klassNames.find(klass);
            if (kit == klassNames.end()) {
                uintptr_t namePtr = kernelHandler.readmem<uintptr_t>(klass + offsets::klass_layout::name_ptr);
                kit = klassNames.emplace(klass, ReadAscii(namePtr, 32)).first;
            }
            if (kit->second != "DroppedItem") continue;

            Vector3 newRawPos;
            if (!ReadWorldPosition(ent, newRawPos)) continue;

            uintptr_t item = kernelHandler.readmem<uintptr_t>(ent + offsets::world_item::item);
            if (!Decryption::is_valid_ptr(item)) continue;

            CachedItem cached;
            cached.data.entityId = ent;
            cached.data.pos = newRawPos;
            cached.data.smoothedPos = newRawPos;
            cached.data.velocity = {};
            cached.data.lastUpdateTime = nowSec;
            cached.data.amount = kernelHandler.readmem<int>(item + offsets::item::amount);

            uintptr_t def = kernelHandler.readmem<uintptr_t>(item + offsets::item::info);
            if (Decryption::is_valid_ptr(def)) {
                uintptr_t snPtr = kernelHandler.readmem<uintptr_t>(def + offsets::item_definition::shortname);
                if (Decryption::is_valid_ptr(snPtr))
                    cached.data.label = ReadUnityString(snPtr);
                if (cached.data.label.empty()) {
                    uintptr_t dn = kernelHandler.readmem<uintptr_t>(def + offsets::item_definition::displayName);
                    if (Decryption::is_valid_ptr(dn)) {
                        uintptr_t en = kernelHandler.readmem<uintptr_t>(dn + offsets::item_definition::phraseEnglish);
                        if (Decryption::is_valid_ptr(en))
                            cached.data.label = ReadUnityString(en);
                    }
                }
            }
            if (cached.data.label.empty()) continue;

            cached.lastSeenTime = nowSec;
            cached.lastScanSeen = nowSec;
            cached.spawnTime = nowSec;
            cached.lastRawPos = newRawPos;
            cached.lastRawTime = nowSec;
            itemCache[ent] = std::move(cached);
        }
    }

    void UpdateCachedItem(CachedItem& c, const Vector3& newRawPos, float nowSec) {
        const float dt = nowSec - c.lastRawTime;
        const bool validDt = dt > 0.0005f && dt < 1.0f;

        if (validDt) {
            Vector3 inst{};
            inst.x = (newRawPos.x - c.lastRawPos.x) / dt;
            inst.y = (newRawPos.y - c.lastRawPos.y) / dt;
            inst.z = (newRawPos.z - c.lastRawPos.z) / dt;

            const float v2 = inst.x * inst.x + inst.y * inst.y + inst.z * inst.z;
            if (v2 > MAX_VELOCITY * MAX_VELOCITY) inst = {};

            const float k = 1.f - std::exp(-dt / 0.04f);
            c.data.velocity.x += (inst.x - c.data.velocity.x) * k;
            c.data.velocity.y += (inst.y - c.data.velocity.y) * k;
            c.data.velocity.z += (inst.z - c.data.velocity.z) * k;
        }

        const float age = nowSec - c.spawnTime;

        if (age < NEW_ITEM_AGE_SEC) {
            c.data.smoothedPos = newRawPos;
        }
        else {
            const float k = 1.f - std::exp(-dt / 0.02f);
            c.data.smoothedPos.x += (newRawPos.x - c.data.smoothedPos.x) * k;
            c.data.smoothedPos.y += (newRawPos.y - c.data.smoothedPos.y) * k;
            c.data.smoothedPos.z += (newRawPos.z - c.data.smoothedPos.z) * k;
        }

        c.data.pos = newRawPos;
        c.data.lastUpdateTime = nowSec;
        c.lastRawPos = newRawPos;
        c.lastRawTime = nowSec;
        c.lastSeenTime = nowSec;
    }

    void UpdateLoop() {
        std::vector<uintptr_t> entityCache;
        entityCache.reserve(4096);

        std::vector<uintptr_t> removeList;
        removeList.reserve(64);

        while (threadRunning.load(std::memory_order_relaxed)) {
            const auto startTime = std::chrono::steady_clock::now();
            const auto nowSec = std::chrono::duration<float>(startTime.time_since_epoch()).count();

            const bool didFullScan = UpdateBufferIfNeeded();

            if (didFullScan && Decryption::is_valid_ptr(cachedEntityList) && cachedSize > 0) {
                if (ReadEntityPointers(cachedEntityList, cachedSize, entityCache)) {
                    ScanForItems(entityCache, nowSec);
                }
            }

            removeList.clear();
            for (auto& kv : itemCache) {
                CachedItem& c = kv.second;

                Vector3 newRawPos;
                if (ReadWorldPosition(kv.first, newRawPos)) {
                    UpdateCachedItem(c, newRawPos, nowSec);
                }

                const bool scanStale =
                    (nowSec - c.lastScanSeen) > SCAN_SEEN_GRACE_SEC;

                const bool posStale =
                    (nowSec - c.lastSeenTime) > POS_READ_GRACE_SEC;

                if (scanStale || posStale)
                    removeList.push_back(kv.first);
            }

            for (uintptr_t ent : removeList)
                itemCache.erase(ent);

            int writeIdx;
            {
                std::lock_guard<std::mutex> lock(bufferSwapMutex);
                writeIdx = 1 - readBufferIdx;
            }

            auto& out = itemBuffers[writeIdx];
            out.clear();
            out.reserve(itemCache.size());
            for (const auto& kv : itemCache)
                out.push_back(kv.second.data);

            {
                std::ostringstream debug;
                debug << "Items:" << itemCache.size() << " | Entities:" << cachedSize;
                std::lock_guard<std::mutex> lock(bufferSwapMutex);
                debug_info = debug.str();
                readBufferIdx = writeIdx;
            }

            const auto endTime = std::chrono::steady_clock::now();
            const auto elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime).count();
            if (elapsedMs < FAST_TICK_MS)
                std::this_thread::sleep_for(std::chrono::milliseconds(FAST_TICK_MS - elapsedMs));
        }
    }

public:
    ItemEspManager() {
        itemBuffers[0].reserve(1024);
        itemBuffers[1].reserve(1024);
        threadRunning.store(true, std::memory_order_release);
        updateThread = std::thread(&ItemEspManager::UpdateLoop, this);
    }

    ~ItemEspManager() {
        threadRunning.store(false, std::memory_order_release);
        if (updateThread.joinable()) updateThread.join();
    }

    std::vector<ItemEspData> GetItems() const {
        std::lock_guard<std::mutex> lock(const_cast<std::mutex&>(bufferSwapMutex));
        return itemBuffers[readBufferIdx];
    }

    const std::string& GetDebugInfo() const { return debug_info; }

    void Update(uintptr_t, const Vector3&, float) {
    }
};