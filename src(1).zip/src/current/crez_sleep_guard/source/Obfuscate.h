#pragma once
#include <cstdint>
#include <utility>

// Forced-include stub for the project's obfuscation macros.
// Provides compile-time XOR string encryption honoring OBF_SEED.
// Deliberately simple: strings are decrypted at first use into a
// thread-local buffer, never present as plaintext in .rdata.

#ifndef OBF_SEED
#define OBF_SEED 0x8F3B21D47C9E5A01ull
#endif

namespace obf_detail
{
    constexpr std::uint64_t kSeed = OBF_SEED;

    constexpr std::uint64_t next(std::uint64_t s)
    {
        // splitmix64 step
        s += 0x9E3779B97F4A7C15ull;
        std::uint64_t z = s;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
        return z ^ (z >> 31);
    }

    constexpr std::size_t str_len(const char* s)
    {
        std::size_t n = 0;
        while (s[n] != '\0') ++n;
        return n;
    }

    template <std::size_t N>
    struct encrypted
    {
        char data[N]{};
        std::size_t size = N - 1; // strlen excluding terminator

        constexpr encrypted(const char (&src)[N])
        {
            std::uint64_t s = obf_detail::next(kSeed);
            for (std::size_t i = 0; i < N; ++i)
            {
                s = obf_detail::next(s);
                data[i] = static_cast<char>(static_cast<unsigned char>(src[i]) ^ static_cast<unsigned char>(s & 0xFF));
            }
        }

        char* decrypt() const
        {
            static thread_local char plain[N];
            std::uint64_t s = obf_detail::next(kSeed);
            for (std::size_t i = 0; i < N; ++i)
            {
                s = obf_detail::next(s);
                plain[i] = static_cast<char>(static_cast<unsigned char>(data[i]) ^ static_cast<unsigned char>(s & 0xFF));
            }
            return plain;
        }
    };
}

#define _xorstr(str)                                                    \
    [&]() -> const char* {                                              \
        static const obf_detail::encrypted<sizeof(str)> _obf_enc(str);  \
        return _obf_enc.decrypt();                                      \
    }()

namespace obf_detail { template <std::size_t N> struct encryptedw; }

template <std::size_t N>
struct obf_detail::encryptedw
{
    wchar_t data[N]{};
    std::size_t size = N - 1;

    constexpr encryptedw(const wchar_t (&src)[N])
    {
        std::uint64_t s = obf_detail::next(kSeed);
        for (std::size_t i = 0; i < N; ++i)
        {
            s = obf_detail::next(s);
            data[i] = static_cast<wchar_t>(static_cast<std::uint32_t>(src[i]) ^ static_cast<std::uint32_t>(s & 0xFFFF));
        }
    }

    wchar_t* decrypt() const
    {
        static thread_local wchar_t plain[N];
        std::uint64_t s = obf_detail::next(kSeed);
        for (std::size_t i = 0; i < N; ++i)
        {
            s = obf_detail::next(s);
            plain[i] = static_cast<wchar_t>(static_cast<std::uint32_t>(data[i]) ^ static_cast<std::uint32_t>(s & 0xFFFF));
        }
        return plain;
    }
};

#define _xorstrw(str)                                                   \
    [&]() -> const wchar_t* {                                           \
        static const obf_detail::encryptedw<sizeof(str) / sizeof(wchar_t)> _obf_encw(str); \
        return _obf_encw.decrypt();                                     \
    }()
