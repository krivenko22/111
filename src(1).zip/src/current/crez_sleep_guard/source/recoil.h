#pragma once
#include "Feature.h"
#include "RenderFeature.h"
#include "Driver/Driver.h"
#include "recoil_math.h"
#include "imgui/imgui.h"
#include <chrono>
#include <cstdio>
#include <windows.h>

// Open-loop relative mouse compensation; no process memory writes.
// User must tune for weapon/sensitivity; NOT native recoil suppression.
class RecoilModule : public Module {
public:
    int mode=0;
    bool onlyAds=true;
    bool nativeRecoilUnavailable=false;
    float vertical=45.f,horizontal=0.f;
    RecoilModule():Module(_xorstr("Recoil Control"),ModuleCategory::Combat,true){enabled=false;}
    void OnRenderMenu() override {
        RenderFeature::SectionTitle(_xorstr("КОМПЕНСАЦИЯ ОТДАЧИ МЫШЬЮ"));
        RenderFeature::Toggle(this,_xorstr("Включить компенсацию"),&enabled,0);
        const char* modes[]={_xorstr("Полный: 100% настройки"),_xorstr("Легит: 88% и лёгкая тряска")};
        ImGui::Combo(_xorstr("Режим"),&mode,modes,IM_ARRAYSIZE(modes));
        RenderFeature::SliderFloat(this,_xorstr("Вертикальная сила (мышь/сек)"),&vertical,0.f,300.f,_xorstr("%.0f"));
        RenderFeature::SliderFloat(this,_xorstr("Горизонтальная сила (мышь/сек)"),&horizontal,-100.f,100.f,_xorstr("%.0f"));
        RenderFeature::Toggle(this,_xorstr("Только при удержании ПКМ"),&onlyAds,1);
        RenderFeature::Text(_xorstr("Настроить под оружие; 100% не гарантирует ноль отдачи"));
        ImGui::BeginDisabled();
        ImGui::Checkbox(_xorstr("Native no recoil: адрес оружия не подтвержден"),&nativeRecoilUnavailable);
        ImGui::EndDisabled();
    }
    void OnRenderOverlay() override {
        if(!enabled){Reset();return;}
        const char* status="hold fire";
        auto now=std::chrono::steady_clock::now();
        const bool canAct=GameForeground()&&(GetAsyncKeyState(VK_LBUTTON)&0x8000)&&(!onlyAds||(GetAsyncKeyState(VK_RBUTTON)&0x8000));
        if(!canAct){Reset();status="hold fire + aim (if enabled)";}
        else {
            status=mode==1?"legit 88% calibrated":"full 100% calibrated";
            if(lastTime.time_since_epoch().count()){
                float dt=std::chrono::duration<float>(now-lastTime).count();
                auto delta=RecoilMath::Step(state,vertical,horizontal,mode,dt);
                if((delta.x||delta.y)&&GameForeground()&&(GetAsyncKeyState(VK_LBUTTON)&0x8000)&&(!onlyAds||(GetAsyncKeyState(VK_RBUTTON)&0x8000))){
                    INPUT in{};in.type=INPUT_MOUSE;in.mi.dx=delta.x;in.mi.dy=delta.y;in.mi.dwFlags=MOUSEEVENTF_MOVE;
                    if(SendInput(1,&in,sizeof(in))!=1){Reset();status="mouse input rejected";}
                }
            }
            lastTime=now;
        }
        ImDrawList* d=ImGui::GetBackgroundDrawList();
        if(d){char msg[128]{};std::snprintf(msg,sizeof(msg),"Recoil experimental: %s",status);d->AddText({12.f,60.f},IM_COL32(240,180,100,255),msg);}
    }
private:
    RecoilMath::State state{};std::chrono::steady_clock::time_point lastTime{};
    static bool GameForeground(){HWND w=GetForegroundWindow();DWORD fg=0;if(w)GetWindowThreadProcessId(w,&fg);return fg!=0&&fg==pId;}
    void Reset(){state.reset();lastTime={};}
};
