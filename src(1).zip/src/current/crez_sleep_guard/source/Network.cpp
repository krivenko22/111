#include "Network.h"

#include <cstdio>

namespace Network
{
    TimeSnapshot GetTime()
    {
        TimeSnapshot snapshot{};

        ::GetLocalTime(&snapshot.local);
        snapshot.synchronized = false;

        return snapshot;
    }

    std::string GetCurrentTimeString(bool withSeconds)
    {
        const TimeSnapshot snapshot = GetTime();

        char buffer[32]{};

        if (withSeconds)
        {
            std::snprintf(
                buffer,
                sizeof(buffer),
                "%02u:%02u:%02u",
                static_cast<unsigned>(snapshot.local.wHour),
                static_cast<unsigned>(snapshot.local.wMinute),
                static_cast<unsigned>(snapshot.local.wSecond)
            );
        }
        else
        {
            std::snprintf(
                buffer,
                sizeof(buffer),
                "%02u:%02u",
                static_cast<unsigned>(snapshot.local.wHour),
                static_cast<unsigned>(snapshot.local.wMinute)
            );
        }

        return std::string(buffer);
    }
}
