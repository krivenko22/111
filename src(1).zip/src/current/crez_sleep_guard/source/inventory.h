#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>
#include <chrono>
#include <thread>
#include <mutex>
#include <atomic>
#include <utility>
#include <cmath>
#include <condition_variable>
#include "Offsets.h"
#include "decryptors.h"
#include "Driver/Driver.h"

extern uintptr_t gBase;

struct InventoryItem {
    std::string shortname = "";
    std::string displayName = "";
    int amount = 0;
    float condition = 0.f;
    float maxCondition = 0.f;
    uint64_t uid = 0;
    int containerType = 0;
};

struct PlayerInventoryData {
    std::vector<InventoryItem> items;
    uintptr_t playerId = 0;
    float updateTime = 0.f;
};

class PlayerInventoryReader {
private:
    static constexpr int UPDATE_INTERVAL_MS = 250;
    static constexpr int MAX_STRING_LENGTH = 64;
    static constexpr float STALE_TTL_SEC = 8.f;

    std::unordered_map<uintptr_t, PlayerInventoryData> inventoryCache;
    mutable std::mutex cacheMutex;

    std::vector<PlayerInventoryData> inventoryBuffers[2];
    int readBufferIdx = 0;
    mutable std::mutex bufferSwapMutex;

    std::thread updateThread;
    std::atomic<bool> threadRunning{ false };

    std::vector<uintptr_t> targetPlayers;
    std::mutex targetMutex;

    std::mutex wakeMutex;
    std::condition_variable wakeCV;
    std::atomic<bool> targetsDirty{ false };

    std::string ReadUnityString(uintptr_t stringPtr) {
        if (!Decryption::is_valid_ptr(stringPtr)) return "";

        const int length = kernelHandler.readmem<int>(stringPtr + offsets::unity_string::m_stringLength);
        if (length <= 0 || length > MAX_STRING_LENGTH) return "";

        wchar_t wbuf[MAX_STRING_LENGTH + 1] = {};
        kernelHandler.read_memory(
            stringPtr + offsets::unity_string::first_char,
            reinterpret_cast<uint64_t>(wbuf),
            static_cast<size_t>(length) * sizeof(wchar_t)
        );

        std::string result;
        result.reserve(static_cast<size_t>(length));

        for (int i = 0; i < length; ++i) {
            if (wbuf[i] == 0) break;
            result.push_back(static_cast<char>(wbuf[i]));
        }

        return result;
    }

    bool ReadItemList(uintptr_t container, std::vector<InventoryItem>& outItems) {
        outItems.clear();

        if (!Decryption::is_valid_ptr(container)) return false;

        const uintptr_t itemList = kernelHandler.readmem<uintptr_t>(
            container + offsets::item_container::ItemList
        );
        if (!Decryption::is_valid_ptr(itemList)) return false;

        const uintptr_t arrayObj = kernelHandler.readmem<uintptr_t>(
            itemList + offsets::system_list::array
        );
        if (!Decryption::is_valid_ptr(arrayObj)) return false;

        const int count = kernelHandler.readmem<int>(
            itemList + offsets::system_list::size
        );
        if (count < 0 || count > 100) return false;
        if (count == 0) return true;

        const uintptr_t arrayData = arrayObj + offsets::system_list::array_first_element;
        if (!Decryption::is_valid_ptr(arrayData)) return false;

        outItems.reserve(static_cast<size_t>(count));

        for (int i = 0; i < count; ++i) {
            const uintptr_t item = kernelHandler.readmem<uintptr_t>(
                arrayData + static_cast<size_t>(i) * sizeof(uintptr_t)
            );
            if (!Decryption::is_valid_ptr(item)) continue;

            InventoryItem invItem;
            invItem.amount = kernelHandler.readmem<int>(item + offsets::item::amount);
            invItem.condition = kernelHandler.readmem<float>(item + offsets::item::condition);
            invItem.maxCondition = kernelHandler.readmem<float>(item + offsets::item::maxCondition);
            invItem.uid = kernelHandler.readmem<uint64_t>(item + offsets::item::uid);

            const uintptr_t def = kernelHandler.readmem<uintptr_t>(item + offsets::item::info);
            if (Decryption::is_valid_ptr(def)) {
                const uintptr_t snPtr = kernelHandler.readmem<uintptr_t>(
                    def + offsets::item_definition::shortname
                );
                if (Decryption::is_valid_ptr(snPtr)) {
                    invItem.shortname = ReadUnityString(snPtr);
                }

                const uintptr_t dnPtr = kernelHandler.readmem<uintptr_t>(
                    def + offsets::item_definition::displayName
                );
                if (Decryption::is_valid_ptr(dnPtr)) {
                    invItem.displayName = ReadUnityString(dnPtr);
                }
            }

            if (!invItem.shortname.empty() || !invItem.displayName.empty()) {
                outItems.push_back(std::move(invItem));
            }
        }

        return true;
    }

    void UpdateLoop() {
        while (threadRunning.load(std::memory_order_relaxed)) {
            const auto loopStart = std::chrono::steady_clock::now();
            const float nowSec = std::chrono::duration<float>(loopStart.time_since_epoch()).count();

            int writeIdx = 0;
            {
                std::lock_guard<std::mutex> lock(bufferSwapMutex);
                writeIdx = 1 - readBufferIdx;
            }

            auto& out = inventoryBuffers[writeIdx];
            out.clear();

            std::vector<uintptr_t> targets;
            {
                std::lock_guard<std::mutex> lock(targetMutex);
                targets = targetPlayers;
            }

            std::unordered_map<uintptr_t, bool> seen;
            seen.reserve(targets.size());

            for (uintptr_t player : targets) {
                if (!Decryption::is_valid_ptr(player)) continue;
                seen[player] = true;

                const uintptr_t invField = kernelHandler.readmem<uintptr_t>(
                    player + offsets::base_player::player_inventory
                );
                const uintptr_t inv = Decryption::player_inventory(invField);

                PlayerInventoryData data;
                data.playerId = player;
                data.updateTime = nowSec;

                if (Decryption::is_valid_ptr(inv)) {
                    const uintptr_t beltContainer = kernelHandler.readmem<uintptr_t>(
                        inv + offsets::player_inventory::containerBelt
                    );
                    if (Decryption::is_valid_ptr(beltContainer)) {
                        std::vector<InventoryItem> beltItems;
                        if (ReadItemList(beltContainer, beltItems)) {
                            for (auto& item : beltItems) {
                                item.containerType = 0;
                                data.items.push_back(std::move(item));
                            }
                        }
                    }

                    const uintptr_t mainContainer = kernelHandler.readmem<uintptr_t>(
                        inv + offsets::player_inventory::containerMain
                    );
                    if (Decryption::is_valid_ptr(mainContainer)) {
                        std::vector<InventoryItem> mainItems;
                        if (ReadItemList(mainContainer, mainItems)) {
                            for (auto& item : mainItems) {
                                item.containerType = 1;
                                data.items.push_back(std::move(item));
                            }
                        }
                    }

                    const uintptr_t wearContainer = kernelHandler.readmem<uintptr_t>(
                        inv + offsets::player_inventory::containerWear
                    );
                    if (Decryption::is_valid_ptr(wearContainer)) {
                        std::vector<InventoryItem> wearItems;
                        if (ReadItemList(wearContainer, wearItems)) {
                            for (auto& item : wearItems) {
                                item.containerType = 2;
                                data.items.push_back(std::move(item));
                            }
                        }
                    }
                }

                {
                    std::lock_guard<std::mutex> lock(cacheMutex);
                    inventoryCache[player] = data;
                }

                out.push_back(std::move(data));
            }

            {
                std::lock_guard<std::mutex> lock(cacheMutex);
                for (auto it = inventoryCache.begin(); it != inventoryCache.end();) {
                    if (seen.find(it->first) == seen.end() &&
                        nowSec - it->second.updateTime > STALE_TTL_SEC) {
                        it = inventoryCache.erase(it);
                    }
                    else {
                        ++it;
                    }
                }
            }

            {
                std::lock_guard<std::mutex> lock(bufferSwapMutex);
                readBufferIdx = writeIdx;
            }

            const auto loopEnd = std::chrono::steady_clock::now();
            const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(loopEnd - loopStart);
            auto sleepTime = std::chrono::milliseconds(UPDATE_INTERVAL_MS) - elapsed;

            if (sleepTime.count() < 0) {
                sleepTime = std::chrono::milliseconds(0);
            }

            {
                std::unique_lock<std::mutex> lock(wakeMutex);

                wakeCV.wait_for(
                    lock,
                    sleepTime,
                    [this] {
                        return targetsDirty.load(std::memory_order_acquire) ||
                            !threadRunning.load(std::memory_order_acquire);
                    }
                );

                targetsDirty.store(false, std::memory_order_release);
            }
        }
    }

public:
    PlayerInventoryReader() {
        inventoryBuffers[0].reserve(64);
        inventoryBuffers[1].reserve(64);

        threadRunning.store(true, std::memory_order_release);
        updateThread = std::thread(&PlayerInventoryReader::UpdateLoop, this);
    }

    ~PlayerInventoryReader() {
        threadRunning.store(false, std::memory_order_release);
        wakeCV.notify_all();

        if (updateThread.joinable()) {
            updateThread.join();
        }
    }

    void SetTargetPlayers(const std::vector<uintptr_t>& players) {
        bool changed = false;

        {
            std::lock_guard<std::mutex> lock(targetMutex);

            if (targetPlayers != players) {
                targetPlayers = players;
                changed = true;
            }
        }

        if (changed) {
            targetsDirty.store(true, std::memory_order_release);
            wakeCV.notify_one();
        }
    }

    std::vector<PlayerInventoryData> GetInventories() const {
        std::lock_guard<std::mutex> lock(bufferSwapMutex);
        return inventoryBuffers[readBufferIdx];
    }

    bool GetPlayerInventory(uintptr_t playerId, PlayerInventoryData& out) const {
        std::lock_guard<std::mutex> lock(cacheMutex);

        const auto it = inventoryCache.find(playerId);
        if (it == inventoryCache.end()) return false;

        out = it->second;
        return true;
    }
};