#pragma once
#include "Feature.h"
#include "Bone.h"
#include "world_to_screen.h"
#include "imgui/imgui.h"
#include "RenderFeature.h"

class SkeletonModule {
public:
    bool drawSkeleton = false;
    float skeletonColor[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

    bool drawOutline = true;
    float outlineColor[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
    float lineThickness = 1.5f;
    float outlineThickness = 3.0f;

    SkeletonModule() = default;

    void OnRenderMenu() {
        static const std::string sSkeleton = _xorstr("Скелет");
        static const std::string sSkeletonColor = _xorstr("Цвет скелетона");
        static const std::string sOutline = _xorstr("Обводка скелетона");
        static const std::string sOutlineOptions = _xorstr("SkeletonOutlineOptions");
        static const std::string sOutlineColor = _xorstr("Цвет обводки скелетона");
        static const std::string sLineThickness = _xorstr("Толщина линии скелетона");
        static const std::string sOutlineThickness = _xorstr("Толщина обводки скелетона");
        static const std::string sFormat = _xorstr("%.2f");

        RenderFeature::Toggle(
            this,
            sSkeleton.c_str(),
            &drawSkeleton,
            10
        );

        ImGui::Spacing();

        RenderFeature::ColorEdit4(
            this,
            sSkeletonColor.c_str(),
            skeletonColor
        );

        RenderFeature::Toggle(
            this,
            sOutline.c_str(),
            &drawOutline,
            11
        );

        const float reveal =
            RenderFeature::BeginAnimatedGroup(
                this,
                sOutlineOptions.c_str(),
                drawOutline,
                0,
                16.f,
                1.f
            );

        if (reveal > 0.001f) {
            ImGui::Spacing();

            RenderFeature::ColorEdit4(
                this,
                sOutlineColor.c_str(),
                outlineColor
            );

            RenderFeature::SliderFloat(
                this,
                sLineThickness.c_str(),
                &lineThickness,
                0.5f,
                5.0f,
                sFormat.c_str()
            );

            RenderFeature::SliderFloat(
                this,
                sOutlineThickness.c_str(),
                &outlineThickness,
                1.0f,
                8.0f,
                sFormat.c_str()
            );
        }

        RenderFeature::EndAnimatedGroup(
            this,
            sOutlineOptions.c_str(),
            0
        );
    }

    void ProcessAndDraw(uintptr_t ent, const PlayerRenderData& pd, const Matrix4x4& viewMatrix, int width, int height, ImDrawList* drawList, const Vector3& camPos, float predictTime, ImU32 skeletonColor) {
        if (!drawSkeleton) return;

        BonePositionCache* positions = BoneManager::Get().GetBonePositions(ent, predictTime, pd.velocity, pd.isSleeping);
        if (positions && positions->ok) {
            DrawSkeleton(*positions, viewMatrix, width, height, drawList, skeletonColor);
        }
    }

    void DrawCached(const BonePositionCache* positions, const Matrix4x4& viewMatrix, int width, int height, ImDrawList* drawList, ImU32 color) {
        if (drawSkeleton && positions && positions->ok) DrawSkeleton(*positions, viewMatrix, width, height, drawList, color);
    }

private:
    void DrawSkeleton(const BonePositionCache& pc, const Matrix4x4& viewMatrix, int width, int height, ImDrawList* drawList, ImU32 color) {
        const ImU32 outCol = IM_COL32(
            (int)(outlineColor[0] * 255.f),
            (int)(outlineColor[1] * 255.f),
            (int)(outlineColor[2] * 255.f),
            (int)(outlineColor[3] * 255.f)
        );

        const float outlineW = (std::max)(outlineThickness, lineThickness + 0.5f);

        auto draw_chain = [&](const int* slots, int n) {
            ImVec2 pts[32]{};
            bool ok[32]{};
            for (int i = 0; i < n; ++i) {
                const Vector3& b = pc.pos[slots[i]];
                if (b.x == 0.f && b.y == 0.f && b.z == 0.f) continue;
                ImVec2 screen;
                if (WorldToScreenUtils::WorldToScreen(b, viewMatrix, screen, width, height)) {
                    pts[i] = screen;
                    ok[i] = true;
                }
            }
            for (int i = 0; i + 1 < n; ++i) {
                if (ok[i] && ok[i + 1]) {
                    if (drawOutline) {
                        drawList->AddLine(pts[i], pts[i + 1], outCol, outlineW);
                    }
                    drawList->AddLine(pts[i], pts[i + 1], color, lineThickness);
                }
            }
            };

        static const int spine[] = { 0, 7, 8, 13, 14 };
        static const int larm[] = { 8, 9, 10, 11, 12 };
        static const int rarm[] = { 8, 15, 16, 17, 18 };
        static const int lleg[] = { 0, 1, 2, 3 };
        static const int rleg[] = { 0, 4, 5, 6 };

        draw_chain(spine, 5);
        draw_chain(larm, 5);
        draw_chain(rarm, 5);
        draw_chain(lleg, 4);
        draw_chain(rleg, 4);
    }
};