#pragma once
#include "Offsets.h"
#include "decryptors.h"
#include "Driver/Driver.h"
#include <d3d11.h>
#include <imgui.h>
#include <unordered_map>
#include <string>
#include <vector>
#include <chrono>
#include <cfloat>
#include <cstdio>

extern ID3D11Device* gD3DDevice;

struct ItemData {
    uint32_t uid = 0;
    uint32_t itemId = 0;
    std::string shortname = "";
    int amount = 0;
    float condition = 0.0f;
    ImTextureID textureId = 0;
    bool valid = false;
};

class InventoryManager {
private:
    std::unordered_map<uint32_t, ImTextureID> textureCache;
    std::vector<ItemData> cachedBelt, cachedMain, cachedWear;
    std::chrono::steady_clock::time_point lastUpdateTime;
    uintptr_t lastPlayerPtr = 0;
    bool needsUpdate = true;

    static constexpr int UPDATE_INTERVAL_MS = 500;
    static constexpr int MAX_ITEMS_PER_CONTAINER = 30;
    static constexpr int MAX_BELT_ITEMS = 6;
    static constexpr int MAX_TEXTURE_DIMENSION = 512;
    static constexpr int BYTES_PER_PIXEL = 4;
    static constexpr int MAX_STRING_LENGTH = 128;

    std::string ReadUnityString(uintptr_t stringPtr) {
        if (!Decryption::is_valid_ptr(stringPtr)) return "";
        int length = kernelHandler.readmem<int>(stringPtr + offsets::unity_string::m_stringLength);
        if (length <= 0 || length > MAX_STRING_LENGTH) return "";

        std::vector<wchar_t> wbuf(length + 1, 0);
        kernelHandler.read_memory(
            stringPtr + offsets::unity_string::first_char,
            reinterpret_cast<uint64_t>(wbuf.data()),
            (size_t)length * sizeof(wchar_t)
        );

        std::string result;
        result.reserve(length);
        for (int i = 0; i < length; ++i) {
            if (wbuf[i] == 0) break;
            result += static_cast<char>(wbuf[i]);
        }
        return result;
    }

    ImTextureID GetOrCreateTexture(uint32_t itemId, uintptr_t itemDefPtr) {
        auto it = textureCache.find(itemId);
        if (it != textureCache.end()) return it->second;
        ImTextureID result = CreateTexture(itemId, itemDefPtr);
        textureCache[itemId] = result;
        return result;
    }

    ImTextureID CreateTexture(uint32_t itemId, uintptr_t itemDefPtr) {
        uintptr_t iconSprite = kernelHandler.readmem<uintptr_t>(itemDefPtr + offsets::item_definition::iconSprite);
        if (!Decryption::is_valid_ptr(iconSprite)) return 0;

        uintptr_t spriteRD = kernelHandler.readmem<uintptr_t>(iconSprite + offsets::sprite::m_RD);
        if (!Decryption::is_valid_ptr(spriteRD)) return 0;

        uintptr_t texturePtr = kernelHandler.readmem<uintptr_t>(spriteRD + offsets::sprite_render_data::texture);
        if (!Decryption::is_valid_ptr(texturePtr)) return 0;

        int width = kernelHandler.readmem<int>(texturePtr + offsets::texture2d::width);
        int height = kernelHandler.readmem<int>(texturePtr + offsets::texture2d::height);
        if (width <= 0 || height <= 0 || width > MAX_TEXTURE_DIMENSION || height > MAX_TEXTURE_DIMENSION) return 0;

        uintptr_t imageDataPtr = kernelHandler.readmem<uintptr_t>(texturePtr + offsets::texture2d::image_data);
        if (!Decryption::is_valid_ptr(imageDataPtr)) return 0;

        size_t pixelCount = (size_t)width * height * BYTES_PER_PIXEL;
        if (pixelCount > (size_t)MAX_TEXTURE_DIMENSION * MAX_TEXTURE_DIMENSION * BYTES_PER_PIXEL) return 0;

        std::vector<unsigned char> pixels(pixelCount);
        kernelHandler.read_memory(imageDataPtr, reinterpret_cast<uint64_t>(pixels.data()), pixelCount);

        bool allZero = true;
        for (size_t i = 0; i < pixelCount; i += BYTES_PER_PIXEL) {
            if (pixels[i] != 0 || pixels[i + 1] != 0 || pixels[i + 2] != 0 || pixels[i + 3] != 0) {
                allZero = false;
                break;
            }
        }
        if (allZero) return 0;

        ID3D11Texture2D* pTexture = nullptr;
        ID3D11ShaderResourceView* srv = nullptr;

        D3D11_TEXTURE2D_DESC texDesc = {};
        texDesc.Width = width;
        texDesc.Height = height;
        texDesc.MipLevels = 1;
        texDesc.ArraySize = 1;
        texDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        texDesc.SampleDesc.Count = 1;
        texDesc.Usage = D3D11_USAGE_DEFAULT;
        texDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

        D3D11_SUBRESOURCE_DATA subResource = {};
        subResource.pSysMem = pixels.data();
        subResource.SysMemPitch = width * BYTES_PER_PIXEL;

        if (!SUCCEEDED(gD3DDevice->CreateTexture2D(&texDesc, &subResource, &pTexture))) return 0;

        D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
        srvDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
        srvDesc.Texture2D.MipLevels = 1;
        srvDesc.Texture2D.MostDetailedMip = 0;

        HRESULT hr = gD3DDevice->CreateShaderResourceView(pTexture, &srvDesc, &srv);
        pTexture->Release();
        if (!SUCCEEDED(hr)) return 0;

        return reinterpret_cast<ImTextureID>(srv);
    }

    std::vector<ItemData> ReadContainer(uintptr_t containerPtr) {
        std::vector<ItemData> items;
        if (!Decryption::is_valid_ptr(containerPtr)) return items;

        uintptr_t itemList = kernelHandler.readmem<uintptr_t>(containerPtr + offsets::item_container::ItemList);
        if (!Decryption::is_valid_ptr(itemList)) return items;

        uintptr_t itemsArray = kernelHandler.readmem<uintptr_t>(itemList + offsets::system_list::array);
        int count = kernelHandler.readmem<int>(itemList + offsets::system_list::size);
        if (!Decryption::is_valid_ptr(itemsArray) || count <= 0 || count > MAX_ITEMS_PER_CONTAINER) return items;

        for (int i = 0; i < count; ++i) {
            uintptr_t itemPtr = kernelHandler.readmem<uintptr_t>(
                itemsArray + offsets::system_list::array_first_element + i * offsets::system_list::element_size
            );
            if (!Decryption::is_valid_ptr(itemPtr)) continue;

            ItemData data;
            data.uid = (uint32_t)(kernelHandler.readmem<uint64_t>(itemPtr + offsets::item::uid) & 0xFFFFFFFF);
            data.amount = kernelHandler.readmem<int>(itemPtr + offsets::item::amount);
            data.condition = kernelHandler.readmem<float>(itemPtr + offsets::item::condition);

            uintptr_t itemDef = kernelHandler.readmem<uintptr_t>(itemPtr + offsets::item::info);
            if (Decryption::is_valid_ptr(itemDef)) {
                data.itemId = kernelHandler.readmem<uint32_t>(itemDef + offsets::item_definition::itemid);
                uintptr_t shortnamePtr = kernelHandler.readmem<uintptr_t>(itemDef + offsets::item_definition::shortname);
                data.shortname = ReadUnityString(shortnamePtr);
                data.textureId = GetOrCreateTexture(data.itemId, itemDef);
            }
            data.valid = true;
            items.push_back(data);
        }
        return items;
    }

    void UpdateCache(uintptr_t player) {
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastUpdateTime).count();
        if (player != lastPlayerPtr) { needsUpdate = true; lastPlayerPtr = player; }
        if (!needsUpdate && elapsed < UPDATE_INTERVAL_MS) return;
        lastUpdateTime = now;
        needsUpdate = false;

        uintptr_t inventory = Decryption::TryDecryptInventory(player);
        if (!Decryption::is_valid_ptr(inventory)) {
            cachedBelt.clear(); cachedMain.clear(); cachedWear.clear();
            return;
        }

        cachedBelt = ReadContainer(kernelHandler.readmem<uintptr_t>(inventory + offsets::player_inventory::containerBelt));
        cachedMain = ReadContainer(kernelHandler.readmem<uintptr_t>(inventory + offsets::player_inventory::containerMain));
        cachedWear = ReadContainer(kernelHandler.readmem<uintptr_t>(inventory + offsets::player_inventory::containerWear));
    }

public:
    void RenderPlayerInventory(uintptr_t player, ImVec2 screenPos) {
        UpdateCache(player);
        if (cachedBelt.empty() && cachedMain.empty() && cachedWear.empty()) return;

        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        ImFont* font = ImGui::GetFont();
        if (!dl || !font) return;

        const float slotSize = 48.0f, padding = 4.0f, panelPad = 10.0f;
        const float panelWidth = panelPad * 2 + slotSize * 6 + padding * 5;
        const ImU32 bgColor = IM_COL32(15, 15, 20, 230);
        const ImU32 slotBg = IM_COL32(35, 35, 45, 255);
        const ImU32 slotBorder = IM_COL32(70, 70, 85, 255);
        const ImU32 textCol = IM_COL32(255, 255, 255, 240);
        const ImU32 amtCol = IM_COL32(255, 220, 100, 255);

        auto DrawSlot = [&](ImVec2 pos, const ItemData& item) {
            ImVec2 p1 = pos, p2 = { pos.x + slotSize, pos.y + slotSize };
            dl->AddRectFilled(p1, p2, slotBg, 6.0f);
            dl->AddRect(p1, p2, slotBorder, 6.0f, 0, 1.5f);
            if (!item.valid) return;

            if (item.textureId != 0) {
                dl->AddImage(item.textureId, { p1.x + 3, p1.y + 3 }, { p2.x - 3, p2.y - 3 });
            }
            else {
                ImVec2 ts = font->CalcTextSizeA(11.0f, FLT_MAX, slotSize - 4, item.shortname.c_str());
                dl->AddText({ p1.x + (slotSize - ts.x) / 2, p1.y + (slotSize - ts.y) / 2 }, textCol, item.shortname.c_str());
            }

            if (item.amount > 1) {
                char buf[32];
                std::snprintf(buf, sizeof(buf), "%d", item.amount);
                ImVec2 as = font->CalcTextSizeA(13.0f, FLT_MAX, 0.0f, buf);
                dl->AddText({ p2.x - as.x - 3, p2.y - as.y - 2 }, amtCol, buf);
            }
            };

        float currentY = screenPos.y;

        if (!cachedMain.empty()) {
            ImVec2 p1 = { screenPos.x, currentY };
            ImVec2 p2 = { screenPos.x + panelWidth, currentY + panelPad * 2 + slotSize * 4 + padding * 3 };
            dl->AddRectFilled(p1, p2, bgColor, 8.0f);
            dl->AddRect(p1, p2, IM_COL32(60, 60, 70, 150), 8.0f, 0, 1.5f);
            for (int i = 0; i < 24; ++i) {
                int r = i / 6, c = i % 6;
                DrawSlot({ p1.x + panelPad + c * (slotSize + padding), p1.y + panelPad + r * (slotSize + padding) },
                    (i < (int)cachedMain.size()) ? cachedMain[i] : ItemData());
            }
            currentY = p2.y + 8.0f;
        }

        if (!cachedWear.empty()) {
            dl->AddText({ screenPos.x, currentY }, IM_COL32(120, 200, 255, 255), "CLOTHING");
            currentY += 16.0f;
            ImVec2 p1 = { screenPos.x, currentY };
            ImVec2 p2 = { screenPos.x + panelWidth, currentY + panelPad * 2 + slotSize };
            dl->AddRectFilled(p1, p2, bgColor, 8.0f);
            for (int i = 0; i < (int)cachedWear.size() && i < 6; ++i)
                DrawSlot({ p1.x + panelPad + i * (slotSize + padding), p1.y + panelPad }, cachedWear[i]);
            currentY = p2.y + 8.0f;
        }

        if (!cachedBelt.empty()) {
            dl->AddText({ screenPos.x, currentY }, IM_COL32(255, 120, 120, 255), "HOTBAR");
            currentY += 16.0f;
            ImVec2 p1 = { screenPos.x, currentY };
            ImVec2 p2 = { screenPos.x + panelWidth, currentY + panelPad * 2 + slotSize };
            dl->AddRectFilled(p1, p2, bgColor, 8.0f);
            for (int i = 0; i < 6; ++i)
                DrawSlot({ p1.x + panelPad + i * (slotSize + padding), p1.y + panelPad },
                    (i < (int)cachedBelt.size()) ? cachedBelt[i] : ItemData());
        }
    }

    std::string GetHeldWeaponShortname(uintptr_t localPlayer) {
        if (!Decryption::is_valid_ptr(localPlayer)) return "";

        uint64_t rawActive = kernelHandler.readmem<uint64_t>(localPlayer + offsets::base_player::clActiveItem);
        if (rawActive == 0) return "";
        uint32_t activeItemUid = (uint32_t)(Decryption::clActiveItem(rawActive) & 0xFFFFFFFF);
        if (activeItemUid == 0) return "";

        uintptr_t inventory = Decryption::TryDecryptInventory(localPlayer);
        if (!Decryption::is_valid_ptr(inventory)) return "";

        uintptr_t beltContainer = kernelHandler.readmem<uintptr_t>(inventory + offsets::player_inventory::containerBelt);
        if (!Decryption::is_valid_ptr(beltContainer)) return "";

        uintptr_t itemList = kernelHandler.readmem<uintptr_t>(beltContainer + offsets::item_container::ItemList);
        if (!Decryption::is_valid_ptr(itemList)) return "";

        uintptr_t itemsArray = kernelHandler.readmem<uintptr_t>(itemList + offsets::system_list::array);
        int count = kernelHandler.readmem<int>(itemList + offsets::system_list::size);
        if (!Decryption::is_valid_ptr(itemsArray) || count <= 0 || count > MAX_BELT_ITEMS) return "";

        for (int i = 0; i < count; ++i) {
            uintptr_t itemPtr = kernelHandler.readmem<uintptr_t>(
                itemsArray + offsets::system_list::array_first_element + i * offsets::system_list::element_size
            );
            if (!Decryption::is_valid_ptr(itemPtr)) continue;

            uint32_t uid = (uint32_t)(kernelHandler.readmem<uint64_t>(itemPtr + offsets::item::uid) & 0xFFFFFFFF);
            if (uid != activeItemUid) continue;

            uintptr_t itemDef = kernelHandler.readmem<uintptr_t>(itemPtr + offsets::item::info);
            if (!Decryption::is_valid_ptr(itemDef)) return "";

            uintptr_t shortnamePtr = kernelHandler.readmem<uintptr_t>(itemDef + offsets::item_definition::shortname);
            return ReadUnityString(shortnamePtr);
        }
        return "";
    }

    uintptr_t GetHeldEntity(uintptr_t localPlayer) {
        if (!Decryption::is_valid_ptr(localPlayer)) return 0;

        uint64_t rawActive = kernelHandler.readmem<uint64_t>(localPlayer + offsets::base_player::clActiveItem);
        if (rawActive == 0) return 0;
        uint32_t activeItemUid = (uint32_t)(Decryption::clActiveItem(rawActive) & 0xFFFFFFFF);
        if (activeItemUid == 0) return 0;

        uintptr_t inventory = Decryption::TryDecryptInventory(localPlayer);
        if (!Decryption::is_valid_ptr(inventory)) return 0;

        uintptr_t beltContainer = kernelHandler.readmem<uintptr_t>(inventory + offsets::player_inventory::containerBelt);
        if (!Decryption::is_valid_ptr(beltContainer)) return 0;

        uintptr_t itemList = kernelHandler.readmem<uintptr_t>(beltContainer + offsets::item_container::ItemList);
        if (!Decryption::is_valid_ptr(itemList)) return 0;

        uintptr_t itemsArray = kernelHandler.readmem<uintptr_t>(itemList + offsets::system_list::array);
        int count = kernelHandler.readmem<int>(itemList + offsets::system_list::size);
        if (!Decryption::is_valid_ptr(itemsArray) || count <= 0 || count > MAX_BELT_ITEMS) return 0;

        for (int i = 0; i < count; ++i) {
            uintptr_t itemPtr = kernelHandler.readmem<uintptr_t>(
                itemsArray + offsets::system_list::array_first_element + i * offsets::system_list::element_size
            );
            if (!Decryption::is_valid_ptr(itemPtr)) continue;

            uint32_t uid = (uint32_t)(kernelHandler.readmem<uint64_t>(itemPtr + offsets::item::uid) & 0xFFFFFFFF);
            if (uid != activeItemUid) continue;

            uintptr_t heldEntity = kernelHandler.readmem<uintptr_t>(itemPtr + offsets::item::HeldEntity);
            return heldEntity;
        }
        return 0;
    }

    void ClearCache() {
        for (auto& [id, tex] : textureCache) {
            if (tex != 0) reinterpret_cast<ID3D11ShaderResourceView*>(tex)->Release();
        }
        textureCache.clear();
    }

    ~InventoryManager() { ClearCache(); }
};