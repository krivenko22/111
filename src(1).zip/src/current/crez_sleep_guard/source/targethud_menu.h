#pragma once
#include "targethud.h"
#include <functional>
#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"

struct TargetHudMenuBridge {
    std::function<ImFont* ()> font;
    std::function<float()> menuAlpha;
    std::function<bool()> interactive;
};

template <typename TInterfaceManager>
inline bool RegisterTargetHudElement(
    TInterfaceManager& interfaceManager,
    const TargetHudMenuBridge& bridge
) {
    ImGuiViewport* viewport = ImGui::GetMainViewport();

    ImVec2 defaultPosition(120.f, 120.f);

    if (viewport) {
        defaultPosition = ImVec2(
            viewport->Size.x * 0.5f - 125.f,
            viewport->Size.y * 0.24f
        );
    }

    return interfaceManager.RegisterElement(
        "target_hud",
        "Target HUD",
        defaultPosition,
        ImVec2(250.f, 95.f),
        [bridge](
            ImDrawList* draw,
            const ImRect& rect,
            float alpha,
            float scale
            ) {
                (void)scale;

                ImFont* font = bridge.font ? bridge.font() : nullptr;

                if (!draw || !font)
                    return;

                const float menuAlpha = bridge.menuAlpha ? bridge.menuAlpha() : 0.f;
                const bool interactive = bridge.interactive ? bridge.interactive() : false;
                const bool preview = menuAlpha > 0.001f;

                const float finalAlpha = preview
                    ? ImClamp(menuAlpha, 0.f, 1.f)
                    : ImClamp(alpha, 0.f, 1.f);

                TargetHud::Get().DrawInterface(
                    draw,
                    font,
                    rect,
                    finalAlpha,
                    preview,
                    interactive
                );
        },
        true,
        true
    );
}