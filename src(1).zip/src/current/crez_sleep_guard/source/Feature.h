#pragma once

#include <windows.h>
#include <string>

enum class ModuleCategory
{
    Combat,
    Visuals,
    Input,
    Player,
    Weapon,
    Configs
};

enum class KeyBindMode
{
    Toggle,
    Hold
};

struct KeyBind
{
    int key = 0;
    KeyBindMode mode = KeyBindMode::Toggle;
    bool previousDown = false;

    bool IsBound() const { return key > 0; }

    bool IsDown() const {
        return key > 0 && (GetAsyncKeyState(key) & 0x8000) != 0;
    }

    void Clear() {
        key = 0;
        previousDown = false;
    }
};

class Module
{
public:
    std::string name;
    ModuleCategory category;
    bool enabled = false;
    KeyBind keybind{};

    Module(
        const std::string& moduleName,
        ModuleCategory moduleCategory = ModuleCategory::Visuals,
        bool forceExpanded = false
    ) : name(moduleName),
        category(moduleCategory),
        menuExpanded(forceExpanded),
        m_forceExpanded(forceExpanded)
    {
    }

    virtual ~Module() = default;

    virtual void OnRenderMenu() = 0;
    virtual void OnRenderOverlay() = 0;
    virtual bool NeedsAimStateLock() const { return false; }

    virtual bool IsMenuExpanded() const {
        return menuExpanded;
    }

    bool IsMenuExpansionLocked() const { return m_forceExpanded; }

    void SetMenuExpanded(bool expanded) {
        if (!m_forceExpanded) {
            menuExpanded = expanded;
        }
    }

    void ToggleMenuExpanded() {
        if (!m_forceExpanded) {
            menuExpanded = !menuExpanded;
        }
    }

    void SetKeyBind(int virtualKey, KeyBindMode bindMode = KeyBindMode::Toggle) {
        keybind.key = virtualKey;
        keybind.mode = bindMode;
        keybind.previousDown = false;
    }

    void ClearKeyBind() { keybind.Clear(); }

    void UpdateKeyBind() {
        if (!keybind.IsBound()) return;

        const bool down = keybind.IsDown();

        if (keybind.mode == KeyBindMode::Toggle) {
            if (down && !keybind.previousDown) {
                enabled = !enabled;
            }
        }
        else {
            enabled = down;
        }

        keybind.previousDown = down;
    }

private:
    bool menuExpanded = false;
    bool m_forceExpanded = false;
};