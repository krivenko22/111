#pragma once

#include "Feature.h"
#include "RenderFeature.h"
#include "Offsets.h"
#include "base_networkable.h"
#include "world_to_screen.h"
#include "localplayer.h"
#include "imgui/imgui.h"
#include "Driver/Driver.h"

#include "arrows1.h"
#include "triangle2.h"
#include "triangle3.h"

#include <windows.h>
#include <d3d11.h>
#include <wincodec.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <string>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "windowscodecs.lib")

class ArrowsModule : public Module
{
public:
    enum class ArrowStyle
    {
        Arrows1 = 0,
        Triangle2 = 1,
        Triangle3 = 2
    };

    enum class TargetType
    {
        Player,
        NPC,
        Sleeping
    };

    float arrowSize = 24.f;
    float maxDistance = 1000.f;
    float crosshairDistance = 100.f;

    bool drawOutline = true;

    bool showName = true;
    bool showDistance = true;

    bool useScreenCoordinates = false;

    bool showPlayers = true;
    bool showNPCs = false;
    bool showSleeping = false;

    float playerColor[4] = {
        1.0f, 1.0f, 1.0f, 1.0f
    };

    float npcColor[4] = {
        1.0f, 0.5f, 0.2f, 1.0f
    };

    float sleepingColor[4] = {
        0.4f, 0.7f, 1.0f, 1.0f
    };

    ArrowStyle arrowStyle = ArrowStyle::Triangle3;

    ArrowsModule()
        : Module(
            _xorstr("Arrows"),
            ModuleCategory::Visuals
        ), networkable(BaseNetworkable::Get())
    {
        s_instance = this;
    }

    ~ArrowsModule() override
    {
        ReleaseTextures();

        if (s_instance == this)
            s_instance = nullptr;
    }

    static void SetD3D11Device(
        ID3D11Device* device
    )
    {
        if (s_device == device)
            return;

        if (s_instance)
            s_instance->ReleaseTextures();

        s_device = device;
    }

    void OnRenderMenu() override
    {
        static const std::string sEnable =
            _xorstr("Включить стрелки направления");

        static const std::string sBind =
            _xorstr("Bind");

        static const std::string sOptions =
            _xorstr("ArrowsOptions");

        static const std::string sArrowSize =
            _xorstr("Размер стрелки");

        static const std::string sMaxDistance =
            _xorstr("Максимальная дистанция");

        static const std::string sCrosshairDistance =
            _xorstr("Расстояние от прицела");

        static const std::string sArrowType =
            _xorstr("Тип стрелки");

        static const std::string sArrowStyleId =
            _xorstr("##ArrowStyle");

        static const std::string sScreenCoordinates =
            _xorstr("Ориентироваться по экранным координатам");

        static const std::string sOutline =
            _xorstr("Обводка стрелок");

        static const std::string sShowName =
            _xorstr("Показывать ник игрока");

        static const std::string sShowDistance =
            _xorstr("Показывать дистанцию");

        static const std::string sFilters =
            _xorstr("Фильтры:");

        static const std::string sPlayers =
            _xorstr("Показывать игроков");

        static const std::string sNPC =
            _xorstr("Показывать NPC");

        static const std::string sSleeping =
            _xorstr("Показывать спящих");

        static const std::string sColors =
            _xorstr("Цвета:");

        static const std::string sPlayerColor =
            _xorstr("Цвет игроков");

        static const std::string sNpcColor =
            _xorstr("Цвет NPC");

        static const std::string sSleepingColor =
            _xorstr("Цвет спящих");

        static const std::string sPx =
            _xorstr("%.0f px");

        static const std::string sMeters =
            _xorstr("%.0f м");

        static const std::string arrowTypesStorage[] = {
            _xorstr("Arrows1"),
            _xorstr("Triangle2"),
            _xorstr("Triangle3")
        };

        const char* arrowTypes[] = {
            arrowTypesStorage[0].c_str(),
            arrowTypesStorage[1].c_str(),
            arrowTypesStorage[2].c_str()
        };

        // ------------------------------------------------------------
        // Main toggle
        // ------------------------------------------------------------

        RenderFeature::Toggle(
            this,
            sEnable.c_str(),
            &enabled,
            0
        );

        // ------------------------------------------------------------
        // Bind
        // ------------------------------------------------------------

        bool bindToggle =
            keybind.mode == KeyBindMode::Toggle;

        RenderFeature::BindButton(
            this,
            sBind.c_str(),
            &keybind.key,
            &bindToggle,
            0
        );

        keybind.mode =
            bindToggle
            ? KeyBindMode::Toggle
            : KeyBindMode::Hold;

        // ------------------------------------------------------------
        // Animated options
        // ------------------------------------------------------------

        const float reveal =
            RenderFeature::BeginAnimatedGroup(
                this,
                sOptions.c_str(),
                enabled,
                0,
                16.f,
                1.f
            );

        if (reveal > 0.001f)
        {
            ImGui::Spacing();

            // --------------------------------------------------------
            // Distance / size
            // --------------------------------------------------------

            RenderFeature::SliderFloat(
                this,
                sArrowSize.c_str(),
                &arrowSize,
                10.f,
                100.f,
                sPx.c_str()
            );

            RenderFeature::SliderFloat(
                this,
                sMaxDistance.c_str(),
                &maxDistance,
                100.f,
                1000.f,
                sMeters.c_str()
            );

            RenderFeature::SliderFloat(
                this,
                sCrosshairDistance.c_str(),
                &crosshairDistance,
                50.f,
                800.f,
                sPx.c_str()
            );

            ImGui::Spacing();

            // --------------------------------------------------------
            // Arrow type
            // --------------------------------------------------------

            ImGui::Text(
                "%s",
                sArrowType.c_str()
            );

            int currentStyle =
                static_cast<int>(arrowStyle);

            ImGui::PushID(
                "ArrowStyleCombo"
            );

            if (ImGui::Combo(
                sArrowStyleId.c_str(),
                &currentStyle,
                arrowTypes,
                IM_ARRAYSIZE(arrowTypes)
            ))
            {
                currentStyle =
                    (std::max)(
                        0,
                        (std::min)(
                            currentStyle,
                            2
                            )
                        );

                arrowStyle =
                    static_cast<ArrowStyle>(
                        currentStyle
                        );
            }

            ImGui::PopID();

            ImGui::Spacing();

            // --------------------------------------------------------
            // General options
            // --------------------------------------------------------

            RenderFeature::Toggle(
                this,
                sScreenCoordinates.c_str(),
                &useScreenCoordinates,
                1
            );

            RenderFeature::Toggle(
                this,
                sOutline.c_str(),
                &drawOutline,
                2
            );

            RenderFeature::Toggle(
                this,
                sShowName.c_str(),
                &showName,
                3
            );

            RenderFeature::Toggle(
                this,
                sShowDistance.c_str(),
                &showDistance,
                4
            );

            ImGui::Spacing();

            // --------------------------------------------------------
            // Filters
            // --------------------------------------------------------

            ImGui::Text(
                "%s",
                sFilters.c_str()
            );

            ImGui::Spacing();

            RenderFeature::Toggle(
                this,
                sPlayers.c_str(),
                &showPlayers,
                5
            );

            RenderFeature::Toggle(
                this,
                sNPC.c_str(),
                &showNPCs,
                6
            );

            RenderFeature::Toggle(
                this,
                sSleeping.c_str(),
                &showSleeping,
                7
            );

            ImGui::Spacing();

            // --------------------------------------------------------
            // Colors
            // --------------------------------------------------------

            ImGui::Text(
                "%s",
                sColors.c_str()
            );

            ImGui::Spacing();

            ImGui::PushID(
                "ArrowPlayerColor"
            );

            RenderFeature::ColorEdit4(
                this,
                sPlayerColor.c_str(),
                playerColor
            );

            ImGui::PopID();

            ImGui::PushID(
                "ArrowNPCColor"
            );

            RenderFeature::ColorEdit4(
                this,
                sNpcColor.c_str(),
                npcColor
            );

            ImGui::PopID();

            ImGui::PushID(
                "ArrowSleepingColor"
            );

            RenderFeature::ColorEdit4(
                this,
                sSleepingColor.c_str(),
                sleepingColor
            );

            ImGui::PopID();
        }

        RenderFeature::EndAnimatedGroup(
            this,
            sOptions.c_str(),
            0
        );
    }

    void OnRenderOverlay() override
    {
        if (!enabled)
            return;

        networkable.GetSnapshot(renderSnapshot);
        const RenderSnapshot& snapshot = renderSnapshot;

        const auto cam =
            WorldToScreenUtils::GetCameraSnapshot();

        const ImVec2 displaySize =
            ImGui::GetIO().DisplaySize;

        const int width =
            static_cast<int>(
                displaySize.x
                );

        const int height =
            static_cast<int>(
                displaySize.y
                );

        if (!cam.valid)
            return;

        if (width <= 0 ||
            height <= 0)
        {
            return;
        }

        if (snapshot.players.empty())
            return;

        ImDrawList* draw =
            ImGui::GetBackgroundDrawList();

        if (!draw)
            return;

        EnsureTextures();

        const uintptr_t localPlayer =
            LocalPlayerUtils::GetLocalPlayerId(
                snapshot.players
            );

        const float cx =
            width * 0.5f;

        const float cy =
            height * 0.5f;

        const float safeCrosshair =
            (std::max)(
                10.f,
                crosshairDistance
                );

        const float safeArrowSize =
            (std::max)(
                8.f,
                arrowSize
                );

        constexpr float PI =
            3.14159265358979323846f;

        constexpr float TWO_PI =
            6.28318530717958647692f;

        for (const auto& pd :
            snapshot.players)
        {
            if (!pd.valid)
                continue;

            if (pd.entityId ==
                localPlayer)
            {
                continue;
            }

            if (!pd.isAlive)
                continue;

            TargetType targetType =
                TargetType::Player;

            if (pd.isNpc)
            {
                targetType =
                    TargetType::NPC;
            }
            else if (pd.isSleeping)
            {
                targetType =
                    TargetType::Sleeping;
            }

            if (
                targetType ==
                TargetType::Player &&
                !showPlayers
                )
            {
                continue;
            }

            if (
                targetType ==
                TargetType::NPC &&
                !showNPCs
                )
            {
                continue;
            }

            if (
                targetType ==
                TargetType::Sleeping &&
                !showSleeping
                )
            {
                continue;
            }

            ImU32 tintColor = 0;

            switch (targetType)
            {
            case TargetType::Player:
                tintColor = IM_COL32(
                    static_cast<int>(
                        playerColor[0] * 255.f
                        ),
                    static_cast<int>(
                        playerColor[1] * 255.f
                        ),
                    static_cast<int>(
                        playerColor[2] * 255.f
                        ),
                    static_cast<int>(
                        playerColor[3] * 255.f
                        )
                );
                break;

            case TargetType::NPC:
                tintColor = IM_COL32(
                    static_cast<int>(
                        npcColor[0] * 255.f
                        ),
                    static_cast<int>(
                        npcColor[1] * 255.f
                        ),
                    static_cast<int>(
                        npcColor[2] * 255.f
                        ),
                    static_cast<int>(
                        npcColor[3] * 255.f
                        )
                );
                break;

            case TargetType::Sleeping:
                tintColor = IM_COL32(
                    static_cast<int>(
                        sleepingColor[0] * 255.f
                        ),
                    static_cast<int>(
                        sleepingColor[1] * 255.f
                        ),
                    static_cast<int>(
                        sleepingColor[2] * 255.f
                        ),
                    static_cast<int>(
                        sleepingColor[3] * 255.f
                        )
                );
                break;
            }

            const float dx =
                pd.position.x -
                cam.position.x;

            const float dy =
                pd.position.y -
                cam.position.y;

            const float dz =
                pd.position.z -
                cam.position.z;

            const float dist =
                std::sqrt(
                    dx * dx +
                    dy * dy +
                    dz * dz
                );

            if (!std::isfinite(dist))
                continue;

            if (dist > maxDistance)
                continue;

            float angle = 0.f;

            if (useScreenCoordinates)
            {
                Vector3 headPos = {
                    pd.position.x,
                    pd.position.y + 1.7f,
                    pd.position.z
                };

                ImVec2 screenHead{};

                const bool screenValid =
                    WorldToScreenUtils::WorldToScreen(
                        headPos,
                        cam.viewMatrix,
                        screenHead,
                        width,
                        height
                    ) &&
                    std::isfinite(screenHead.x) &&
                    std::isfinite(screenHead.y);

                if (!screenValid)
                    continue;

                const float screenDx =
                    screenHead.x - cx;

                const float screenDy =
                    screenHead.y - cy;

                if (!std::isfinite(screenDx) ||
                    !std::isfinite(screenDy))
                {
                    continue;
                }

                if (std::fabs(screenDx) < 0.01f &&
                    std::fabs(screenDy) < 0.01f)
                {
                    continue;
                }

                angle =
                    std::atan2(
                        screenDy,
                        screenDx
                    );
            }
            else
            {
                if (!GetHorizontalBearing(
                    cam.viewMatrix,
                    dx,
                    dz,
                    angle
                ))
                {
                    continue;
                }

                angle =
                    angle -
                    PI * 0.5f;

                while (angle > PI)
                    angle -= TWO_PI;

                while (angle < -PI)
                    angle += TWO_PI;
            }

            const ImVec2 arrowCenter = {
                cx +
                std::cos(angle) *
                safeCrosshair,

                cy +
                std::sin(angle) *
                safeCrosshair
            };

            const float rotation =
                angle +
                PI * 0.5f;

            const TextureData* texture =
                GetSelectedTexture();

            if (
                texture &&
                texture->srv
                )
            {
                DrawArrowTexture(
                    draw,
                    *texture,
                    arrowCenter,
                    rotation,
                    safeArrowSize,
                    tintColor
                );
            }

            float textY =
                arrowCenter.y +
                safeArrowSize * 0.55f +
                6.f;

            if (
                showName &&
                pd.name &&
                pd.name[0] != '\0'
                )
            {
                const char* name =
                    pd.name;

                const ImVec2 nameSize =
                    ImGui::CalcTextSize(
                        name
                    );

                const float textX =
                    arrowCenter.x -
                    nameSize.x * 0.5f;

                draw->AddText(
                    ImVec2(
                        textX + 1.f,
                        textY + 1.f
                    ),
                    IM_COL32(
                        0,
                        0,
                        0,
                        220
                    ),
                    name
                );

                draw->AddText(
                    ImVec2(
                        textX,
                        textY
                    ),
                    tintColor,
                    name
                );

                textY +=
                    nameSize.y +
                    2.f;
            }

            if (showDistance)
            {
                char distanceText[64]{};

                std::snprintf(
                    distanceText,
                    sizeof(distanceText),
                    _xorstr("%.0f m"),
                    dist
                );

                const ImVec2 distanceSize =
                    ImGui::CalcTextSize(
                        distanceText
                    );

                const float textX =
                    arrowCenter.x -
                    distanceSize.x * 0.5f;

                draw->AddText(
                    ImVec2(
                        textX + 1.f,
                        textY + 1.f
                    ),
                    IM_COL32(
                        0,
                        0,
                        0,
                        220
                    ),
                    distanceText
                );

                draw->AddText(
                    ImVec2(
                        textX,
                        textY
                    ),
                    tintColor,
                    distanceText
                );
            }
        }
    }

private:
    struct TextureData
    {
        ID3D11ShaderResourceView* srv =
            nullptr;

        UINT width = 0;
        UINT height = 0;

        bool loaded = false;

        void Release()
        {
            if (srv)
            {
                srv->Release();
                srv = nullptr;
            }

            width = 0;
            height = 0;
            loaded = false;
        }
    };

    inline static ID3D11Device* s_device =
        nullptr;

    inline static ArrowsModule* s_instance =
        nullptr;

    TextureData textureArrows1{};
    TextureData textureTriangle2{};
    TextureData textureTriangle3{};

    template <typename MatrixType>
    static bool GetHorizontalBearing(
        const MatrixType& matrix,
        float dx,
        float dz,
        float& angle
    )
    {
        float m[16]{};

        if (sizeof(MatrixType) < sizeof(m))
            return false;

        std::memcpy(
            m,
            &matrix,
            sizeof(m)
        );

        float rightX = m[0];
        float rightZ = m[8];

        const float rightLen =
            std::sqrt(
                rightX * rightX +
                rightZ * rightZ
            );

        if (
            !std::isfinite(rightLen) ||
            rightLen < 0.01f
            )
        {
            return false;
        }

        rightX /= rightLen;
        rightZ /= rightLen;

        const float cameraYaw =
            std::atan2(
                -rightZ,
                rightX
            );

        const float targetYaw =
            std::atan2(
                dx,
                dz
            );

        float bearing =
            targetYaw -
            cameraYaw;

        constexpr float PI =
            3.14159265358979323846f;

        constexpr float TWO_PI =
            6.28318530717958647692f;

        while (bearing > PI)
            bearing -= TWO_PI;

        while (bearing < -PI)
            bearing += TWO_PI;

        angle = bearing;

        return std::isfinite(angle);
    }

    static bool DecodePNG(
        const unsigned char* data,
        size_t dataSize,
        std::vector<unsigned char>& pixels,
        UINT& width,
        UINT& height
    )
    {
        pixels.clear();
        width = 0;
        height = 0;

        if (!data || dataSize == 0)
            return false;

        HRESULT coResult =
            CoInitializeEx(
                nullptr,
                COINIT_MULTITHREADED
            );

        bool needUninit = false;

        if (SUCCEEDED(coResult))
            needUninit = true;

        if (
            coResult != S_OK &&
            coResult != S_FALSE &&
            coResult != RPC_E_CHANGED_MODE
            )
        {
            return false;
        }

        IWICImagingFactory* factory =
            nullptr;

        IWICStream* stream =
            nullptr;

        IWICBitmapDecoder* decoder =
            nullptr;

        IWICBitmapFrameDecode* frame =
            nullptr;

        IWICFormatConverter* converter =
            nullptr;

        bool success = false;

        do
        {
            HRESULT hr =
                CoCreateInstance(
                    CLSID_WICImagingFactory,
                    nullptr,
                    CLSCTX_INPROC_SERVER,
                    IID_PPV_ARGS(
                        &factory
                    )
                );

            if (FAILED(hr))
                break;

            hr =
                factory->CreateStream(
                    &stream
                );

            if (FAILED(hr))
                break;

            hr =
                stream->InitializeFromMemory(
                    const_cast<BYTE*>(
                        data
                        ),
                    static_cast<DWORD>(
                        dataSize
                        )
                );

            if (FAILED(hr))
                break;

            hr =
                factory->CreateDecoderFromStream(
                    stream,
                    nullptr,
                    WICDecodeMetadataCacheOnLoad,
                    &decoder
                );

            if (FAILED(hr))
                break;

            hr =
                decoder->GetFrame(
                    0,
                    &frame
                );

            if (FAILED(hr))
                break;

            hr =
                factory->CreateFormatConverter(
                    &converter
                );

            if (FAILED(hr))
                break;

            hr =
                converter->Initialize(
                    frame,
                    GUID_WICPixelFormat32bppRGBA,
                    WICBitmapDitherTypeNone,
                    nullptr,
                    0.0,
                    WICBitmapPaletteTypeCustom
                );

            if (FAILED(hr))
                break;

            UINT w = 0;
            UINT h = 0;

            hr =
                converter->GetSize(
                    &w,
                    &h
                );

            if (FAILED(hr))
                break;

            if (w == 0 || h == 0)
                break;

            const size_t stride =
                static_cast<size_t>(
                    w
                    ) * 4ull;

            const size_t bufferSize =
                stride *
                static_cast<size_t>(
                    h
                    );

            pixels.resize(
                bufferSize
            );

            hr =
                converter->CopyPixels(
                    nullptr,
                    static_cast<UINT>(
                        stride
                        ),
                    static_cast<UINT>(
                        bufferSize
                        ),
                    pixels.data()
                );

            if (FAILED(hr))
            {
                pixels.clear();
                break;
            }

            width = w;
            height = h;
            success = true;

        } while (false);

        if (converter)
            converter->Release();

        if (frame)
            frame->Release();

        if (decoder)
            decoder->Release();

        if (stream)
            stream->Release();

        if (factory)
            factory->Release();

        if (needUninit)
            CoUninitialize();

        return success;
    }

    static bool CreateTextureFromPNG(
        ID3D11Device* device,
        const unsigned char* data,
        size_t dataSize,
        TextureData& output
    )
    {
        if (
            !device ||
            !data ||
            dataSize == 0
            )
        {
            return false;
        }

        std::vector<unsigned char> pixels;

        UINT width = 0;
        UINT height = 0;

        if (
            !DecodePNG(
                data,
                dataSize,
                pixels,
                width,
                height
            )
            )
        {
            return false;
        }

        if (pixels.empty())
            return false;

        D3D11_TEXTURE2D_DESC desc{};

        desc.Width = width;
        desc.Height = height;
        desc.MipLevels = 1;
        desc.ArraySize = 1;

        desc.Format =
            DXGI_FORMAT_R8G8B8A8_UNORM;

        desc.SampleDesc.Count = 1;
        desc.SampleDesc.Quality = 0;

        desc.Usage =
            D3D11_USAGE_DEFAULT;

        desc.BindFlags =
            D3D11_BIND_SHADER_RESOURCE;

        desc.CPUAccessFlags = 0;
        desc.MiscFlags = 0;

        D3D11_SUBRESOURCE_DATA initialData{};

        initialData.pSysMem =
            pixels.data();

        initialData.SysMemPitch =
            static_cast<UINT>(
                width * 4u
                );

        ID3D11Texture2D* texture =
            nullptr;

        HRESULT hr =
            device->CreateTexture2D(
                &desc,
                &initialData,
                &texture
            );

        if (
            FAILED(hr) ||
            !texture
            )
        {
            return false;
        }

        D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc{};

        srvDesc.Format =
            DXGI_FORMAT_R8G8B8A8_UNORM;

        srvDesc.ViewDimension =
            D3D11_SRV_DIMENSION_TEXTURE2D;

        srvDesc.Texture2D.MostDetailedMip =
            0;

        srvDesc.Texture2D.MipLevels =
            1;

        ID3D11ShaderResourceView* srv =
            nullptr;

        hr =
            device->CreateShaderResourceView(
                texture,
                &srvDesc,
                &srv
            );

        texture->Release();

        if (
            FAILED(hr) ||
            !srv
            )
        {
            return false;
        }

        output.Release();

        output.srv = srv;
        output.width = width;
        output.height = height;
        output.loaded = true;

        return true;
    }

    void EnsureTextures()
    {
        if (!s_device)
            return;

        if (!textureArrows1.loaded)
        {
            CreateTextureFromPNG(
                s_device,
                arrows,
                arrows_size,
                textureArrows1
            );
        }

        if (!textureTriangle2.loaded)
        {
            CreateTextureFromPNG(
                s_device,
                triangle,
                triangle_size,
                textureTriangle2
            );
        }

        if (!textureTriangle3.loaded)
        {
            CreateTextureFromPNG(
                s_device,
                triangle2,
                triangle2_size,
                textureTriangle3
            );
        }
    }

    void ReleaseTextures()
    {
        textureArrows1.Release();
        textureTriangle2.Release();
        textureTriangle3.Release();
    }

    const TextureData* GetSelectedTexture() const
    {
        switch (arrowStyle)
        {
        case ArrowStyle::Arrows1:
            return &textureArrows1;

        case ArrowStyle::Triangle2:
            return &textureTriangle2;

        case ArrowStyle::Triangle3:
            return &textureTriangle3;

        default:
            return nullptr;
        }
    }

    static void DrawArrowTexture(
        ImDrawList* draw,
        const TextureData& texture,
        const ImVec2& center,
        float rotation,
        float maxSize,
        ImU32 tintColor
    )
    {
        if (
            !draw ||
            !texture.srv ||
            texture.width == 0 ||
            texture.height == 0
            )
        {
            return;
        }

        float width =
            static_cast<float>(
                texture.width
                );

        float height =
            static_cast<float>(
                texture.height
                );

        const float aspect =
            width / height;

        float drawWidth =
            maxSize;

        float drawHeight =
            maxSize;

        if (aspect > 1.f)
        {
            drawHeight =
                drawWidth /
                aspect;
        }
        else
        {
            drawWidth =
                drawHeight *
                aspect;
        }

        const float halfWidth =
            drawWidth * 0.5f;

        const float halfHeight =
            drawHeight * 0.5f;

        const float cs =
            std::cos(rotation);

        const float sn =
            std::sin(rotation);

        auto Rotate =
            [&](float x, float y)
            {
                return ImVec2(
                    center.x +
                    x * cs -
                    y * sn,

                    center.y +
                    x * sn +
                    y * cs
                );
            };

        const ImVec2 p0 =
            Rotate(
                -halfWidth,
                -halfHeight
            );

        const ImVec2 p1 =
            Rotate(
                halfWidth,
                -halfHeight
            );

        const ImVec2 p2 =
            Rotate(
                halfWidth,
                halfHeight
            );

        const ImVec2 p3 =
            Rotate(
                -halfWidth,
                halfHeight
            );

        draw->AddImageQuad(
            reinterpret_cast<ImTextureID>(
                texture.srv
                ),
            p0,
            p1,
            p2,
            p3,
            ImVec2(
                0.f,
                0.f
            ),
            ImVec2(
                1.f,
                0.f
            ),
            ImVec2(
                1.f,
                1.f
            ),
            ImVec2(
                0.f,
                1.f
            ),
            tintColor
        );
    }

private:
    RenderSnapshot renderSnapshot;
    BaseNetworkable& networkable;
};