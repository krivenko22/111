#include "source/imgui/imgui.h"
#include "source/Unity/overlay_coordinates.h"
#include <cassert>
#include <cstdio>
#include <cmath>
int main(){
 using namespace OverlayCoordinates;
 ImGui::CreateContext();auto& io=ImGui::GetIO();io.DisplaySize={1920,1080};io.DeltaTime=1.f/60;
 unsigned char*p;int w,h;io.Fonts->GetTexDataAsRGBA32(&p,&w,&h);
 ImGui::NewFrame();auto*d=ImGui::GetBackgroundDrawList();
 d->AddRectFilled({2,2},{5,5},IM_COL32_WHITE);int existing=d->VtxBuffer.Size;ImVec2 original=d->VtxBuffer[0].pos;
 d->PushClipRect({0,0},{1280,720},false);d->AddDrawCmd();int v=d->VtxBuffer.Size,c=d->CmdBuffer.Size-1;
 d->AddRectFilled({10,20},{30,40},IM_COL32_WHITE);const int end=d->CmdBuffer.Size;
 Area monitor{-1920,0,0,1080},game{-1820,120,-540,840};ImVec2 off=Offset(game,monitor);assert(off.x==100&&off.y==120);
 Translate(d,v,c,end,off,io.DisplaySize);
 assert(d->VtxBuffer[0].pos.x==original.x && d->VtxBuffer[0].pos.y==original.y);
 assert(d->VtxBuffer[existing].pos.x==110 && d->VtxBuffer[existing].pos.y==140);
 auto clip=d->CmdBuffer[c].ClipRect;assert(clip.x==100&&clip.y==120&&clip.z==1380&&clip.w==840);
 d->PopClipRect();d->AddRectFilled({0,0},{5,5},IM_COL32_WHITE);ImGui::Render();
 // Partially off-monitor game windows clamp clip rectangles, not vertices.
 ImGui::NewFrame();d=ImGui::GetBackgroundDrawList();d->PushClipRect({0,0},{1280,720},false);d->AddDrawCmd();v=d->VtxBuffer.Size;c=d->CmdBuffer.Size-1;
 d->AddRectFilled({10,20},{30,40},IM_COL32_WHITE);Translate(d,v,c,d->CmdBuffer.Size,{-120,-80},io.DisplaySize);
 clip=d->CmdBuffer[c].ClipRect;assert(clip.x==0&&clip.y==0&&clip.z==1160&&clip.w==640);assert(d->VtxBuffer[v].pos.x==-110);
 d->PopClipRect();ImGui::Render();ImGui::DestroyContext();puts("PASS overlay geometry: game-local projection, negative-monitor offset, clipping and unchanged menu vertices");
}
