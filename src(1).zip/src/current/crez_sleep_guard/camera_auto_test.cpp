#include "source/Unity/camera_candidate.h"
#include <map>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <cmath>
static std::map<uint64_t,unsigned char> mem;
template<class T>void put(uint64_t a,T v){auto*p=(unsigned char*)&v;for(size_t i=0;i<sizeof(T);++i)mem[a+i]=p[i];}
static void str(uint64_t a,const char* s){for(size_t i=0;i<=std::strlen(s);++i)put(a+i,s[i]);}
static bool read(uint64_t a,void* out,size_t n){auto*p=(unsigned char*)out;for(size_t i=0;i<n;++i){auto it=mem.find(a+i);if(it==mem.end())return false;p[i]=it->second;}return true;}
static bool near(float a,float b){return std::abs(a-b)<0.0002f;}
static void candidate(uint64_t obj,uint64_t cls,uint64_t name,const char* text){put(obj,cls);put(cls+0x10,name);str(name,text);}
static float column(const Matrix4x4&m,const Vector3&p,int c){return p.x*m.m[0][c]+p.y*m.m[1][c]+p.z*m.m[2][c]+m.m[3][c];}
int main(){
 uint64_t base=0x50000000,cl=0x60000000,st=0x60010000,camera=0x60020000,tr=0x60030000;
 uint64_t ck=0x60040000,cn=0x60050000,tk=0x60060000,tn=0x60070000,nativeC=0x60080000,nativeT=0x60090000,data=0x600A0000,mats=0x600B0000,parents=0x600C0000;
 put(base+0xF0C83A0,cl);put(cl+0xB8,st);put(st+0x60,camera);put(st+0x68,tr);
 candidate(camera,ck,cn,"Camera");candidate(tr,tk,tn,"Transform");put(camera+0x10,nativeC);put(tr+0x10,nativeT);
 Matrix4x4 proj{};float values[16]={0.5625f,0,0,0,0,1,0,0,0,0,-1.00004f,-1,0,0,-0.100002f,0};memcpy(&proj,values,sizeof(proj));put(nativeC+0xB0,proj);
 put(nativeT+0x28,data);put<int32_t>(nativeT+0x30,0);put(data+0x18,mats);put(data+0x20,parents);
 const float q=std::sqrt(0.5f);
 put(mats,TransformPosition::Matrix{1,2,3,0,0,0,0,1,1,1,1,0});put(mats+48,TransformPosition::Matrix{10,20,30,0,0,q,0,q,1,1,1,0});put<int32_t>(parents,1);put<int32_t>(parents+4,-1);
 CameraCandidate::Refs refs{};assert(CameraCandidate::Acquire(read,base,refs));assert(refs.camera==camera && refs.transform==tr && refs.nativeCamera==nativeC);
 Matrix4x4 loaded{};assert(CameraCandidate::Projection(read,refs,loaded));
 CameraPose::Pose pose{};assert(CameraPose::World(read,tr,pose));assert(near(pose.position.x,13)&&near(pose.position.y,22)&&near(pose.position.z,29));
 Matrix4x4 m{};assert(CameraPose::Build(pose,loaded,m));Vector3 ahead{23,22,29};assert(near(column(m,ahead,0),0));assert(near(column(m,ahead,1),0));assert(near(column(m,ahead,3),10));
 Vector3 side{23,22,28};float x90=column(m,side,0);assert(x90>0);
 values[0]=0.8423705f;values[5]=1.497548f;memcpy(&proj,values,sizeof(proj));put(nativeC+0xB0,proj);assert(CameraCandidate::Projection(read,refs,loaded));assert(CameraPose::Build(pose,loaded,m));assert(column(m,side,0)>x90);
 put<int32_t>(parents+4,0);assert(!CameraPose::World(read,tr,pose));put<int32_t>(parents+4,-1);
 put(tn,'X');assert(!CameraCandidate::Acquire(read,base,refs));put(tn,'T');
 values[11]=0;memcpy(&proj,values,sizeof(proj));put(nativeC+0xB0,proj);assert(CameraCandidate::Acquire(read,base,refs));assert(!CameraCandidate::Projection(read,refs,loaded));
 puts("PASS synthetic camera: typed references, changing projection, world pose, rotation, invalid data and cycles");
}
