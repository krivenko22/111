#include "source/Unity/flags.h"
#include <map>
#include <cstring>
#include <cassert>
#include <cstdio>
#include <thread>
#include <atomic>
static std::map<uint64_t,unsigned char> mem;
static int teamReads=0; static uint64_t teamAddress=0;
kernelmode_proc_handler kernelHandler;
kernelmode_proc_handler::kernelmode_proc_handler():handle(INVALID_HANDLE_VALUE),pid(0){}
kernelmode_proc_handler::~kernelmode_proc_handler(){}
bool kernelmode_proc_handler::read_memory(uint64_t src,uint64_t dst,size_t n){
 if(src==teamAddress)teamReads++;
 auto *out=reinterpret_cast<unsigned char*>(dst); for(size_t i=0;i<n;i++) {auto it=mem.find(src+i);if(it==mem.end()){std::memset(out,0,n);return false;}out[i]=it->second;} return true;
}
template<class T> void put(uint64_t a,T v){auto*p=reinterpret_cast<unsigned char*>(&v);for(size_t i=0;i<sizeof v;i++)mem[a+i]=p[i];}
int main(){
 uint64_t local=0x11000000,target=0x12000000,team=0x13000000,list=0x14000000,arr=0x15000000,m0=0x16000000,m1=0x17000000,str=0x18000000;
 teamAddress=local+offsets::base_player::player_team;put(teamAddress,team);
 put(team+offsets::player_team::memberList,list);put(list+offsets::system_list::size,2);put(list+offsets::system_list::array,arr);
 put(arr+offsets::system_list::array_first_element,m0);put(arr+offsets::system_list::array_first_element+offsets::player_team::member_stride,m1);
 put(m0+offsets::player_team::member_steam_id,uint64_t(111));put(m1+offsets::player_team::member_steam_id,uint64_t(222));
 put(target+offsets::base_player::userIDString,str);put(str+offsets::unity_string::m_stringLength,3);
 const wchar_t digits[]=L"222";for(int i=0;i<3;i++)put(str+offsets::unity_string::first_char+sizeof(wchar_t)*i,digits[i]);
 assert(PlayerFlagsUtils::IsTeammate(target,local));
 PlayerFlagsUtils::cachedTeamCount=0;PlayerFlagsUtils::cachedTeamPtr=0;teamReads=0;
 PlayerFlagsUtils::UpdateTeamCache(local);
 for(int i=0;i<100;i++)assert(PlayerFlagsUtils::IsTeammateCached(target,local));
 assert(teamReads==1);assert(!PlayerFlagsUtils::IsTeammateCached(local,local));
 puts("PASS team mock: same result; one local-team read for 100 candidates");
}
