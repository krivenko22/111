#include <windows.h>
#include "source/Menu.h"
#include <cassert>
#include <cstdio>
std::atomic<uintptr_t> g_currentAimTarget{0};
ID3D11Device* gD3DDevice=nullptr;
kernelmode_proc_handler kernelHandler;
kernelmode_proc_handler::kernelmode_proc_handler():handle(INVALID_HANDLE_VALUE),pid(0){}
kernelmode_proc_handler::~kernelmode_proc_handler(){}
bool kernelmode_proc_handler::read_memory(uint64_t,uint64_t,size_t){return false;}
int main(){
 ImGui::CreateContext();auto& io=ImGui::GetIO();io.DisplaySize={1920,1080};io.DeltaTime=1.f/60;io.IniFilename=nullptr;
 Menu menu;menu.SetupStyle(nullptr);unsigned char* pixels=nullptr;int w=0,h=0;io.Fonts->GetTexDataAsRGBA32(&pixels,&w,&h);assert(pixels&&w&&h);
 ModuleManager modules;auto aim=std::make_shared<AimModule>();modules.RegisterModule(aim);
 auto frame=[&](){ImGui::NewFrame();menu.Render(modules);ImGui::Render();assert(ImGui::GetDrawData()->TotalVtxCount>0);};
 auto frames=[&](int n){for(int i=0;i<n;i++)frame();};
 auto move=[&](float x,float y){io.AddMousePosEvent(x,y);frame();};
 auto down=[&](){io.AddMouseButtonEvent(0,true);frame();};
 auto up=[&](){io.AddMouseButtonEvent(0,false);frame();};
 auto click=[&](float x,float y){move(x,y);down();up();};
 frames(100);
 // Main panel at x=510,y=240; trace panel begins x=1422,y=314.
 move(1460,390);down();move(1480,406);move(1510,424);move(1550,430);up();
 assert(aim->trace.count>=3 && aim->trace.Valid());
 assert(aim->trace.points[0].x>=20 && aim->trace.points[aim->trace.count-1].x>aim->trace.points[0].x);
 const int recorded=aim->trace.count;
 // The real ImGui slider is in the legacy trace panel, beneath the canvas.
 assert(aim->traceStrengthPercent>8.79f && aim->traceStrengthPercent<8.81f);
 click(1542,591);assert(aim->traceStrengthPercent>48.f && aim->traceStrengthPercent<52.f);
 click(1644,591);assert(aim->traceStrengthPercent>98.f);
 click(1438,591);assert(aim->traceStrengthPercent<2.f);
 ConfigStore config;aim->RegisterTraceConfig(config);aim->traceStrengthPercent=37.5f;
 AimModule restored;ConfigStore load;restored.RegisterTraceConfig(load);assert(load.Load(config.Snapshot()));
 assert(restored.traceStrengthPercent==37.5f && restored.trace.count==recorded);
 // Legacy config without the new key retains 8.8% by default.
 AimModule old;ConfigStore oldLoad;old.RegisterTraceConfig(oldLoad);
 assert(oldLoad.Load("CREZ_LAST_CONFIG_V1\naim.trace.count=0\n"));assert(old.traceStrengthPercent>8.79f&&old.traceStrengthPercent<8.81f);
 // Canvas hidden outside Aim tab and cannot be drawn there.
 click(550,392);frames(80);move(1460,390);down();move(1490,420);up();assert(aim->trace.count==recorded);
 click(550,342);frames(80);click(1480,634);frames(4);assert(aim->trace.count==0);
 puts("PASS trace menu: press-drag, percent slider 0/50/100, config migration, tab visibility and clear");ImGui::DestroyContext();
}
