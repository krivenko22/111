#include "source/Unity/elysium_aim_core.h"
#include <cassert>
#include <cmath>
#include <cstdio>
int main(){using namespace ElysiumAimCore;
 Choice c;Consider(c,{1,1000,540,10},1920,1080,120,0,0);Consider(c,{2,970,540,50},1920,1080,120,0,0);assert(c.candidate.id==2);
 c={};Consider(c,{1,1000,540,10},1920,1080,120,1,0);Consider(c,{2,970,540,50},1920,1080,120,1,0);assert(c.candidate.id==1);
 c={};Consider(c,{1,1130,540,10},1920,1080,120,0,1);Consider(c,{2,970,540,50},1920,1080,120,0,1);assert(c.candidate.id==1&&c.locked);
 c={};Consider(c,{1,1150,540,10},1920,1080,120,0,1);assert(!c.candidate.id);
 Consider(c,{1,NAN,540,10},1920,1080,120,0,0);assert(!c.candidate.id);
 MoveState a{},b{};int fast=0,slow=0;
 for(int i=0;i<144;i++){auto m=Step(40,0,.035f,10,1.f/144,a);assert(m.x>=0&&m.x<=4&&m.y==0);fast+=m.x;}
 for(int i=0;i<60;i++)slow+=Step(40,0,.035f,10,1.f/60,b).x;
 assert(std::abs(fast-slow)<=5);auto m=Step(-40,0,.035f,10,1.f/60,a);assert(m.x<=0);
 m=Step(1,1,.035f,10,1.f/60,a);assert(!m.x&&!m.y&&a.residualX==0);
 m=Step(NAN,1,.035f,10,.02f,a);assert(!m.x&&!m.y);
 m=Step(40,0,.035f,10,.2f,a);assert(!m.x&&!m.y&&a.residualX==0);
 puts("PASS Elysium-style core: priority, lock/FOV hysteresis, directional motion, 60/144Hz, deadzone and guards");
}
