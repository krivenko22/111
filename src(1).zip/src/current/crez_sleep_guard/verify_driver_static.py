#!/usr/bin/env python3
"""Offline structural check for the exact WmipRpc.sys previously inspected.
Does not load or execute the driver. Requires `python -m pip install pefile`.
"""
import argparse, hashlib, struct
import pefile
p=argparse.ArgumentParser(); p.add_argument('driver'); a=p.parse_args()
raw=open(a.driver,'rb').read()
expected='fcee2d41f0735d8f38d6179a299adf905db5fe0d85b5a8aa8ecdcd6ac2d95921'
if hashlib.sha256(raw).hexdigest()!=expected: raise SystemExit('FAIL: SHA-256 differs; do not assume this protocol')
pe=pefile.PE(data=raw); img=pe.get_memory_mapped_image()
def check(condition,message):
 if not condition: raise SystemExit('FAIL: '+message)
check(pe.FILE_HEADER.Machine==0x8664 and pe.OPTIONAL_HEADER.Subsystem==1,'PE architecture/subsystem')
check('\\Device\\WmipRpc'.encode('utf-16le') in raw and '\\DosDevices\\WmipRpc'.encode('utf-16le') in raw,'device names')
check(img[0x2dc1:0x2dc7]==bytes.fromhex('81c10000deff'),'IOCTL dispatch base')
check(img[0x2dfd:0x2e03]==bytes.fromhex('c70601000200'),'heartbeat version')
check(img[0x5360:0x5364]==bytes.fromhex('5ac37ea1'),'four-byte XOR key')
case_table=[struct.unpack_from('<I',img,0x37a0+i*4)[0] for i in range(14)]
index=img[0x37d8:0x37d8+0x71]
expected_cases={0x220000:0x2ded,0x220010:0x2efb,0x220014:0x2fdd,0x220020:0x3180,0x220028:0x327e,0x220030:0x34c1}
for code,rva in expected_cases.items():check(case_table[index[code-0x220000]]==rva,f'IOCTL {code:#x}')
print('PASS: exact driver hash, x64/native, device names, heartbeat, dispatch and XOR key')
print('Static ABI checks only: driver safety and runtime compatibility are NOT established.')
