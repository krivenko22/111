#include "source/Menu.h"
#include <cassert>
#include <cstdio>
int main(){
 InterfaceManager m;assert(m.ConfigPosition("watermark",false)==16.f);
 m.SetConfigPosition("watermark",false,88.f);assert(m.ConfigPosition("watermark",false)==88.f);
 m.SetConfigPosition("late",false,42.f);m.SetConfigPosition("late",true,64.f);
 bool ok=m.RegisterElement("late","late",{2.f,3.f},{30.f,30.f},[](ImDrawList*,const ImRect&,float,float){});
 assert(ok&&m.ConfigPosition("late",false)==42.f&&m.ConfigPosition("late",true)==64.f);
 puts("PASS interface config: existing and late-registered positions");
}
