#include "source/Unity/local_input_candidate.h"
#include <map>
#include <cassert>
#include <cstring>
#include <cstdio>
static std::map<uint64_t,unsigned char> mem;
template<class T>void put(uint64_t a,T value){const auto*p=(unsigned char*)&value;for(size_t i=0;i<sizeof(T);++i)mem[a+i]=p[i];}
static bool read(uint64_t a,void* d,size_t n){auto*p=(unsigned char*)d;for(size_t i=0;i<n;i++){auto it=mem.find(a+i);if(it==mem.end())return false;p[i]=it->second;}return true;}
int main(){
 uint64_t player=0x10000000,input=0x20000000,klass=0x30000000,name=0x40000000;
 put(player+0x678,input);put(input,klass);put(klass+0x10,name);put(input+0x20,player);
 const char type[]="PlayerInput";for(size_t i=0;i<sizeof(type);i++)put(name+i,type[i]);
 put(input+0x44,Vector3{5.77556f,293.79f,0});Vector3 angles{};
 assert(LocalInputCandidate::Angles(read,player,angles));assert(angles.y>293 && angles.y<294);
 put(input+0x20,uint64_t(0));assert(!LocalInputCandidate::Angles(read,player,angles));
 put(input+0x20,player);put(name,'X');assert(!LocalInputCandidate::Angles(read,player,angles));
 put(name,'P');put(input+0x44,Vector3{200,0,0});assert(!LocalInputCandidate::Angles(read,player,angles));
 puts("PASS local input: class, owner backlink, candidate angle bounds; synthetic only");
}
