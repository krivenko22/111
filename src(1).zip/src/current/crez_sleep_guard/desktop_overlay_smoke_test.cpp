#include <windows.h>
#define CREZ_OVERLAY_TEST
#include "source/Overlay.h"
#include <atomic>
#include <thread>
#include <cstdio>
#include <cassert>
ID3D11Device* gD3DDevice=nullptr;
std::atomic<uintptr_t> g_currentAimTarget{0};
LRESULT CALLBACK proc(HWND w,UINT m,WPARAM a,LPARAM b){if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProc(w,m,a,b);}
class TestMod:public Module{public:std::atomic<int> frames{0};TestMod():Module("Test",ModuleCategory::Visuals){}void OnRenderMenu()override{}void OnRenderOverlay()override{frames++;ImGui::GetBackgroundDrawList()->AddRect({20,20},{300,150},0xffffffff);}};
int main(int argc,char**argv){
 if(argc>1){WNDCLASSA wc{};wc.lpfnWndProc=proc;wc.hInstance=GetModuleHandleA(0);wc.lpszClassName="FakeRustForOverlayTest";assert(RegisterClassA(&wc));
  HWND w=CreateWindowA(wc.lpszClassName,"Fake Rust",WS_OVERLAPPEDWINDOW|WS_VISIBLE,100,120,900,700,0,0,wc.hInstance,0);assert(w);ShowWindow(w,SW_SHOW);MSG m{};while(GetMessage(&m,0,0,0)>0){TranslateMessage(&m);DispatchMessage(&m);}return 0;}
 char exe[MAX_PATH]{};GetModuleFileNameA(0,exe,MAX_PATH);std::string cmd=std::string("\"")+exe+"\" game";
 STARTUPINFOA si{};si.cb=sizeof(si);PROCESS_INFORMATION pi{};assert(CreateProcessA(nullptr,cmd.data(),nullptr,nullptr,FALSE,0,nullptr,nullptr,&si,&pi));pId=pi.dwProcessId;
 HWND game=nullptr;for(int i=0;i<100&&!game;i++){Sleep(50);game=FindWindowA("FakeRustForOverlayTest",nullptr);}assert(game);
 WNDCLASSA wc{};wc.lpfnWndProc=proc;wc.hInstance=GetModuleHandleA(0);wc.lpszClassName="DesktopAppForOverlayTest";assert(RegisterClassA(&wc));
 HWND app=CreateWindowA(wc.lpszClassName,"Desktop app",WS_OVERLAPPEDWINDOW|WS_VISIBLE,500,300,600,400,0,0,wc.hInstance,0);assert(app);
 Menu menu;Overlay ov;assert(ov.Init());menu.SetupStyle(ov.GetD3DDevice());menu.Toggle();
 ModuleManager modules;auto mod=std::make_shared<TestMod>();mod->SetKeyBind(VK_F1,KeyBindMode::Toggle);modules.RegisterModule(mod);auto aim=std::make_shared<AimModule>();modules.RegisterModule(aim);LastConfig config;std::atomic<bool> cancel{false};std::atomic<bool> ok{false};
 std::thread driver([&]{
   for(int i=0;i<200 && mod->frames.load()<5;i++)Sleep(20);
   SetForegroundWindow(app);Sleep(150);bool appFocused=GetForegroundWindow()==app;
   int before=mod->frames.load();Sleep(350);int after=mod->frames.load();
   HWND over=ov.TestWindow();LONG_PTR ex=GetWindowLongPtr(over,GWL_EXSTYLE);RECT o{};GetWindowRect(over,&o);
   auto press=[](WORD vk){INPUT in{};in.type=INPUT_KEYBOARD;in.ki.wVk=vk;SendInput(1,&in,sizeof(in));Sleep(70);in.ki.dwFlags=KEYEVENTF_KEYUP;SendInput(1,&in,sizeof(in));Sleep(150);};
   press(VK_F1); // must not toggle game module while desktop app is active
   press(VK_DELETE);bool opened=(GetWindowLongPtr(over,GWL_EXSTYLE)&WS_EX_TRANSPARENT)==0;
   bool menuFocused=GetForegroundWindow()==over;Sleep(700);
   SetCursorPos(1460,390);Sleep(100);INPUT mouse{};mouse.type=INPUT_MOUSE;mouse.mi.dwFlags=MOUSEEVENTF_LEFTDOWN;SendInput(1,&mouse,sizeof(mouse));
   Sleep(100);SetCursorPos(1490,410);Sleep(120);SetCursorPos(1530,430);Sleep(120);
   mouse.mi.dwFlags=MOUSEEVENTF_LEFTUP;SendInput(1,&mouse,sizeof(mouse));Sleep(120);
   press(VK_DELETE);bool closed=(GetWindowLongPtr(over,GWL_EXSTYLE)&WS_EX_TRANSPARENT)!=0;
   ShowWindow(game,SW_MINIMIZE);Sleep(250);int minimizedBefore=mod->frames.load();Sleep(250);bool stillRendering=mod->frames.load()>minimizedBefore && IsWindowVisible(over);
   if(appFocused&&after>before&&(ex&WS_EX_TOPMOST)&&IsWindowVisible(over)&&o.right-o.left>=900&&opened&&menuFocused&&closed&&stillRendering)ok=true;
   if(!ok)printf("failed details appFocused=%d frames=%d top=%d visible=%d width=%ld open=%d focus=%d closed=%d minimized=%d\n",appFocused,after-before,!!(ex&WS_EX_TOPMOST),IsWindowVisible(over),o.right-o.left,opened,menuFocused,closed,stillRendering);
   cancel=true;
 });
 ov.Run(modules,menu,config,nullptr,&cancel);driver.join();ov.Shutdown();DestroyWindow(app);PostMessage(game,WM_CLOSE,0,0);WaitForSingleObject(pi.hProcess,2000);CloseHandle(pi.hThread);CloseHandle(pi.hProcess);
 assert(ok.load());assert(!mod->enabled);assert(aim->trace.count>=3&&aim->trace.Valid());printf("PASS overlay Win32/D3D: %d frames over desktop; Del/focus/clickthrough, mouse trace, inactive keybind, minimized Rust\n",mod->frames.load());
}
