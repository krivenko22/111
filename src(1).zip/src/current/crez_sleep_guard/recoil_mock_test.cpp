#include <windows.h>
static SHORT WINAPI FakeKeys(int);
static HWND WINAPI FakeForeground();
static DWORD WINAPI FakeWindowPid(HWND,LPDWORD);
static UINT WINAPI FakeSend(UINT,LPINPUT,int);
#define GetAsyncKeyState FakeKeys
#define GetForegroundWindow FakeForeground
#define GetWindowThreadProcessId FakeWindowPid
#define SendInput FakeSend
#include "source/recoil.h"
#undef GetAsyncKeyState
#undef GetForegroundWindow
#undef GetWindowThreadProcessId
#undef SendInput
#include <cassert>
#include <thread>
#include <cstdio>
static bool fire=false,aim=false,focus=true;
static int sends=0,totalY=0;
static SHORT WINAPI FakeKeys(int key){return ((key==VK_LBUTTON&&fire)||(key==VK_RBUTTON&&aim))?SHORT(0x8000):0;}
static HWND WINAPI FakeForeground(){return (HWND)1;}
static DWORD WINAPI FakeWindowPid(HWND,LPDWORD out){*out=focus?1234:7777;return 1;}
static UINT WINAPI FakeSend(UINT n,LPINPUT in,int){assert(n==1&&in->type==INPUT_MOUSE&&in->mi.dwFlags==MOUSEEVENTF_MOVE);++sends;totalY+=in->mi.dy;return n;}
static void frame(RecoilModule& r){ImGui::NewFrame();r.OnRenderOverlay();ImGui::EndFrame();}
int main(){
 pId=1234;ImGui::CreateContext();ImGuiIO& io=ImGui::GetIO();io.DisplaySize={1920,1080};io.DeltaTime=1.f/60;unsigned char* px;int w,h;io.Fonts->GetTexDataAsRGBA32(&px,&w,&h);
 RecoilModule r;r.vertical=200.f;fire=true;aim=true;frame(r);assert(sends==0);
 r.enabled=true;frame(r);assert(sends==0);std::this_thread::sleep_for(std::chrono::milliseconds(20));frame(r);assert(sends==1&&totalY>0);
 fire=false;frame(r);assert(sends==1);fire=true;aim=false;frame(r);assert(sends==1);
 aim=true;focus=false;frame(r);assert(sends==1);focus=true;
 frame(r);assert(sends==1);std::this_thread::sleep_for(std::chrono::milliseconds(20));frame(r);assert(sends==2);
 r.enabled=false;frame(r);assert(sends==2);ImGui::DestroyContext();
 puts("PASS recoil mock: disabled, focus, fire+aim hold, release/reset, relative-move only");
}
