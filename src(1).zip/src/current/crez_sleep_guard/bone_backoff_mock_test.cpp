#include "source/Unity/types.h"
#include "source/Bone.h"
#include <map>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <thread>
static std::map<uint64_t,unsigned char> mem;static int calls=0;
kernelmode_proc_handler kernelHandler;
kernelmode_proc_handler::kernelmode_proc_handler():handle(INVALID_HANDLE_VALUE),pid(0){}
kernelmode_proc_handler::~kernelmode_proc_handler(){}
bool kernelmode_proc_handler::read_memory(uint64_t addr,uint64_t out,size_t n){calls++;auto*p=(unsigned char*)out;for(size_t i=0;i<n;i++){auto it=mem.find(addr+i);if(it==mem.end()){std::memset(p,0,n);return false;}p[i]=it->second;}return true;}
template<class T>void put(uint64_t a,T v){auto*p=(unsigned char*)&v;for(size_t i=0;i<sizeof(v);i++)mem[a+i]=p[i];}
int main(){uintptr_t ent=0x20000000,model=0x30000000;put(ent+offsets::base_entity::model,model);put<uint32_t>(ent+offsets::base_combat_entity::lifestate,0);put<uint64_t>(model+offsets::model::boneTransforms,0);
 auto& bone=BoneManager::Get();Vector3 v{};assert(!bone.GetBonePositions(ent,0,v,false));int initial=calls;assert(initial==3);
 for(int i=0;i<10;i++)assert(!bone.GetBonePositions(ent,0,v,false));assert(calls-initial==20);
 std::this_thread::sleep_for(std::chrono::milliseconds(115));int before=calls;assert(!bone.GetBonePositions(ent,0,v,false));assert(calls-before==3);
 puts("PASS bone cache: bad skeleton backoff and retry");}
