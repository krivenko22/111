#include "source/Unity/retry_ref_cache.h"
#include <cassert>
#include <cstdio>
int main(){RetryRefCache c{};assert(c.ShouldTry(1));c.Record(1,false);assert(!c.CanUse(5));assert(!c.ShouldTry(25));assert(c.ShouldTry(26));c.Record(26,true);assert(c.CanUse(275));assert(c.ShouldTry(276));c.Record(276,false);assert(c.CanUse(277));assert(!c.ShouldTry(300));assert(c.ShouldTry(301));c.Record(301,false);assert(c.CanUse(425));assert(!c.CanUse(426));c.Record(450,true);assert(c.CanUse(700));puts("PASS camera reference retry: successful cadence, rapid retries, finite failure retention");}
