#include "source/Unity/snap_aim.h"
#include <cassert>
#include <cmath>
#include <cstdio>
int main(){using namespace SnapAim;
 auto m=Calculate(40,-40,.035f);assert(m.x==40&&m.y==-40);
 m=Calculate(1000,-1000,.15f);assert(m.x==64&&m.y==-64);
 m=Calculate(1,-1,.035f);assert(!m.x&&!m.y);
 m=Calculate(NAN,1,.035f);assert(!m.x&&!m.y);
 Gate g;assert(g.Ready(0,0,1,100000));g.Sent(0,0,1,100000);
 assert(!g.Ready(.1f,0,1,101000));assert(!g.Ready(0,0,1,102000));
 assert(g.Ready(.1f,0,1,102000));assert(g.Ready(0,0,1,120000));
 g.Reset();assert(g.Ready(0,0,1,100001));assert(!g.Ready(NAN,0,1,100001));
 puts("PASS snap: immediate both axes, calibration gain, bounds, duplicate guard and retry");
}
