#include <windows.h>
#include <cstdint>
#include <map>
#include <cstring>
#include <cassert>
#include <cstdio>
#include "source/Unity/decryptors.h"
static std::map<uint64_t, unsigned char> bytes;
template<typename T> void put(uint64_t address, T value) {auto p=(unsigned char*)&value;for(size_t i=0;i<sizeof(T);++i)bytes[address+i]=p[i];}
kernelmode_proc_handler kernelHandler;
kernelmode_proc_handler::kernelmode_proc_handler():handle(INVALID_HANDLE_VALUE),pid(0){}
kernelmode_proc_handler::~kernelmode_proc_handler(){}
bool kernelmode_proc_handler::read_memory(uint64_t src,uint64_t dst,size_t size){
 if(!dst||!size)return false;
 auto* p=(unsigned char*)(uintptr_t)dst;std::memset(p,0,size);
 for(size_t i=0;i<size;++i){auto it=bytes.find(src+i);if(it==bytes.end()){std::memset(p,0,size);return false;}p[i]=it->second;}return true;
}
int main(){
 // Synthetic fixture values from the user's report: no real memory access.
 const uint64_t w1=0x1D0CF08ECF0ULL, raw1=0x1D2A18DB7D0ULL, realm=0x1D0CF1B9ED0ULL;
 const uint64_t w2=0x1D0CF08ED20ULL, raw2=0x1D2A1E74B28ULL, dict=0x1D0CF192B00ULL;
 put<uint8_t>(w1+0x14,1);put<uint64_t>(w1+0x18,0x399CCCD67A87A0D3ULL);put<uint64_t>(raw1,realm);
 put<uint8_t>(w2+0x14,1);put<uint64_t>(w2+0x18,0x010AA8279664C69BULL);put<uint64_t>(raw2,dict);
 assert(Decryption::client_entities(w1)==realm);assert(Decryption::entity_list(w2)==dict);
 put<uint8_t>(w1+0x14,0);assert(Decryption::client_entities(w1)==0);put<uint8_t>(w1+0x14,1);
 bytes.erase(raw1);assert(Decryption::client_entities(w1)==0);put<uint64_t>(raw1,realm);
 const uint64_t page=0x11000000, tagged=page+0x29, bitmap=0x12000000;
 put<uint8_t>(page+0x20,2);put<uint32_t>(page+0x1c,1);put<uint64_t>(page+0x10,bitmap);
 put<uint32_t>(bitmap,1);put<uint64_t>(page+0x28,realm);
 assert(Decryption::ResolveRealmHandle(tagged)==realm);
 put<uint8_t>(page+0x20,1);assert(Decryption::ResolveRealmHandle(tagged)==0);
 put<uint8_t>(page+0x20,2);put<uint32_t>(bitmap,0);assert(Decryption::ResolveRealmHandle(tagged)==0);
 puts("PASS realm chain: live-report values in synthetic memory, direct/tagged, invalid and failed reads");
}
