#include "source/Unity/sleep_indicator.h"
#include <cassert>
#include <cstdio>
#include <cstring>
#include <map>
#include <cmath>
#include <algorithm>
int main(){
 using namespace SleepIndicator;
 std::map<uint64_t,unsigned char> mem;
 auto put=[&](uint64_t p,const void* src,size_t n){auto*b=(const unsigned char*)src;for(size_t i=0;i<n;++i)mem[p+i]=b[i];};
 auto u64=[&](uint64_t p,uint64_t x){put(p,&x,sizeof x);};auto u32=[&](uint64_t p,uint32_t x){put(p,&x,sizeof x);};
 auto read=[&](uint64_t a,void* out,size_t n){auto*b=(unsigned char*)out;for(size_t i=0;i<n;i++){auto it=mem.find(a+i);if(it==mem.end())return false;b[i]=it->second;}return true;};
 const uint64_t local=0x11000000,state=0x12000000,klass=0x13000000,name=0x14000000;
 u32(local+0x6e0,0x100);u64(local+0x340,state);u64(state,klass);u64(klass+0x10,name);put(name,"ModelState",11);u32(state+0x60,4);
 assert(Calibrate(read,local,0x6e0,0x340,0x60)==klass);
 u32(local+0x6e0,0x110);assert(!Calibrate(read,local,0x6e0,0x340,0x60));u32(local+0x6e0,0x100);
 u32(state+0x60,12);assert(!Calibrate(read,local,0x6e0,0x340,0x60));u32(state+0x60,4);
 put(name,"OtherState",11);assert(!Calibrate(read,local,0x6e0,0x340,0x60));put(name,"ModelState",11);
 mem.erase(state+0x60);assert(!Calibrate(read,local,0x6e0,0x340,0x60));u32(state+0x60,4);
 assert(!Both(0,0)&&!Both(0x10,0)&&!Both(0,0x8)&&Both(0x10,0x8));
 Tracker t;const uintptr_t m=0x31000000;Vector3 p{10,0,20};
 // Isolated model/player bits, unreadable state and stationary awake are not sleep.
 assert(!t.Observe(m,1000,false,true,true,p));
 assert(!t.Observe(m,1100,true,false,true,p));
 assert(!t.Observe(m,1200,true,true,true,p));assert(!t.Observe(m,1400,true,true,true,p));
 assert(t.Observe(m,1700,true,true,true,p)); // >= 500ms, at least three reads
 assert(t.Observe(m,1750,false,false,true,p,true)); // one missed read may not flicker
 assert(!t.Observe(m,1900,false,false,true,p,true)); // grace expires
 assert(!t.Observe(m,2000,true,true,true,p));assert(!t.Observe(m,2250,true,true,true,p));assert(t.Observe(m,2500,true,true,true,p));
 assert(!t.Observe(m,2510,true,false,true,p,true)); // explicit wake is immediate
 assert(!t.Observe(m,2600,true,true,true,p));assert(!t.Observe(m,2850,true,true,true,p));assert(t.Observe(m,3100,true,true,true,p));
 p.x+=.07f;assert(!t.Observe(m,3101,true,true,true,p)); // movement immediately cancels
 assert(!t.Observe(m+0x10000,3700,true,true,true,p)); // recycled entity model
 assert(!t.Observe(m+0x10000,3900,true,true,false,p)); // stale position
 p.x=NAN;assert(!t.Observe(m,4000,true,true,true,p));
 puts("PASS sleep guard: local class/awake validation, both flags, stable samples, grace, movement/wake, bad reads, model change");
}
