#include "source/Unity/player_name_candidate.h"
#include <map>
#include <cassert>
#include <cstdio>
#include <cstring>
static std::map<uint64_t,unsigned char> mem;
kernelmode_proc_handler kernelHandler;
kernelmode_proc_handler::kernelmode_proc_handler():handle(INVALID_HANDLE_VALUE),pid(0){}
kernelmode_proc_handler::~kernelmode_proc_handler(){}
bool kernelmode_proc_handler::read_memory(uint64_t,uint64_t,size_t){return false;}
template<class T>void put(uint64_t a,T v){auto p=(unsigned char*)&v;for(size_t i=0;i<sizeof v;++i)mem[a+i]=p[i];}
void bytes(uint64_t a,const void*p,size_t n){for(size_t i=0;i<n;++i)mem[a+i]=((const unsigned char*)p)[i];}
bool read(uint64_t a,void*p,size_t n){for(size_t i=0;i<n;i++){if(!mem.count(a+i))return false;((unsigned char*)p)[i]=mem[a+i];}return true;}
int main(){uint64_t ent=0x20000000,str=0x30000000,klass=0x40000000,cname=0x41000000,ns=0x42000000;
 put(ent+0x518,str);put(str,klass);put(klass+0x10,cname);put(klass+0x18,ns);bytes(cname,"String",7);bytes(ns,"System",7);put<int32_t>(str+0x10,4);const wchar_t value[]=L"Test";bytes(str+0x14,value,8);
 std::string s;assert(PlayerNameCandidate::Read(read,ent,1,s)&&s=="Test");assert(!PlayerNameCandidate::Read(read,ent,2,s));
 const wchar_t ru[]=L"Привет";put<int32_t>(str+0x10,6);bytes(str+0x14,ru,12);assert(PlayerNameCandidate::Read(read,ent,1,s)&&s=="\xD0\x9F\xD1\x80\xD0\xB8\xD0\xB2\xD0\xB5\xD1\x82");
 put<int32_t>(str+0x10,33);assert(!PlayerNameCandidate::Read(read,ent,1,s));put<int32_t>(str+0x10,4);bytes(ns,"Bogus!",7);assert(!PlayerNameCandidate::Read(read,ent,1,s));
 puts("PASS names: candidate, String class validation, bounds and read failure");}
