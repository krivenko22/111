#include "source/Unity/srcoaw_visuals.h"
#include <cassert>
#include <cmath>
#include <cstdio>
int main(){
 ImGui::CreateContext();ImGuiIO& io=ImGui::GetIO();io.DisplaySize={1920,1080};io.DeltaTime=1.f/60;unsigned char* pixels;int w,h;io.Fonts->GetTexDataAsRGBA32(&pixels,&w,&h);ImGui::NewFrame();
 ImDrawList* d=ImGui::GetBackgroundDrawList();d->Flags=ImDrawListFlags_None;
 int before=d->VtxBuffer.Size;SrcoawVisuals::Fill(d,{10,20},{110,220},IM_COL32(1,2,3,255),IM_COL32(4,5,6,255));assert(d->VtxBuffer.Size==before+4);
 assert(d->VtxBuffer[before].col==IM_COL32(1,2,3,255));assert(d->VtxBuffer[before+2].col==IM_COL32(4,5,6,255));
 before=d->VtxBuffer.Size;SrcoawVisuals::GradientBorder(d,{10,20},{110,220},IM_COL32_WHITE,IM_COL32_BLACK,1);assert(d->VtxBuffer.Size==before+16);
 before=d->VtxBuffer.Size;SrcoawVisuals::SnapLine(d,{10,20},{110,220},1920,1080,0,IM_COL32_WHITE);assert(d->VtxBuffer.Size>before);
 before=d->VtxBuffer.Size;SrcoawVisuals::HeadCircle(d,{10,20},{10,30},IM_COL32_WHITE);assert(d->VtxBuffer.Size>before);
 before=d->VtxBuffer.Size;SrcoawVisuals::Fill(d,{NAN,20},{110,220},IM_COL32_WHITE,IM_COL32_BLACK);SrcoawVisuals::GradientBorder(d,{10,20},{11,21},IM_COL32_WHITE,IM_COL32_BLACK,1);SrcoawVisuals::HeadCircle(d,{10,20},{10,20},IM_COL32_WHITE);assert(d->VtxBuffer.Size==before);
 ImGui::EndFrame();ImGui::DestroyContext();puts("PASS srcoaw visual primitives: gradient fill/border, snapline, head circle and invalid geometry");
}
