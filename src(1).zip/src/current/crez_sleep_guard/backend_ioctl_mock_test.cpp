#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>
#include <atomic>
#include <thread>
#include "Driver/Driver.h"
#include "Driver/WmipProtocol.h"
static std::atomic<int> calls{0},missing{0},wrong_version{0},fail_read{0},short_read{0},fail_write{0},read_calls{0},write_calls{0};
static void xor4(void* b,size_t n){auto*p=(unsigned char*)b;const unsigned char key[4]={0x5a,0xc3,0x7e,0xa1};for(size_t i=0;i<n;i++)p[i]^=key[i&3];}
static HANDLE WINAPI FakeCreate(LPCWSTR path,DWORD,DWORD,LPSECURITY_ATTRIBUTES,DWORD,DWORD,HANDLE){
 if(wcscmp(path,L"\\\\.\\WmipRpc")!=0){SetLastError(ERROR_INVALID_NAME);return INVALID_HANDLE_VALUE;}
 if(missing){SetLastError(ERROR_FILE_NOT_FOUND);return INVALID_HANDLE_VALUE;}return (HANDLE)0x1234;
}
static BOOL WINAPI FakeClose(HANDLE){return TRUE;}
static BOOL WINAPI FakeIoctl(HANDLE,DWORD code,LPVOID in,DWORD inlen,LPVOID out,DWORD outlen,LPDWORD got,LPOVERLAPPED){
 calls++;*got=0;
 if(code==0x220000){if(in||inlen||!out||outlen!=sizeof(WmipHeartbeat))return FALSE;WmipHeartbeat h{wrong_version?0xDEADu:0x20001u,2636,1,0};std::memcpy(out,&h,sizeof(h));*got=sizeof(h);return TRUE;}
 if(code==0x220010){
   if(inlen!=sizeof(WmipMemory)||!out)return FALSE;WmipMemory q;std::memcpy(&q,in,sizeof(q));xor4(&q,sizeof(q));
   if(q.pid!=1234||q.size+sizeof(q)!=outlen)return FALSE;
   read_calls++;
   if(fail_read){std::memset(out,0x7f,outlen);SetLastError(ERROR_PARTIAL_COPY);return FALSE;}
   std::memcpy(out,&q,sizeof(q));std::memcpy((BYTE*)out+sizeof(q),(void*)(uintptr_t)q.address,q.size);xor4(out,outlen);*got=short_read?outlen-1:outlen;return TRUE;
 }
 if(code==0x220014){
   if(!in||inlen<sizeof(WmipMemory)||out||outlen)return FALSE;
   if(fail_write){SetLastError(ERROR_ACCESS_DENIED);return FALSE;}
   std::vector<BYTE> req((BYTE*)in,(BYTE*)in+inlen);xor4(req.data(),req.size());WmipMemory q;std::memcpy(&q,req.data(),sizeof(q));
   if(q.pid!=1234||q.size+sizeof(q)!=inlen)return FALSE;
   std::memcpy((void*)(uintptr_t)q.address,req.data()+sizeof(q),q.size);write_calls++;return TRUE;
 }
 if(code==0x220020 && inlen==sizeof(WmipModule)&&out==in&&outlen==inlen){auto* q=(WmipModule*)in;if(q->pid!=1234||wcscmp(q->name,L"GameAssembly.dll"))return FALSE;q->base=0x76540000;q->image_size=0x100000;*got=outlen;return TRUE;}
 if(code==0x220028 && inlen==sizeof(WmipAlloc)&&out==in&&outlen==inlen){auto* q=(WmipAlloc*)in;if(q->pid!=1234||q->size!=16)return FALSE;q->address=0x44440000;*got=outlen;return TRUE;}
 if(code==0x220030 && inlen==sizeof(WmipProtect)&&out==in&&outlen==inlen){auto* q=(WmipProtect*)in;if(q->pid!=1234||q->size!=8)return FALSE;q->old_protect=PAGE_READONLY;*got=outlen;return TRUE;}
 return FALSE;
}
uint32_t get_process_pid(const char*){return 1234;}
#define CreateFileW FakeCreate
#define CloseHandle FakeClose
#define DeviceIoControl FakeIoctl
#include "Driver/Driver.cpp"
int main(){
 DWORD e=0;missing=1;if(ProbeWmipDevice(&e)||e!=ERROR_FILE_NOT_FOUND)return 1;
 {kernelmode_proc_handler absent;if(absent.attach("fixture.exe")||absent.is_attached())return 2;}missing=0;
 wrong_version=1;if(ProbeWmipDevice(&e)||e!=ERROR_REVISION_MISMATCH)return 3;
 {kernelmode_proc_handler wrong;if(wrong.attach("fixture.exe")||wrong.is_attached())return 4;}wrong_version=0;
 if(!ProbeWmipDevice(&e)||e!=0||!kernelHandler.attach("fixture.exe"))return 5;
 uint64_t marker=0x12345678,output=0;
 if(!kernelHandler.read_memory((uint64_t)&marker,(uint64_t)&output,8)||output!=marker||read_calls!=1)return 6;
 fail_read=1;output=0xdead;if(kernelHandler.read_memory((uint64_t)&marker,(uint64_t)&output,8)||output!=0)return 7;fail_read=0;
 short_read=1;output=0xdead;if(kernelHandler.read_memory((uint64_t)&marker,(uint64_t)&output,8)||output!=0)return 8;short_read=0;
 std::atomic<bool> threadOk{true};std::vector<std::thread> workers;
 for(int t=0;t<4;t++)workers.emplace_back([t,&threadOk](){
  uint64_t src=0x123456780000ull+uint64_t(t),dst=0;
  for(int i=0;i<1000;i++){dst=0;if(!kernelHandler.read_memory((uint64_t)&src,(uint64_t)&dst,sizeof(src))||dst!=src){threadOk=false;break;}}
 });
 for(auto& th:workers)th.join();if(!threadOk)return 16;
 if(kernelHandler.get_module_base("GameAssembly.dll")!=0x76540000)return 9;
 uint64_t val=0x987654321;int before=calls;if(!kernelHandler.write_memory((uint64_t)&marker,(uint64_t)&val,8))return 14;
 if(marker!=val||write_calls!=1||calls!=before+1)return 10;
 before=calls;if(kernelHandler.write_memory((uint64_t)&marker,(uint64_t)&val,0)||calls!=before)return 11;
 fail_write=1;if(kernelHandler.write_memory((uint64_t)&marker,(uint64_t)&val,8))return 15;fail_write=0;
 if(kernelHandler.virtual_alloc(16,MEM_COMMIT,PAGE_READWRITE,0)!=0x44440000)return 12;
 if(kernelHandler.virtual_protect((uint64_t)&marker,8,PAGE_READWRITE)!=PAGE_READONLY)return 13;
 puts("PASS WmipRpc: protocol, failures, concurrent reads with thread-local buffers, module, alloc/protect");return 0;
}
