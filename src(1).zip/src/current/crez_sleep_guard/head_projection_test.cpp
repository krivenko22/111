#include "source/Unity/head_projection.h"
#include <cassert>
#include <cstdio>
#include <limits>
struct P {float x,y,w;};
static P project(const Matrix4x4& m, Vector3 p) {
 return {p.x*m.m[0][0]+p.y*m.m[1][0]+p.z*m.m[2][0]+m.m[3][0],
         p.x*m.m[0][1]+p.y*m.m[1][1]+p.z*m.m[2][1]+m.m[3][1],
         p.x*m.m[0][3]+p.y*m.m[1][3]+p.z*m.m[2][3]+m.m[3][3]};
}
static bool near(float a,float b){return std::abs(a-b)<0.0001f;}
int main(){
 Matrix4x4 m{};
 assert(HeadProjection::Build({10,20,30},{0,0,0},16.f/9,90,m));
 auto f=project(m,{10,20,40});assert(near(f.x,0)&&near(f.y,0)&&near(f.w,10));
 assert(project(m,{11,20,40}).x>0);assert(project(m,{10,21,40}).y>0);assert(project(m,{10,20,20}).w<0);
 assert(HeadProjection::Build({10,20,30},{0,90,0},16.f/9,90,m));f=project(m,{20,20,30});assert(near(f.x,0)&&near(f.y,0)&&near(f.w,10));
 assert(HeadProjection::Build({10,20,30},{-45,0,0},1,90,m));f=project(m,{10,21,31});assert(near(f.x,0)&&near(f.y,0)&&f.w>0);
 assert(HeadProjection::Build({0,0,0},{0,0,0},1,25,m));
 auto scoped=project(m,{1,0,10});
 assert(HeadProjection::Build({0,0,0},{0,0,0},1,75,m));
 auto regular=project(m,{1,0,10}); assert(scoped.x>regular.x);
 assert(!HeadProjection::Build({0,0,0},{0,0,0},1,9,m));
 assert(!HeadProjection::Build({0,0,0},{100,0,0},1,90,m));
 assert(!HeadProjection::Build({0,0,0},{0,0,0},0,90,m));
 assert(!HeadProjection::Build({0,0,0},{0,0,0},1,180,m));
 assert(!HeadProjection::Build({0,0,0},{0,std::numeric_limits<float>::quiet_NaN(),0},1,90,m));
 puts("PASS head projection math: translated, yaw, pitch, behind, invalid inputs");
}
