#include "source/Unity/last_config.h"
#include <cassert>
#include <cstdio>
#include <cmath>
#include <string>
int main(){
 wchar_t base[MAX_PATH]{};assert(GetTempPathW(MAX_PATH,base));std::wstring root=std::wstring(base)+L"crez_cfg_test_"+std::to_wstring(GetCurrentProcessId());assert(CreateDirectoryW(root.c_str(),nullptr));assert(SetEnvironmentVariableW(L"LOCALAPPDATA",root.c_str()));
 int mode=1,key=2;bool enabled=false;float radius=120;{LastConfig c;c.Int("mode",mode,0,3);c.Int("key",key,0,255);c.Bool("enabled",enabled);c.Float("radius",radius,20,400);assert(c.Init());mode=2;key=81;enabled=true;radius=190;assert(c.Tick(true));}
 mode=0;key=0;enabled=false;radius=20;{LastConfig c;c.Int("mode",mode,0,3);c.Int("key",key,0,255);c.Bool("enabled",enabled);c.Float("radius",radius,20,400);assert(c.Init());assert(mode==2&&key==81&&enabled&&radius==190);}
 std::wstring path=root+L"\\Crez\\last.cfg";HANDLE f=CreateFileW(path.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,0,nullptr);assert(f!=INVALID_HANDLE_VALUE);DWORD n;assert(WriteFile(f,"bad",3,&n,nullptr));CloseHandle(f);
 {LastConfig c;c.Int("mode",mode,0,3);assert(!c.Init());mode=3;assert(!c.Tick(true));}
 f=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);char buf[4]{};assert(f!=INVALID_HANDLE_VALUE&&ReadFile(f,buf,3,&n,nullptr)&&n==3&&std::string(buf)=="bad");CloseHandle(f);
 DeleteFileW(path.c_str());RemoveDirectoryW((root+L"\\Crez").c_str());RemoveDirectoryW(root.c_str());puts("PASS windows last config: disk round-trip and corrupt file preservation");
}
