#include "source/Unity/srcoaw_aim_core.h"
#include <cassert>
#include <cmath>
#include <cstdio>
int main(){using namespace SrcoawAimCore;
 assert(TargetFov(120,20,true)==120);assert(TargetFov(120,40,true)==60);assert(TargetFov(120,5000,true)==1);assert(TargetFov(120,100,false)==120);
 assert(EffectiveSmoothing(10,0,100)==10);assert(EffectiveSmoothing(10,50,100)==30);assert(EffectiveSmoothing(10,100,100)==50);
 Choice c;Consider(c,{1,970,540,50,1},1920,1080,120,false,0);Consider(c,{2,1020,540,50,0},1920,1080,120,false,0);assert(c.candidate.id==2);
 c={};Consider(c,{1,1000,540,50,0},1920,1080,120,false,0);Consider(c,{2,970,540,50,0},1920,1080,120,false,0);assert(c.candidate.id==2);
 c={};Consider(c,{1,1030,540,40,0},1920,1080,120,true,0);assert(!c.candidate.id);
 c={};Consider(c,{1,1130,540,10,0},1920,1080,120,false,1);Consider(c,{2,970,540,20,0},1920,1080,120,false,1);assert(c.candidate.id==1&&c.locked);
 MoveState a{},b{};int fast=0,slow=0;for(int i=0;i<144;i++)fast+=Step(40,0,.035f,10,120,1.f/144,a).x;for(int i=0;i<60;i++)slow+=Step(40,0,.035f,10,120,1.f/60,b).x;assert(fast>0&&std::abs(fast-slow)<=3);
 auto m=Step(-40,0,.035f,10,120,1.f/60,a);assert(m.x<=0);m=Step(NAN,0,.035f,10,120,.02f,a);assert(!m.x&&!m.y&&a.residualX==0);
 puts("PASS srcoaw selection: priority, screen distance, scaling, edge smoothing, lock extension and bounded input");
}
