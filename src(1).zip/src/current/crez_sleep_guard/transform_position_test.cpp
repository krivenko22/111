#include "source/Unity/transform_position.h"
#include <map>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <cmath>
static std::map<uint64_t,unsigned char> mem;
template<class T> void put(uint64_t a,T value){const auto*p=(unsigned char*)&value;for(size_t i=0;i<sizeof(T);i++)mem[a+i]=p[i];}
static int reads=0;static bool denyBulk=false;
static bool read(uint64_t a,void* dest,size_t n){++reads;if(denyBulk&&(n==12||n==16))return false;auto*p=(unsigned char*)dest;for(size_t i=0;i<n;i++){auto it=mem.find(a+i);if(it==mem.end())return false;p[i]=it->second;}return true;}
static bool near(float a,float b){return std::abs(a-b)<0.0005f;}
int main(){
 using namespace TransformPosition;
 const uint64_t t=0x20000000,native=0x21000000,data=0x22000000,mats=0x23000000,parents=0x24000000;
 put<uint64_t>(t+0x10,native);put<uint64_t>(native+0x28,data);put<int32_t>(native+0x30,0);
 put<uint64_t>(data+0x18,mats);put<uint64_t>(data+0x20,parents);
 Matrix child{1,2,3,0, 0,0,0,1, 1,1,1,0};
 Matrix parent{10,20,30,0, 0,0,0,1, 2,3,4,0};
 put<Matrix>(mats,child);put<Matrix>(mats+48,parent);put<int32_t>(parents,1);put<int32_t>(parents+4,-1);
 Vector3 p{};reads=0;assert(WorldPosition(read,t,p));assert(reads==7);assert(near(p.x,12)&&near(p.y,26)&&near(p.z,42));
 denyBulk=true;reads=0;assert(WorldPosition(read,t,p));assert(reads==11&&near(p.x,12)&&near(p.y,26)&&near(p.z,42));denyBulk=false;
 const float s=std::sqrt(0.5f);parent.qy=s;parent.qw=s;parent.sx=parent.sy=parent.sz=1;put<Matrix>(mats+48,parent);
 assert(WorldPosition(read,t,p));assert(near(p.x,13)&&near(p.y,22)&&near(p.z,29));
 put<int32_t>(parents+4,0);assert(!WorldPosition(read,t,p)); // cycle
 put<int32_t>(parents+4,-1);put<int32_t>(native+0x30,4096);assert(!WorldPosition(read,t,p));
 put<int32_t>(native+0x30,0);parent.qw=0;parent.qy=0;put<Matrix>(mats+48,parent);assert(!WorldPosition(read,t,p));
 parent.qw=1;parent.px=100000;put<Matrix>(mats+48,parent);assert(!WorldPosition(read,t,p));
 puts("PASS transform traversal: translation, scale, rotation, cycles, bounds and invalid quaternion");
}
