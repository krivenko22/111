#include <windows.h>
#include <cstdint>
#include <cstdio>
#include "Driver/Driver.h"
int main(){
 // This test must run where the WmipRpc device is absent. It checks that the
 // driver-only build refuses to attach rather than using OpenProcess.
 HANDLE h=CreateFileA("\\\\.\\WmipRpc",GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_EXISTING,0,nullptr);
 if(h!=INVALID_HANDLE_VALUE){CloseHandle(h);puts("SKIP: WmipRpc exists; test requires no driver");return 2;}
 if(kernelHandler.attach("backend_self_test.exe") || kernelHandler.is_attached()) {puts("FAIL: attached without driver");return 1;}
 uint64_t marker=123, output=999;
 if(kernelHandler.read_memory((uint64_t)&marker,(uint64_t)&output,8) || output!=0){puts("FAIL: read without driver");return 3;}
 uint64_t newValue=1; kernelHandler.write_memory((uint64_t)&marker,(uint64_t)&newValue,8);
 if(marker!=123 || kernelHandler.virtual_alloc(4096,MEM_COMMIT,PAGE_READWRITE,0)!=0 || kernelHandler.virtual_protect((uint64_t)&marker,8,PAGE_READWRITE)!=0){puts("FAIL: gate");return 4;}
 puts("PASS missing device refuses attach; no fallback or requests without device");return 0;
}
